"""Independent final B execution; no source commits or mutation in this stage."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
import types

ROOT = Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code\campaign24-final-b')
OUT = ROOT.parent/'final-b-receipts'
HEAD = 'd0ccef65bcbe0c90483e6c0f691ed95f92228c6c'
TREE = '22f91455d651a81296ab8724f9db7cfead65af08'
MANIFEST = 'ce4a2e34d070a1916d1957ff1cd6c6267fc54879d5e7a0485693eac034e8be9d'
VERIFIER = '724292f70da0d11e6d87c4e5b19f9f0a53aafe856e9f16e20966eff6107103d4'
CHECKPOINT = ROOT/'docs/brain/checkpoints/M1-03/SECURITY-DEPENDENCY-DB24'
SCRIPT = CHECKPOINT/'verify24.py'
ENV = {k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_', 'GITHUB_', 'NPM_', 'PHASE4_'))
    and k not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    for path in (SCRIPT, CHECKPOINT/'manifest.json'):
        for parent in path.parents:
            info = parent.lstat()
            assert stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info,'st_file_attributes',0)&1024
    raw = SCRIPT.read_bytes()
    assert sha(raw) == VERIFIER
    assert sha((CHECKPOINT/'manifest.json').read_bytes()) == MANIFEST
    module = types.ModuleType('authenticated_final_b_verifier')
    module.__file__ = str(SCRIPT)
    exec(compile(raw,str(SCRIPT),'exec'),module.__dict__)
    records = []
    def command(name, argv, expected=0, verify_json=False):
        started = time.monotonic()
        code, output, error = module.bounded(argv, ROOT, ENV, 8*1024*1024, 900)
        (OUT/(name+'.stdout.txt')).write_bytes(output)
        (OUT/(name+'.stderr.txt')).write_bytes(error)
        record = dict(name=name,argv=argv,cwd=str(ROOT),exit=code,expectedExit=expected,
            seconds=round(time.monotonic()-started,3),stdoutBytes=len(output),stderrBytes=len(error),
            stdoutSHA256=sha(output),stderrSHA256=sha(error),head=HEAD,tree=TREE)
        if verify_json:
            record['result'] = json.loads(output)
        records.append(record)
        (OUT/(name+'.receipt.json')).write_bytes((json.dumps(record,indent=2)+'\n').encode())
        print(json.dumps(record),flush=True)
        assert code == expected, name+'_UNEXPECTED_EXIT'
        if verify_json:
            assert record['result']['status']=='VERIFIED' and record['result']['release']=='NO_GO'
            assert record['result']['acceptanceGranted'] is False
        return record
    base = [sys.executable,'-B',str(SCRIPT),'--root',str(CHECKPOINT),
        '--expected-manifest-sha256',MANIFEST,'--expected-verifier-sha256',VERIFIER]
    command('artifact-integrity',base,verify_json=True)
    full = base+['--git-root',str(ROOT),'--expected-head',HEAD,'--expected-tree',TREE]
    command('git-before-install',full,verify_json=True)
    node = shutil.which('node')
    # The standard Windows shim honors the installed global npm ahead of the
    # older bundled CLI beside node.exe. Resolve that normal dispatch first.
    npm_shim = shutil.which('npm.cmd')
    global_root = subprocess.run([npm_shim,'root','-g'],cwd=ROOT,env=ENV,
        capture_output=True,timeout=30)
    assert global_root.returncode==0
    npm = Path(global_root.stdout.decode().strip())/'npm/bin/npm-cli.js'
    assert node and npm.is_file()
    version = subprocess.run([node,str(npm),'--version'],cwd=ROOT,env=ENV,capture_output=True,timeout=30)
    assert version.returncode==0 and version.stdout.strip()==b'11.20.0'
    cache = ROOT.parent/'final-b-npm-cache'
    assert not os.path.lexists(cache), 'FINAL_B_NPM_CACHE_NOT_FRESH'
    assert not os.path.lexists(ROOT/'node_modules'), 'FINAL_B_INSTALL_ALREADY_EXISTS'
    command('npm-ci',[node,str(npm),'ci','--no-fund','--cache',str(cache)])
    command('mandatory-postinstall-check',[node,'scripts/postinstall.mjs','--check'])
    proof = command('full-git-and-source',full+['--execute-source-checks'],verify_json=True)
    assert proof['result']['sourceChecks']['release24']=='PASS_FINITE_SOURCE_GOVERNANCE_ONLY'
    assert proof['result']['sourceChecks']['phase4']=='PASS_UNCHANGED_PRODUCER_STRICT_CHECK'
    status = subprocess.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=ROOT,env=ENV,capture_output=True,timeout=60)
    assert status.returncode==0 and not status.stdout
    summary = dict(schema=1,qualification='INDEPENDENT_COMPLETE_STANDALONE_FINAL_HEAD_CHECKOUT_B_PROOF_NOT_ACCEPTANCE',
        head=HEAD,tree=TREE,manifestSHA256=MANIFEST,verifierSHA256=VERIFIER,
        npmVersion='11.20.0',npmCliSHA256=sha(npm.read_bytes()),freshNormalInstall=True,
        mandatoryPostinstall='EXECUTED_AND_CHECKED',commands=records,trackedAndUntrackedStatusClean=True,
        protectedWorkflowMutation='NOT_RUN_WAITING_ROOT_A_RESULT',acceptanceGranted=False,release='NO_GO')
    (OUT/'verification-summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
    print(json.dumps(dict(status='B_FULL_VERIFIED_MUTATION_PENDING',head=HEAD,tree=TREE,
        summarySHA256=sha((OUT/'verification-summary.json').read_bytes()),release='NO_GO')),flush=True)


if __name__=='__main__':
    main()
