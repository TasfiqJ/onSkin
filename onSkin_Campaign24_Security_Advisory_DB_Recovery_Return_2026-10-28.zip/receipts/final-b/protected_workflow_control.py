"""Authorized independent B control after root confirmed A was not refused."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import types

ROOT = Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code\campaign24-final-b')
OUT = ROOT.parent/'final-b-receipts'
HEAD = 'd0ccef65bcbe0c90483e6c0f691ed95f92228c6c'
TREE = '22f91455d651a81296ab8724f9db7cfead65af08'
MANIFEST = 'ce4a2e34d070a1916d1957ff1cd6c6267fc54879d5e7a0485693eac034e8be9d'
VERIFIER = '724292f70da0d11e6d87c4e5b19f9f0a53aafe856e9f16e20966eff6107103d4'
CHECKPOINT = ROOT/'docs/brain/checkpoints/M1-03/SECURITY-DEPENDENCY-DB24'
SCRIPT = CHECKPOINT/'verify24.py'
ENV = {k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_', 'GITHUB_', 'NPM_', 'PHASE4_'))
    and k not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def metadata(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not stat.S_ISLNK(value.st_mode)
    assert value.st_nlink == 1 and not getattr(value,'st_file_attributes',0)&1024
    return dict(device=value.st_dev,inode=value.st_ino,mode=value.st_mode,mtimeNS=value.st_mtime_ns,
        size=value.st_size,attributes=getattr(value,'st_file_attributes',0))


def git(*args):
    value = subprocess.run(['git','--no-replace-objects',*args],cwd=ROOT,env=ENV,capture_output=True,timeout=120)
    assert value.returncode == 0
    return value.stdout


def main():
    baseline_path = OUT/'full-git-and-source.receipt.json'
    baseline = json.loads(baseline_path.read_bytes())
    assert baseline['exit']==0 and baseline['result']['status']=='VERIFIED'
    assert baseline['head']==HEAD and baseline['tree']==TREE
    assert git('rev-parse','HEAD').decode().strip()==HEAD and git('rev-parse','HEAD^{tree}').decode().strip()==TREE
    assert not git('status','--porcelain=v1','--untracked-files=all')
    raw = SCRIPT.read_bytes();assert sha(raw)==VERIFIER
    module = types.ModuleType('authenticated_b_protected_control_verifier')
    module.__file__=str(SCRIPT);exec(compile(raw,str(SCRIPT),'exec'),module.__dict__)
    workflow = ROOT/'.github/workflows/security.yml'
    backup = OUT/'protected-workflow-original-inode-backup.yml'
    assert workflow.drive.casefold()==backup.drive.casefold()
    assert workflow.parent.stat().st_dev==OUT.stat().st_dev
    assert not os.path.lexists(backup)
    for parent in workflow.parents:
        value=parent.lstat()
        assert stat.S_ISDIR(value.st_mode) and not stat.S_ISLNK(value.st_mode) and not getattr(value,'st_file_attributes',0)&1024
    before = workflow.read_bytes();identity = metadata(workflow)
    original_blob=git('rev-parse','HEAD:.github/workflows/security.yml').decode().strip()
    assert hashlib.sha1(('blob '+str(len(before))+'\0').encode()+before).hexdigest()==original_blob
    index_before=git('ls-files','--stage','-z')
    command=baseline['argv']
    def verify(name):
        start=time.monotonic();code,output,error=module.bounded(command,ROOT,ENV,8*1024*1024,900)
        (OUT/(name+'.stdout.txt')).write_bytes(output);(OUT/(name+'.stderr.txt')).write_bytes(error)
        row=dict(name=name,argv=command,cwd=str(ROOT),exit=code,seconds=round(time.monotonic()-start,3),
            stdoutSHA256=sha(output),stderrSHA256=sha(error),result=json.loads(output),head=HEAD,tree=TREE)
        (OUT/(name+'.receipt.json')).write_bytes((json.dumps(row,indent=2)+'\n').encode())
        print(json.dumps(row),flush=True)
        return row
    created = None
    moved = False
    try:
        os.rename(workflow,backup);moved=True
        assert metadata(backup)==identity and backup.read_bytes()==before
        descriptor=os.open(workflow,os.O_WRONLY|os.O_CREAT|os.O_EXCL,stat.S_IMODE(identity['mode']))
        try:
            created=os.fstat(descriptor)
            body=before+b'\n# Campaign24 public synthetic protected-byte control only\n'
            with os.fdopen(descriptor,'wb',closefd=False) as stream:stream.write(body);stream.flush();os.fsync(descriptor)
        finally:os.close(descriptor)
        assert workflow.read_bytes()!=before and metadata(backup)==identity
        tampered=verify('protected-tampered')
        assert tampered['exit']==1 and tampered['result']['status']=='CONTEXT_INVALID'
        assert tampered['result']['error']=='GIT_CHECKOUT_DIRTY'
    finally:
        if moved:
            if os.path.lexists(workflow):
                current=workflow.lstat()
                assert created is not None and current.st_dev==created.st_dev and current.st_ino==created.st_ino
                assert stat.S_ISREG(current.st_mode) and not stat.S_ISLNK(current.st_mode)
                workflow.unlink()
            os.rename(backup,workflow)
        assert not os.path.lexists(backup)
        assert workflow.read_bytes()==before and metadata(workflow)==identity
        assert git('ls-files','--stage','-z')==index_before
        assert not git('status','--porcelain=v1','--untracked-files=all')
        restore=dict(qualification='ACTUAL_ORIGINAL_INODE_RENAME_RESTORATION_BEFORE_REVERIFY',
            path='.github/workflows/security.yml',originalSHA256=sha(before),restoredSHA256=sha(workflow.read_bytes()),
            originalMetadata=identity,restoredMetadata=metadata(workflow),originalBlob=original_blob,
            indexUnchanged=True,workingStatusClean=True,head=HEAD,tree=TREE,acceptanceGranted=False,release='NO_GO')
        (OUT/'protected-exact-restoration.json').write_bytes((json.dumps(restore,indent=2)+'\n').encode())
        print(json.dumps(dict(status='ORIGINAL_INODE_AND_BYTES_EXACTLY_RESTORED',head=HEAD,tree=TREE)),flush=True)
    restored=verify('protected-restored-full')
    assert restored['exit']==0 and restored['result']['status']=='VERIFIED'
    assert restored['result']['sourceChecks']['release24']=='PASS_FINITE_SOURCE_GOVERNANCE_ONLY'
    assert restored['result']['sourceChecks']['phase4']=='PASS_UNCHANGED_PRODUCER_STRICT_CHECK'
    assert workflow.read_bytes()==before and metadata(workflow)==identity
    assert git('ls-files','--stage','-z')==index_before and not git('status','--porcelain=v1','--untracked-files=all')
    result=dict(schema=1,qualification='ACTUAL_COMPLETE_FINAL_CHECKOUT_PROTECTED_WORKFLOW_CONTROL_NOT_ACCEPTANCE',
        head=HEAD,tree=TREE,path='.github/workflows/security.yml',exits=[baseline['exit'],tampered['exit'],restored['exit']],
        baselineReceipt=baseline_path.name,baselineReceiptSHA256=sha(baseline_path.read_bytes()),
        tamperedReceipt='protected-tampered.receipt.json',restoredReceipt='protected-restored-full.receipt.json',
        sameVerifierArgvAllStates=True,fullSourceChecksPerformedForBothPositiveStates=True,
        originalInodeModeMtimeDeviceBytesRestored=True,indexUnchanged=True,workingStatusClean=True,
        automaticApprovalRefusal=False,acceptanceGranted=False,release='NO_GO')
    (OUT/'protected-control-summary.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
    print(json.dumps(result),flush=True)


if __name__=='__main__':
    main()
