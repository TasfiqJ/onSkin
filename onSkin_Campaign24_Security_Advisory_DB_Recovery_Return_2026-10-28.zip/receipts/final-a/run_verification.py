"""Task-owned independent checkout A controls; no acceptance authority."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time

ROOT = Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code\campaign24-final-a')
OUT = ROOT.parent / 'final-a-receipts'
HEAD = 'd0ccef65bcbe0c90483e6c0f691ed95f92228c6c'
TREE = '22f91455d651a81296ab8724f9db7cfead65af08'
MANIFEST = 'ce4a2e34d070a1916d1957ff1cd6c6267fc54879d5e7a0485693eac034e8be9d'
VERIFIER = '724292f70da0d11e6d87c4e5b19f9f0a53aafe856e9f16e20966eff6107103d4'
CHECKPOINT = ROOT / 'docs/brain/checkpoints/M1-03/SECURITY-DEPENDENCY-DB24'
EXTERNAL = ROOT.parent / 'campaign24-evidence/verify24.py'
JOURNAL = []


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def run(label, argv, timeout=900):
    start = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=timeout, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    assert len(result.stdout) <= 16 * 1024 * 1024 and len(result.stderr) <= 4 * 1024 * 1024
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    entry = dict(label=label, cwd=str(ROOT), argv=list(map(str, argv)), exit=result.returncode,
                 elapsedSeconds=round(time.monotonic() - start, 3),
                 stdoutBytes=len(result.stdout), stdoutSHA256=digest(result.stdout),
                 stderrBytes=len(result.stderr), stderrSHA256=digest(result.stderr))
    JOURNAL.append(entry)
    (OUT / 'commands.json').write_text(json.dumps(JOURNAL, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(label=label, exit=result.returncode, stdoutBytes=len(result.stdout), stderrBytes=len(result.stderr))), flush=True)
    return result


def command_text(label, args):
    result = run(label, ['git', *args])
    assert result.returncode == 0 and not result.stderr
    return result.stdout.decode('utf-8').strip()


def file_identity(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    assert not getattr(info, 'st_file_attributes', 0) & 1024
    raw = path.read_bytes()
    return dict(device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
                mtimeNs=info.st_mtime_ns, bytes=len(raw), sha256=digest(raw))


def object_proof(label):
    assert (ROOT / '.git').is_dir() and not (ROOT / '.git').is_symlink()
    assert command_text(label + '-shallow', ['rev-parse', '--is-shallow-repository']) == 'false'
    for name in ['.git/objects/info/alternates', '.git/objects/info/http-alternates', '.git/shallow']:
        assert not (ROOT / name).exists()
    result = run(label + '-partial', ['git', 'config', '--get', 'extensions.partialClone'])
    assert result.returncode == 1 and not result.stdout and not result.stderr
    objects = ROOT / '.git/objects'
    records = []
    for parent, directories, files in os.walk(objects, followlinks=False):
        for name in directories + files:
            path = Path(parent) / name
            info = path.lstat()
            assert not stat.S_ISLNK(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024
            if name in files:
                assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                records.append(dict(path=path.relative_to(objects).as_posix(), device=info.st_dev,
                                    inode=info.st_ino, links=info.st_nlink, bytes=info.st_size))
    assert records
    value = dict(qualification='INDEPENDENT_COMPLETE_REMOTE_GIT_STORE_ONLY',
                 gitDirectory=str(ROOT / '.git'), objectDirectory=str(objects),
                 shallow=False, partial=False, alternates=False,
                 objectFiles=records, allLinksExactlyOne=True, acceptanceGranted=False)
    (OUT / (label + '-object-proof.json')).write_text(json.dumps(value, indent=2) + '\n')
    return value


def verify(label):
    args = [sys.executable, '-B', str(EXTERNAL), '--root', str(CHECKPOINT),
            '--expected-manifest-sha256', MANIFEST, '--expected-verifier-sha256', VERIFIER,
            '--git-root', str(ROOT), '--expected-head', HEAD, '--expected-tree', TREE,
            '--execute-source-checks']
    result = run(label, args, 1800)
    assert not result.stderr
    value = json.loads(result.stdout)
    return result.returncode, value


def main():
    assert command_text('head', ['rev-parse', 'HEAD']) == HEAD
    assert command_text('tree', ['rev-parse', 'HEAD^{tree}']) == TREE
    assert command_text('autocrlf', ['config', '--get', 'core.autocrlf']) == 'false'
    assert command_text('longpaths', ['config', '--get', 'core.longpaths']) == 'true'
    assert not command_text('clean-before-install', ['status', '--porcelain=v1', '--untracked-files=all'])
    before_objects = object_proof('before')
    for label, argv in [('node-version', ['node', '--version']),
                        ('npm-version', [shutil.which('npm.cmd') or 'npm', '--version']),
                        ('python-version', [sys.executable, '--version']),
                        ('git-version', ['git', '--version'])]:
        result = run(label, argv)
        assert result.returncode == 0
        if label == 'npm-version':
            assert result.stdout.strip() == b'11.20.0'
    assert digest(EXTERNAL.read_bytes()) == VERIFIER
    assert digest((CHECKPOINT / 'verify24.py').read_bytes()) == VERIFIER
    assert digest((CHECKPOINT / 'manifest.json').read_bytes()) == MANIFEST
    installed = run('npm-ci', [shutil.which('npm.cmd') or 'npm', 'ci', '--no-fund'], 1800)
    assert installed.returncode == 0
    assert not command_text('clean-after-install', ['status', '--porcelain=v1', '--untracked-files=all'])
    original_code, original_result = verify('current')
    assert original_code == 0 and original_result['status'] == 'VERIFIED'
    protected = ROOT / '.github/workflows/security.yml'
    original = file_identity(protected)
    original_bytes = protected.read_bytes()
    backup = OUT / 'security-original.same-volume-backup'
    assert not backup.exists() and backup.parent.stat().st_dev == protected.parent.stat().st_dev
    mutation = None
    tampered_result = None
    os.rename(protected, backup)
    try:
        assert file_identity(backup) == original
        with protected.open('xb') as stream:
            stream.write(original_bytes + b'\n# Campaign24 isolated protected-file refusal control\n')
        os.chmod(protected, stat.S_IMODE(original['mode']))
        mutation = file_identity(protected)
        tampered_code, tampered_result = verify('tampered')
        assert tampered_code == 1 and tampered_result['status'] == 'CONTEXT_INVALID'
    finally:
        os.replace(backup, protected)
    restored = file_identity(protected)
    assert restored == original
    restored_code, restored_result = verify('restored')
    assert restored_code == 0 and restored_result['status'] == 'VERIFIED'
    assert not command_text('clean-final', ['status', '--porcelain=v1', '--untracked-files=all'])
    assert command_text('head-final', ['rev-parse', 'HEAD']) == HEAD
    assert command_text('tree-final', ['rev-parse', 'HEAD^{tree}']) == TREE
    after_objects = object_proof('after')
    assert before_objects == after_objects
    result = dict(schema=1, qualification='INDEPENDENT_FULL_CHECKOUT_TECHNICAL_INTEGRITY_ONLY_NOT_ACCEPTANCE',
                  head=HEAD, tree=TREE, manifestSHA256=MANIFEST, verifierSHA256=VERIFIER,
                  current=original_result, tampered=tampered_result, restored=restored_result,
                  exits=[original_code, tampered_code, restored_code], protectedFile='.github/workflows/security.yml',
                  originalIdentity=original, tamperedIdentity=mutation, restoredIdentity=restored,
                  restoration='EXACT_SAME_INODE_DEVICE_MODE_MTIME_BYTES_HASH', cleanBeforeAndAfter=True,
                  completeRemoteGitStore=True, objectFilesAllLinksOne=True, objectStoreUnchanged=True,
                  sourceAcceptance='SUBMITTED_REVIEW_REQUIRED', acceptanceGranted=False, release='NO_GO')
    (OUT / 'final-a-verification.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(state='VERIFIED', exits=result['exits'], head=HEAD, tree=TREE,
                         sourceAcceptance='SUBMITTED_REVIEW_REQUIRED', acceptanceGranted=False, release='NO_GO')), flush=True)


if __name__ == '__main__':
    main()
