"""Construct explicit-inventory Campaign24 artifacts, without self-acceptance."""
import argparse
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import sys
import zipfile

HERE = Path(__file__).resolve().parent
utility_path=HERE/'verify24.py'
utility_node=utility_path.lstat()
assert stat.S_ISREG(utility_node.st_mode) and utility_node.st_nlink==1 and not getattr(utility_node,'st_file_attributes',0)&1024
with utility_path.open('rb') as utility_stream:utility_raw=utility_stream.read(128*1024+1)
assert 0<len(utility_raw)<=128*1024
assert hashlib.sha256(utility_raw).hexdigest()=='724292f70da0d11e6d87c4e5b19f9f0a53aafe856e9f16e20966eff6107103d4'
spec = importlib.util.spec_from_file_location('integrity24', HERE/'verify24.py')
verify = importlib.util.module_from_spec(spec)
exec(compile(utility_raw,str(utility_path),'exec'),verify.__dict__)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)+'\n').encode('utf-8')


def witnesses(files):
    verify.paths(files)
    return {name: dict(bytes=len(raw), sha256=verify.sha(raw)) for name, raw in sorted(files.items())}


def zip_bytes(files):
    verify.paths(files)
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=False) as archive:
        for name, raw in sorted(files.items()):
            item = zipfile.ZipInfo(name, (2026,10,28,0,0,0))
            item.create_system = 3
            item.external_attr = (stat.S_IFREG | 0o644) << 16
            item.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(item, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    raw = output.getvalue()
    check = verify.Archive(raw)
    check.exact(files)
    for name, data in files.items():
        assert check.read(name) == data
    return raw


def selected(mapping):
    assert type(mapping) is dict and mapping
    verify.paths(mapping)
    return {name: verify.read_regular(Path(path)) for name,path in mapping.items()}


def fresh_file(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw)
    assert verify.read_regular(path) == raw


def current(root):
    assert not verify.git(root, 'status', '--porcelain=v1', '--untracked-files=all', '-z')
    return verify.git(root,'rev-parse','HEAD').decode().strip(), verify.git(root,'rev-parse','HEAD^{tree}').decode().strip()


def checkpoint(args, plan):
    root = Path(args.git_root).resolve()
    head, tree = current(root)
    runtime = plan['runtimeHead']
    assert verify.git(root,'rev-list','--parents','-n','1',head).decode().split() == [head,runtime]
    assert set(verify.diff(root,runtime,head)) == verify.WORKLIST
    source = dict(base=verify.BASE,baseTree=verify.BASE_TREE,runtimeHead=runtime,
        runtimeTree=verify.git(root,'rev-parse',runtime+'^{tree}').decode().strip(),sourceHead=head,sourceTree=tree)
    payload_files = selected(plan['payloadFiles'])
    payload = zip_bytes(payload_files)
    files = {'README.md': verify.read_regular(Path(plan['readme'])),
             'FINAL_REPORT.md': verify.read_regular(Path(plan['report'])),
             'verify24.py': verify.read_regular(HERE/'verify24.py'), 'payload.zip': payload}
    manifest = dict(schema=1,authority=verify.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',
        acceptanceGranted=False,release='NO_GO',inputManifestSHA256=verify.INPUT,source=source,
        files=witnesses(files),payload=dict(schema=1,files=witnesses(payload_files),
            qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE'))
    files['manifest.json'] = encoded(manifest)
    destination = root/verify.CHECKPOINT
    assert not destination.exists()
    destination.mkdir(parents=True)
    for name, raw in files.items():
        fresh_file(destination/name,raw)
    verified = verify.checkpoint(verify.Directory(destination),verify.sha(files['manifest.json']))
    result = dict(source=source,checkpointPath=str(destination),
        manifestSHA256=verify.sha(files['manifest.json']),verifierSHA256=verify.sha(files['verify24.py']),
        payloadSHA256=verify.sha(payload),payloadFiles=len(payload_files),
        qualification='ARTIFACT_INTEGRITY_ONLY_NOT_ACCEPTANCE',release='NO_GO',acceptanceGranted=False)
    assert verified['source']==source
    fresh_file(HERE/'checkpoint-build.receipt.json',encoded(result))
    print(json.dumps(result,sort_keys=True))


def returned(args,plan):
    root=Path(args.git_root).resolve()
    head,tree=current(root)
    checkpoint_root=root/verify.CHECKPOINT
    manifest_raw=verify.read_regular(checkpoint_root/'manifest.json')
    inner=verify.checkpoint(verify.Directory(checkpoint_root),verify.sha(manifest_raw))
    source=dict(inner['source'],candidateHead=head,candidateTree=tree)
    destination=Path(plan['stage']).resolve()
    assert not destination.exists()
    destination.mkdir(parents=True)
    bundle=destination/'source.delta.bundle'
    verify.git(root,'bundle','create','--version=2',str(bundle),'HEAD','^'+verify.BASE)
    bundle_raw=verify.read_regular(bundle)
    files=selected(plan['files'])
    assert {'FINAL_REPORT.md'} <= set(files) and not {'manifest.json','source.delta.bundle','verify_return24.py'} & set(files)
    files.update({'source.delta.bundle':bundle_raw,'verify_return24.py':verify.read_regular(HERE/'verify_return24.py')})
    for name in verify.CHECKPOINT_FILES:
        files['checkpoint/'+name]=verify.read_regular(checkpoint_root/name)
    manifest=dict(schema=1,authority=verify.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',
        acceptanceGranted=False,release='NO_GO',inputManifestSHA256=verify.INPUT,
        source=source,files=witnesses(files),qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
        checkpoint=dict(path='checkpoint',manifestSHA256=verify.sha(manifest_raw)),
        gitDelta=dict(path='source.delta.bundle',base=verify.BASE,baseTree=verify.BASE_TREE,head=head,tree=tree))
    files['manifest.json']=encoded(manifest)
    for name,raw in files.items():
        if name=='source.delta.bundle':
            assert verify.read_regular(bundle)==raw
        else:
            fresh_file(destination/name,raw)
    outer_zip=zip_bytes(files)
    output=Path(plan['zip']).resolve()
    fresh_file(output,outer_zip)
    proof=verify.return_packet(verify.Archive(outer_zip),verify.sha(files['manifest.json']),root)
    assert proof['status']=='VERIFIED' and proof['git']['head']==head
    assert current(root)==(head,tree)
    result=dict(zip=str(output),stage=str(destination),zipBytes=len(outer_zip),zipSHA256=verify.sha(outer_zip),
        manifestSHA256=verify.sha(files['manifest.json']),verifierSHA256=verify.sha(files['verify_return24.py']),
        checkpointManifestSHA256=verify.sha(manifest_raw),filesIncludingManifest=len(files),
        expandedBytes=sum(map(len,files.values())),head=head,tree=tree,
        status='SUBMITTED_REVIEW_REQUIRED',release='NO_GO',acceptanceGranted=False,integrityProof=proof)
    fresh_file(HERE/'return-build.receipt.json',encoded(result))
    print(json.dumps(result,sort_keys=True))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['checkpoint','return'])
    parser.add_argument('--git-root',required=True)
    parser.add_argument('--plan',required=True)
    args=parser.parse_args()
    plan=verify.loads(verify.read_regular(Path(args.plan)))
    (checkpoint if args.mode=='checkpoint' else returned)(args,plan)


if __name__=='__main__':
    main()
