"""Enumerate candidate transitions and unchanged protected Git identities."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('integrity24',HERE/'verify24.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=HERE.parent/'campaign24-source'
assert not m.git(root,'status','--porcelain=v1','--untracked-files=all','-z')
head=m.git(root,'rev-parse','HEAD').decode().strip()
tree=m.git(root,'rev-parse','HEAD^{tree}').decode().strip()


def metadata(revision):
    result={}
    for record in m.git(root,'ls-tree','-r','-l','-z',revision).split(b'\0'):
        if not record:continue
        raw,name=record.split(b'\t',1)
        mode,kind,oid,size=raw.decode('ascii').split();name=name.decode('utf-8')
        assert kind=='blob' and mode in ('100644','100755') and name not in result
        result[name]=dict(mode=mode,blob=oid,bytes=int(size))
    m.paths(result)
    return result


before=metadata(m.BASE);after=metadata(head)
assert len(before)==23468
protected={name:entry for name,entry in before.items() if name not in m.EXISTING}
assert all(after.get(name)==entry for name,entry in protected.items())
assert set(after)-set(before)<=m.NEW
assert len([p for p in set(after)-set(before) if not p.startswith(m.CHECKPOINT)])<=40
transitions=[];prior=m.BASE
for line in m.git(root,'rev-list','--reverse','--parents',m.BASE+'..'+head).decode().splitlines():
    values=line.split();assert len(values)==2 and values[1]==prior
    commit=values[0];changes=m.diff(root,prior,commit);rows=[]
    for name,entry in sorted(changes.items()):
        assert name in m.EXISTING|m.NEW
        oldmode,newmode,oldblob,newblob,status=entry
        oldraw=None if status=='A' else m.git(root,'show',prior+':'+name)
        raw=m.git(root,'show',commit+':'+name)
        def identity(data):
            return None if data is None else dict(bytes=len(data),sha256=m.sha(data),
                gitBlob=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest())
        old=identity(oldraw);new=identity(raw)
        assert new['gitBlob']==newblob and (old is None or old['gitBlob']==oldblob)
        rows.append(dict(path=name,status=status,oldMode=oldmode[1:],newMode=newmode,
            oldBlob=oldblob,newBlob=newblob,old=old,new=new))
    transitions.append(dict(parent=prior,commit=commit,
        tree=m.git(root,'rev-parse',commit+'^{tree}').decode().strip(),changes=rows))
    prior=commit
assert prior==head
paths=sorted({r['path'] for t in transitions for r in t['changes']})
result=dict(schema=1,qualification='ALL_COMMITTED_CANDIDATE_TRANSITIONS_NOT_A_PRIVATE_CONTENT_SCAN',
    base=m.BASE,baseTree=m.BASE_TREE,head=head,tree=tree,transitions=transitions,
    distinctChangedPaths=len(paths),paths=paths,release='NO_GO',acceptanceGranted=False)
protected_result=dict(schema=1,qualification='READ_ONLY_GIT_MODE_BLOB_SIZE_IDENTITIES_NOT_PRIVATE_WORKING_CONTENT_AUDIT',
    base=m.BASE,head=head,files=protected,count=len(protected),allUnchanged=True,
    originalSecurityWorkflow=protected['.github/workflows/security.yml'],release='NO_GO',acceptanceGranted=False)
for filename,value in [('source-paths.json',result),('protected-identities.json',protected_result),
    ('source-tree-inventory.json',dict(head=head,tree=tree,files=after,count=len(after),qualification='GIT_METADATA_ONLY'))]:
    (HERE/filename).write_bytes((json.dumps(value,indent=2,sort_keys=True)+'\n').encode('utf-8'))
print(json.dumps(dict(head=head,tree=tree,commits=len(transitions),changedPaths=len(paths),
    trackedFiles=len(after),protectedUnchanged=len(protected),packageLockUnchanged=before['package-lock.json']==after['package-lock.json'])))
