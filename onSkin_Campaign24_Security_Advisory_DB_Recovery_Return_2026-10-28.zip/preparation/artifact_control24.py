"""Actual frozen return current/corrupted/exact-restored integrity control."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('builder24',HERE/'build_packet24.py');b=importlib.util.module_from_spec(s);s.loader.exec_module(b)
m=b.verify
receipt=json.loads((HERE/'return-build.receipt.json').read_bytes())
path=Path(receipt['zip']).resolve()
assert path.parent==HERE and path.name.startswith('onSkin_Campaign24_') and path.suffix=='.zip'
original=m.read_regular(path)
original_node=path.stat()
assert m.sha(original)==receipt['zipSHA256']
verifier=HERE/'verify_return24.py'
assert m.sha(m.read_regular(verifier))==receipt['verifierSHA256']
argv=[sys.executable,'-B',str(verifier),'--archive',str(path),
    '--expected-manifest-sha256',receipt['manifestSHA256'],
    '--expected-verifier-sha256',receipt['verifierSHA256']]
environment={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','GITHUB_','NPM_','PHASE4_'))}
records=[]


def run(label,expected):
    start=time.monotonic();code,out,err=m.bounded(argv,HERE,environment,2*1024*1024,120)
    (HERE/('artifact-'+label+'.stdout.json')).write_bytes(out)
    (HERE/('artifact-'+label+'.stderr.log')).write_bytes(err)
    value=json.loads(out)
    assert code==expected and not err and value['acceptanceGranted'] is False and value['release']=='NO_GO'
    if expected==0:
        assert value['status']=='VERIFIED' and value['sourceChecks']['state']=='NOT_RUN'
    else:
        assert value['status']=='CONTEXT_INVALID' and value['error']=='ARTIFACT_HASH_MISMATCH'
        assert b'SYNTHETIC_REPORT_MUTATION_24' not in out
    records.append(dict(state=label,argv=argv,exit=code,durationSeconds=round(time.monotonic()-start,3),
        stdoutSHA256=m.sha(out),stderrSHA256=m.sha(err),result=value))


run('current',0)
archive=m.Archive(original)
files={name:archive.read(name) for name in archive.members}
files['FINAL_REPORT.md']+=b'\nSYNTHETIC_REPORT_MUTATION_24\n'
altered=b.zip_bytes(files)
assert m.sha(altered)!=m.sha(original)
try:
    path.write_bytes(altered)
    assert m.read_regular(path)==altered
    run('corrupted',1)
finally:
    path.write_bytes(original)
    assert m.read_regular(path)==original and m.sha(m.read_regular(path))==receipt['zipSHA256']
    os.utime(path,ns=(original_node.st_atime_ns,original_node.st_mtime_ns))
    restored_node=path.stat()
    assert (restored_node.st_dev,restored_node.st_ino,restored_node.st_mode,restored_node.st_mtime_ns)==(original_node.st_dev,original_node.st_ino,original_node.st_mode,original_node.st_mtime_ns)
    assert getattr(restored_node,'st_file_attributes',None)==getattr(original_node,'st_file_attributes',None)
run('restored',0)
value=dict(qualification='ACTUAL_FROZEN_RETURN_CORRUPTION_RESTORATION_ARTIFACT_ONLY_NOT_ACCEPTANCE',
    originalSHA256=m.sha(original),corruptedSHA256=m.sha(altered),restoredSHA256=m.sha(m.read_regular(path)),
    exactBytesRestored=True,exits=[r['exit'] for r in records],commands=records,
    sameDeviceInodeModeMtimeAttributesRestored=True,
    sourceChecks='NOT_RUN_HERE_SEPARATE_INDEPENDENT_CHECKOUT_PROOF',release='NO_GO',acceptanceGranted=False)
(HERE/'artifact-control-final.receipt.json').write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in value.items() if k!='commands'},sort_keys=True))
