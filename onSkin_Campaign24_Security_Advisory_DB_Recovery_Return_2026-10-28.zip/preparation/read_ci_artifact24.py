"""Inspect authenticated public CI ZIPs, including exact data descriptors."""
import argparse
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import struct
import sys
import zipfile
import zlib

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('paths24',HERE/'verify24.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def inspect(raw):
    assert 22 <= len(raw) <= 4*1024*1024
    end=len(raw)-22
    e=struct.unpack_from('<4s4H2IH',raw,end)
    assert e[0]==b'PK\x05\x06' and e[1]==e[2]==0 and e[3]==e[4] and 0<e[4]<=256 and e[7]==0
    assert e[5]+e[6]==end
    cursor=e[6]; records=[]
    while cursor<end:
        c=struct.unpack_from('<4s6H3I5H2I',raw,cursor)
        assert c[0]==b'PK\x01\x02' and c[1]>>8==3 and c[2]<=20
        assert c[3] in (0,8,2048,2056) and c[4] in (0,8)
        assert c[11]==c[12]==c[13]==0 and c[15]>>16 in (stat.S_IFREG|0o644,stat.S_IFREG|0o666) and c[15]&65535 in (0,32)
        n=raw[cursor+46:cursor+46+c[10]]
        name=n.decode('utf-8' if c[3]&2048 else 'cp437');m.safe_path(name)
        records.append((name,n,c))
        cursor+=46+c[10]
    assert cursor==end and len(records)==e[4]
    names=[r[0] for r in records]
    assert len(set(names))==len(names);m.paths(names)
    assert sum(r[2][9] for r in records)<=16*1024*1024
    contents={};boundary=0
    for name,n,c in sorted(records,key=lambda r:r[2][16]):
        _,made,version,flags,method,mtime,mdate,crc,compressed,size,nlen,_,_,_,_,_,offset=c
        assert offset==boundary and size<=2*1024*1024 and size<=max(1048576,compressed*500)
        l=struct.unpack_from('<4s5H3I2H',raw,offset)
        assert l[:6]==(b'PK\x03\x04',version,flags,method,mtime,mdate) and l[9:]==(nlen,0)
        assert raw[offset+30:offset+30+nlen]==n
        assert l[6:9]==((0,0,0) if flags&8 else (crc,compressed,size))
        start=offset+30+nlen; finish=start+compressed
        assert finish<=e[6]
        packed=raw[start:finish]
        if method==8:
            d=zlib.decompressobj(-15);unpacked=d.decompress(packed,size+1)
            assert d.eof and not d.unconsumed_tail and not d.unused_data
        else:unpacked=packed
        assert len(unpacked)==size and zlib.crc32(unpacked)&0xffffffff==crc
        if flags&8:
            if raw[finish:finish+4]==b'PK\x07\x08':
                assert struct.unpack_from('<3I',raw,finish+4)==(crc,compressed,size);finish+=16
            else:
                assert struct.unpack_from('<3I',raw,finish)==(crc,compressed,size);finish+=12
        boundary=finish;contents[name]=unpacked
    assert boundary==e[6]
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        assert archive.namelist()==names
        for name,data in contents.items():assert archive.read(name)==data
    return contents


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',required=True);parser.add_argument('--sha256',required=True)
    parser.add_argument('--output',required=True);parser.add_argument('--head',required=True);parser.add_argument('--tree',required=True)
    args=parser.parse_args()
    raw=m.read_regular(Path(args.archive),4*1024*1024)
    assert m.sha(raw)==args.sha256
    contents=inspect(raw)
    # Actual framing/descriptor corruption must refuse without affecting original.
    corrupted=bytearray(raw);corrupted[0]=0
    try:inspect(bytes(corrupted))
    except (AssertionError,ValueError,struct.error,zlib.error):pass
    else:raise AssertionError('corruption admitted')
    assert inspect(raw)==contents
    public=json.loads(contents['security22-public.json'])
    assert public['source']['head']==args.head and public['source']['tree']==args.tree
    assert public['executionComplete'] is True and public['candidateReady'] is False and public['acceptanceGranted'] is False
    index=json.loads(contents['security22-components/index.json'],object_pairs_hook=m.pairs)
    assert index['candidateReady'] is False and index['acceptanceGranted'] is False
    assert index['unresolvedRequired']==public['unresolvedRequired']
    expected={'security22-components/'+name for name in index['files']} | {
        'security22-components/index.json','security22-public.json','security23-native-controls.json',
        'security23-toolchain-controls.json','security24-advisory-controls.tap',
        'security24-advisory-graph.json','security24-source-controls.jsonl'}
    assert set(contents)==expected
    identity=public['toolchain']['identitySHA256']
    early_unbound=0
    for name,witness in index['files'].items():
        assert '/' not in name;m.safe_path(name)
        data=contents['security22-components/'+name]
        assert len(data)==witness['bytes'] and m.sha(data)==witness['sha256']
        record=json.loads(data,object_pairs_hook=m.pairs)
        if name.startswith('progress-'):
            assert record['acceptanceGranted'] is False and record['candidateReady'] is False
            if record['source'] is None:
                early_unbound+=1
            else:
                assert record['source']['head']==args.head and record['source']['tree']==args.tree
            if record['toolchain'] is not None:
                assert record['toolchain']['identitySHA256']==identity
        else:
            assert record['head']==args.head and record['tree']==args.tree
            assert record['toolchainIdentitySHA256']==identity and record['admission']=='NOT_GRANTED'
    for name,result in public['components'].items():
        record=json.loads(contents['security22-components/'+name+'.json'])
        assert record['component']==name and record['result']==result
    native=json.loads(contents['security23-native-controls.json'])
    assert native['headObserved']==args.head and native['treeObserved']==args.tree
    assert native['executionComplete'] is True and native['acceptanceGranted'] is False
    output=Path(args.output);assert not output.exists();output.mkdir(parents=True)
    inventory={}
    for name,data in sorted(contents.items()):
        if name.endswith(('.json','.jsonl','.tap')):
            data.decode('utf-8',errors='strict')
        else:raise AssertionError('unapproved artifact member type')
        target=output.joinpath(*name.split('/'));target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(data)
        assert m.read_regular(target)==data
        inventory[name]=dict(bytes=len(data),sha256=m.sha(data))
    proof=dict(qualification='BYTE_VERIFIED_PUBLIC_CI_ARTIFACT_STRUCTURE_NOT_ACCEPTANCE',
        sha256=m.sha(raw),bytes=len(raw),head=args.head,tree=args.tree,files=inventory,
        indexedComponentRecords=len(index['files']),publicComponents=len(public['components']),
        exactIndexedHashesVerified=True,finalComponentsIdentityVerified=True,
        earlyProgressSourceBindingUnavailable=early_unbound,
        expandedBytes=sum(len(b) for b in contents.values()),executionComplete=True,candidateReady=False,
        sourceZipRegularModes=sorted({oct(item.external_attr>>16) for item in zipfile.ZipFile(io.BytesIO(raw)).infolist()}),
        framingCorruptionControl=[0,1,0],release='NO_GO',acceptanceGranted=False)
    (output.parent/(output.name+'-verification.json')).write_bytes((json.dumps(proof,indent=2)+'\n').encode())
    print(json.dumps({k:v for k,v in proof.items() if k!='files'},sort_keys=True))


if __name__=='__main__':
    try:main()
    except Exception:
        print('PUBLIC_CI_ARTIFACT_REFUSED');sys.exit(1)
