"""Run public source checks with bounded children and external receipts."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('containment24', HERE/'verify24.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
root = HERE.parent/'campaign24-source'
node = shutil.which('node')
npm = str(Path(node).parent/'node_modules/npm/bin/npm-cli.js')
cache = str(HERE/'turbo-cache')
mobile = root/'apps/mobile'
vitest = str(root/'node_modules/vitest/vitest.mjs')
commands = [
    ('mandatory-postinstall', [node, 'scripts/postinstall.mjs', '--check'], root, 120, 0),
    ('tooling-original', [node, npm, 'run', 'phase9:tooling-security:test'], root, 300, 0),
    ('security24', [node, '--test', 'scripts/security24/patch-tooling.test.mjs', 'scripts/security24/advisory-behavior.test.mjs'], root, 600, 0),
    ('forced-root-tests', [node, npm, 'run', 'test', '--', '--force', '--cache-dir', cache], root, 900, 0),
    ('forced-typecheck', [node, npm, 'run', 'typecheck', '--', '--force', '--cache-dir', cache], root, 900, 0),
    ('forced-lint', [node, npm, 'run', 'lint', '--', '--force', '--cache-dir', cache], root, 900, 0),
    ('layout15', [node, vitest, 'run', 'src/features/photos/progressEmptyLayout.c08b2.test.ts', '--reporter=json', '--outputFile='+str(HERE/'layout15-result.json')], mobile, 300, 0),
    ('focused97', [node, vitest, 'run', *['src/features/photos/'+name for name in ['compareAccessibility.test.ts', 'manualCompare20.test.ts', 'manualCompare20Route.test.ts', 'progressDataAuthority.c08a1.test.ts', 'progressImageDemand.test.ts', 'progressRoutes.test.ts', 'progressSensitiveImageAuthority.c08a2.test.ts', 'timeline.test.ts']], '--reporter=json', '--outputFile='+str(HERE/'focused97-result.json')], mobile, 300, 0),
    ('launch-contracts', [node, npm, 'run', 'launch:contract:verify'], root, 900, 0),
    ('privacy-source-original', [node, '--test', 'scripts/phase9/ios-privacy-source-audit.test.mjs'], root, 300, 0),
    ('privacy-archive-original', [node, '--test', 'scripts/phase9/ios-archive-privacy-evidence.test.mjs'], root, 300, 0),
    ('viewshot-original', [node, '--test', 'scripts/phase9/patch-react-native-view-shot-privacy.test.mjs'], root, 300, 0),
    ('widget-extension-original', [node, npm, 'run', 'phase5:ios-extension-contract:smoke'], root, 300, 0),
    ('native-successor23', [node, '--test', 'scripts/phase9/ios-privacy-lock-succession23.test.mjs'], root, 300, 0),
    ('native-current23', [node, '--test', 'scripts/security23/native-source.test.mjs'], root, 300, 0),
    ('native-current-cli', [node, 'scripts/phase9/ios-privacy-source-audit.mjs', '--strict', '--check'], root, 300, 0),
    ('native-config-current', [node, 'scripts/phase5/check-native-config.mjs'], root, 300, 0),
    ('native-config-strict', [node, 'scripts/phase5/check-native-config.mjs', '--strict'], root, 300, 1),
    ('db-local-contract', [node, npm, 'run', 'phase2:db-local-contract'], root, 300, 0),
    ('db-mirror24', [node, '--test', 'scripts/phase2/canonical-postgres-mirror24.test.mjs'], root, 300, 0),
    ('export-ios', [node, str(root/'node_modules/expo/bin/cli'), 'export', '--platform', 'ios', '--output-dir', str(HERE/'unsigned-ios'), '--source-maps', 'external', '--dump-assetmap', '--clear'], mobile, 900, 0),
    ('export-android', [node, str(root/'node_modules/expo/bin/cli'), 'export', '--platform', 'android', '--output-dir', str(HERE/'unsigned-android'), '--source-maps', 'external', '--dump-assetmap', '--clear'], mobile, 900, 0),
]
selected = set(sys.argv[1:])
environment = {k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_', 'NPM_', 'PHASE4_', 'GITHUB_', 'SUPABASE_', 'EXPO_PUBLIC_', 'REVENUECAT_', 'SENTRY_', 'OPENAI_', 'AWS_'))}
environment.update(CI='1', EXPO_NO_TELEMETRY='1', DO_NOT_TRACK='1')
records = []
for name, argv, cwd, timeout, expected in commands:
    if selected and name not in selected:
        continue
    head = module.git(root, 'rev-parse', 'HEAD').decode().strip()
    tree = module.git(root, 'rev-parse', 'HEAD^{tree}').decode().strip()
    print('START '+name+' '+head, flush=True)
    started = time.monotonic()
    record = {'name': name, 'argv': argv, 'cwd': str(cwd), 'head': head, 'tree': tree, 'expectedExit': expected, 'timeoutSeconds': timeout}
    try:
        env = dict(environment)
        if name.startswith('export-'):
            env['NODE_ENV'] = 'production'
        code, output, error = module.bounded(argv, cwd, env, 16*1024*1024, timeout)
        (HERE/(name+'.stdout.log')).write_bytes(output)
        (HERE/(name+'.stderr.log')).write_bytes(error)
        record.update(exit=code, expectedExitObserved=code==expected,
                      stdoutBytes=len(output), stdoutSHA256=module.sha(output),
                      stderrBytes=len(error), stderrSHA256=module.sha(error))
    except module.Refusal as error:
        record.update(exit=None, expectedExitObserved=False, boundedFailure=error.args[0])
    record['durationSeconds'] = round(time.monotonic()-started, 3)
    record['endHead'] = module.git(root, 'rev-parse', 'HEAD').decode().strip()
    record['sourceCommitUnchanged'] = record['endHead']==head
    (HERE/(name+'.receipt.json')).write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
    records.append(record)
    print('DONE '+name+' '+str(record.get('exit'))+' '+str(record['durationSeconds']), flush=True)
(HERE/'validation-last-run.json').write_text(json.dumps(records, indent=2)+'\n', encoding='utf-8')
sys.exit(0 if all(r['expectedExitObserved'] and r['sourceCommitUnchanged'] for r in records) else 1)
