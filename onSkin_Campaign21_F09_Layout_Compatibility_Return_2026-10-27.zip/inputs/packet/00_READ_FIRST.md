# Campaign21 read first: F09 layout compatibility

This is the independent Brain's source-only engineering task context, NOT a qualified release or security approval. It is for Codex, NOT the Brain succession transfer. Authenticate with the **external** SHA-256 supplied in the Brain chat. Do not use old Campaign20 packets or upload the separate historical returns in lieu of this packet.

Read 00_READ_FIRST, 01_LIVE_PR24_AUDIT, 02_SEVEN_FAILING_CASES, 03_F09_PRIVACY_AND_BOUNDARIES, 04_RELEASE_GATES, and TASK_DIRECTIVE. The same complete directive appears byte-for-byte in TASK_DIRECTIVE.md, PROMPT_TEMPLATE.md, EXACT_PROMPT.md. Do not compare rich-chat rendered paste bytes to these source files. Live GitHub and exact pinned Git objects supersede time-stamped observations, subject to no unsafe ref drift.
