"""External SHA-256 anchored exact-inventory verifier for Campaign21 Codex context.

Authenticates orientation bytes, not Git/PR acceptance, a source reviewer, Security,
medical measurement, database custody, device or release admission.
"""
from pathlib import Path
from hashlib import sha256
import argparse, json, os, re, stat, sys, unicodedata

def stop(reason):
    print(json.dumps({"status":"CONTEXT_INVALID","error":reason},sort_keys=True))
    return 1

def safe(name):
    if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9._/-]+',name): return False
    if name.startswith('/') or '\\' in name or re.match(r'^[a-zA-Z]:',name): return False
    parts=name.split('/')
    return all(x not in ('','.','..') and not x.startswith('.') and not x.endswith('.')
               and not re.fullmatch(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?', x, re.I)
               for x in parts)

def regular(p,root):
    x=p
    while True:
        v=x.lstat()
        if stat.S_ISLNK(v.st_mode) or (getattr(v,'st_file_attributes',0)&1024):
            raise ValueError('LINK_OR_REPARSE:'+str(p))
        if x==root: break
        if root not in x.parents: raise ValueError('ESCAPED_ROOT')
        x=x.parent
    if not p.is_file() or p.stat().st_nlink != 1: raise ValueError('NOT_SINGLE_REGULAR:'+str(p))
    return p.read_bytes()

def pairs(xs):
    d={}
    for k,v in xs:
        if k in d: raise ValueError('DUPLICATE_JSON_KEY:'+k)
        d[k]=v
    return d

def verify(root,expected):
    if not re.fullmatch('[0-9a-f]{64}',expected): raise ValueError('BAD_EXTERNAL_ANCHOR')
    data=regular(root/'manifest.json',root)
    if sha256(data).hexdigest()!=expected: raise ValueError('EXTERNAL_MANIFEST_SHA256_MISMATCH')
    m=json.loads(data,object_pairs_hook=pairs)
    if set(m)!={'schema','authority','status','files','promptTriple'} or m['schema']!=1 or m['authority']!='BRAIN-M1X-F09-LAYOUT-COMPATIBILITY21-REPAIR-01' or m['status']!='CONTEXT_ONLY': raise ValueError('MANIFEST_SCOPE')
    witnesses=m['files']
    if not isinstance(witnesses,dict) or not witnesses: raise ValueError('EMPTY_MANIFEST')
    allowed=set(witnesses)|{'manifest.json'}
    found=set(); collisions=set()
    for child in root.rglob('*'):
        relative=child.relative_to(root).as_posix()
        if not safe(relative): raise ValueError('UNSAFE_NAME:'+relative)
        key=unicodedata.normalize('NFKC',relative).casefold()
        if key in collisions: raise ValueError('NAME_COLLISION')
        collisions.add(key)
        if child.is_dir(): raise ValueError('UNEXPECTED_DIRECTORY:'+relative)
        regular(child,root)
        found.add(relative)
    if found!=allowed: raise ValueError('INVENTORY_MISMATCH:'+repr(sorted(found^allowed)))
    for name,w in witnesses.items():
        if not safe(name) or set(w)!={'bytes','sha256'} or not isinstance(w['bytes'],int) or w['bytes']<0: raise ValueError('UNSAFE_WITNESS')
        body=regular(root/name,root)
        if len(body)!=w['bytes'] or sha256(body).hexdigest()!=w['sha256']: raise ValueError('CONTENT_MISMATCH:'+name)
    promptnames=['TASK_DIRECTIVE.md','PROMPT_TEMPLATE.md','EXACT_PROMPT.md']
    if m['promptTriple']!=promptnames or len({regular(root/x,root) for x in promptnames})!=1: raise ValueError('PROMPT_TRIPLE_MISMATCH')
    return {'status':'VERIFIED','files':len(allowed),'manifest_sha256':expected,'prompt_triple':'IDENTICAL','release':'NO_GO'}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--expected-manifest-sha256',required=True)
    args=p.parse_args()
    try: print(json.dumps(verify(Path(__file__).resolve().parent,args.expected_manifest_sha256),sort_keys=True)); return 0
    except (ValueError,OSError,TypeError,KeyError,json.JSONDecodeError) as e: return stop(str(e))
if __name__=='__main__':sys.exit(main())
