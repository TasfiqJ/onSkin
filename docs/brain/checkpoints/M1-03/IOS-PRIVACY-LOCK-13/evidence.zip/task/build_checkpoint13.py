from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
CHECKPOINT=ROOT/'docs/brain/checkpoints/M1-03/IOS-PRIVACY-LOCK-13'
SOURCE='d94196a646d8e6f16936145f87d8822e0fff9ed5'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,value):path.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain=v1')
proof=json.loads((HERE/'source-proof13.json').read_bytes())
independent=json.loads((HERE/'independent-proof13.json').read_bytes())
assert proof['source']['commit']==independent['source_commit']==SOURCE
CHECKPOINT.mkdir(exist_ok=False)
(CHECKPOINT/'source-proof.json').write_bytes((HERE/'source-proof13.json').read_bytes())
(CHECKPOINT/'protected-files.json.gz').write_bytes((HERE/'protected-files13.json.gz').read_bytes())
(CHECKPOINT/'verify_checkpoint.py').write_bytes((HERE/'verify_checkpoint13.py').read_bytes())
archive_index={}
excluded=['source-artifact-download13.json']
entries={}
for p in sorted(HERE.iterdir()):
    if p.is_file() and p.name not in excluded and p.suffix in ('.log','.json','.py','.cjs'):
        entries['task/'+p.name]=p.read_bytes()
for p in sorted((HERE/'context').iterdir()):
    if p.is_file():entries['inputs/context/'+p.name]=p.read_bytes()
entries['inputs/user-request.txt']=Path(r'C:\Users\jasim\.codex\attachments\b627b1da-e0fe-458f-901e-61b0f20172fe\Pasted text.txt').read_bytes()
with zipfile.ZipFile(CHECKPOINT/'evidence.zip','x') as archive:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,data)
        archive_index[name]=dict(bytes=len(data),sha256=sha(data))
dump(CHECKPOINT/'archive-index.json',archive_index)
receipts={p.name:json.loads(p.read_bytes()) for p in sorted(HERE.glob('*.receipt.json'))}
completion={
    'status':'PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED',
    'authorization':'BRAIN-M103-IOS-PRIVACY-LOCK-SUCCESSION13-CANDIDATE-01',
    'source':proof['source'],'implementation':proof['implementation'],'base':proof['base'],
    'branch':proof['branch'],'pr':17,'base_branch':proof['base_branch'],
    'outcome':'Exact eight-node Vitest4.1.12 candidate APPLIED through separately pinned source-only native lock successor. Original mapping and producers remain byte-identical. No independent acceptance or release.',
    'successor_sha256':'824d99e0f57bee122af6b89f640c1bfe401b367b8f7211b1c0abf61b5a249409',
    'old_lock_sha256':'99aa497f2d0cc2ca237167403fbbb9d9aee0a4e42fa991ea44f9661487ecf568',
    'candidate_lock_sha256':'7656c2e6bf482df5a9bc94c9789816a40c5f2b5cfb30e2f10748411229c136cb',
    'original_native_ledger':'All native ledger hashes, counts, warnings, schema1, archive_required and false claims identical to PR16; only current lock input and separately named successor input change.',
    'tests':{'cold_install':'Primary and independent fresh npm caches,1028 packages, no lock drift; npm optional-script warnings retained without approval',
        'root':{'passed':6190,'cached_tasks':0,'measured_source':'b835356f4c4a45cd0a8fab8de744d16bc63f1ea5','later_delta':'Only new custody document labels and Phase4 Git/timestamp projection metadata; all executable/test/package bytes unchanged. Final evidence-head CI executes independently.'},
        'typecheck_lint':'Forced uncached PASS at clean measured source; final-head CI observed separately',
        'native_tests':{'total':81,'passed_windows':79,'skipped_windows':2,'failed':0,'skips':'Original and successor actual file-symlink tests lack Windows privilege; actual Linux native tests are exercised by unchanged CI step.'},
        'source13_refusals':68,'dependency13_refusals':66,'predecessor_refusals':[23,44,58,9,55,49],
        'original_semantic_negatives':{'count':151,'current':0,'malicious':1,'restored':0,'class':'Original unedited bundle fixtures in real GitHub source job121207060958 at b835; raw log retained. Overall run later CANCELLED by newer source push; final-head result is separate.'},
        'launch_and_source_packet':'Original unchanged launch chain and strict source-packet PASS',
        'security_original_suite':{'tests':70,'failures':21,'errors':19,'exit':1,'supported_python':'bundled Python3.12; retained exact failing case identities match prior receipt set'},
        'security_original_source':{'exit':1,'code':'SOURCE_INVENTORY_DRIFT'},
        'independent':independent,'historical':json.loads((HERE/'historical-proof13.json').read_bytes())},
    'receipts':receipts,
    'source_security_review':json.loads((HERE/'security-artifact-review13.json').read_bytes()),
    'source_ci':'Exact b835 API observations archived. Original steps passed; canonical DB FAILED H01_SQL_PROBE_FAILED / registry Data limit exceeded. Overall Quality and exports later CANCELLED by newer source push. Security FAIL; iOS source-only PASS. Never borrowed as final-head PASS.',
    'final_ci':'Resolve final pushed evidence HEAD after publication and report its actual Quality/DB/Security/iOS/Expo jobs externally. No recursive self-hash or invented final results in this checkpoint.',
    'outside_scope_unapplied':{'owner_packet':'docs/release/full-app-j01/security-custody13.unapplied.json','paths':['scripts/phase9/security_acceptance/','.github/security/','.github/workflows/security.yml','docs/phase-9/security-advisory-exceptions.json','scripts/phase2/','supabase/','LAUNCH_READINESS.md','BLOCKERS.md','docs/e2e/generated/'],'blockers':['Unreviewed original current/history findings and source inventory/rule custody','Zod/node-forge and scanner-runtime advisories; expired reviews/proposal','Canonical registry quota failure; protected DB06/DB08/R2B not accepted','Readiness/CAT07/provenance, native phone/archive/Apple, research/rights/clinical/provider/commercial gates']},
    'retained_failures':['Original native consumer actual primary0/1/0 reproduced exactly three MAPPING_LOCK_DRIFT errors before patch.','Two early source13 harness attempts expected narrower error labels; actual earlier guards refused. Expectations corrected without weakening guards.','Python3.9 helper rejected write_text(newline=...); corrected task helper to write exact bytes before harness creation.','Custody source correction explicitly distinguishes applied Campaign13 successor from immutable Release12 UNAPPLIED witness.','Original Security failures retained; source-head canonical registry quota failure retained; source CI concurrency cancellations remain CANCELLED.'],
    'raw_secret_reports':'NOT_PUBLISHED. Downloaded originals stay task-local; only artifact hashes, actual exits, aggregate counts and public advisory IDs are included.',
    'protected_count':proof['protected_count'],'changed_source_paths':len(proof['changed_files']),
    'gates':{'G97':'FAIL/NO_GO','DB06_DB08_R2B':'NOT_ACCEPTED','M1_03':'BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED','M2':'NOT_AUTHORIZED','public_release':'CLOSED'},
    'product_limits':'All real working non-Korean F01-F17/F19-F20, all12 consumer and6 professional groups plus only independently validated J01 are the required product. F09 diary/history/manual compare required. F18 and J02-J27/J05 deferred. J01 authenticated intake missing; G1/G2/G3/G5 and separate G4 remain closed. No positive count/size/score/percentage/causality/improvement/diagnosis/accuracy, provider/paid/native/Apple/clinical/public release claim.',
    'spend_usd':0,'acceptanceGranted':False,'merge':False,
}
dump(CHECKPOINT/'completion-report.json',completion)
readme='''# Campaign13: source candidate submitted; acceptance closed

PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED. Exact Vitest4.1.12 eight-node patch
is APPLIED through a separately authenticated source-only lock successor. Original
iOS mapping, Apple baseline, audit writer, Phase4 writer and all historical
contracts remain intact. No source, Security, DB, device, Apple or release approval.

The independently supplied external manifest SHA256 must be copied from the final
report. Run from a clean full checkout with all pinned historical objects:

    python -B docs/brain/checkpoints/M1-03/IOS-PRIVACY-LOCK-13/verify_checkpoint.py --expected-manifest-sha256 EXTERNAL_SHA256

The manifest authenticates the exact checkpoint inventory, verifier, evidence ZIP,
source scope and protected inventory. The verifier checks current bytes, Git modes
and blobs, five source intermediates,23290 protected paths, old trees, absences and
the evidence-only tail. Wrong external anchors and altered evidence must reject.
It grants no acceptance. Source and final evidence commit/tree are separate.

Evidence distinguishes actual installed-source runs, in-memory dependency readers,
disposable Git/materialized fixtures and a fresh independent23308-file checkout
with separate Git objects, no alternates/hardlinks and cold installation. The
independent governance lock mutation, native installed-source mutation and actual
Phase4 workflow-input mutation each completed0/1/0. Original Release08-12 consumers
each passed and rejected tampered original locks at their own endpoints.

Forced6190 root tests, uncached typecheck/lint,68 source and66 dependency refusals,
unchanged23/44/58/9/55/49 controls, original151 semantic negatives and the launch/
source-packet checks are individually source-bound in the receipts. Windows native
tests pass79 with2 explicit file-symlink privilege skips; unchanged CI exercises
the real Linux cases. Native ledgers/status/claims stay identical; Phase4 preserves
14 tasks,7 blocked/7 scaffold,420 source occurrences and zero missing.

Original Security remains failing: source inventory drift,70-test suite21 failures/
19 errors, genuine current/history findings1144/4388 and remaining advisories and
expired reviews. Raw secret reports are withheld. Sanitized aggregate evidence and
exact protected-owner tasks retain original custody. Canonical DB source CI again
failed registry Data limit exceeded; no workflow/SQL/provider workaround applied.

Observe FINAL pushed evidence-head CI separately; source-head success, cancellation
and failure must never be relabeled as final results. The externally delivered full
report states all final jobs and source/evidence identities without a recursive
evidence commit. G97 FAIL/NO_GO, protected DB not accepted, M1-03 blocked/not accepted,
M2 not authorized, J01 research/qualified gates, native/Apple/provider/paid/clinical/
readiness/CAT07/public release closed. Brain alone audits and later decides ordinary
promotion. No merge, self-acceptance, background monitor or purchase. USD0.
'''
(CHECKPOINT/'README.md').write_bytes(readme.encode())
handoff=f'''Campaign13 PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED
PR https://github.com/TasfiqJ/onSkin/pull/17 remains DRAFT, stacked on pinned PR16.
Branch stage/m103-ios-privacy-lock-succession13; measured source {SOURCE}; tree {proof['source']['tree']}.
Exact reviewed eight-node Vitest4.1.12 candidate APPLIED via source-only ios-sdk-lock-succession13.v1.json. Original mapping and producers preserved byte-for-byte; native identities, source pins and archive_required claims retained.
Checkpoint: docs/brain/checkpoints/M1-03/IOS-PRIVACY-LOCK-13/README.md
Use the externally supplied manifest SHA256 from the final report; never substitute an internal anchor. Final evidence HEAD/tree is resolved after push and reported separately.
Protected-owner tasks: docs/release/full-app-j01/security-custody13.unapplied.json
Independent complete-checkout governance/native/worklist0/1/0 and original Release08-12 endpoint0/1/0 completed. Source/evidence and disposable/historical/independent classes remain distinct.
G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED. J01 research and G1/G2/G3/G5, separate G4, native/Apple/provider/paid/clinical/readiness/CAT07/public release closed. F09 required; F18/J02-J27/J05 deferred.
Final-head Quality/DB/Security/iOS/Expo actual results must be read at the pushed delivery SHA. Current source passes never approve release; original Security and canonical quota failures remain unresolved.
Only independent Brain audits/accepts source and later authorizes ordinary promotion. No merge, purchase or self-acceptance. Spend USD0.
'''.encode()
(ROOT/'ONSKIN_BRAIN_HANDOFF.txt').write_bytes(handoff)
files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()),mode='100644') for p in sorted(CHECKPOINT.iterdir()) if p.is_file()}
manifest={'version':1,'authorization':completion['authorization'],'source':proof['source'],'files':files,'handoff_sha256':sha(handoff),'acceptanceGranted':False,'release':'NO_GO'}
dump(CHECKPOINT/'manifest.json',manifest)
digest=sha((CHECKPOINT/'manifest.json').read_bytes())
(HERE/'checkpoint-manifest-sha13.txt').write_bytes((digest+'\n').encode())
print(json.dumps({'manifest_sha256':digest,'files':len(files)+1,'archived_files':len(archive_index),'source':proof['source'],'acceptanceGranted':False}))
