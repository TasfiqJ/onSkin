from pathlib import Path
import gzip,hashlib,importlib.util,json,subprocess
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
BASE='bbbd59073b7add22ac350bced0d9a34124c12ffb'
SOURCE='d94196a646d8e6f16936145f87d8822e0fff9ed5'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def tree(ref):
    result={}
    for row in git('ls-tree','-r','-z',ref).split(b'\0'):
        if row:
            meta,path=row.split(b'\t',1);mode,kind,blob=meta.decode().split()
            assert kind=='blob'
            result[path.decode()]=dict(mode=mode,blob=blob)
    return result
assert git('rev-parse','HEAD').decode().strip()==SOURCE
assert not git('status','--porcelain=v1')
spec=importlib.util.spec_from_file_location('scope13',ROOT/'scripts/release/full-app-j01/check.py')
check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
baseline=tree(BASE);current=tree(SOURCE)
protected={p:dict(v) for p,v in baseline.items() if p not in check.RELEASE13_EXISTING}
process=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
cache={}
def blob_data(oid):
    process.stdin.write((oid+'\n').encode());process.stdin.flush()
    header=process.stdout.readline().decode().split();assert header[0]==oid and header[1]=='blob'
    size=int(header[2]);raw=process.stdout.read(size);assert len(raw)==size and process.stdout.read(1)==b'\n'
    return raw
for path,row in protected.items():
    assert current[path]==baseline[path],path
    if row['blob'] not in cache:
        data=blob_data(row['blob']);cache[row['blob']]=dict(sha256=sha(data),bytes=len(data))
    row.update(cache[row['blob']])
    assert sha((ROOT/path).read_bytes())==row['sha256'],path
commits=[]
for commit in git('rev-list','--reverse',BASE+'..'+SOURCE).decode().splitlines():
    parents=git('rev-list','--parents','-n','1',commit).decode().split()[1:];assert len(parents)==1
    before=tree(parents[0]);after=tree(commit);changes=[]
    for path in sorted(set(before)|set(after)):
        if before.get(path)!=after.get(path):
            assert check.allowed13(path) and path in after and after[path]['mode']=='100644',path
            data=blob_data(after[path]['blob'])
            changes.append(dict(path=path,before=before.get(path),after=dict(after[path],sha256=sha(data),bytes=len(data))))
    commits.append(dict(commit=commit,tree=git('rev-parse',commit+'^{tree}').decode().strip(),parents=parents,changes=changes))
changes=[]
for path in sorted(set(baseline)|set(current)):
    if baseline.get(path)!=current.get(path):
        data=blob_data(current[path]['blob'])
        changes.append(dict(path=path,before=baseline.get(path),after=dict(current[path],sha256=sha(data),bytes=len(data))))
process.stdin.close();assert process.wait()==0
proof=dict(authorization='BRAIN-M103-IOS-PRIVACY-LOCK-SUCCESSION13-CANDIDATE-01',
    source=dict(commit=SOURCE,tree=git('rev-parse',SOURCE+'^{tree}').decode().strip()),
    implementation=dict(commit='32c0d29743230faab1a8421cfdff6beea9343931',tree='926159902c18e88643d07665213995055685a0f8'),
    base=dict(commit=BASE,tree='4a70f0934a56e27863742084272c9bb4bfd5492d'),
    branch='stage/m103-ios-privacy-lock-succession13',pr=17,base_branch='stage/m103-dependency-witness12',
    changed_files=changes,intermediate_commits=commits,protected_count=len(protected),
    protected_inventory_sha256=sha(json.dumps(protected,sort_keys=True,separators=(',',':')).encode()),
    old_refs=json.loads((HERE/'preflight.json').read_bytes())['refs'],
    absences=['apps/mobile/ios/Podfile.lock'],acceptanceGranted=False,release='NO_GO')
for path in proof['absences']:assert not (ROOT/path).exists()
(HERE/'protected-files13.json.gz').write_bytes(gzip.compress(json.dumps(protected,sort_keys=True,separators=(',',':')).encode(),mtime=0))
(HERE/'source-proof13.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
print(json.dumps({'source':proof['source'],'changed_paths':len(changes),'protected':len(protected),'intermediate_commits':len(commits),'all_verified':True}))
