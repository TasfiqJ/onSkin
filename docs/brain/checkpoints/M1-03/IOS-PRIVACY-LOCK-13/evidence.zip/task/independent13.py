from pathlib import Path
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
TARGET=HERE/'independent-complete'
SOURCE='d94196a646d8e6f16936145f87d8822e0fff9ed5'
def git(*args):return subprocess.check_output(['git',*args],cwd=TARGET)
def run(name,argv):return subprocess.run([sys.executable,str(HERE/'run_at.py'),name,str(TARGET),*argv]).returncode
assert not git('status','--porcelain=v1')
git('fetch','--no-tags','origin','refs/heads/stage/m103-ios-privacy-lock-succession13')
git('switch','--detach',SOURCE)
assert not git('status','--porcelain=v1')
assert git('rev-parse','--is-shallow-repository').strip()==b'false'
assert not (TARGET/'.git/objects/info/alternates').exists()
assert all(p.stat().st_nlink==1 for p in (TARGET/'.git/objects').rglob('*') if p.is_file())
files=git('ls-files','-z').split(b'\0')[:-1]
assert all((TARGET/p.decode()).is_file() for p in files)
argv=[sys.executable,'-B','scripts/release/full-app-j01/check.py']
assert run('independent-current13',argv)==0
lock=TARGET/'package-lock.json';raw=lock.read_bytes()
try:
    value=json.loads(raw);value['packages']['node_modules/unreviewed13']={'version':'1.0.0'}
    lock.write_bytes((json.dumps(value,indent=2)+'\n').encode())
    assert run('independent-malicious13',argv)==1
finally:lock.write_bytes(raw)
assert run('independent-restored13',argv)==0
native=['node','scripts/phase9/ios-privacy-source-audit.mjs','--check','--strict']
assert run('native-independent-current13',native)==0
pin=TARGET/'node_modules/expo-image/ios/ExpoImage.podspec';raw=pin.read_bytes()
try:
    pin.write_bytes(raw+b'\n# changed real installed native source13\n')
    assert run('native-independent-malicious13',native)==1
finally:pin.write_bytes(raw)
assert run('native-independent-restored13',native)==0
worklist=['node','scripts/phase4/build-source-worklist.mjs','--strict','--check']
assert run('worklist-independent-current13',worklist)==0
path=TARGET/'.github/workflows/quality.yml';raw=path.read_bytes()
try:
    path.write_bytes(raw+b'\n# changed authentic source input in disposable complete checkout13\n')
    assert run('worklist-independent-malicious13',worklist)==1
finally:path.write_bytes(raw)
assert run('worklist-independent-restored13',worklist)==0
assert not git('status','--porcelain=v1')
report=json.loads((TARGET/'docs/phase-4/generated/source-worklist.json').read_bytes())
assert report['summary']['itemCount']==14 and report['summary']['sourcePathCount']==420
proof={'qualification':'INDEPENDENT_COMPLETE_CHECKOUT_SEPARATE_GIT_OBJECTS','checkout':str(TARGET),'source_commit':SOURCE,'source_tree':git('rev-parse','HEAD^{tree}').decode().strip(),'tracked_files':len(files),'all_tracked_files_materialized':True,'shallow':False,'alternates':False,'hardlinked_objects':False,'cold_install':'independent-cold-ci13.receipt.json; exact lock and executable source bytes unchanged since b835; later custody/projection-only changes fetched before tests','governance_actual_lock_mutation':[0,1,0],'native_actual_installed_source_pin_mutation':[0,1,0],'phase4_actual_workflow_source_input_mutation':[0,1,0],'mutations':'Uncommitted disposable changes restored byte-for-byte; no production protected ref changed','worklist_summary':report['summary'],'clean_after':True,'acceptanceGranted':False,'release':'NO_GO'}
(HERE/'independent-proof13.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
print(json.dumps(proof),flush=True)
