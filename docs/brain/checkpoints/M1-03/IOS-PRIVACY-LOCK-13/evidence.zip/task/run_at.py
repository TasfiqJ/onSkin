import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
name,cwd,*argv=sys.argv[1:];cwd=Path(cwd)
assert name.replace('-','').replace('_','').isalnum()
def identity():
    def git(*args):return subprocess.check_output(['git',*args],cwd=cwd)
    status=git('status','--porcelain=v1')
    return dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),clean=not status,status_sha256=hashlib.sha256(status).hexdigest())
started=datetime.datetime.now(datetime.timezone.utc).isoformat();before=identity();t=time.monotonic()
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CI='true',EXPO_NO_TELEMETRY='1')
with (HERE/(name+'.log')).open('xb') as stream:
    result=subprocess.run(argv,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,env=env)
raw=(HERE/(name+'.log')).read_bytes()
receipt=dict(name=name,argv=argv,cwd=str(cwd),started=started,elapsed_seconds=round(time.monotonic()-t,3),exit=result.returncode,log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw),source_before=before,source_after=identity())
(HERE/(name+'.receipt.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt),flush=True)
print(raw[-1500:].decode('utf8',errors='backslashreplace').encode(sys.stdout.encoding or 'utf8',errors='backslashreplace').decode(sys.stdout.encoding or 'utf8'))
sys.exit(result.returncode)
