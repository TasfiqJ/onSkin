from pathlib import Path
import json,subprocess
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
folder=ROOT/'scripts/release/full-app-j01'
source=(folder/'source_consumer12.test.py').read_text(encoding='utf8')
source=source.replace('source12','source13').replace('source12_','source13_').replace('source12-','source13-')
source=source.replace('RELEASE12','RELEASE13').replace('R12_','R13_').replace('allowed12','allowed13').replace('validate12','validate13').replace('SECURITY-12','SECURITY-13').replace('Release12 fixture','Release13 fixture')
source=source.replace('check.validate11_checker','check.validate13_checker')
source=source.replace("for name in ('test_contract.py','source_consumer09.test.py','source_consumer10.test.py',\n                 'source_consumer11.test.py','dependency_guard11.test.py'):","for name in ('test_contract.py','source_consumer09.test.py','source_consumer10.test.py',\n                 'source_consumer11.test.py','dependency_guard11.test.py',\n                 'source_consumer12.test.py','dependency_guard12.test.py'):")
source=source.replace("check.RELEASE13_BASE),lambda p:git('show',':'+p))","check.RELEASE13_BASE),lambda p:git('show',':'+p))")
needle="            expect('complete-materialized-fixture-current',check.source13_guard,0)"
replacement="""            # Only authentic installed source-pin bytes are materialized here.
            # This fixture is explicitly not independent complete-checkout proof.
            manifest=json.loads((root/check.RELEASE13_MANIFEST).read_bytes())
            for row in manifest['unchangedNativeMappings']:
                for pin in row['notes']['sourcePins']:
                    target=fixture/pin['path'];target.parent.mkdir(parents=True,exist_ok=True)
                    target.write_bytes((root/pin['path']).read_bytes())
            expect('complete-materialized-fixture-current',check.source13_guard,0)"""
assert needle in source
source=source.replace(needle,replacement)
source=source.replace("git('cat-file','blob','843be0fdf1fe9354dfdc4750118481486d9a778a')","git('show',check.RELEASE13_BASE+':package-lock.json')")
source=source.replace("'candidate-activation-while-blocked'","'old-lock-cannot-masquerade-as-current-successor'").replace("code='R13_PATCH_UNAPPLIED'","code='R12_CANDIDATE_LOCK_SHA256'")
source=source.replace('check.RELEASE13_BLOCKER','check.RELEASE12_BLOCKER').replace("code='R13_BLOCKER_REMOVAL'","code='R13_SCOPE'")
source=source.replace("'refs/pull/15/merge'","'refs/pull/16/merge'")
source=source.replace("'stage/m103-security-source-recovery11'","'stage/m103-dependency-witness12'").replace("'stage/m103-dependency-witness12',repo=","'stage/m103-ios-privacy-lock-succession13',repo=")
source=source.replace("event['number']=15","event['number']=16")
source=source.replace("check.RELEASE11_BASE","check.RELEASE12_BASE")
# Keep the authentic finite path set: each original native path is protected.
source=source.replace("'scripts/phase9/security_acceptance/proposal.json',\n        'docs/brain/checkpoints", "'scripts/phase9/security_acceptance/proposal.json',\n        'docs/phase-9/ios-sdk-package-mapping.json','scripts/phase9/ios-privacy-source-audit.mjs',\n        'docs/phase-9/apple-ios-privacy-baseline.json',\n        'docs/brain/checkpoints")
(folder/'source_consumer13.test.py').write_bytes(source.encode('utf8'))

dependency=(folder/'dependency_guard12.test.py').read_text(encoding='utf8')
dependency=dependency.replace('dependency12','dependency13').replace('RELEASE12_MANIFEST','RELEASE13_MANIFEST').replace('RELEASE12_LOCK_SHA256','RELEASE12_LOCK_SHA256').replace('dependency12_guard','dependency13_guard')
# dependency13 returns the independently anchored native successor, whereas
# previous source/dependency controls keep exercising the old witness directly.
start=dependency.index('    for name, mutate in [')
end=dependency.index("    actual_lock=",start)
dependency=dependency[:start]+'''    for name, mutate in [
        ('wrong-version',lambda x:x.__setitem__('schemaVersion',2)),
        ('wrong-PR',lambda x:x.__setitem__('pr',16)),
        ('wrong-source',lambda x:x['base'].__setitem__('commit','0'*40)),
        ('wrong-original-lock',lambda x:x['originalLock'].__setitem__('sha256',check.RELEASE12_LOCK_SHA256)),
        ('fake-native-archive',lambda x:x['claims'].__setitem__('releaseArchive','INSPECTED')),
        ('fake-Apple',lambda x:x['claims'].__setitem__('appleAttestation','ACCEPTED')),
        ('wrong-user-space-classification',lambda x:x['candidateNodes']['node_modules/vitest'].__setitem__('dev',False)),
        *[(f'enable-{key}',lambda x,k=key:x['admissions'].__setitem__(k,True)) for key in authority['admissions']],
        *[(f'clear-{key}',lambda x,k=key:x['gates'].__setitem__(k,'PASS')) for key in authority['gates']],
    ]:
        value=copy.deepcopy(authority); mutate(value)
        expect(name,overrides={check.RELEASE13_MANIFEST:(json.dumps(value,indent=2)+'\\n').encode()})
    for row in authority['registry']:
        for key in ('metadata','attestations'):
            path=row[key]['path']
            expect('altered-'+key+':'+row['path'],overrides={path:check.regular(check.ROOT/path)+b' '})
    for path in (authority['provenance']['path'],authority['dependencyWitness']['path'],
                 authority['originalMapping']['path']):
        expect('altered-protected-witness:'+path,overrides={path:check.regular(check.ROOT/path)+b' '})
    for path in authority['unchangedNativeNodes']:
        for key in ('version','integrity','resolved'):
            value=json.loads(current);value['packages'][path][key]='forged'
            expect('altered-native:'+path+':'+key,(json.dumps(value,indent=2)+'\\n').encode())
    for path in ('package.json','apps/mobile/package.json'):
        expect('changed-declaration:'+path,overrides={path:check.regular(check.ROOT/path)+b' '})
    expect('authentic-restored',expected=0)
''' + dependency[end:]
dependency=dependency.replace("actual_lock=check.regular(check.ROOT/'package-lock.json')","actual_lock=check.git('show',check.RELEASE13_BASE+':package-lock.json')")
dependency=dependency.replace('check.unapplied12_guard(actual_lock)','check.unapplied12_guard(actual_lock,lambda p:check.git(\'show\',check.RELEASE13_BASE+\':\'+p))')
dependency=dependency.replace("return overrides.get(path,check.regular(check.ROOT/path))","return overrides.get(path,check.git('show',check.RELEASE13_BASE+':'+path))")
(folder/'dependency_guard13.test.py').write_bytes(dependency.encode('utf8'))
candidate=subprocess.check_output(['git','show','b74d999799d7f6843b335c91b6974596629ce20f:package-lock.json'],cwd=ROOT)
(ROOT/'package-lock.json').write_bytes(candidate)
print('created two finite Campaign13 harnesses; exact candidate lock applied')
