from pathlib import Path
import hashlib,json,zipfile
HERE=Path(__file__).resolve().parent
def read(artifact,name):
    with zipfile.ZipFile(HERE/('source-security-'+str(artifact)+'.zip')) as z:return z.read(name)
secret=json.loads(read(12603897996,'secret-scan-proof.json'))
assert secret['source']['tree']=='542aa50815c26d6ce1acc1bb431f8d886d40a2a8'
commands={k:{'exit':v['exit'],'stdout_sha256':v['stdout_sha256'],'stderr_sha256':v['stderr_sha256']} for k,v in secret['commands'].items()}
current_count=len(secret['commands']['gitleaks-current']['report'])
sarif=json.loads(read(12603897996,'gitleaks-results.sarif'))
history_count=sum(len(x.get('results',[])) for x in sarif['runs'])
audit=json.loads(read(12603384081,'npm-audit-high.json'))
primaries={name:[{k:a.get(k) for k in ['source','name','title','url','severity','range']} for a in node.get('via',[]) if isinstance(a,dict)] for name,node in audit.get('vulnerabilities',{}).items() if any(isinstance(x,dict) for x in node.get('via',[]))}
review={'qualification':'FRESH_IMMUTABLE_SOURCE_HEAD_ORIGINAL_JOBS; SANITIZED_AGGREGATES_ONLY','source_commit':'b835356f4c4a45cd0a8fab8de744d16bc63f1ea5','source_tree':secret['source']['tree'],'ci_merge_head':secret['source']['head'],'run':40206037618,'commands':commands,'gitleaks_current_findings':current_count,'gitleaks_history_findings':history_count,'findings_disposition':'UNREVIEWED; scanner findings are not automatically confirmed exposed credentials','coverage':'Original pinned source inventories/rules/targets and independent qualified custody remain unaccepted; exact source tree is not full-coverage acceptance.','npm_primary_advisories':primaries,'patched_vitest_advisories_present':any('GHSA-qxg6-89mg-rqv8' in json.dumps(audit) or 'GHSA-xp26-3454-mjgp' in json.dumps(audit) for _ in [0]),'npm_exception_errors':read(12603384081,'npm-exception-gate.stderr').decode().splitlines(),'osv_exception_errors':read(12604025299,'osv-exception-gate.stderr').decode().splitlines(),'original_decision':json.loads(read(12603059642,'g97-decision.json')),'raw_secret_artifacts_published':False,'acceptanceGranted':False}
assert not review['patched_vitest_advisories_present']
(HERE/'security-artifact-review13.json').write_bytes((json.dumps(review,indent=2)+'\n').encode())
print(json.dumps({k:review[k] for k in ['source_commit','source_tree','gitleaks_current_findings','gitleaks_history_findings','patched_vitest_advisories_present','original_decision','raw_secret_artifacts_published']}))
