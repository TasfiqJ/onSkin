import datetime,json,subprocess,sys,urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
label,commit=sys.argv[1:]
result=subprocess.run(['git','credential','fill'],input='protocol=https\nhost=github.com\n\n',capture_output=True,text=True,cwd=ROOT,check=True)
credential=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
def api(path):
    req=urllib.request.Request('https://api.github.com/repos/TasfiqJ/onSkin/'+path,headers={'Authorization':'Bearer '+credential['password'],'User-Agent':'onSkin-Campaign13','Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(req,timeout=40) as response:return json.load(response)
runs=api('actions/runs?head_sha='+commit+'&event=pull_request&per_page=100')['workflow_runs']
assert all(run['head_sha']==commit for run in runs)
rows=[]
for run in runs:
    jobs=api('actions/runs/'+str(run['id'])+'/jobs?per_page=100')['jobs']
    rows.append({'run':run,'jobs':jobs})
pr=api('pulls/17')
summary={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit,'observations':rows,'pr':{k:pr.get(k) for k in ['number','state','draft','merged','auto_merge','maintainer_can_modify','merge_commit_sha']},'head_sha':pr['head']['sha'],'base_sha':pr['base']['sha']}
(HERE/(label+'-ci-observed.json')).write_bytes((json.dumps(summary,indent=2)+'\n').encode())
for row in rows:
    run=row['run'];print(json.dumps({'workflow':run['name'],'id':run['id'],'head':run['head_sha'],'status':run['status'],'conclusion':run['conclusion'],'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in row['jobs']]}),flush=True)
print(json.dumps({'pr':summary['pr'],'head_sha':summary['head_sha'],'base_sha':summary['base_sha']}))
