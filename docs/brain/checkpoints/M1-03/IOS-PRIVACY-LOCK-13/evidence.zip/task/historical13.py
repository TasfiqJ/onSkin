from pathlib import Path
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
TARGET=HERE/'independent-complete'
def git(*args):return subprocess.check_output(['git',*args],cwd=TARGET)
def run(name,argv):
    return subprocess.run([sys.executable,str(HERE/'run_at.py'),name,str(TARGET),*argv]).returncode
assert not git('status','--porcelain=v1')
assert not (TARGET/'.git/objects/info/alternates').exists()
argv=[sys.executable,'-B','scripts/release/full-app-j01/check.py']
refs=[('12','bbbd59073b7add22ac350bced0d9a34124c12ffb'),
      ('11','9e3ba80e09579ee4855948f13297049791c4d5d7'),
      ('10','14805e7f708297e72419035f517acc41ba52da70'),
      ('09','8ac97c32901272d97d1bff05f2abc294811055a6'),
      ('08','d08347f0011672cd309d835628c094b5e9f4725d')]
for label,ref in refs:
    git('switch','--detach',ref)
    assert not git('status','--porcelain=v1')
    assert run('historical13-release'+label+'-current',argv)==0
    path=TARGET/'package-lock.json';raw=path.read_bytes()
    try:
        path.write_bytes(raw+b' ')
        assert run('historical13-release'+label+'-malicious',argv)==1
    finally:path.write_bytes(raw)
    assert run('historical13-release'+label+'-restored',argv)==0
    assert not git('status','--porcelain=v1')
(HERE/'historical-proof13.json').write_bytes((json.dumps({'qualification':'INDEPENDENT_COMPLETE_CHECKOUT_SEPARATE_GIT_OBJECTS','endpoints':dict(refs),'original_lock_witness':[0,1,0],'alternates':False,'acceptance':False},indent=2)+'\n').encode())
git('fetch','--no-tags','origin','refs/heads/stage/m103-ios-privacy-lock-succession13')
git('switch','--detach','b835356f4c4a45cd0a8fab8de744d16bc63f1ea5')
assert not git('status','--porcelain=v1')
assert run('independent-cold-ci13',['node',r'C:\Users\jasim\AppData\Roaming\npm\node_modules\npm\bin\npm-cli.js','ci','--cache',str(HERE/'npm-independent-cache13'),'--no-audit','--no-fund'])==0
assert hashlib.sha256((TARGET/'package-lock.json').read_bytes()).hexdigest()=='7656c2e6bf482df5a9bc94c9789816a40c5f2b5cfb30e2f10748411229c136cb'
assert not git('status','--porcelain=v1')
print('HISTORICAL_ENDPOINTS_0_1_0_AND_INDEPENDENT_COLD_SOURCE_READY',flush=True)
