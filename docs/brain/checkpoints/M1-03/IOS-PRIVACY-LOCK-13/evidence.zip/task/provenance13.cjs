const fs = require('node:fs');
const path = require('node:path');
const npm = path.join(process.env.APPDATA, 'npm/node_modules/npm');
const pacote = require(path.join(npm, 'node_modules/pacote'));
(async () => {
  const root = __dirname;
  const raw = Buffer.from(await (await fetch('https://registry.npmjs.org/-/npm/v1/keys')).arrayBuffer());
  fs.writeFileSync(path.join(root, 'registry-keys13.json'), raw);
  const keys = JSON.parse(raw).keys.map(key => ({...key,pemkey:`-----BEGIN PUBLIC KEY-----\n${key.key}\n-----END PUBLIC KEY-----`}));
  const rows = JSON.parse(fs.readFileSync(path.join(root, 'registry13.json'))).nodes;
  const verified=[];
  for (const row of rows) {
    const name=row.path.slice('node_modules/'.length);
    const mani=await pacote.manifest(name+'@4.1.12', {
      registry:'https://registry.npmjs.org/',fullMetadata:true,verifySignatures:true,verifyAttestations:true,
      '//registry.npmjs.org/:_keys':keys,cache:path.join(root,'npm-provenance-cache13'),tufCache:path.join(root,'tuf13'),
    });
    if (mani.dist.integrity!==row.integrity || mani._attestationBundles?.length!==2) throw Error('missing exact integrity/provenance');
    const statements=mani._attestationBundles.map(x=>({predicateType:x.predicateType,statement:JSON.parse(Buffer.from(x.bundle.dsseEnvelope.payload,'base64').toString())}));
    const provenance=statements.find(x=>x.predicateType==='https://slsa.dev/provenance/v1').statement;
    const build=provenance.predicate.buildDefinition;
    if (build.externalParameters.workflow.repository!=='https://github.com/vitest-dev/vitest' ||
        build.externalParameters.workflow.path!=='.github/workflows/publish.yml' ||
        build.externalParameters.workflow.ref!=='refs/heads/v4' ||
        build.resolvedDependencies[0].digest.gitCommit!=='4766ce1e72ded629d3a37637f57eeae643789a8c') throw Error('upstream mismatch');
    verified.push({path:row.path,registry_signature:'VERIFIED',attestations:'VERIFIED',statements});
    console.log(name+' FRESH_SIGNATURE_AND_PROVENANCE_VERIFIED');
  }
  fs.writeFileSync(path.join(root,'provenance13.json'),JSON.stringify({npm:'11.20.0',pacote:require(path.join(npm,'node_modules/pacote/package.json')).version,verified},null,2)+'\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
