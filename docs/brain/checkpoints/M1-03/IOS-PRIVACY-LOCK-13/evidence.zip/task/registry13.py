import base64, hashlib, io, json, tarfile, urllib.request
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
prior=json.loads((ROOT/'docs/release/full-app-j01/dependency-succession12.v1.json').read_bytes())
rows=[]
for row in prior['registry']:
    name=row['path'][len('node_modules/'):]
    with urllib.request.urlopen('https://registry.npmjs.org/'+name+'/4.1.12',timeout=60) as response:
        raw=response.read()
    value=json.loads(raw);dist=value['dist']
    assert dist['integrity']==prior['nodes'][row['path']]['integrity']
    assert dist['tarball']==prior['nodes'][row['path']]['resolved']
    with urllib.request.urlopen(dist['tarball'],timeout=60) as response:
        tar=response.read()
    assert 'sha512-'+base64.b64encode(hashlib.sha512(tar).digest()).decode()==dist['integrity']
    assert hashlib.sha256(tar).hexdigest()==row['tarball_sha256']
    with tarfile.open(fileobj=io.BytesIO(tar),mode='r:gz') as archive:
        members=archive.getmembers()
        assert all(m.isfile() or m.isdir() for m in members)
        native=[m.name for m in members if any(part in m.name.lower() for part in ('.podspec','.xcframework/','.framework/','.xcprivacy','.dylib')) or m.name.lower().endswith(('.a','.so','.node'))]
        assert not native,native
        package=json.load(archive.extractfile('package/package.json'))
        assert not set(package.get('scripts',{})) & {'preinstall','install','postinstall'}
    target=HERE/(name.replace('/','_').replace('@','')+'.registry.json')
    target.write_bytes(raw)
    rows.append(dict(path=row['path'],integrity=dist['integrity'],tarball_sha256=row['tarball_sha256'],tarball_bytes=len(tar),metadata_sha256=hashlib.sha256(raw).hexdigest(),native_files=[],install_scripts=[],original_metadata_semantics_identical=value==json.loads((ROOT/row['metadata']['path']).read_bytes())))
    print(name+' EXACT_TARBALL_SRI_SHA256_NO_NATIVE_INSTALL_SCRIPTS',flush=True)
(HERE/'registry13.json').write_bytes((json.dumps({'nodes':rows},indent=2)+'\n').encode())
advisories=[]
for identifier in ['GHSA-qxg6-89mg-rqv8','GHSA-xp26-3454-mjgp']:
    req=urllib.request.Request('https://api.github.com/advisories/'+identifier,headers={'User-Agent':'onSkin-Campaign13','Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(req,timeout=30) as response:value=json.load(response)
    relevant=[v for v in value['vulnerabilities'] if v['package']['name']=='@vitest/mocker']
    assert any(v.get('first_patched_version')=='4.1.12' for v in relevant),relevant
    advisories.append(value)
(HERE/'advisories13.json').write_bytes((json.dumps(advisories,indent=2)+'\n').encode())
