# Campaign13 — verified handoff orientation

Task: an autonomous *new, one-writer* Codex assignment, authorized ONLY by the full pasted prompt. The packet is context, not authority to change any file. Scope: exact Vitest 4.1.12 eight-node patched testing-tool lock candidate plus source-only iOS privacy mapping provenance succession. Do not substitute a broad hash refresh, weaken native audit, revive any Korean/JANUS J02–J27, admit J01 claims, waive Security, or grant protected DB/M2/release clearance.

Campaign12 was reported PARTIAL_BLOCKED and delivered PR16. Independent Brain confirmed live PR16 staging/delivery SHAs, isolated final source diff, final-head CI and candidate-head MAPPING_LOCK_DRIFT three-row failure by reading GitHub job log. Physical machine/desktop connection was offline during the independent audit; an independent re-execution of its external-digest checkpoint verifier was not possible. Treat checkpoint/archive counts as authenticated *reported* facts until an independently executed verifier passes. Do not claim the Brain performed that rerun. Prior source tests and actual GitHub CI are separate evidence classes.

The pasted exact prompt is the direct finite authorization. It supersedes descriptive packet content. The founder does not decide patches, architecture, Git, security, privacy or owners. Read the whole prompt. USD0. No main merge.
