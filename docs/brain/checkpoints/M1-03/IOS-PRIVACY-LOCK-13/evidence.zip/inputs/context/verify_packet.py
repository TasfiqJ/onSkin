#!/usr/bin/env python3
"""Read-only independently anchored Campaign13 packet verifier; context only."""
import hashlib,json,pathlib,stat,sys,unicodedata,argparse

R=pathlib.Path(__file__).resolve().parent
PLACEHOLDER=b'__EXTERNAL_MANIFEST_SHA256__'
def digest(data): return hashlib.sha256(data).hexdigest()
def reject(msg):raise ValueError(msg)
def namekey(path):
    if not isinstance(path,str) or not path or path.startswith('/') or '\\' in path or ':' in path or any((not x or x in ('.','..') or x.endswith('.') or x.strip()!=x) for x in path.split('/')):reject('UNSAFE_PATH: '+str(path))
    return unicodedata.normalize('NFKC',path).casefold()
def read_regular(path):
    for c in [path,*path.parents]:
        info=c.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&1024:reject('LINK_COMPONENT '+str(c))
        if c==path and not stat.S_ISREG(info.st_mode):reject('NOT_REGULAR '+str(c))
    return path.read_bytes()
def pairs(p):
    d={}
    for k,v in p:
        if k in d:reject('DUPLICATE_KEY '+str(k))
        d[k]=v
    return d

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--expected-manifest-sha256',required=True);args=ap.parse_args()
    expected=args.expected_manifest_sha256
    if len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected):reject('INVALID_EXTERNAL_SHA')
    manifest_raw=read_regular(R/'manifest.json')
    if digest(manifest_raw)!=expected:reject('EXTERNAL_MANIFEST_MISMATCH')
    manifest=json.loads(manifest_raw,object_pairs_hook=pairs)
    if manifest['authority']!='BRAIN-M103-IOS-PRIVACY-LOCK-SUCCESSION13-CANDIDATE-01':reject('AUTHORITY')
    names=[f['path'] for f in manifest['files']]
    if len(set(map(namekey,names)))!=len(names):reject('DUPLICATE_PATH')
    actual=[]
    for p in R.rglob('*'):
        if p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&1024:reject('SYMLINK')
        if p.is_file():actual.append(p.relative_to(R).as_posix())
        elif not p.is_dir():reject('NONREGULAR')
    if set(actual)!=set(names)|{'manifest.json','EXACT_PROMPT.md'}:reject('FILE_INVENTORY')
    for f in manifest['files']:
        data=read_regular(R/f['path'])
        if len(data)!=f['bytes'] or digest(data)!=f['sha256']:reject('FILE_TAMPER '+f['path'])
    template=read_regular(R/'PROMPT_TEMPLATE.md')
    if template.count(PLACEHOLDER)!=1:reject('TEMPLATE_PLACEHOLDER')
    expected_prompt=template.replace(PLACEHOLDER,expected.encode('ascii'))
    if read_regular(R/'EXACT_PROMPT.md')!=expected_prompt:reject('PROMPT_NOT_DERIVED')
    print('VERIFIED: '+str(len(names))+' authenticated regular files, manifest SHA256='+expected+', exact prompt derived. Context only; source/security/database/J01/release admissions NONE.')
if __name__=='__main__':
    try:main()
    except Exception as exc:print('CONTEXT_INVALID: '+str(exc),file=sys.stderr);sys.exit(1)
