# Real candidate-head failure and authentic protected files

Original iOS privacy mapping path: `docs/phase-9/ios-sdk-package-mapping.json`; immutable at PR16 blob `9776ac1b83e79c39e71b34867481d71cb56a29a4`, SHA256 `9821f06f2ae17b76b3f633eee24ef95dd36f39f13ca6770235e3f9d8bd2de246`. Its v1 `lockIntegrity.packageLockSha256` in EXACTLY three mapped packages = `99aa497f2d0cc2ca237167403fbbb9d9aee0a4e42fa991ea44f9661487ecf568`:

- `@react-native-google-signin/google-signin` v16.1.2, mapped Apple GoogleSignIn source candidate;
- `expo-image` v57.0.5, mapped SDWebImage source candidate;
- `react-native` v0.86.3, mapped Hermes source candidate (plus hermes-compiler lock entry).

These are source-only *candidates*: Podfile.lock, native release archive/frameworks, signature and App Store privacy declarations NOT proven. Do not change statuses or fake signed archives.

Original mapping parser/contract `scripts/phase9/ios-privacy-contract.mjs` blob `3ca1f9a55e43ffd358f7c7a86dffa3174436e59c`. `mappingErrors()` near lines 1519–1595, in particular 1558–1567 requires mapping's entire lock SHA256 equal the currently read `package-lock.json`. It also verifies each mapped package's version/integrity and installed native source pins. Source writer `scripts/phase9/ios-privacy-source-audit.mjs` blob `b908d68e44f00b19d2b0a0d128eeb8468a4b04e9` MUST stay byte-stable. Existing source tests `scripts/phase9/ios-privacy-source-audit.test.mjs` blob `2a254283688b0143edc4887dc305b06b1b3d0b1d`.

Original root lock SHA256 `99aa497f2d0cc2ca237167403fbbb9d9aee0a4e42fa991ea44f9661487ecf568`, Git blob `e53de80bf46db8f7a7fcd97781971911e2d328bd` at PR15 and PR16 FINAL.

Exact vetted eight-node Vitest 4.1.12 candidate lock SHA256 `7656c2e6bf482df5a9bc94c9789816a40c5f2b5cfb30e2f10748411229c136cb`, Git blob `843be0fdf1fe9354dfdc4750118481486d9a778a` at historical immutable PR16 candidate source commit `b74d999799d7f6843b335c91b6974596629ce20f` (tree `d8f13fca77945f8f7015e7392cd97b300ccb3494`). Eight reviewed nodes are in `docs/brain/contracts/SECURITY-11/dependency-patch.v1.json` and `docs/release/full-app-j01/dependency-succession12.v1.json`; latter SHA256 `5f3ac49ea52a6e4b955bb31495324f157d2d5a85d0d55ca1b66216e7faa565a2`. Exact provenance and registry files are `docs/brain/contracts/SECURITY-12/registry/**`; preserve bytes.

Original candidate CI Quality run `40163991148`, repository job `121081172942`, step `Verify installed iOS native sources` FAIL: native source tests passed, then source check emitted THREE `MAPPING_LOCK_DRIFT` errors for each listed mapping and exited1. The candidate lock changed testing-tool nodes, not those native mappings. No workaround was applied. Current PR16 final original lock passes source checks; Quality green. The proposed patch is UNAPPLIED.

Prior blocker `docs/brain/contracts/SECURITY-12/dependency-install-blocker.v1.json` SHA256 `d52d4153dd4f718559aa2a7461824d013545f37929f609ca677fa7cd9f50ab35` is immutable. Original iOS privacy mapper v1 remains immutable; new separately reviewed successor MUST authenticate original whole-lock witness and current candidate and preserve exact three package identities/native source pin checks.
