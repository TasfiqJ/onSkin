# Pinned GitHub status independently observed October 25, 2026

Repo: TasfiqJ/onSkin.

- PR16 `stage/m103-dependency-witness12`: FINAL HEAD `bbbd59073b7add22ac350bced0d9a34124c12ffb`, TREE `4a70f0934a56e27863742084272c9bb4bfd5492d`, DRAFT OPEN UNMERGED, base PR15.
- PR16 measured SOURCE `b95f469650b30bffafc86bad039b93d678e54cac`, TREE `a6d3077b85617248aa9beb4c0b45fb3299b3016f`.
- PR15 `stage/m103-security-source-recovery11`: `9e3ba80e09579ee4855948f13297049791c4d5d7`, TREE `0c3d2dc79a54a405315df06f05d284bd643cd538`.
- PR14 `stage/full-app-j01-quality-projections10`: `14805e7f708297e72419035f517acc41ba52da70`.
- PR13 `stage/full-app-j01-source-packet-ci09`: `8ac97c32901272d97d1bff05f2abc294811055a6`.
- PR12 `stage/full-app-j01-release-contract08`: `d08347f0011672cd309d835628c094b5e9f4725d`.
- PR11 `stage/m1-retained-resilience`: `50f25abeafaa6127e105e2a9d825e6d15dc1dcdb`.
- PR10 Security `stage/m1-gate-recovery`: `cd2bd51997f283c0b446bf2124f427f482550fa8`.
- `main`: `d9912f4c8b30358593569c5b9b4e84773c6f463e`.

All old refs were OPEN/DRAFT/UNMERGED as applicable, and protected/read-only. Re-fetch every ref/tree and check working tree/one writer before touching code. Do not trust a stale snapshot if any ref moved.

Final PR16 workflows at DELIVERY head: Quality `40165532845` success (repository gates, canonical DB reset and structural tests, PG15/17 deletion, iOS/Android Expo exports PASS); Security `40165532856` failure (secret/static OSV/code/source-only acceptance, live Supabase SKIPPED); iOS source-only contract `40165532859` success. Exact job IDs: Quality source `121085683606`, canonical DB `121085683741`, PG15 `121085683711`, PG17 `121085683733`, Expo android `121087886863`, ios `121087886881`; Security code `121085683442`, static `121085683552`, secret `121085683642`, source acceptance `121086490348`, live skipped `121085684140`; iOS `121085683434`.

The green canonical local DB at this exact evidence head is NOT protected DB06/DB08/R2B acceptance or hosted provider execution. Previous registry Data limit exceeded must remain an historical job failure, not fraudulently erased.
