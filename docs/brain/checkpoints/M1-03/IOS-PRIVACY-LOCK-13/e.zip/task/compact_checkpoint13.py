from pathlib import Path
import hashlib,json,subprocess,zipfile
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
CP=ROOT/'docs/brain/checkpoints/M1-03/IOS-PRIVACY-LOCK-13'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
assert git('rev-parse','HEAD').decode().strip()=='48c35bbfde28256c63d0b8790709cea2af165589'
assert not git('status','--porcelain=v1')
expected={'README.md','archive-index.json','completion-report.json','evidence.zip','manifest.json','protected-files.json.gz','source-proof.json','verify_checkpoint.py'}
assert {p.name for p in CP.iterdir()}==expected
old={p.name:p.read_bytes() for p in CP.iterdir()}
entries={}
with zipfile.ZipFile(CP/'evidence.zip') as z:
    for name in z.namelist():entries[name]=z.read(name)
for name,raw in old.items():entries['previous-checkpoint/'+name]=raw
proof=json.loads(old['source-proof.json'])
completion=json.loads(old['completion-report.json'])
completion['retained_failures'].append('First final-head original governed-evidence test failed git ENOBUFS: tracked docs path output1048876 bytes exceeded its protected default1048576 buffer by300 bytes. Evidence compacted into four current paths without touching the test/guard or removing evidence. The underlying inventory buffer is a separately scoped maintenance ceiling.')
completion['evidence_compaction']={'previous_head':'48c35bbfde28256c63d0b8790709cea2af165589','previous_tree':'1ca299019b166ad16f849873896683ec9ae6ec6c','previous_manifest_sha256':'2820dd6b9dd47124e55ebddc690042404a721e89b571d2d11653f0ae346361bc','before_docs_path_bytes':1048876,'legacy_max_buffer_bytes':1048576,'expected_after_docs_path_bytes':1048566,'remaining_bytes':10,'protected_test':'scripts/launch/governed-evidence-chain.test.mjs','protected_test_sha256':sha((ROOT/'scripts/launch/governed-evidence-chain.test.mjs').read_bytes()),'owner':'Release provenance/source-inventory custodian; future buffer correction UNAPPLIED outside finite grant','all_original_evidence_preserved':True}
entries['checkpoint/source-proof.json']=old['source-proof.json']
entries['checkpoint/protected-files.json.gz']=old['protected-files.json.gz']
entries['checkpoint/completion-report.json']=(json.dumps(completion,indent=2)+'\n').encode()
for name in ['final-quality13.log','final-ci-observed.json','independent-delivery-proof13.json','security-local-parity13.json','final-security-review13.json','compact_checkpoint13.py']:
    entries['task/'+name]=(HERE/name).read_bytes()
readme='''# Campaign13 source candidate and compact evidence checkpoint

PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED. Exact eight-node Vitest4.1.12 candidate
APPLIED through the pinned source-only native successor. Original mapping, producers,
old contracts and all independent custody remain unchanged/unaccepted. USD0.

This checkpoint uses four tracked paths to fit an unchanged protected original
test's1MiB Git docs-filename buffer. Its first final-head run failed ENOBUFS300 bytes
over that ceiling. All earlier files, failed raw receipts and full evidence remain
inside e.zip and immutable Git history. No guard, inventory or diagnostic is bypassed.
Current filename inventory fits by10 bytes; future expansion needs separately scoped
release-provenance custodian work on the protected test. That fix is UNAPPLIED.

Copy the external m.json SHA256 from the final report and run in a clean full clone:

    python -B docs/brain/checkpoints/M1-03/IOS-PRIVACY-LOCK-13/v.py --expected-manifest-sha256 EXTERNAL_SHA256

m.json authenticates all current checkpoint files, every ZIP entry and the root
handoff. e.zip contains checkpoint/source-proof.json, completion-report.json and
protected-files.json.gz, the full original archive and prior checkpoint copies.
v.py checks source/modes/blobs/intermediates,23290 protected old files, pinned trees,
absences and every evidence-tail state. Only task-created checkpoint paths may be
compacted; original protected files cannot be deleted. It grants no acceptance.

Independent complete23308-file source checkout: separate Git objects, no alternates
or hardlinks, cold dependencies. Real governance lock/native installed-source/Phase4
workflow-input0/1/0 and original Release08-12 endpoint0/1/0 passed. Disposable fixture,
historical, primary and independent evidence classes stay separate. Original151
semantic negatives,68 source/66 dependency refusals, previous23/44/58/9/55/49 controls,
forced6190 root tests and uncached typecheck/lint/launch/source-packet pass in their
exact recorded versions. Final pushed-head CI and verifier are reported separately.

Original native ledgers, schema1, warnings, archive_required and false claims are
unchanged. Phase4 preserves14 tasks,7 blocked/7 scaffold,420 occurrences,0 missing.
Raw secret reports are withheld; sanitized original current/history1144/4388 findings,
remaining advisories, expired reviews, source inventory and70-test21/19 failures remain.
Canonical registry quota failure is separate from PostgreSQL rehearsals and protected
DB06/DB08/R2B custody. Final-head actual failures/skips never become PASS.

G97 FAIL/NO_GO; DB not accepted; M1-03 blocked/not accepted; M2 not authorized;
J01 intake/G1/G2/G3/G5 and separate G4, native/Apple/provider/paid/clinical/readiness/
CAT07/public release closed. F09 required; F18/J02-J27/J05 deferred. Brain alone
audits source and later ordinary promotion. No merge, self-acceptance or purchase.
'''.encode()
v=(HERE/'verify_checkpoint13.py').read_text(encoding='utf8')
v=v.replace("regular(HERE/'manifest.json')","regular(HERE/'m.json')")
v=v.replace("set(manifest['files'])|{'manifest.json'}","set(manifest['files'])|{'m.json'}")
v=v.replace("proof=parse(regular(HERE/'source-proof.json'))", """# ponytail: four paths fit the protected1MiB inventory; a larger guard buffer needs separate scope.
    def archived(name):
        with zipfile.ZipFile(HERE/'e.zip') as archive:
            return archive.read(name)
    proof=parse(archived('checkpoint/source-proof.json'))""")
v=v.replace("gzip.decompress(regular(HERE/'protected-files.json.gz'))","gzip.decompress(archived('checkpoint/protected-files.json.gz'))")
old_tail="""        for line in git('diff','--raw','--no-abbrev','--no-renames','-z',parents[1],commit).split(b'\\0')[::2]:
            if line:
                require(line.decode().split()[1]=='100644' and line.decode().split()[-1] in ('A','M'),
                    'EVIDENCE_TAIL_MODE')"""
new_tail="""        fields=git('diff','--raw','--no-abbrev','--no-renames','-z',parents[1],commit).split(b'\\0')
        require(fields[-1]==b'' and len(fields)%2==1,'EVIDENCE_DIFF_SHAPE')
        for n in range(0,len(fields)-1,2):
            meta=fields[n].decode().split();path=fields[n+1].decode()
            if meta[-1]=='D':
                require(path.startswith(PREFIX) and path not in tree(SOURCE) and
                    meta[0]==':100644' and meta[1]=='000000','COMPACTION_ONLY_TASK_CREATED_PATH')
            else:
                require(meta[1]=='100644' and meta[-1] in ('A','M'),'EVIDENCE_TAIL_MODE')"""
assert old_tail in v
v=v.replace(old_tail,new_tail)
v=v.replace("index=parse(regular(HERE/'archive-index.json'))","index=manifest['archive_index']")
v=v.replace("zipfile.ZipFile(HERE/'evidence.zip')","zipfile.ZipFile(HERE/'e.zip')")
entries['task/compact-v13.py']=v.encode()
index={}
with zipfile.ZipFile(CP/'e.zip','x') as archive:
    for name,raw in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,raw);index[name]=dict(bytes=len(raw),sha256=sha(raw))
(CP/'v.py').write_bytes(v.encode())
(CP/'README.md').write_bytes(readme)
handoff=(ROOT/'ONSKIN_BRAIN_HANDOFF.txt').read_text(encoding='utf8').replace('Use the externally supplied manifest SHA256 from the final report;','Use the externally supplied m.json SHA256 with checkpoint v.py from the final report;')
handoff+='Checkpoint compaction: README.md,m.json,e.zip,v.py retain all evidence inside e.zip. Original protected Git docs-inventory test is unchanged; prior ENOBUFS and future buffer-owner blocker are recorded.\n'
(ROOT/'ONSKIN_BRAIN_HANDOFF.txt').write_bytes(handoff.encode())
for name in expected-{'README.md'}:
    path=CP/name
    assert path.resolve().parent==CP.resolve() and not path.is_symlink() and path.read_bytes()==old[name]
    path.unlink()  # Only exact task-created bytes, already archived and preserved in Git history.
files={name:dict(bytes=(CP/name).stat().st_size,sha256=sha((CP/name).read_bytes()),mode='100644') for name in ['README.md','e.zip','v.py']}
manifest={'version':1,'authorization':'BRAIN-M103-IOS-PRIVACY-LOCK-SUCCESSION13-CANDIDATE-01','source':proof['source'],'files':files,'archive_index':index,'handoff_sha256':sha(handoff.encode()),'acceptanceGranted':False,'release':'NO_GO'}
(CP/'m.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode());digest=sha((CP/'m.json').read_bytes())
(HERE/'checkpoint-manifest-sha13.txt').write_bytes((digest+'\n').encode())
print(json.dumps({'manifest_sha256':digest,'files':4,'archived_files':len(index),'docs_filename_bytes_expected':1048566,'legacy_test':'UNCHANGED'}))
