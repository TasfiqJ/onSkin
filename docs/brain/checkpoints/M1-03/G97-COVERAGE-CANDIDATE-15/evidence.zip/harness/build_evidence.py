"""Build only the four-file evidence tail after the immutable source freeze."""
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import zipfile

RUN=Path(__file__).resolve().parent
ROOT=Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code\source-recovery11-5ca49b38f6ad44539feab22fc4ca507e\source')
sys.path.insert(0,str(ROOT/'scripts/security15'))
import source_bindings as b
import verify_candidate as v
frozen=b.parse((RUN/'frozen-source.json').read_bytes())
source,tree=frozen['source'],frozen['tree']
assert b.git(ROOT,'rev-parse','HEAD').decode().strip()==source
checkpoint=ROOT/b.CHECKPOINT
candidate=(RUN/'candidate-sealed.jsonl.gz').read_bytes()
header,rows=v.payload(candidate)
assert (header['source'],header['tree'])==(source,tree)
assert b.sha(candidate)=='bacf85f331fd1b23378ddac00a0154c04ff92f263f8c9a1b715f53ac79d241e1'
assert b.parse((RUN/'sealed-independent-proof.json').read_bytes())['source']==source
assert b.parse((RUN/'candidate-sealed.receipt.json').read_bytes())['exit']==0
assert b.parse((RUN/'inherited-proof.json').read_bytes())
base=b.snapshot(ROOT,b.BASE);current=b.snapshot(ROOT,source)
changed={n:dict(before=base.get(n),after=current.get(n)) for n in sorted(set(base)|set(current)) if base.get(n)!=current.get(n)}
protected={n:r for n,r in base.items() if n not in changed}
scope=dict(source=source,tree=tree,base=dict(source=b.BASE,tree=b.TREE),source_delta=changed,
           protected_unchanged=protected,source_commits=b.git(ROOT,'rev-list','--reverse',b.BASE+'..'+source).decode().splitlines(),
           original_inventory=header['original_files'],current_inventory=header['current_files'],
           original_manifest_sha256=b.inv.PINS['source-manifest.json'],original_targets_sha256=b.inv.PINS['scan-targets.json.gz'],
           protected_absences=header['protected_absences'])
packet=b.parse((ROOT/'docs/release/full-app-j01/g97-source-coverage15.unapplied.json').read_bytes())
packet['frozen_source']=dict(commit=source,tree=tree,candidate_sha256=b.sha(candidate),
                            candidate_member='candidate.jsonl.gz',candidate_status='OWNER_REVIEW_REQUIRED')
for task in packet['tasks']:
    task['review_target']=dict(commit=source,tree=tree,candidate_sha256=b.sha(candidate))
    task['owner_decision']='NOT_PERFORMED'
    task['permitted_paths']=['scripts/security15/'+n for n in ('build_candidate.py','verify_candidate.py','test_candidate.py','test_integrity.py','source_bindings.py')]+['scripts/release/full-app-j01/check.py','scripts/release/full-app-j01/source_consumer15.test.py','docs/brain/contracts/SECURITY-15/**','docs/brain/task-specs/SECURITY-15/**','docs/release/full-app-j01/g97-source-coverage15.md','docs/release/full-app-j01/g97-source-coverage15.unapplied.json',b.CHECKPOINT+'**','ONSKIN_BRAIN_HANDOFF.txt']
    task['conditional_projection_paths']=['docs/phase-4/generated/source-worklist.json','docs/phase-4/generated/source-worklist.md']
    task['protected_inventory']='source-scope.json.gz::protected_unchanged; every other baseline path outside the finite human grant remains read-only'
readme=f"""# Campaign15 complete source candidate â€” OWNER_REVIEW_REQUIRED

PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED. Authority {b.AUTHORITY}.
Frozen source {source}; tree {tree}. PR19 remains draft/open/unmerged, stacked only on immutable PR18.
Candidate member evidence.zip::candidate.jsonl.gz; SHA256 {b.sha(candidate)}.
Original {header['original_files']} identities; current {header['current_files']} paths; {header['counts']}.
Every original/current identity and archive is retained, including source scripts/docs and historical evidence.
Policy refusals and review needs: {header['blockers']}. No new exclusion is installed.

This four-file evidence tail is NEW_UNACCEPTED_EVIDENCE. It is separately scoped and authenticated, never waived from an original scan.
The snapshot was computed after source freeze. The policy contains stable finite invariants; it contains no impossible future commit hash.
The externally anchored manifest authenticates this verifier, archive, every member, immutable executable sources and the full candidate.
tail-plan.json names every cumulative tail delta and preimage. The manifest authenticates the archive and itself via the mandatory external digest;
the final evidence commit/tree and all tail blobs/SHA256 are measured after commit and supplied in the final PR/return, avoiding circular self-hashes.
No recursive evidence chain is created. Source CI observations in this archive are separate from final evidence-head CI.

Run from a complete byte-preserving checkout with all stack objects and Python3.9+:
python -B {b.CHECKPOINT}verify15.py --expected-manifest-sha256 <EXTERNAL_DIGEST_FROM_FINAL_PR_OR_RETURN>

The verifier authenticates executable imports before execution, recomputes the entire immutable source candidate and original coverage witnesses,
checks original policy refusals, safe path/regular modes, index/worktree identity and exactly one compact evidence-only tail.
Wrong digest, changed evidence, incomplete inventory or unauthorized tail paths refuse. Exit0 means technical consistency only.

Resolved, source/payload-bound owner packets are evidence.zip::resolved-owner-packets.json.
High-impact private-key/service-token review, original current/history scanner replay and coverage successor decisions,
expired proposal replacement, OSV Zod/node-forge/braces and scanner-runtime opentelemetry-api/certifi/mcp,
independent DB06/DB08/R2B custody and genuine readiness/CAT07 remain UNAPPLIED and require qualified owners.
Gitleaks aggregates are UNREVIEWED; verified-only TruffleHog exit0 does not dispose of them.
No raw matches, finding paths/lines, individual fingerprints, private artifacts or credential values are packaged.

G97 FAIL/NO_GO; DB NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED.
J01 authenticated dossier/G1/G2/G3/G5 and separate longitudinal G4, native/device/provider/paid/Apple/legal/clinical/readiness/CAT07/public gates remain closed.
F09 encrypted private history/manual comparison REQUIRED; F18 and J02â€“J27 including J05 DEFER. No positive pore metrics or medical claims.
STOP_FOR_QUALIFIED_SECURITY_CUSTODIAN. USD0. No merge, provider action or self-acceptance.
"""
(checkpoint/'README.md').open('xb').write(readme.encode())
handoff=f"""Campaign15 PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED; source candidate only.
PR19 https://github.com/TasfiqJ/onSkin/pull/19; stage/m103-g97-coverage-candidate15 stacked on immutable PR18.
Frozen source {source}; tree {tree}.
Checkpoint: {b.CHECKPOINT}README.md
Use verify15.py with the external manifest SHA256 supplied in the final PR/return.
Complete {header['current_files']}-path candidate remains OWNER_REVIEW_REQUIRED; original scanner SOURCE_INVENTORY_DRIFT remains FAIL.
STOP_FOR_QUALIFIED_SECURITY_CUSTODIAN; owner decisions and private finding review remain UNAPPLIED.
G97 FAIL/NO_GO; DB NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED; J01 and release closed.
USD0. No merge, credential/provider/Apple action or self-acceptance.
"""
(ROOT/'ONSKIN_BRAIN_HANDOFF.txt').write_bytes(handoff.encode())
members={'candidate.jsonl.gz':candidate,'source-scope.json.gz':gzip.compress(b.canonical(scope),mtime=0),
         'resolved-owner-packets.json':b.canonical(packet)+b'\n'}
for p in sorted(RUN.iterdir()):
    if p.is_file() and (p.name.endswith(('.receipt.json','.log')) or p.name in (
        'source-ci-observed.json','source-db-failure.json','source-findings.aggregate.json',
        'sealed-findings.aggregate.json','independent-proof.json','sealed-independent-proof.json',
        'inherited-proof.json','frozen-source.json','sealed-worklist-proof.json')):
        members['receipts/'+p.name]=p.read_bytes()
notes=dict(failures_preserved=[
    'Original Security source genuinely FAILS SOURCE_INVENTORY_DRIFT; expected pending original-owner migration.',
    'Initial source15 deletion fixture attempted to delete an already-absent example; corrected; final115 refusals pass.',
    'Initial source-only/build checks overlapped owned source changes and refused INCOMPLETE; before/after identities retained.',
    'Initial Node768MiB typecheck OOM exit134;4096MiB forced rerun passed; no source workaround.',
    'Earlier source343 GitHub Quality was automatically cancelled by the final source update; never claimed PASS.',
    'Local native audit/archive fixtures retain their actual Windows symlink skips.',
    'Python3.9 orchestration helpers lacked hashlib.file_digest and Path.write_text(newline=); corrected without source-policy changes.',
    'One unquoted PowerShell tree expression and an oversized orchestration command failed; corrected using bounded bytes/arguments.',
    'Historical no-checkout fixture initially had no materialized index; checked out the exact endpoint before running controls.'
],classification='TECHNICAL_SOURCE_EVIDENCE_ONLY_NO_QUALIFIED_SIGNATURE',
    source_consumer=dict(refusals=115,positives=6,class_='REAL_GIT_FIXTURE_NOT_INDEPENDENT_COMPLETE_CHECKOUT'),
    independent='Complete separate objects/no alternates/no hardlinks source consistency only; no Security/custody/native/release qualification',
    phase4='Original producer is current on the clean frozen independent source. Primary check during untracked checkpoint construction refused DIRTY/stale; no source-stale projection was regenerated. Clean final-tail check is recorded externally.14 items7blocked7scaffold420occurrences0missing.',
    source_guard='Original Release08â€“14 AST/global/module controls preserved; original66 provenance and finite8MiB buffer untouched.',
    public='No disabled gate enabled; F09 required,F18/J02-J27/J05 defer; J01 and public release closed.')
members['classification.json']=b.canonical(notes)+b'\n'
for p in sorted((ROOT/'../../campaign15-context-k66v4r0x').resolve().iterdir()):
    if p.is_file():members['authenticated-context/'+p.name]=p.read_bytes()
members['harness/build_evidence.py']=Path(__file__).read_bytes()
members['harness/run.py']=(RUN/'run.py').read_bytes()
tail_names=[b.CHECKPOINT+n for n in ('README.md','verify15.py','manifest.json','evidence.zip')]+['ONSKIN_BRAIN_HANDOFF.txt']
plan={n:dict(before=dict(mode=current[n]['mode'],blob=current[n]['blob']) if n in current else None,
             status='NEW_UNACCEPTED_EVIDENCE') for n in sorted(tail_names)}
members['tail-plan.json']=b.canonical(plan)+b'\n'
archive=checkpoint/'evidence.zip'
with archive.open('xb') as output:
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,data in sorted(members.items()):
            info=zipfile.ZipInfo(n,date_time=(2026,10,25,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data)
assert v.archive(archive.read_bytes())==members
def receipt(data):
    return dict(bytes=len(data),sha256=b.sha(data),blob=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest(),mode='100644')
tool_names=['scripts/security15/'+n for n in ('source_bindings.py','build_candidate.py','verify_candidate.py')]
tool_names+=['scripts/security14/source_inventory.py','scripts/release/full-app-j01/check.py']
manifest=dict(schema=1,status='OWNER_REVIEW_REQUIRED',acceptanceGranted=False,source=source,tree=tree,
    candidate_sha256=b.sha(candidate),source_count=len(current),base=b.BASE,base_tree=b.TREE,
    files={n:receipt((checkpoint/n).read_bytes()) for n in ('README.md','verify15.py','evidence.zip')},
    tools={n:receipt((ROOT/n).read_bytes()) for n in tool_names},
    members={n:dict(bytes=len(data),sha256=b.sha(data)) for n,data in sorted(members.items())},
    tail='EXACTLY_ONE_NEW_UNACCEPTED_EVIDENCE_COMMIT',spend_usd=0)
(checkpoint/'manifest.json').open('xb').write(b.canonical(manifest)+b'\n')
print(b.canonical(dict(source=source,tree=tree,candidate_sha256=b.sha(candidate),
      manifest_sha256=b.sha((checkpoint/'manifest.json').read_bytes()),archive_sha256=b.sha(archive.read_bytes()),
      archive_bytes=archive.stat().st_size,members=len(members),source_delta=len(changed),protected_unchanged=len(protected))).decode())
