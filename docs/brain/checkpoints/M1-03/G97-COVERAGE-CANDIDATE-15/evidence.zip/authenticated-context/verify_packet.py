"""Validate a safely extracted Campaign15 packet from an EXTERNAL manifest SHA256."""
from pathlib import Path
import argparse, hashlib, json, os, re, stat, sys, unicodedata
ROOT=Path(__file__).resolve().parent
ANCHOR='BRAIN-M103-G97-FULL-COVERAGE15-CANDIDATE-01'

def check(value,label):
    if not value:raise ValueError(label)

def sha(data):return hashlib.sha256(data).hexdigest()

def name_key(name):
    check(isinstance(name,str) and re.fullmatch(r'[A-Za-z0-9._/-]+',name) and not name.startswith('/') and
          all(part and part not in ('.','..') and not part.endswith('.') and
              part.casefold() not in ('.git','con','nul','aux','prn') for part in name.split('/')),
          'UNSAFE_NAME')
    return unicodedata.normalize('NFKC',name).casefold()

def regular(p):
    for q in (p,*p.parents):
        s=q.lstat()
        check(not stat.S_ISLNK(s.st_mode) and not getattr(s,'st_file_attributes',0)&1024,'LINK_REPARSE')
    s=p.lstat();check(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and s.st_size<=1024*1024,'NONREGULAR')
    return p.read_bytes()

def object_pairs(rows):
    obj={}
    for k,v in rows:
        check(k not in obj,'DUPLICATE_JSON_KEY');obj[k]=v
    return obj

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-manifest-sha256',required=True)
    a=parser.parse_args()
    check(re.fullmatch('[0-9a-f]{64}',a.expected_manifest_sha256) is not None,'EXPECTED_SHA_SHAPE')
    mraw=regular(ROOT/'manifest.json')
    check(sha(mraw)==a.expected_manifest_sha256,'EXTERNAL_MANIFEST_MISMATCH')
    manifest=json.loads(mraw,object_pairs_hook=object_pairs)
    check(manifest['schema']==1 and manifest['authority']==ANCHOR and
          manifest['mode']=='AUTHENTICATED_HANDOFF_CONTEXT_ONLY' and manifest['acceptanceGranted'] is False,
          'MANIFEST_AUTHORITY')
    entries=manifest['files'];check(isinstance(entries,list) and len(entries)>=5,'FILE_COUNT')
    expected={'manifest.json','EXACT_PROMPT.md'};normalized=set()
    for row in entries:
        key=name_key(row['path'])
        check(key not in normalized and row['path'] not in expected,'MANIFEST_PATH_DUPLICATE')
        normalized.add(key);expected.add(row['path'])
        raw=regular(ROOT/row['path'])
        check(row['bytes']==len(raw) and row['sha256']==sha(raw) and row['mode']=='100644',
              'FILE_DIGEST:'+row['path'])
    physical=set()
    for p in ROOT.rglob('*'):
        s=p.lstat()
        check(not stat.S_ISLNK(s.st_mode) and not getattr(s,'st_file_attributes',0)&1024,'PACKET_LINK')
        check(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode),'PACKET_SPECIAL')
        if p.is_file():physical.add(p.relative_to(ROOT).as_posix())
    check(physical==expected,'PACKET_FILES_OR_ABSENCE')
    template=regular(ROOT/'PROMPT_TEMPLATE.md')
    derived=template.replace(b'{{EXPECTED_MANIFEST_SHA256}}',a.expected_manifest_sha256.encode())
    check(template.count(b'{{EXPECTED_MANIFEST_SHA256}}')==1 and
          regular(ROOT/'EXACT_PROMPT.md')==derived,'EXACT_PROMPT_DERIVATION')
    print('VERIFIED: '+str(len(entries))+' authenticated regular files + exact derived prompt; context only; Security, DB, J01 and release NOT_ACCEPTED')

if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,TypeError,OSError,UnicodeError) as e:
        print('CONTEXT_INVALID:',type(e).__name__,str(e));sys.exit(1)
