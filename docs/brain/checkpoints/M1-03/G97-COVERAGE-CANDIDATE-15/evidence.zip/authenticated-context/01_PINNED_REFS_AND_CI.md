# Live immutable refs and Campaign14 independently reviewed CI

Checked on October 25, 2026 by independent Brain using GitHub connector.

- PR18 `stage/m103-g97-provenance-triage14`: `53cf869c5fc5f13ecd18dc1ef9c3a6288eaae51a`, tree `1c483dedfb4c5d51994be07f65f1a40bdd52be73`, draft/open/unmerged, targets PR17.
- Campaign14 measured source: `63c7d910ec85659f3180e4ea7ddd41c7f44e2c5c`, tree `5d914609352e75b112997dea7043c6bfc0913ba1`.
- PR17 `d0c5ad49ba22c8da7136d59a399589af1cea0e82`, tree `4cfe9c819df4c22fc5d19d79f9c0e89e0e24c973`.
- PR16 `bbbd59073b7add22ac350bced0d9a34124c12ffb`.
- PR15 `9e3ba80e09579ee4855948f13297049791c4d5d7`.
- PR14 `14805e7f708297e72419035f517acc41ba52da70`.
- PR13 `8ac97c32901272d97d1bff05f2abc294811055a6`.
- PR12 `d08347f0011672cd309d835628c094b5e9f4725d`.
- PR11 `50f25abeafaa6127e105e2a9d825e6d15dc1dcdb`.
- PR10 Security `cd2bd51997f283c0b446bf2124f427f482550fa8`.
- `main` `d9912f4c8b30358593569c5b9b4e84773c6f463e`.
All older PRs draft/open/unmerged in latest check. Recheck before writes/final.

FINAL-head Campaign14 CI at `53cf869...`:
- Quality run `40220375919` FAIL overall: canonical DB job `121250455458` `H01_SQL_PROBE_FAILED`, Docker registry `Rate exceeded` (historical earlier registry `Data limit exceeded`). No database source changed.
- Repository quality job `121250455575` PASS incl original 66 governed provenance tests, original 151 semantic negative cases and forced root 6190 tests.
- PG15 job `121250455564` PASS; PG17 `121250455375` PASS.
- Expo iOS `121254852402` PASS and Android `121254852408` PASS, source exports only.
- iOS source-only `40220375935` PASS.
- Security `40220375925` FAIL: secret job `121250455470`, static OSV `121250455591`, code `121250455683`, automated source acceptance `121251333431`; live Supabase `121250456256` SKIPPED.

No source-only checks authorize Security, hosted database custody, M1-03, M2, clinical, paid, Apple or release GO.
