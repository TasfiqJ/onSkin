# onSkin V2 Campaign15 — authenticated orientation

This context belongs to independent ChatGPT Brain authorization `BRAIN-M103-G97-COVERAGE15-CANDIDATE-01` and is supplied to a NEW Codex chat. The FULL pasted exact prompt is authoritative, not this orientation. Founder makes no technical decisions; Codex is one autonomous implementation writer; Brain later independently accepts scoped source only. No merges, secret exposure, spend or release.

Start from PR18 final HEAD `53cf869c5fc5f13ecd18dc1ef9c3a6288eaae51a`, tree `1c483dedfb4c5d51994be07f65f1a40bdd52be73`, stacked PR17. Re-fetch LIVE refs/ancestry, root/nested instructions, clean workspace and safety before writing.

GOAL: NEW fail-closed complete source-coverage candidate for the original G97 owner to review, covering every source and historical evidence path rather than omitting changed paths. Also exact fresh scanner diagnostic reconciliation with no credential publication. Original G97 acceptance remains FAIL. A candidate is NOT the original Security manifest and does NOT waive findings or replace qualified Security custody.
