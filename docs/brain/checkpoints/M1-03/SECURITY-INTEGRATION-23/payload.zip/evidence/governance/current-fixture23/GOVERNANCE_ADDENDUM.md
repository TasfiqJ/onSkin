# Campaign23 governance addendum — pre-tail, source only

Authority: BRAIN-M1X-SECURITY-INTEGRATION23-REPAIR-01. Date: 2026-10-28 (America/Toronto). This is scoped governance and historical-fixture evidence. Source acceptance remains SUBMITTED_REVIEW_REQUIRED; release remains NO_GO.

## Exact source and preservation

The fixture dispatch was committed as worker `77186abb9e27c0864d4302645bc42c66f978a153`, tree `edc04827a25a85139ef2da8545d250513fbaec2c`, and integrated at root `1bd95e82cc3c8dbcc16afaf839f2adeaed628105`, tree `a56098ae58100d74b453c2be2748008be5201e16`. The checker bytes are identical at both commits: SHA256 `5d1786de3ddf5de4a1c0a3e67b5beed793b908b34de4b045a65c28233c83bd26`.

All 201,170 inherited checker-prefix bytes and 136 earlier function definitions remain byte/AST-preserved against exact PR26. The original `main()` and terminal entry point are unchanged. All original 151-case script bytes remain identical to Release08: SHA256 `191f74631da86413c687801c7a620bbe01c0bd7d98c83f6bdd72947faf2ec455`. Every pre-existing line of the 141-refusal consumer is retained in sequence; new controls were appended. The current consumer SHA256 is `0af8a3e73d1dc7d5419591b0dcb4e19abd8b60ca77094106e1b78822f0b82f18`.

The default current validation retains its complete source23 guard, inherited baseline replay and current error handling. Its original try/check/error-path AST is unchanged, apart from normalizing a path alias of the real current BUNDLE to that same canonical BUNDLE. A noncanonical spelling resolving to the current BUNDLE cannot select historical fixture mode.

## Explicit historical fixture route

Only an explicit external `--bundle-dir` selects the separately identified historical fixture path. Its authenticated checker is immutable Release08 `d08347f0011672cd309d835628c094b5e9f4725d`, tree `0998881bc543840395dca375769ea1b7c9a8d4c7`, checker SHA256 `7118308899a2b6b89e98680697d486b85dacd9b9fad8702cdf39a54751f6b822`.

The eight canonical files actually consumed by that checker match their authentic Release08 SHA256 values byte-for-byte: schema, five contract/matrix/history documents, and two historical snapshots. The fourteen original bundle files are unchanged; fifteen later additions are outside this old checker's input set. No fixture-meaning conflict was found. A changed canonical input or forged schema refuses rather than inheriting historical trust.

Actual submitted mutant bytes are read through bounded, stable regular23 reads and captured as the input snapshot. They are not replaced by old inputs. The complete selected snapshot is checked again after validation; a mutation during the check refuses. Only source witnesses declared by the authentic canonical documents and fixed historical validator may use immutable Git-backed source bytes. A forged reference to an unapproved public tracked file was refused before its content was opened. No private-path control was attempted.

The actual checkout ROOT remains unchanged. Successful fixture results say `HISTORICAL_BUNDLE_FIXTURE_ONLY_NOT_CURRENT_SOURCE`, with current source/governance/acceptance `NOT_CHECKED_CURRENT`, every admission false and NO_GO. Errors retain the original safe error family first—including the `SCHEMA_` prefix—and append a fixed historical-only scope suffix. This preserves the unchanged original assertions and exit 1 meanings. It does not produce current-source, Security, native or release acceptance.

Seven legitimate earlier Campaign23 checker profiles are bound by exact content hashes. There is no general allowance to omit the current reader or fixture helper.

## Executed controls

| Execution | Exact scope | Result |
|---|---|---|
| Unmodified current source CLI before fixture dispatch | Root `4e14d1fc414ee22bcd8af73176ece161aa45d8f8`, tree `82a1195ccead556f1de76a9110597eede88a2886`; normal installed source; Python 3.9.13 | Exit 0, 323.375 seconds, head/status unchanged, clean before/after, stderr empty. Current source-governance only; NOT acceptance. |
| Unchanged current `test_contract.py` using explicit historical fixtures | Committed worker `77186abb`, checker SHA256 above; authentic Release08 semantics; actual mutants | Exit 0, 191.140 seconds. All original 151 negatives plus current/restored controls passed; clean before/after. The script's own qualification remains BUNDLE_FIXTURES_ONLY_NOT_INDEPENDENT_CHECKOUT. |
| Current committed consumer, Windows Python 3.9.13 | Same worker head/tree and exact checker/consumer bytes | Exit 0, 33.469 seconds; 156 refusals / 33 positives; clean after. |
| Current committed consumer, authenticated official Windows Python 3.12.10 | Same worker head/tree and exact checker/consumer bytes | Exit 0, 33.500 seconds; 156 refusals / 33 positives; clean after. |

New controls cover explicit/default dispatch, noncanonical current-path selection, authentic and forged earlier checker profiles, unchanged canonical inputs, actual unmodified and mutated fixtures, forged schema/checker/tree, missing and hard-linked inputs, mutation during validation, unapproved source-witness refusal, error disclosure, historical-only failure labels and restoration. Existing source/evidence and no-admission assertions remain executed.

The earlier 180-second direct CLI attempt timed out and is retained as incomplete; it is not passed evidence. A separate instrumented read-only probe measured the current source23 guard at 34.828 seconds and the explicit PR25 historical replay at 207.281 seconds, both exit 0. That stage probe is not a whole-CLI substitute. The subsequent unmodified whole CLI completed with the larger finite deadline above. Runtime projections for repeated fixture calls were Windows estimates, not observed Ubuntu CI failures.

The post-dispatch default CLI at root `1bd95e82` is being collected independently by root in a normal installed remote clone. This addendum does not convert the earlier 4e14 execution into that later proof. Root owns final-head CI, the two final independent checkouts, strict Phase4, the sole evidence tail, delivered artifact controls and downloaded-byte verification.

An already-started isolated-worker normal `npm ci --no-audit --no-fund` completed in 80.921 seconds with exit 0 and mandatory postinstall, without Turbo or root-checkout changes. The no-audit installation option is not a dependency scan or finding waiver; required public advisories remain separately open.

## Evidence and boundaries

Selected receipts are `GOVERNANCE_PRESERVATION_FIXTURE23.json`, `fixture08-current-input-authentication.json`, `original151-current-script-fixture23.receipt.json`, and the two `consumer23-fixture-committed-python*.receipt.json` files. Raw local logs are separate and need not be published.

The earlier original 151 execution at immutable Release08 and all historical consumers 09–22 remain separate successful evidence with their original qualifications. Partial historical native pins are not a complete historical installation. Fixture replay is not current positive proof. G97 remains FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED. Native/J01/VoiceOver/provider/clinical/legal/Apple/public release remain closed. USD0; no merge.

One earlier public Git-fixture command completed four technical controls, then exited 1 when ordinary cleanup hit a Windows read-only Git object. A subsequent bounded native cleanup request was rejected before process creation as “blocked by policy,” without a more specific reason. No retry, move, deliberate read, alternate wrapper, identity or delegated cleanup occurred after that review denial. The retained directory stays outside the source checkout and is excluded from all package inputs. These facts do not grant acceptance.
