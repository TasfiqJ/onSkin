# Time-bound verified GitHub refs and CI — 2026-10-25

Repo `TasfiqJ/onSkin`. All refs must be re-fetched live before decisions and delivery; this is not an indefinite lease.

| Ref | Exact HEAD | State |
|---|---|---|
| PR15 `stage/m103-security-source-recovery11` | `9e3ba80e09579ee4855948f13297049791c4d5d7` | draft/open/unmerged; tree `0c3d2dc79a54a405315df06f05d284bd643cd538` |
| PR14 `stage/full-app-j01-quality-projections10` | `14805e7f708297e72419035f517acc41ba52da70` | draft/open/unmerged; tree `90c9427743b99fb43747d68cd55e413d2aee3ad4` |
| PR13 `stage/full-app-j01-source-packet-ci09` | `8ac97c32901272d97d1bff05f2abc294811055a6` | draft/open/unmerged |
| PR12 `stage/full-app-j01-release-contract08` | `d08347f0011672cd309d835628c094b5e9f4725d` | draft/open/unmerged |
| PR11 `stage/m1-retained-resilience` | `50f25abeafaa6127e105e2a9d825e6d15dc1dcdb` | draft/open/unmerged |
| PR10 `stage/m1-gate-recovery` | `cd2bd51997f283c0b446bf2124f427f482550fa8` | draft/open/unmerged |
| `main` | `d9912f4c8b30358593569c5b9b4e84773c6f463e` | unchanged |

Campaign11 source commit `90a2b90bc859172683fd4a352ddd4cb13b307e89`, tree `d3b9e8c6626d8b04632ec586ee408b160d8f0393`. Six source commits and three evidence-only commits in PR15. Final PR15 head is `9e3ba80...` and branch remains draft, no auto-merge. No main merge.

**Exact PR15 final-head CI (Github Actions attempt1)**: Quality #40156333953 FAIL overall; Repository quality gates PASS (job121058417805), PostgreSQL15/17 rehearsals PASS (jobs121058417988,121058418021), Expo iOS/Android SOURCE exports PASS (jobs121060282524,121060282567), canonical DB #121058418041 FAIL with `H01_SQL_PROBE_FAILED: exit-nonzero`, registry `Data limit exceeded`. Security #40156333954 FAIL: secret #121058418024, static/OSV #121058418115, code #121058418190, original source-only acceptance #121059261377 all FAIL; live Supabase #121058418724 SKIPPED. iOS source-only #40156333972 PASS (job121058417880). The earlier PR14 canonical job #121019681930 PASSED; it is historical and no protected DB acceptance.

Live branch mismatch/dirty writer stops work; no force/reset/rebase. Read-only links: https://github.com/TasfiqJ/onSkin/pull/15 ; https://github.com/TasfiqJ/onSkin/actions/runs/40156333953 ; https://github.com/TasfiqJ/onSkin/actions/runs/40156333954 .
