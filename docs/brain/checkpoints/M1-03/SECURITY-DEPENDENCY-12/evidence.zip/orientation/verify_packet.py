"""Verify externally anchored Campaign12 orientation ZIP extraction; grants no source approval."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import stat
import sys
import unicodedata

HERE = Path(__file__).resolve().parent
TOKEN = '{{MANIFEST_SHA256}}'

def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode('ascii')+b'\0'+data).hexdigest()
def key(path):
    if not isinstance(path,str) or not re.fullmatch(r'[A-Za-z0-9_.-]+',path) or path in ('.','..'):
        raise ValueError('BAD_FILENAME')
    return unicodedata.normalize('NFKC',path).casefold()
def read_file(path):
    v=path.lstat()
    if not stat.S_ISREG(v.st_mode) or stat.S_ISLNK(v.st_mode) or getattr(v,'st_file_attributes',0)&1024:
        raise ValueError('NONREGULAR_FILE:'+path.name)
    return path.read_bytes()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--expected-manifest-sha256',required=True)
    args=parser.parse_args()
    anchor=args.expected_manifest_sha256
    if not re.fullmatch('[0-9a-f]{64}',anchor): raise ValueError('INVALID_EXTERNAL_DIGEST')
    raw=read_file(HERE/'manifest.json')
    if sha(raw)!=anchor: raise ValueError('EXTERNAL_MANIFEST_SHA256_MISMATCH')
    manifest=json.loads(raw.decode('utf-8'))
    if manifest['id']!='BRAIN-M103-DEPENDENCY-WITNESS12-CANDIDATE-01' or manifest['version']!=1:
        raise ValueError('WRONG_AUTHORITY')
    rows=manifest['files']; names=[entry['path'] for entry in rows]
    expected=set(names)|{'manifest.json','EXACT_PROMPT.md'}
    if len(expected)!=len(names)+2 or len({key(p) for p in expected})!=len(expected):
        raise ValueError('NAME_COLLISION')
    actual=set()
    for entry in HERE.iterdir():
        key(entry.name)
        if not stat.S_ISREG(entry.lstat().st_mode) or entry.is_symlink():
            raise ValueError('NONREGULAR_ENTRY:'+entry.name)
        actual.add(entry.name)
    if actual!=expected: raise ValueError('INVENTORY_MISMATCH')
    for row in rows:
        data=read_file(HERE/row['path'])
        if len(data)!=row['bytes'] or sha(data)!=row['sha256'] or blob(data)!=row['blob'] or row['mode']!='100644':
            raise ValueError('FILE_TAMPER:'+row['path'])
    template=read_file(HERE/'PROMPT_TEMPLATE.md')
    if template.count(TOKEN.encode())!=1: raise ValueError('TEMPLATE_DERIVATION')
    expected_prompt=template.replace(TOKEN.encode(),anchor.encode('ascii'))
    if read_file(HERE/'EXACT_PROMPT.md')!=expected_prompt: raise ValueError('EXACT_PROMPT_DERIVATION')
    print(f'VERIFIED: {len(rows)} manifest entries; exact prompt derivation; authority scoped; no source/security/release admission')

if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,OSError,UnicodeError,json.JSONDecodeError) as error:
        print('CONTEXT_INVALID:',error,file=sys.stderr)
        sys.exit(1)
