# Verified history and unauthorised patch blocker

Campaign11 source of record: `docs/brain/contracts/SECURITY-11/dependency-patch.v1.json` (from immutable PR15). It records EIGHT audited Vitest4.1.12 npm lock nodes: `@vitest/expect`, `@vitest/mocker`, `@vitest/pretty-format`, `@vitest/runner`, `@vitest/snapshot`, `@vitest/spy`, `@vitest/utils`, `vitest`. An earlier local cold install and graph tests passed, but the existing Release08–11 exact retained-source source-witness guard refused new root `package-lock.json` bytes. Campaign11 subsequently reverted the lock in reviewable commits, leaving final root package/app declarations and root lock exactly as PR14.

Original SHA256 `package-lock.json`: `99aa497f2d0cc2ca237167403fbbb9d9aee0a4e42fa991ea44f9661487ecf568`. Candidate lock SHA256 from Campaign11: `7656c2e6bf482df5a9bc94c9789816a40c5f2b5cfb30e2f10748411229c136cb`. The original project `docs/release/full-app-j01/contract.v1.json`, `matrix.v1.json` and `roadmap.v1.json` and historical checkpoint must not be edited; a new versioned exact candidate witness can supersede current working byte expectations **only** without altering archived proof. `scripts/release/full-app-j01/check.py` still checks current root lock against the original historical witness, so simply writing the patched lock is invalid.

PR15 source commit sequence and change classes:
- `8db06270f5200aa5bf79cca3c7eddcc211b3dca2`: CORE05/CORE06 source tests
- `5d1928148c619cf3e8b537c3a438f1bdb8b46965`: first candidate root lock + dependency report
- `9942b5496cbe56360f82e776e892ddf12fb04b91`: original lock restored after witness refusal
- `6e9936ae3fec41bba3eecab12521deefd2bd5d56`: Release11 source guard/test
- `6730e61e00ca36d9632e94852cd34f528108f742`: owner packet/source guard
- `90a2b90bc859172683fd4a352ddd4cb13b307e89`: original Phase4 worklist JSON/Markdown regenerate

Original 151 semantics and prior source09(23)/source10(44)/source11(58) rejection controls must remain. Campaign11 dependency11(9) also required. Treat the Vitest advisories `GHSA-qxg6-89mg-rqv8` and `GHSA-xp26-3454-mjgp` as **live verification requests**, not a permanently accepted patched-version assertion. No source/dependency active grant or release approval arises from this packet.
