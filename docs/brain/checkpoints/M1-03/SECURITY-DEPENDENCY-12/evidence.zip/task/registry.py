from pathlib import Path
import urllib.request, urllib.parse, json, hashlib, base64, concurrent.futures, tarfile, io, datetime, subprocess
OUT = Path(__file__).resolve().parent
ROOT = Path(json.loads((OUT/'owner.json').read_text())['repo'])
CONTRACT = json.loads((ROOT/'docs/brain/contracts/SECURITY-11/dependency-patch.v1.json').read_bytes())
def fetch(row):
    path, node = row
    name = path[len('node_modules/'):]
    url = 'https://registry.npmjs.org/'+urllib.parse.quote(name, safe='')+'/4.1.12'
    raw = urllib.request.urlopen(url, timeout=40).read()
    metadata = json.loads(raw); dist = metadata['dist']
    assert metadata['name'] == name and metadata['version'] == '4.1.12'
    assert dist['integrity'] == node['integrity'] and dist['tarball'] == node['resolved']
    for key in ('dependencies', 'peerDependencies', 'peerDependenciesMeta', 'engines'):
        assert metadata.get(key) == node.get(key), (name, key)
    assert {k:v.removeprefix('./') for k,v in metadata.get('bin',{}).items()} == node.get('bin',{})
    tgz = urllib.request.urlopen(dist['tarball'], timeout=40).read()
    algorithm, value = dist['integrity'].split('-', 1)
    assert algorithm == 'sha512' and base64.b64encode(hashlib.sha512(tgz).digest()).decode() == value
    with tarfile.open(fileobj=io.BytesIO(tgz), mode='r:gz') as archive:
        assert not any(n.endswith(('.node','.so','.dll','.dylib')) for n in archive.getnames())
        package = json.load(archive.extractfile('package/package.json'))
        assert not any(k in package.get('scripts',{}) for k in ('preinstall','install','postinstall'))
    key = name.replace('/','_').replace('@','')
    (OUT/(key+'.registry.json')).write_bytes(raw)
    return dict(path=path, url=url, metadata_sha256=hashlib.sha256(raw).hexdigest(), tarball_sha256=hashlib.sha256(tgz).hexdigest(), integrity=dist['integrity'], integrity_verified=True, signatures=dist.get('signatures',[]), attestations=dist.get('attestations'), native_files=False, install_scripts=False, gitHead=metadata.get('gitHead'), repository=metadata.get('repository'))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
    rows = list(executor.map(fetch, CONTRACT['nodes'].items()))
report = dict(observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), nodes=rows, registry_integrity='VERIFIED_SHA512', qualification='HTTPS_REGISTRY_AND_TARBALL_INTEGRITY; signatures/provenance not yet verified')
(OUT/'registry12.json').write_bytes((json.dumps(report, indent=2)+'\n').encode())
candidate = subprocess.check_output(['git','show','5d1928148c619cf3e8b537c3a438f1bdb8b46965:package-lock.json'],cwd=ROOT)
assert hashlib.sha256(candidate).hexdigest() == '7656c2e6bf482df5a9bc94c9789816a40c5f2b5cfb30e2f10748411229c136cb'
original = subprocess.check_output(['git','show','9e3ba80e09579ee4855948f13297049791c4d5d7:package-lock.json'],cwd=ROOT)
before, after = json.loads(original), json.loads(candidate)
changed = [k for k in before['packages'] if before['packages'][k] != after['packages'][k]]
assert set(changed) == set(CONTRACT['nodes'])
expected = json.loads(original); expected['packages'].update(CONTRACT['nodes'])
assert expected == after and list(before['packages']) == list(after['packages'])
(OUT/'candidate-lock.json').write_bytes(candidate)
print(json.dumps(report,indent=2))
