from pathlib import Path
import json,subprocess,hashlib,zipfile,collections
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_text())['repo'])
BASE='9e3ba80e09579ee4855948f13297049791c4d5d7'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def witness(path):
    data=(ROOT/path).read_bytes()
    meta=subprocess.check_output(['git','ls-tree',BASE,'--',path],cwd=ROOT).decode().split('\t')[0].split()
    return dict(path=path,mode=meta[0],blob=meta[2],sha256=sha(data),bytes=len(data),unchanged_from_base=data==subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT))
artifacts=[]
for name in ['decision','secret','static','code']:
    p=HERE/('security11-'+name+'.zip')
    with zipfile.ZipFile(p) as archive:
        artifacts.append(dict(name=name,run_id=40156333954,head=BASE,sha256=sha(p.read_bytes()),entries=[dict(path=i.filename,sha256=sha(archive.read(i)),bytes=i.file_size) for i in archive.infolist()]))
with zipfile.ZipFile(HERE/'security11-secret.zip') as archive:
    proof=json.loads(archive.read('secret-scan-proof.json'))
    current=proof['commands']['gitleaks-current']['report']
    sarif=json.loads(archive.read('gitleaks-results.sarif'))
    secrets=dict(source_head=proof['source']['head'],source_tree=proof['source']['tree'],
        context=proof['context'],current_finding_count=len(current),history_finding_count=len(sarif['runs'][0]['results']),
        current_checkpoint_path_count=sum('docs/brain/checkpoints/' in x.get('File','') for x in current),
        current_findings='UNREVIEWED; current-source findings include retained evidence artifacts; location alone is not a disposition',
        exits={k:v['exit'] for k,v in proof['commands'].items()},
        tool_identities={k:{a:b for a,b in v.items() if a in ('asset','binary','url','version')} for k,v in proof['tools'].items()})
with zipfile.ZipFile(HERE/'security11-static.zip') as archive:
    advisory=archive.read('osv-exception-gate.stderr').decode()
summary=dict(qualification='LIVE_DOWNLOADED_IMMUTABLE_PR15_ARTIFACTS; NOT_CANDIDATE_SOURCE_SCAN',artifacts=artifacts,secrets=secrets,static_diagnostics=advisory.splitlines())
(HERE/'security11-artifact-review.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
paths=['package.json','apps/mobile/package.json','.github/workflows/security.yml','.github/workflows/quality.yml',
    'scripts/phase9/security_acceptance/proposal.json','scripts/phase9/security_acceptance/source-manifest.json',
    'scripts/phase9/security_acceptance/scan-targets.json.gz','scripts/phase9/security_acceptance/gitleaks.toml',
    'scripts/phase9/security_acceptance/semgrep-requirements-linux-py312.txt',
    'docs/phase-9/security-advisory-exceptions.json','scripts/phase4/build-source-worklist.mjs',
    'scripts/core05/adherence-source-contract.test.mjs','scripts/core06/recommendation-admission-source-contract.test.mjs']
protected=[witness(x) for x in paths]
actions=[
dict(id='SEC12-SOURCE',owner='Original Security source/coverage custodian plus independent qualified reviewer',status='UNAPPLIED_SCOPE_PROTECTED',
 problem='Unmodified source contract rejects SOURCE_INVENTORY_DRIFT; scanner source manifests/rules/inventories and expired original proposal remain protected.',
 next_action='Separately authorize a source-versioned inventory/coverage recovery bound to exact source tree, every scanner/tool/rule identity and all current/history targets. Rerun the unmodified original scanner suite and preserve every failure. No renewal by date edit.',
 protected_paths=['scripts/phase9/security_acceptance/','.github/security/','.github/workflows/security.yml']),
dict(id='SEC12-SECRET',owner='Qualified security incident/secret custodian independent of implementer',status='UNAPPLIED_FINDINGS_UNREVIEWED',
 problem='PR15 genuine current-source Gitleaks exit2 with 1144 findings; full-history Gitleaks exit2; verified-only TruffleHog exits0 do not dispose of Gitleaks findings.',
 next_action='Inspect original findings privately, establish actual issuer/scope/liveness, revoke or rotate real exposed credentials through authorized owners, attribute retained historical artifact findings without deleting history, then rerun complete current/history scans with exact source and reviewed genuine finding dispositions.',
 forbidden='No raw secret publication, invented fingerprints, shortened history or bulk allowlist.'),
dict(id='SEC12-ADVISORIES',owner='Qualified dependency/application security owner and scanner-runtime custodian',status='UNAPPLIED_REMAINING_RISK',
 problem='Vitest patch is a source candidate only. Zod3 finding requires a separately reviewed major-version compatibility plan; node-forge/braces exception reviews expired; braces advisory identity/status changed. Scanner runtime findings include certifi, mcp and opentelemetry-api.',
 next_action='Independently revalidate every live original finding against upstream, distinguish application graph from scanner/retained evidence runtimes, scope compatible repairs and qualified dispositions separately. No audit-fix, broad update, exception expiry edit or unreviewed Zod3-to4 migration.'),
dict(id='DB12-CUSTODY',owner='Independent DB06/DB08/R2B protected database custodian',status='UNAPPLIED_NOT_ACCEPTED',
 problem='PR15 canonical DB failed H01_SQL_PROBE_FAILED / registry Data limit exceeded. Historical PR14 PASS is not current-source or protected-custody acceptance.',
 next_action='Observe final-head canonical CI independently and obtain exact-source replay/acceptance under a separate protected custody grant. No hosted fallback, quota purchase, SQL/workflow edit or stale pass substitution.'),
dict(id='READINESS12',owner='Independent Brain, governed evidence and CAT07/provenance owners',status='UNAPPLIED_NOT_AUTHORIZED',
 problem='Qualified independent evidence, readiness/CAT07, authenticated J01 intake, native/Apple/provider/paid/clinical/public release gates remain closed.',
 next_action='Provide authentic separately authorized owner evidence and exact-source acceptance through Brain. Legacy runtime consumer migration stays NOT_DONE; no feature checkbox changes.')]
packet=dict(schema_version=1,authorization='BRAIN-M103-DEPENDENCY-WITNESS12-CANDIDATE-01',status='UNAPPLIED_EXTERNAL_SECURITY_CUSTODY',
 base=dict(commit=BASE,tree='0c3d2dc79a54a405315df06f05d284bd643cd538'),
 final_source_binding='The external-digest SECURITY-DEPENDENCY-12 checkpoint source-proof binds this file and the final measured source; this packet is not a signature or acceptance.',
 dependency_candidate=dict(manifest='docs/release/full-app-j01/dependency-succession12.v1.json',sha256='5f3ac49ea52a6e4b955bb31495324f157d2d5a85d0d55ca1b66216e7faa565a2',status='CANDIDATE_REVIEW_REQUIRED'),
 original_security_artifact_review=summary,protected_witnesses=protected,
 current_original_source_check=dict(argv=['python','-B','scripts/phase9/security_acceptance/contract.py','source'],exit=1,code='SOURCE_INVENTORY_DRIFT',acceptanceGranted=False),
 local_scanner_execution='Source preflight fails; original full Linux executable suite unavailable locally because registered WSL disk is missing. Original supported Python source tests and final-head original GitHub Security jobs are reported separately; no substitute scan is asserted.',
 actions=actions,qualified_owner_acceptance=None,security='FAIL/NO_GO',M1_03='BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED',M2='NOT_AUTHORIZED',spend_usd=0,
 admissions=dict(security=False,db=False,J01=False,paid=False,native=False,apple=False,public_release=False))
(ROOT/'docs/release/full-app-j01/security-custody12.unapplied.json').write_bytes((json.dumps(packet,indent=2)+'\n').encode())
print(json.dumps(dict(protected=len(protected),current_findings=len(current),history_findings=secrets['history_finding_count'],status=packet['status'])))
