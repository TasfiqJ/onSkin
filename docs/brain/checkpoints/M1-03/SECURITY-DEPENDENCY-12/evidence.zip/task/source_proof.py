from pathlib import Path
import gzip,hashlib,importlib.util,json,stat,subprocess,unicodedata
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_text())['repo'])
BASE='9e3ba80e09579ee4855948f13297049791c4d5d7'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def tree(ref):
    values={}
    for entry in git('ls-tree','-r','-z',ref).split(b'\0'):
        if entry:
            info,name=entry.decode().split('\t',1);mode,kind,blob=info.split()
            assert kind=='blob';values[name]=dict(path=name,mode=mode,blob=blob)
    return values
source=git('rev-parse','HEAD').decode().strip()
source_tree=git('rev-parse','HEAD^{tree}').decode().strip()
spec=importlib.util.spec_from_file_location('source12_proof',ROOT/'scripts/release/full-app-j01/check.py')
check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
base=tree(BASE);current=tree(source)
protected=[]
for path,row in base.items():
    if path in check.RELEASE12_EXISTING:continue
    assert current.get(path)==row,('protected git identity',path)
    protected.append(dict(row))
process=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for row in protected:
    process.stdin.write((row['blob']+'\n').encode());process.stdin.flush()
    header=process.stdout.readline().decode().split();size=int(header[2]);raw=process.stdout.read(size)
    assert len(raw)==size and process.stdout.read(1)==b'\n'
    row.update(sha256=sha(raw),bytes=len(raw))
    path=ROOT/row['path'];info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024,row['path']
    assert path.read_bytes()==raw,('protected working bytes',row['path'])
process.stdin.close();assert process.wait()==0
(HERE/'protected-files.json.gz').write_bytes(gzip.compress((json.dumps(protected,separators=(',',':'))+'\n').encode(),mtime=0))
changed=git('diff','--name-only',BASE,source).decode().splitlines()
changed=sorted(set(changed)|{'package-lock.json'})
source_files=[]
for path in changed:
    assert check.allowed12(path),path
    raw=git('show',source+':'+path)
    assert raw==(ROOT/path).read_bytes(),('source working bytes',path)
    source_files.append(dict(current[path],sha256=sha(raw),bytes=len(raw)))
chain=[]
for commit in git('rev-list','--reverse',BASE+'..'+source).decode().splitlines():
    parents=git('rev-list','--parents','-n','1',commit).decode().split()[1:]
    assert len(parents)==1
    delta=git('diff-tree','--no-commit-id','--name-status','-r',commit).decode().splitlines()
    assert all(check.allowed12(x.split('\t')[-1]) for x in delta)
    chain.append(dict(commit=commit,tree=git('rev-parse',commit+'^{tree}').decode().strip(),parents=parents,delta=delta))
pins=[('main','d9912f4c8b30358593569c5b9b4e84773c6f463e'),('PR10','cd2bd51997f283c0b446bf2124f427f482550fa8'),
    ('PR11','50f25abeafaa6127e105e2a9d825e6d15dc1dcdb'),('PR12','d08347f0011672cd309d835628c094b5e9f4725d'),
    ('PR13','8ac97c32901272d97d1bff05f2abc294811055a6'),('PR14','14805e7f708297e72419035f517acc41ba52da70'),('PR15',BASE),
    ('Campaign11 source','90a2b90bc859172683fd4a352ddd4cb13b307e89')]
proof=dict(authority='BRAIN-M103-DEPENDENCY-WITNESS12-CANDIDATE-01',source=dict(commit=source,tree=source_tree),
    base=dict(commit=BASE,tree=check.RELEASE12_TREE),pinned_refs=[dict(ref=name,commit=ref,tree=git('rev-parse',ref+'^{tree}').decode().strip(),
        source_merge_base=git('merge-base',ref,source).decode().strip(),ancestor=subprocess.run(['git','merge-base','--is-ancestor',ref,source],cwd=ROOT,capture_output=True).returncode==0) for name,ref in pins],
    protected_files=len(protected),source_files=source_files,source_chain=chain,source_status='CANDIDATE_REVIEW_REQUIRED',
    old_checker_functions='AST_IDENTICAL_EXCEPT_SOURCE_GUARD',old_tests='BYTE_IDENTICAL',spend_usd=0,acceptanceGranted=False)
(HERE/'source-proof.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
print(json.dumps(dict(source=proof['source'],protected_files=len(protected),changed_files=len(source_files),source_commits=len(chain))))
