from pathlib import Path
import datetime,gzip,hashlib,json,shutil,subprocess,zipfile
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_bytes())['repo'])
CHECKPOINT=ROOT/'docs/brain/checkpoints/M1-03/SECURITY-DEPENDENCY-12'
SOURCE='b95f469650b30bffafc86bad039b93d678e54cac'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def dump(path,value):path.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
assert git('rev-parse','HEAD').decode().strip()==SOURCE
assert not git('status','--porcelain=v1')
proof=json.loads((HERE/'source-proof.json').read_bytes());assert proof['source']['commit']==SOURCE
independent=json.loads((HERE/'independent-proof.json').read_bytes());assert independent['head']==SOURCE
required=['dependency12-unapplied','source12-unapplied','root-unapplied-complete','cold-ci-unapplied',
    'typecheck-unapplied','lint-unapplied','inherited09-unapplied','inherited10-unapplied',
    'inherited11-unapplied','inherited-dependency11-unapplied','native-privacy-unapplied',
    'worklist-unapplied','source-packet-unapplied','launch-contract','core05-core06']
for name in required:assert json.loads((HERE/(name+'.receipt.json')).read_bytes())['exit']==0,name
for name,expected in [('scanner-source',1),('scanner-tests',1),('candidate-ios-privacy-blocker',1),
    ('independent-unapplied-current',0),('independent-unapplied-candidate-refused',1),('independent-unapplied-restored',0),
    ('worklist-final-independent-current',0),('worklist-final-independent-malicious',1),('worklist-final-independent-restored',0)]:
    assert json.loads((HERE/(name+'.receipt.json')).read_bytes())['exit']==expected,name
for name in ['root-unapplied-complete','typecheck-unapplied','lint-unapplied','dependency12-unapplied','source12-unapplied']:
    receipt=json.loads((HERE/(name+'.receipt.json')).read_bytes())
    assert receipt['source_before']['head']==receipt['source_after']['head']==SOURCE and receipt['source_before']['clean'] and receipt['source_after']['clean'],name
assert '6166 passed' in (HERE/'root-unapplied-complete.log').read_text(encoding='utf-8')
CHECKPOINT.mkdir(parents=True,exist_ok=False)
for name in ['source-proof.json','protected-files.json.gz','verify_checkpoint.py']:
    (CHECKPOINT/name).write_bytes((HERE/name).read_bytes())
entries={}
for p in HERE.iterdir():
    if not p.is_file() or '.runner.' in p.name:continue
    if p.suffix in ('.py','.cjs','.log') or p.name.endswith('.receipt.json') or p.name in (
        'owner.json','registry12.json','provenance12.json','registry-keys.json','npm-eight-node-advisories.json',
        'candidate-source-proof.json','candidate-independent-proof.json','independent-proof.json',
        'security11-artifact-review.json','candidate-ci-observed.json'):
        entries['task/'+p.name]=p.read_bytes()
packet=ROOT.parent.parent/'context_DEPENDENCY_WITNESS12_0609519617dd4cf69ab922e7f680bf09'
for p in packet.iterdir():entries['orientation/'+p.name]=p.read_bytes()
# Original scanner artifacts remain private scratch. Public evidence is their
# verified archive/entry hashes, true exits/counts and tool/source identities.
with zipfile.ZipFile(HERE/'security11-secret.zip') as archive:
    current=json.loads(archive.read('secret-scan-proof.json'))['commands']['gitleaks-current']['report']
    values={r.get('Secret','') for r in current}
values={x for x in values if isinstance(x,str) and len(x)>=16 and 'REDACTED' not in x and set(x)!={'*'}}
withheld=[]
for name,data in list(entries.items()):
    text=data.decode('utf-8',errors='replace')
    if any(value in text for value in values):
        withheld.append(dict(path=name,sha256=sha(data),bytes=len(data),reason='Potential actual scanner secret value; retained privately, never published'))
        del entries[name]
archive_index={}
with zipfile.ZipFile(CHECKPOINT/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,data)
        archive_index[name]=dict(sha256=sha(data),bytes=len(data))
dump(CHECKPOINT/'archive-index.json',archive_index)
test_results={}
for p in sorted(HERE.glob('*.receipt.json')):
    value=json.loads(p.read_bytes());test_results[value['name']]=value
completion=dict(status='PARTIAL_BLOCKED',proposal='SUBMITTED_REVIEW_REQUIRED',authorization='BRAIN-M103-DEPENDENCY-WITNESS12-CANDIDATE-01',
    source=proof['source'],candidate_source=dict(commit='b74d999799d7f6843b335c91b6974596629ce20f',tree='d8f13fca77945f8f7015e7392cd97b300ccb3494'),
    branch='stage/m103-dependency-witness12',pr=16,base='stage/m103-security-source-recovery11',
    outcome='Exact eight-node candidate independently installed/tested, but protected native privacy mapping requires original whole-lock hash. Original lock restored; exact versioned proposal and blocker retained; current guard refuses activation.',
    candidate_manifest_sha256='5f3ac49ea52a6e4b955bb31495324f157d2d5a85d0d55ca1b66216e7faa565a2',
    blocker_sha256='d52d4153dd4f718559aa2a7461824d013545f37929f609ca677fa7cd9f50ab35',
    final_lock_sha256='99aa497f2d0cc2ca237167403fbbb9d9aee0a4e42fa991ea44f9661487ecf568',
    candidate_lock_sha256='7656c2e6bf482df5a9bc94c9789816a40c5f2b5cfb30e2f10748411229c136cb',
    test_summary=dict(root=6190,cached_tasks=0,new_source_rejections=55,new_dependency_rejections=49,inherited_rejections=[23,44,58,9],
        semantic_negatives=151,semantic_evidence='Unedited original test_contract.py executed in source b74 GitHub Quality40163991148; final evidence-head execution is observed separately after publication.',
        source_packet_and_launch='PASS',phase4=dict(items=14,blocked=7,local_scaffold=7,source_occurrences=420,missing=0,independent=[0,1,0]),
        original_security_suite=dict(tests=70,failures=21,errors=19,exit=1),original_security_source=dict(exit=1,code='SOURCE_INVENTORY_DRIFT')),
    independent_complete_checkout=independent,receipts=test_results,
    evidence_qualification=dict(in_memory='Dependency reader mutations',git_and_materialized_fixture='55 source rejection controls, separately labeled; alternate object store is not independent proof',
        independent='Complete 23291 tracked-file checkout with separate Git objects/no alternates, genuine current0/candidate-refused1/restored0',
        historical='Original Release08/09/10/11 validators ran at each exact endpoint: current0, altered original lock1. Original restored bytes retained.'),
    retained_failures=[
        'Genuine candidate strict iOS MAPPING_LOCK_DRIFT caused rollback; protected mapping/audit untouched.',
        'Original Security source inventory drift, expired proposal/advisory reviews, actual findings and missing qualified custody remain.',
        'Early source12 fixture expected a narrower error label; authentic stronger guard refused first. Test expectations corrected without changing guards.',
        'Two long command attempts have no completed exit receipt; raw partial streams retained and never counted as PASS.',
        'First candidate root suite failed its clean-worktree assertion because authored changes occurred during the run. Clean frozen-source6190 rerun passed.',
        'First restored-lock root attempt overlapped npm ci and failed module loading before tests. Completed cold install and subsequent clean6190 run are separately bound.',
        'A cosmetic trailing-whitespace worklist mutation was accepted by the semantic producer. Correct semantic count mutation then yielded authentic0/1/0.',
        'Extra independent native privacy command lacked optional @expo/plist and exited1; not qualified. Governance0/1/0 completed independently; installed primary native audit passed.'
    ],
    original_artifact_review='task/security11-artifact-review.json in evidence.zip; no raw secret artifacts or invented fingerprints published',
    withheld_sensitive_entries=withheld,
    final_ci='Observe exact final pushed evidence HEAD after publication. Source/candidate observations are labeled by their own SHA and are never borrowed as final results.',
    gates=dict(G97='FAIL/NO_GO',DB='NOT_ACCEPTED',M1_03='BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED',M2='NOT_AUTHORIZED',J01='MISSING_RESEARCH_AND_QUALIFIED_GATES',release='NO_GO'),
    hidden_disabled='F18 and J02-J27/J05 deferred; positive J01, provider/paid/clinical/native/Apple/public-release claims closed; F09 history/manual compare retained; A-to-B owner boundary and CORE05/CORE06 bytes protected.',
    spend_usd=0,acceptanceGranted=False)
dump(CHECKPOINT/'completion-report.json',completion)
readme='''# Campaign12: submitted, dependency patch UNAPPLIED\n\nPARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED. No Security, database, M2 or release acceptance. USD0.\n\nThe exact tested eight-node Vitest4.1.12 candidate passed registry SHA512, signatures/provenance, cold installation,6190 root tests and original151 governance negatives. GitHub then rejected the protected whole-lock iOS privacy mapping. Its mapping/audit are outside this grant. The lock is restored to original bytes in a separate commit. The reviewed proposal remains source-bound and current activation is refused. No protected witness is refreshed or skipped.\n\nSource, candidate source and all intermediate commits/modes/blobs/SHA256 are in source-proof.json and archived candidate-source-proof.json. protected-files.json.gz binds every23261 protected old path. The original Release08/09/10/11 validators remain effective on their exact endpoints. The standalone checker authenticates evidence and source, never grants acceptance.\n\nFrom a clean full checkout, using the manifest SHA256 copied externally from the final report:\n\n    python -B docs/brain/checkpoints/M1-03/SECURITY-DEPENDENCY-12/verify_checkpoint.py --expected-manifest-sha256 EXTERNAL_SHA256\n\nA wrong digest or tampered manifest/evidence/source must reject. The manifest authenticates this verifier too. evidence.zip retains per-entry hashed raw command streams, argv/cwd/actual exits, test and receipt scripts, orientation derivation and independent proof. No raw secret scanner artifact is published. Any withheld potential-sensitive entry is identified by hash only in completion-report.json.\n\nFinal root6190 tests, uncached typecheck/lint,55 source refusals,49 dependency refusals and unchanged23/44/58/9 controls pass. Original Security70 tests still fail21+19; source preflight rejects SOURCE_INVENTORY_DRIFT. Current-source vs historical findings, scanner-runtime advisories, expired reviews and missing qualified owner are distinct unresolved custody items. All early/harness failures remain classified honestly in completion-report.json. A materialized/alternate-object fixture is not the independent complete checkout.\n\nThe separate complete checkout contains23291 tracked files, independent Git objects and no alternates. Current0/exact-candidate-refused1/restored0 and original Phase4 producer0/1/0 are authentic. Optional installed-native audit there lacked dependencies; the separately installed primary strict native audit passed after rollback.\n\nThe immutable Phase4 writer preserved14 items,7 blocked/7 scaffold,420 source occurrences and0 missing. All old gate semantics,151 original negatives,65/38 identities and47/51 history remain. F09 remains required. F18/J02-J27/J05 defer; J01 research/qualified G1/G2/G3/G5 and separate G4 trend evidence remain missing. Native/provider/paid/clinical/Apple/public-release gates stay closed.\n\nFinal-head GitHub Quality/Security/iOS/DB/Expo outcomes are read after the evidence push and reported separately to avoid recursive evidence commits. The archived candidate observations describe their own source only. Brain alone audits source acceptance and decides any later ordinary promotion.\n'''
(CHECKPOINT/'README.md').write_bytes(readme.encode())
handoff=f'''Campaign12 PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED\nPR https://github.com/TasfiqJ/onSkin/pull/16 remains DRAFT, stacked on immutable PR15.\nBranch stage/m103-dependency-witness12; measured source {SOURCE}; tree {proof['source']['tree']}.\nThe tested Vitest4.1.12 eight-node patch is UNAPPLIED: protected iOS privacy mapping binds the old whole-lock hash. Original lock restored byte-for-byte; source guard refuses current activation and hidden blocker removal.\nExact blocker: docs/brain/contracts/SECURITY-12/dependency-install-blocker.v1.json\nOwner handoff: docs/release/full-app-j01/security-custody12.unapplied.json\nExternally anchored checkpoint: docs/brain/checkpoints/M1-03/SECURITY-DEPENDENCY-12/README.md\nUse the external manifest SHA from the final report, never an internally substituted digest. Resolve final evidence HEAD from the pushed branch; this pointer grants no approval.\nFinal source6190 tests, uncached lint/typecheck,55 source and49 dependency refusals, original23/44/58/9 controls pass. Historical witness proofs and independent complete checkout0/1/0 are separate authenticated evidence classes.\nOriginal Security source inventory drift, expired reviews and unresolved findings remain; qualified Security/DB custody absent. G97 FAIL/NO_GO; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED. J01/paid/native/provider/clinical/Apple/public release closed.\nBrain alone accepts source. No main/older PR mutation, release, purchase or self-acceptance. Spend USD0. Final evidence-head CI is observed after push and reported separately.\n'''.encode()
(ROOT/'ONSKIN_BRAIN_HANDOFF.txt').write_bytes(handoff)
files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()),mode='100644') for p in sorted(CHECKPOINT.iterdir()) if p.is_file()}
manifest=dict(version=1,authority='BRAIN-M103-DEPENDENCY-WITNESS12-CANDIDATE-01',status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,
    source=proof['source'],files=files,handoff=dict(mode='100644',sha256=sha(handoff),blob=hashlib.sha1(b'blob '+str(len(handoff)).encode()+b'\0'+handoff).hexdigest()),
    security='FAIL/NO_GO',M2='NOT_AUTHORIZED',release='NO_GO')
dump(CHECKPOINT/'manifest.json',manifest)
digest=sha((CHECKPOINT/'manifest.json').read_bytes());(HERE/'checkpoint-sha.txt').write_text(digest)
print(json.dumps(dict(manifest_sha256=digest,checkpoint_files=len(files)+1,archived_files=len(archive_index),withheld_sensitive=len(withheld),source=proof['source'])))
