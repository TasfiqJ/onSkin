from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,shutil
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_text())['repo'])
TARGET=HERE/'independent-complete'
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CI='true')
def run(name,argv,cwd):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    r=subprocess.run(argv,cwd=cwd,capture_output=True,env=env)
    raw=r.stdout+b'\nSTDERR\n'+r.stderr
    (HERE/(name+'.log')).write_bytes(raw)
    receipt=dict(name=name,argv=argv,cwd=str(cwd),started=started,exit=r.returncode,
        elapsed_seconds=round(time.monotonic()-t,3),log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw))
    (HERE/(name+'.receipt.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
    print(json.dumps(receipt),flush=True)
    return r
assert not TARGET.exists()
assert shutil.disk_usage(HERE).free>6*1024**3
r=run('independent-clone',['git','-c','core.autocrlf=false','-c','core.longpaths=true','clone',
    '--no-local','--no-hardlinks','--branch','stage/m103-dependency-witness12',str(ROOT),str(TARGET)],HERE)
assert r.returncode==0,r.stderr
assert not (TARGET/'.git/objects/info/alternates').exists()
assert subprocess.check_output(['git','rev-parse','--is-shallow-repository'],cwd=TARGET).strip()==b'false'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=TARGET).decode().strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=TARGET).decode().strip()
files=subprocess.check_output(['git','ls-files','-z'],cwd=TARGET).split(b'\0')[:-1]
assert all((TARGET/x.decode()).is_file() for x in files)
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=TARGET)
argv=[sys.executable,'-B','scripts/release/full-app-j01/check.py']
assert run('independent-current',argv,TARGET).returncode==0
lock=TARGET/'package-lock.json';raw=lock.read_bytes()
try:
    lock.write_bytes(raw+b' ')
    assert run('independent-malicious',argv,TARGET).returncode==1
finally:
    lock.write_bytes(raw)
assert run('independent-restored',argv,TARGET).returncode==0
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=TARGET)
for name,ref in [('release11','9e3ba80e09579ee4855948f13297049791c4d5d7'),
    ('release10','14805e7f708297e72419035f517acc41ba52da70'),
    ('release09','8ac97c32901272d97d1bff05f2abc294811055a6'),
    ('release08','d08347f0011672cd309d835628c094b5e9f4725d')]:
    subprocess.run(['git','-c','core.autocrlf=false','-c','core.longpaths=true','switch','--detach',ref],cwd=TARGET,check=True,capture_output=True)
    assert run('historical-'+name,argv,TARGET).returncode==0,name
    original=lock.read_bytes()
    try:
        lock.write_bytes(original+b' ')
        assert run('historical-'+name+'-malicious',argv,TARGET).returncode==1,name
    finally:
        lock.write_bytes(original)
subprocess.run(['git','-c','core.autocrlf=false','-c','core.longpaths=true','switch','stage/m103-dependency-witness12'],cwd=TARGET,check=True,capture_output=True)
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=TARGET)
proof=dict(qualification='INDEPENDENT_COMPLETE_CHECKOUT_SEPARATE_GIT_OBJECTS',head=head,tree=tree,
    tracked_files=len(files),alternates=False,shallow=False,checkout=str(TARGET),current_malicious_restored=[0,1,0],
    historical_endpoint_checks='RELEASE08/09/10/11 original validators: authentic0, altered old lock1; original restored bytes',
    acceptance=False,release='NO_GO')
(HERE/'independent-proof.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
print(json.dumps(proof),flush=True)
