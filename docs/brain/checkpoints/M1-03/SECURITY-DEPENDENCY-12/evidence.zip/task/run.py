import datetime, hashlib, json, os, pathlib, subprocess, sys, time
HERE = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(json.loads((HERE/'owner.json').read_text())['repo'])
name, *argv = sys.argv[1:]
assert name.replace('-', '').replace('_', '').isalnum()
env = dict(os.environ, PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', CI='true', EXPO_NO_TELEMETRY='1')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity():
    head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
    tree = subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT).decode().strip()
    status = subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT)
    return dict(head=head,tree=tree,status_sha256=hashlib.sha256(status).hexdigest(),clean=not status)
before = identity()
t = time.monotonic()
with (HERE/(name+'.log')).open('xb') as stream:
    result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, env=env)
data = (HERE/(name+'.log')).read_bytes()
receipt = dict(name=name, argv=argv, cwd=str(ROOT), started=started, elapsed_seconds=round(time.monotonic()-t,3), exit=result.returncode, log_sha256=hashlib.sha256(data).hexdigest(), log_bytes=len(data),source_before=before,source_after=identity())
(HERE/(name+'.receipt.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt), flush=True)
print(data.decode('utf-8',errors='replace')[-2200:].encode(sys.stdout.encoding or 'utf-8',errors='backslashreplace').decode(sys.stdout.encoding or 'utf-8'),flush=True)
sys.exit(result.returncode)
