const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const npm = path.join(process.env.APPDATA,'npm/node_modules/npm');
const pacote = require(path.join(npm,'node_modules/pacote'));
const root = __dirname;
(async () => {
  const raw = Buffer.from(await (await fetch('https://registry.npmjs.org/-/npm/v1/keys')).arrayBuffer());
  fs.writeFileSync(path.join(root,'registry-keys.json'),raw);
  const keys = JSON.parse(raw).keys.map(key=>({...key,pemkey:`-----BEGIN PUBLIC KEY-----\n${key.key}\n-----END PUBLIC KEY-----`}));
  const rows = JSON.parse(fs.readFileSync(path.join(root,'registry12.json'))).nodes;
  const verified = [];
  for (const row of rows) {
    const name = row.path.slice('node_modules/'.length);
    const mani = await pacote.manifest(name+'@4.1.12',{
      registry:'https://registry.npmjs.org/', fullMetadata:true,
      verifySignatures:true, verifyAttestations:true,
      '//registry.npmjs.org/:_keys':keys,
      cache:path.join(root,'npm-provenance-cache'), tufCache:path.join(root,'tuf'),
    });
    if (mani.dist.integrity !== row.integrity || !mani._attestationBundles?.length) throw Error('missing integrity/provenance');
    const statements = mani._attestationBundles.map(x=>({predicateType:x.predicateType,statement:JSON.parse(Buffer.from(x.bundle.dsseEnvelope.payload,'base64').toString())}));
    fs.writeFileSync(path.join(root,name.replaceAll('/','_').replace('@','')+'.attestations.json'),JSON.stringify(mani._attestationBundles));
    verified.push({path:row.path,registry_signature:'VERIFIED',attestations:'VERIFIED',statements});
    console.log(name+' SIGNATURE_AND_PROVENANCE_VERIFIED');
  }
  fs.writeFileSync(path.join(root,'provenance12.json'),JSON.stringify({npm:'11.20.0',pacote:require(path.join(npm,'node_modules/pacote/package.json')).version,verified},null,2)+'\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
