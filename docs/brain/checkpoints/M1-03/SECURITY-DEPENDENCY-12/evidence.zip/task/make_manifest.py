from pathlib import Path
import hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
ROOT=Path(json.loads((HERE/'owner.json').read_text())['repo'])
BASE='9e3ba80e09579ee4855948f13297049791c4d5d7'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(x):return hashlib.sha256(x).hexdigest()
def witness(path,ref=BASE):
    raw=git('show',ref+':'+path)
    mode,kind,blob=git('ls-tree',ref,'--',path).decode().split('\t')[0].split()
    return dict(path=path,source_commit=ref,mode=mode,blob=blob,sha256=sha(raw),bytes=len(raw))
contract=json.loads(git('show',BASE+':docs/brain/contracts/SECURITY-11/dependency-patch.v1.json'))
registry=json.loads((HERE/'registry12.json').read_bytes())
directory=ROOT/'docs/brain/contracts/SECURITY-12/registry'
directory.mkdir(parents=True,exist_ok=False)
rows=[]
for row in registry['nodes']:
    key=row['path'][len('node_modules/'):].replace('/','_').replace('@','')
    files={}
    for suffix in ['.registry.json','.attestations.json']:
        name=key+suffix;data=(HERE/name).read_bytes();(directory/name).write_bytes(data)
        files['metadata' if suffix=='.registry.json' else 'attestations']=dict(path=(directory/name).relative_to(ROOT).as_posix(),sha256=sha(data),bytes=len(data))
    rows.append(dict(path=row['path'],integrity=row['integrity'],tarball_sha256=row['tarball_sha256'],integrity_verified=True,signature_verified=True,provenance_verified=True,native_files=False,install_scripts=False,**files))
for name in ['provenance12.json','provenance.log','provenance.receipt.json']:
    (directory/name).write_bytes((HERE/name).read_bytes())
old=json.loads(git('show','50f25abeafaa6127e105e2a9d825e6d15dc1dcdb:docs/release/full-app-j01/precedence.v1.json')) if False else json.loads((ROOT/'docs/release/full-app-j01/precedence.v1.json').read_bytes())
original=next(x for x in old['protected_witnesses'] if x['path']=='package-lock.json')
candidate=(HERE/'candidate-lock.json').read_bytes()
manifest=dict(schema_version=1,authorization='BRAIN-M103-DEPENDENCY-WITNESS12-CANDIDATE-01',status='CANDIDATE_REVIEW_REQUIRED',
    base=dict(commit=BASE,tree='0c3d2dc79a54a405315df06f05d284bd643cd538'),
    campaign11_source=dict(commit='90a2b90bc859172683fd4a352ddd4cb13b307e89',tree='d3b9e8c6626d8b04632ec586ee408b160d8f0393'),
    branch='stage/m103-dependency-witness12',pr=16,base_branch='stage/m103-security-source-recovery11',
    historical_contracts=[witness('docs/release/full-app-j01/'+x) for x in ['contract.v1.json','precedence.v1.json','matrix.v1.json','roadmap.v1.json','history-crosswalk.v1.json']],
    original_root_lock_witness=original,reviewed_nodes_source=witness('docs/brain/contracts/SECURITY-11/dependency-patch.v1.json'),
    candidate_root_lock=dict(path='package-lock.json',mode='100644',blob=git('hash-object','--stdin',).decode().strip()) if False else dict(path='package-lock.json',mode='100644',blob=hashlib.sha1(b'blob '+str(len(candidate)).encode()+b'\0'+candidate).hexdigest(),sha256=sha(candidate),bytes=len(candidate)),
    nodes=contract['nodes'],changed_nodes=list(contract['nodes']),other_nodes='IDENTICAL_ORDER_AND_VALUES; EXACT_WHOLE_FILE_SHA256',
    declarations=[witness(x) for x in ['package.json','apps/mobile/package.json']],registry=rows,
    provenance=dict(path='docs/brain/contracts/SECURITY-12/registry/provenance12.json',sha256=sha((HERE/'provenance12.json').read_bytes()),npm='11.20.0',upstream_repository='https://github.com/vitest-dev/vitest',upstream_commit='4766ce1e72ded629d3a37637f57eeae643789a8c',workflow='.github/workflows/publish.yml',ref='refs/heads/v4'),
    advisories=contract['advisories'],spend_usd=0,
    admissions=dict(security=False,db_custody=False,M1_03=False,M2=False,J01=False,paid=False,native=False,apple=False,public_release=False),
    gates=dict(G97='FAIL/NO_GO',M1_03='BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED',M2='NOT_AUTHORIZED'),
    source_version_handling='Original Release08 witness reads the immutable original lock only within its isolated legacy validation namespace AFTER the separate Release12 guard verifies current/index/history candidate bytes. Historical witness records and semantic functions remain unchanged. No new acceptance.')
raw=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
(ROOT/'docs/release/full-app-j01/dependency-succession12.v1.json').write_bytes(raw)
(HERE/'manifest-sha.txt').write_text(sha(raw))
print('SUCCESSION_MANIFEST_SHA256',sha(raw),'candidate',manifest['candidate_root_lock'])
