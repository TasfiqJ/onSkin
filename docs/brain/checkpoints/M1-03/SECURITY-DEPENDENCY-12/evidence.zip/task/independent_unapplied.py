from pathlib import Path
import hashlib,json,os,subprocess,sys,time
HERE=Path(__file__).resolve().parent
ROOT=HERE/'independent-complete'
owner=json.loads((HERE/'owner.json').read_bytes())
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=owner['repo']).decode().strip()
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT)
(HERE/'candidate-independent-proof.json').write_bytes((HERE/'independent-proof.json').read_bytes())
subprocess.run(['git','fetch','--no-tags','origin','stage/m103-dependency-witness12'],cwd=ROOT,check=True)
subprocess.run(['git','-c','core.autocrlf=false','-c','core.longpaths=true','switch','--detach',source],cwd=ROOT,check=True)
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CI='true')
def run(name,argv,expected):
    t=time.monotonic();r=subprocess.run(argv,cwd=ROOT,capture_output=True,env=env)
    raw=r.stdout+b'\nSTDERR\n'+r.stderr
    (HERE/(name+'.log')).write_bytes(raw)
    rec=dict(name=name,argv=argv,cwd=str(ROOT),source=source,exit=r.returncode,expected_exit=expected,elapsed_seconds=round(time.monotonic()-t,3),log_sha256=hashlib.sha256(raw).hexdigest(),log_bytes=len(raw))
    (HERE/(name+'.receipt.json')).write_bytes((json.dumps(rec,indent=2)+'\n').encode());print(json.dumps(rec),flush=True)
    assert r.returncode==expected,raw[-1000:]
lock=ROOT/'package-lock.json';original=lock.read_bytes()
argv=[sys.executable,'-B','scripts/release/full-app-j01/check.py']
run('independent-unapplied-current',argv,0)
try:
    lock.write_bytes(subprocess.check_output(['git','cat-file','blob','843be0fdf1fe9354dfdc4750118481486d9a778a'],cwd=ROOT))
    run('independent-unapplied-candidate-refused',argv,1)
finally:lock.write_bytes(original)
run('independent-unapplied-restored',argv,0)
run('independent-unapplied-native-privacy',['node','scripts/phase9/ios-privacy-source-audit.mjs','--check','--strict'],0)
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT)
proof=dict(qualification='INDEPENDENT_COMPLETE_CHECKOUT_SEPARATE_GIT_OBJECTS',head=source,
    tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT).decode().strip(),
    tracked_files=len(subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).split(b'\0'))-1,
    alternates=False,shallow=False,checkout=str(ROOT),current_malicious_restored=[0,1,0],
    mutation='Actual exact reviewed candidate lock refused while protected compatibility blocker is active',
    native_privacy_source_check=0,acceptance=False,release='NO_GO')
(HERE/'independent-proof.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode());print(json.dumps(proof),flush=True)
