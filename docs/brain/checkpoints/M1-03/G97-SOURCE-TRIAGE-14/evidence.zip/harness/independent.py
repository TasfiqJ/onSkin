import hashlib,json,pathlib,subprocess,sys
from preflight import RUN
root=RUN/'independent-complete'
SOURCE='36c64689be3e9bc1f4daa84fe6f3d0752464c011'
subprocess.run(['git','checkout','--detach',SOURCE],cwd=root,check=True)
def run(name,args,expected=0):
    r=subprocess.run([sys.executable,'-B',str(RUN/'run_at.py'),name,str(root),*args],cwd=RUN)
    assert r.returncode==expected,(name,r.returncode,expected)
run('independent-cold-ci',['npm.cmd','ci','--cache',str(RUN/'npm-independent-cache'),'--no-audit','--no-fund'])
sys.path.insert(0,str(root/'scripts/security14'))
import source_inventory as inv
snapshot=inv.snapshot(root,SOURCE)
assert not (root/'.git/objects/info/alternates').exists()
for name,row in snapshot.items():
    raw=inv.regular(root/name);assert inv.sha(raw)==row['sha256'],name
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
proof=dict(source=SOURCE,tree=inv.git(root,'rev-parse','HEAD^{tree}').decode().strip(),tracked_files=len(snapshot),all_tracked_bytes_match=True,hardlinks_or_alternates=False,qualification='SEPARATE_COMPLETE_NONLOCAL_CLONE_WITH_FRESH_COLD_INSTALL',controls=[])
controls=[('governance','package-lock.json',['python','-B','scripts/release/full-app-j01/check.py']),
          ('native','docs/phase-9/ios-sdk-package-mapping.json',['node','scripts/phase9/ios-privacy-source-audit.mjs','--check','--strict']),
          ('worklist','docs/phase-4/generated/source-worklist.json',['node','scripts/phase4/build-source-worklist.mjs','--strict','--check'])]
for name,path,args in controls:
    target=root/path;before=target.read_bytes()
    run('independent-'+name+'-current',args)
    try:
        target.write_bytes(before+b' ')
        run('independent-'+name+'-tamper',args,1)
    finally:target.write_bytes(before)
    run('independent-'+name+'-restored',args)
    proof['controls'].append(dict(name=name,exits=[0,1,0],target=path,restored_sha256=hashlib.sha256(before).hexdigest()))
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
(RUN/'independent-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
