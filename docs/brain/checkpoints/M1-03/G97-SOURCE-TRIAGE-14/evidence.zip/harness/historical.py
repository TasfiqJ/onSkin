import json,pathlib,subprocess,sys
from preflight import RUN
root=RUN/'historical-complete'
stages=[
 ('09','8ac97c32901272d97d1bff05f2abc294811055a6',['source_consumer09.test.py']),
 ('10','14805e7f708297e72419035f517acc41ba52da70',['source_consumer10.test.py']),
 ('11','9e3ba80e09579ee4855948f13297049791c4d5d7',['source_consumer11.test.py','dependency_guard11.test.py']),
 ('12','bbbd59073b7add22ac350bced0d9a34124c12ffb',['source_consumer12.test.py','dependency_guard12.test.py']),
 ('13','d0c5ad49ba22c8da7136d59a399589af1cea0e82',['source_consumer13.test.py','dependency_guard13.test.py']),
]
# Fresh cold install at the exact native-source successor. Older checks retain
# their own detached source endpoints; native source packages are unchanged.
subprocess.run(['git','checkout','--detach',stages[-1][1]],cwd=root,check=True)
r=subprocess.run([sys.executable,'-B',str(RUN/'run_at.py'),'historical-cold-ci',str(root),'npm.cmd','ci','--cache',str(RUN/'npm-historical-cache'),'--no-audit','--no-fund'],cwd=RUN)
if r.returncode:raise SystemExit(r.returncode)
for stage,commit,tests in stages:
    assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
    subprocess.run(['git','checkout','--detach',commit],cwd=root,check=True)
    for test in tests:
        name='inherited-'+stage+'-'+('dependency' if test.startswith('dependency') else 'source')
        r=subprocess.run([sys.executable,'-B',str(RUN/'run_at.py'),name,str(root),'python','-B','scripts/release/full-app-j01/'+test],cwd=RUN)
        if r.returncode:raise SystemExit(r.returncode)
