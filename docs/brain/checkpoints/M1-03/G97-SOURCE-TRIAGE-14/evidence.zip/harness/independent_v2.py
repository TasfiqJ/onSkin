import hashlib,importlib.util,json,pathlib,stat,subprocess,sys
from preflight import RUN
root=RUN/'independent-complete';source='63c7d910ec85659f3180e4ea7ddd41c7f44e2c5c'
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
subprocess.run(['git','fetch','--no-tags','origin','stage/m103-g97-provenance-triage14'],cwd=root,check=True)
subprocess.run(['git','checkout','--detach',source],cwd=root,check=True)
sys.path.insert(0,str(root/'scripts/security14'));import source_inventory as inv
spec=importlib.util.spec_from_file_location('audit14',RUN/'verify14_v2.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
snapshot=inv.snapshot(root,source)
for name,row in snapshot.items():
    raw=audit.regular(root/name);assert inv.sha(raw)==row['sha256']
for directory,identity in audit.DIRECTORIES.items():
    s=directory.lstat();assert not stat.S_ISLNK(s.st_mode) and not getattr(s,'st_file_attributes',0)&1024
    assert stat.S_ISDIR(s.st_mode) and (s.st_dev,s.st_ino)==identity[:2]
    assert not directory.is_relative_to(root) or (s.st_dev,s.st_ino,s.st_mtime_ns,s.st_ctime_ns)==identity
assert not (root/'.git/objects/info/alternates').exists()
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
proof=dict(source=source,tree='5d914609352e75b112997dea7043c6bfc0913ba1',tracked_files=len(snapshot),all_tracked_bytes_match=True,
    hardlinks_or_alternates=False,qualification='SEPARATE_COMPLETE_NONLOCAL_CLONE_FULL_FRESH_BYTE_AUDIT_AND_SAME_UNCHANGED_COLD_INSTALLED_LOCK',
    cold_install_receipt='independent-cold-ci.receipt.json',unchanged_lock_sha256=snapshot['package-lock.json']['sha256'],controls=[],acceptanceGranted=False)
(RUN/'refreeze-independent-identity.json').write_text(json.dumps(proof,indent=2)+'\n')
def run(name,args,expected=0):
    r=subprocess.run([sys.executable,'-B',str(RUN/'run_at.py'),'refreeze-independent-'+name,str(root),*args],cwd=RUN)
    assert r.returncode==expected,(name,r.returncode)
for name,path,args in [('governance','package-lock.json',['python','-B','scripts/release/full-app-j01/check.py']),
    ('native','docs/phase-9/ios-sdk-package-mapping.json',['node','scripts/phase9/ios-privacy-source-audit.mjs','--check','--strict']),
    ('worklist','docs/phase-4/generated/source-worklist.json',['node','scripts/phase4/build-source-worklist.mjs','--strict','--check'])]:
    target=root/path;before=target.read_bytes();run(name+'-current',args)
    try:
        if name=='worklist':
            value=json.loads(before);value['summary']['itemCount']=13;target.write_bytes((json.dumps(value,indent=2)+'\n').encode())
        else:target.write_bytes(before+b' ')
        run(name+'-tamper',args,1)
    finally:target.write_bytes(before)
    run(name+'-restored',args);proof['controls'].append(dict(name=name,exits=[0,1,0]))
proof['all_restored']=True
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
(RUN/'refreeze-independent-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
