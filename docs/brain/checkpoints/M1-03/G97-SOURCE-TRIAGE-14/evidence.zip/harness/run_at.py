import datetime, hashlib, json, os, pathlib, subprocess, sys, time
RUN=pathlib.Path(__file__).resolve().parent
name,location,*argv=sys.argv[1:];ROOT=pathlib.Path(location).resolve()
assert ROOT.parent==RUN and name.replace('-','').replace('_','').isalnum()
def identity():
    git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
    return dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),status_sha256=hashlib.sha256(git('status','--porcelain=v1','-uall')).hexdigest())
before=identity();start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (RUN/(name+'.log')).open('xb') as out:
    r=subprocess.run(argv,cwd=ROOT,env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CI='true',EXPO_NO_TELEMETRY='1'),stdout=out,stderr=subprocess.STDOUT)
body=(RUN/(name+'.log')).read_bytes()
receipt=dict(name=name,cwd=str(ROOT),argv=argv,started=start,seconds=round(time.monotonic()-t,3),exit=r.returncode,log_bytes=len(body),log_sha256=hashlib.sha256(body).hexdigest(),source_before=before,source_after=identity())
(RUN/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if not name.startswith('private-'):print(body.decode('utf-8',errors='replace')[-1800:].encode('ascii',errors='backslashreplace').decode(),flush=True)
raise SystemExit(r.returncode)
