const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const packages = { zod3: require('zod3'), zod4: require('zod4') };
const sourceRoot = process.argv[2];
const files = ['DevToolsPlugin.schema.js', 'createMCPDevToolsExtensionSchema.js'].map(n => `${sourceRoot}/node_modules/@expo/cli/build/src/start/server/${n}`);
const results = [];
for (const [name, z] of Object.entries(packages)) {
  const invalid = Array(1000).fill(123);
  const bounded = z.array(z.string()).max(2).safeParse(invalid);
  const unbounded = z.array(z.string()).safeParse(invalid);
  assert.equal(bounded.success, false); assert.equal(unbounded.success, false);
  const consumers = files.map(file => {
    const code = fs.readFileSync(file, 'utf8');
    const context = {exports:{}, require: n => { assert.equal(n, 'zod'); return z; }};
    vm.runInNewContext(code, context, {timeout:1000});
    if (context.exports.DevToolsPluginOutputSchema) {
      assert.equal(context.exports.DevToolsPluginOutputSchema.safeParse([{type:'text',text:'fixture',level:'info'}]).success, true);
      assert.equal(context.exports.DevToolsPluginOutputSchema.safeParse([{type:'unknown'}]).success, false);
    } else {
      const schema=context.exports.createMCPDevToolsExtensionSchema({packageName:'synthetic',cliExtensions:{commands:[{name:'test',title:'Test',parameters:[{name:'value',type:'number'}]}]}});
      assert.equal(schema.safeParse({command:'test',value:1}).success,true);
      assert.equal(schema.safeParse({command:'test',value:'invalid'}).success,false);
    }
    return {source:file.slice(sourceRoot.length+1),sha256:crypto.createHash('sha256').update(code).digest('hex'),minimal_schema_smoke:true};
  });
  results.push({package:name,version:require(name+'/package.json').version,bounded_issues:bounded.error.issues.length,unbounded_issues:unbounded.error.issues.length,consumers});
}
console.log(JSON.stringify({qualification:'ISOLATED_SYNTHETIC_NOT_EXPO_BUILD_OR_MIGRATION_ACCEPTANCE',results}));
