import datetime, hashlib, json, os, pathlib, subprocess, sys, time
RUN=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path(json.loads((RUN/'owner.json').read_text())['repo'])
name,*argv=sys.argv[1:]
assert name.replace('-','').replace('_','').isalnum()
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',CI='true',EXPO_NO_TELEMETRY='1')
def identity():
    git=lambda *a:subprocess.check_output(['git',*a],cwd=ROOT)
    return dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),status_sha256=hashlib.sha256(git('status','--porcelain=v1','-uall')).hexdigest())
before=identity(); started=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
with (RUN/(name+'.log')).open('xb') as out:
    result=subprocess.run(argv,cwd=ROOT,env=env,stdout=out,stderr=subprocess.STDOUT)
data=(RUN/(name+'.log')).read_bytes()
receipt=dict(name=name,argv=argv,started=started,seconds=round(time.monotonic()-t,3),exit=result.returncode,log_bytes=len(data),log_sha256=hashlib.sha256(data).hexdigest(),source_before=before,source_after=identity())
(RUN/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
if not name.startswith('private-'):
    print(data.decode('utf-8',errors='replace')[-3000:].encode('ascii',errors='backslashreplace').decode(),flush=True)
sys.exit(result.returncode)
