"""Complete the semantic worklist negative after a format-only change was accepted."""
import hashlib,json,pathlib,subprocess,sys
from preflight import RUN
root=RUN/'independent-complete'
def run(name,args,expected=0):
    r=subprocess.run([sys.executable,'-B',str(RUN/'run_at.py'),name,str(root),*args],cwd=RUN)
    assert r.returncode==expected,(name,r.returncode,expected)
args=['node','scripts/phase4/build-source-worklist.mjs','--strict','--check']
target=root/'docs/phase-4/generated/source-worklist.json';before=target.read_bytes()
run('independent-worklist-semantic-current',args)
try:
    value=json.loads(before);value['summary']['itemCount']=13
    target.write_bytes((json.dumps(value,indent=2)+'\n').encode())
    run('independent-worklist-semantic-tamper',args,1)
finally:target.write_bytes(before)
run('independent-worklist-semantic-restored',args)
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=root).strip()
assert not (root/'.git/objects/info/alternates').exists()
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0')[:-1]
assert len(tracked)==23323 and all((root/n.decode()).is_file() for n in tracked)
assert not subprocess.check_output(['git','ls-files','-d','-z'],cwd=root)
proof=dict(source='36c64689be3e9bc1f4daa84fe6f3d0752464c011',tree='3ed958e1afb58f710db987d9bde84211fdd37968',tracked_files=len(tracked),
    all_tracked_bytes_match=True,physical_audit='Exhaustive regular/path/component/SHA256 audit completed in independent.py before the first governance invocation; all tracked paths rechecked present and Git clean after restoration.',
    hardlinks_or_alternates=False,qualification='SEPARATE_COMPLETE_NONLOCAL_CLONE_WITH_FRESH_COLD_INSTALL',
    controls=[dict(name=n,exits=[0,1,0]) for n in ['governance','native','worklist-semantic']],
    format_only_worklist_change=dict(exit=0,interpretation='Original producer canonicalizes JSON whitespace; format-only edit is not a semantic negative.'),
    all_restored=True,acceptanceGranted=False)
(RUN/'independent-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
