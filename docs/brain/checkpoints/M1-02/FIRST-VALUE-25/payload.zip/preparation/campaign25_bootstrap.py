"""Independent, bounded Campaign25 archive bootstrap. Never executes packet code."""
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys
import tempfile
import unicodedata
import zipfile

ARCHIVE = Path(r'C:\Users\jasim\.codex\codex-remote-attachments\01a18542-d81f-7392-bf2d-5399d35d7206\4EDB239A-6294-4B49-BA2D-91696DF42C22\1-onSkin_Campaign25_Real_First_Value_Integration_Context_2026-10-28.zip')
EXPECTED = 'c539789e768f94fd0e79c6ab97c64dd247b0fbfb0918921f1d77ee3f20e19fc0'
BASE = Path(__file__).resolve().parent

def require(ok, message):
    if not ok:
        raise ValueError('CONTEXT_INVALID: ' + message)

def unique_json(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result

def inspect():
    with ARCHIVE.open('rb') as stream:
        raw = stream.read(2 * 1024 * 1024 + 1)
    require(len(raw) <= 2 * 1024 * 1024, 'archive size limit')
    z = zipfile.ZipFile(io.BytesIO(raw))
    entries = z.infolist()
    require(len(entries) == 17, 'exactly 17 regular file members required')
    require(not z.comment, 'unexpected ZIP comment')
    require(sum(i.file_size for i in entries) <= 2 * 1024 * 1024, 'expansion limit')
    aliases, kinds, names = {}, {}, set()
    intervals = []
    for i in entries:
        name = i.filename
        require(name == i.orig_filename and name and '\\' not in name and '\x00' not in name, 'unsafe path')
        require(not name.startswith('/') and not re.match(r'^[A-Za-z]:', name), 'absolute or drive path')
        parts = name.split('/')
        require(all(p not in ('', '.', '..') and not p.endswith((' ', '.')) for p in parts), 'unsafe component')
        require(all(not any(ord(c) < 32 or c in ':<>"|?*' for c in p) for p in parts), 'Windows unsafe component')
        require(all(not re.fullmatch(r'(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', p) for p in parts), 'reserved component')
        require(name not in names, 'duplicate member')
        names.add(name)
        for n in range(1, len(parts) + 1):
            path = '/'.join(parts[:n])
            key = unicodedata.normalize('NFKC', path).casefold()
            require(key not in aliases or aliases[key] == path, 'Unicode/case alias including implicit parent')
            aliases[key] = path
            kind = 'file' if n == len(parts) else 'dir'
            require(path not in kinds or kinds[path] == kind, 'file/directory collision')
            kinds[path] = kind
        mode = i.external_attr >> 16
        require(i.create_system == 3 and stat.S_ISREG(mode), 'linked or special member')
        require(not (i.external_attr & (0x10 | 0x400)), 'directory/reparse member')
        require(i.flag_bits in (0, 0x800) and i.compress_type in (0, 8), 'unsupported flags or compression')
        require(not i.extra and not i.comment, 'unexpected extension metadata')
        require(0 <= i.file_size <= 256 * 1024 and 0 < i.compress_size and i.file_size <= i.compress_size * 100, 'member expansion limit')
        off = i.header_offset
        require(raw[off:off+4] == b'PK\x03\x04', 'invalid local header')
        fields = struct.unpack_from('<IHHHHHIIIHH', raw, off)
        _, _, flags, compression, _, _, crc, compressed, expanded, nlen, xlen = fields
        require(flags == i.flag_bits and compression == i.compress_type and crc == i.CRC and compressed == i.compress_size and expanded == i.file_size, 'central/local metadata mismatch')
        require(xlen == 0 and raw[off+30:off+30+nlen].decode('utf-8' if flags & 0x800 else 'cp437') == name, 'local name/extra mismatch')
        intervals.append((off, off + 30 + nlen + xlen + compressed))
    intervals.sort()
    require(intervals[0][0] == 0 and all(a[1] == b[0] for a, b in zip(intervals, intervals[1:])), 'prefix/overlap/unaccounted local bytes')
    require(intervals[-1][1] == z.start_dir, 'unexpected pre-directory bytes')
    eocd = raw.rfind(b'PK\x05\x06')
    require(eocd >= 0 and eocd + 22 == len(raw), 'trailing data or invalid EOCD')
    _, disk, cd_disk, disk_count, count, cd_size, cd_offset, comment_size = struct.unpack_from('<IHHHHIIH', raw, eocd)
    require(disk == cd_disk == comment_size == 0 and disk_count == count == 17 and cd_offset == z.start_dir and cd_offset + cd_size == eocd, 'unsupported or inconsistent directory')
    data = {}
    for i in entries:
        with z.open(i) as stream:
            value = stream.read(i.file_size + 1)
            require(len(value) == i.file_size and not stream.read(1), 'actual member size mismatch')
            data[i.filename] = value
    require(hashlib.sha256(data['manifest.json']).hexdigest() == EXPECTED, 'external manifest SHA256 mismatch')
    manifest = json.loads(data['manifest.json'].decode('utf-8'), object_pairs_hook=unique_json)
    return raw, data, manifest

if __name__ == '__main__':
    try:
        raw, data, manifest = inspect()
        require(set(manifest) == {'authority', 'files', 'qualification', 'schema', 'triad'}, 'manifest schema keys')
        require(manifest['schema'] == 1 and manifest['qualification'] == 'CONTEXT_ONLY_NO_ACCEPTANCE', 'manifest schema')
        inventory = manifest['files']
        require(isinstance(inventory, dict) and len(inventory) == 16 and set(inventory) | {'manifest.json'} == set(data), 'authenticated exact inventory')
        for name, record in inventory.items():
            require(set(record) == {'bytes', 'sha256'} and type(record['bytes']) is int and re.fullmatch('[0-9a-f]{64}', record['sha256']), 'inventory schema')
            require(len(data[name]) == record['bytes'] and hashlib.sha256(data[name]).hexdigest() == record['sha256'], 'member authentication: ' + name)
        triad = ['TASK_DIRECTIVE.md', 'PROMPT_TEMPLATE.md', 'EXACT_PROMPT.md']
        require(manifest['triad'] == {'files': triad, 'identical': True}, 'triad schema')
        require(data[triad[0]] == data[triad[1]] == data[triad[2]], 'directive triad mismatch')
        for parent in [BASE] + list(BASE.parents):
            st = parent.lstat()
            require(not stat.S_ISLNK(st.st_mode) and not getattr(st, 'st_file_attributes', 0) & 0x400, 'reparse extraction ancestor')
        root = Path(tempfile.mkdtemp(prefix='campaign25-context-', dir=str(BASE)))
        require(not list(root.iterdir()), 'extraction directory not empty')
        for name, value in data.items():
            target = root.joinpath(*name.split('/'))
            require(root in target.resolve().parents, 'extraction containment')
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as stream:
                stream.write(value)
        actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        require(actual == set(data), 'extracted inventory')
        for name, value in data.items():
            target = root.joinpath(*name.split('/'))
            st = target.lstat()
            require(stat.S_ISREG(st.st_mode) and not getattr(st, 'st_file_attributes', 0) & 0x400, 'extracted special file')
            require(target.read_bytes() == value, 'extracted bytes mismatch')
        receipt = {'result': 'INDEPENDENT_BOOTSTRAP_AUTHENTICATED', 'archive': str(ARCHIVE), 'archive_sha256': hashlib.sha256(raw).hexdigest(), 'manifest_sha256': EXPECTED, 'verifier_sha256': hashlib.sha256(data['verify_packet.py']).hexdigest(), 'members': 17, 'triad_identical': True, 'expanded_bytes': sum(map(len, data.values())), 'root': str(root)}
        receipt_path = BASE / (root.name + '-bootstrap-receipt.json')
        with receipt_path.open('x', encoding='utf-8') as stream:
            json.dump(receipt, stream, indent=2)
        print(json.dumps(receipt, indent=2))
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
