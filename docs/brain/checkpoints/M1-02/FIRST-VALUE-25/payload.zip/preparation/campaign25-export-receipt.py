from pathlib import Path
import hashlib,json,subprocess

ROOT=Path(__file__).resolve().parent
REPO=ROOT/'campaign25-source'
OUT=ROOT/'campaign25-evidence'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()
source={}
for line in subprocess.check_output(['git','ls-tree','-r','-z','HEAD'],cwd=REPO).split(b'\0'):
    if not line: continue
    meta,name=line.split(b'\t',1); path=name.decode()
    if path.startswith(('apps/','packages/')) or path in ('package.json','package-lock.json') or path.startswith('scripts/postinstall'):
        data=(REPO/path).read_bytes()
        source[path]={'git':meta.decode(),'bytes':len(data),'sha256':sha(data)}
source_raw=(json.dumps(source,sort_keys=True,separators=(',',':'))+'\n').encode()
(OUT/'export-runtime-source-inventory.json').write_bytes(source_raw)
result={'qualification':'ACTUAL_CLEAR_CACHE_UNSIGNED_EXPO_EXPORTS_NOT_NATIVE_EXECUTION_OR_ACCEPTANCE',
 'sourceHeadAtInventory':git('rev-parse','HEAD'),'sourceTreeAtInventory':git('rev-parse','HEAD^{tree}'),
 'runtimeInputInventorySHA256':sha(source_raw),'sourceNote':'App implementation unchanged during final exports; subsequent fixture enum correction and documentation/governance do not change runtime bundle inputs.',
 'node':subprocess.check_output(['node','--version']).decode().strip(),'exports':{},'release':'NO_GO','acceptanceGranted':False}
for platform in ('ios','android'):
    root=OUT/'exports'/(platform+'-final'); files={}
    for path in sorted(root.rglob('*')):
        if path.is_dir(): continue
        assert path.is_file() and not path.is_symlink()
        raw=path.read_bytes(); files[path.relative_to(root).as_posix()]={'bytes':len(raw),'sha256':sha(raw)}
    log=OUT/('export-'+platform+'-final.log'); data=log.read_bytes()
    assert b'Exported:' in data and any(name.endswith('.hbc') for name in files)
    result['exports'][platform]={'exit':0,'command':['expo','export','--platform',platform,'--output-dir','EXTERNAL_EVIDENCE/exports/'+platform+'-final','--source-maps','external','--dump-assetmap','--clear'],
      'cwd':'apps/mobile','NODE_ENV':'production','logBytes':len(data),'logSHA256':sha(data),'files':files,
      'artifactPolicy':'Full bundles/maps remain local; return includes exact inventory and logs, not an installed native build.'}
raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
(OUT/'unsigned-export-receipt.json').write_bytes(raw)
print(json.dumps({'receiptSHA256':sha(raw),'runtimeFiles':len(source),'platformFiles':{k:len(v['files']) for k,v in result['exports'].items()}}))
