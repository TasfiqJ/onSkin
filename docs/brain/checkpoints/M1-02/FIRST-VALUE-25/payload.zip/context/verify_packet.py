#!/usr/bin/env python3
"""Campaign25 context verifier. External digest authenticates manifest, not acceptance."""
import argparse, hashlib, json, os, pathlib, re, stat, sys, unicodedata
R=pathlib.Path(__file__).resolve().parent
HEX=re.compile(r'^[0-9a-f]{64}$')

def sha(data): return hashlib.sha256(data).hexdigest()

def stop(reason): raise ValueError(reason)

def safe(name):
 if not isinstance(name,str) or not name or len(name)>4096 or name.startswith('/') or '\\' in name or ':' in name: stop('PATH_INVALID')
 parts=name.split('/')
 if any(not p or p in ('.','..') or unicodedata.normalize('NFKC',p) in ('.','..') or p.rstrip(' .')!=p for p in parts):stop('PATH_INVALID')
 if any(any(ord(c)<32 for c in p) for p in parts):stop('PATH_INVALID')
 return parts

def verify(root, anchor):
 if not HEX.fullmatch(anchor): stop('ANCHOR_INVALID')
 data=(root/'manifest.json').read_bytes()
 if sha(data)!=anchor:stop('MANIFEST_ANCHOR_MISMATCH')
 manifest=json.loads(data,object_pairs_hook=lambda pairs: unique(pairs))
 if set(manifest)!={'schema','authority','qualification','files','triad'} or manifest['schema']!=1 or manifest['authority']!='BRAIN-M1X-REAL-FIRST-VALUE25-SOURCE-CANDIDATE-01' or manifest['qualification']!='CONTEXT_ONLY_NO_ACCEPTANCE':stop('MANIFEST_SCHEMA')
 members=manifest['files']
 if not isinstance(members,dict) or not members:stop('MANIFEST_FILES')
 expected=set(members)|{'manifest.json'}
 folded={}; implicit={}
 for name in sorted(expected):
  parts=safe(name)
  for i in range(len(parts)):
   p='/'.join(parts[:i+1]);alias=unicodedata.normalize('NFKC',p).casefold();kind='file' if i==len(parts)-1 else 'directory'
   old=folded.setdefault(alias,(p,kind))
   if old!=(p,kind): stop('PATH_ALIAS_OR_COLLISION')
  path=root.joinpath(*parts)
  if not path.is_file() or path.is_symlink(): stop('MISSING_OR_NONREGULAR_FILE')
  for parent in path.parents:
   if parent==root.parent:break
   if parent.is_symlink():stop('SYMLINK_PARENT')
  info=path.stat()
  if not stat.S_ISREG(info.st_mode) or info.st_size>8*1024*1024:stop('FILE_BOUND')
  if name!='manifest.json':
   row=members[name]
   if not isinstance(row,dict) or set(row)!={'bytes','sha256'} or type(row['bytes']) is not int or not HEX.fullmatch(row['sha256']):stop('RECORD_SCHEMA')
   actual=path.read_bytes()
   if len(actual)!=row['bytes'] or sha(actual)!=row['sha256']:stop('FILE_HASH_MISMATCH')
 found={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
 if found!=expected:stop('EXACT_INVENTORY_MISMATCH')
 for p in root.rglob('*'):
  if p.is_symlink() or (not p.is_file() and not p.is_dir()):stop('UNEXPECTED_ENTRY')
  if p.is_dir() and p!=root:
   rel=p.relative_to(root).as_posix(); k=unicodedata.normalize('NFKC',rel).casefold()
   if folded.get(k)!=(rel,'directory'):stop('UNEXPECTED_DIRECTORY')
 trio=('TASK_DIRECTIVE.md','PROMPT_TEMPLATE.md','EXACT_PROMPT.md')
 raws=[(root/n).read_bytes() for n in trio]
 if len(set(raws))!=1 or manifest['triad']!={'files':list(trio),'identical':True}:stop('TRIAD_MISMATCH')
 return {'status':'VERIFIED','context_only':True,'manifest_sha256':anchor,'authenticated_files':len(expected),'triad_identical':True,'release':'NO_GO'}

def unique(pairs):
 o={}
 for k,v in pairs:
  if k in o:stop('DUPLICATE_JSON_KEY')
  o[k]=v
 return o

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--expected-manifest-sha256',required=True);a=p.parse_args()
 try: print(json.dumps(verify(R,a.expected_manifest_sha256),sort_keys=True))
 except Exception as e: print('CONTEXT_INVALID:'+type(e).__name__+':'+str(e),file=sys.stderr);sys.exit(1)
