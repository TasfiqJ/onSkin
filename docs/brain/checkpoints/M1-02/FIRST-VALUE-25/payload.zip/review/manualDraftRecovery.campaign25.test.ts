import { createHash, randomUUID } from 'node:crypto';
import { createElement } from 'react';
import { act, create, type ReactTestRenderer } from 'react-test-renderer';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

import ManualAddScreen from '@/app/shelf/manual';
import { Button } from '@/components/ui/Button';
import { ShelfDataAvailabilityGate } from '@/features/shelf/ShelfDataAvailabilityGate';
import { IntakeProvider } from '@/features/shelf/IntakeContext';
import { addProduct, loadShelf } from '@/features/shelf/store';
import { HEALTH_DATA_CONSENT } from '@/features/onboarding/consentCopy';
import { setHealthDataCollectionConsentLocal } from '@/features/onboarding/healthConsentStore';
import { setStoredSkinProfileFromExplicitQuiz } from '@/features/onboarding/skinProfileStore';
import { ONBOARDING_QUIZ, scoreQuiz, type QuizAnswers } from '@/features/onboarding/quiz';
import { runAccountGenerationOperation } from '@/lib/auth/accountGeneration';
import {
  clearActiveHealthProcessingEpoch,
  setActiveHealthProcessingEpoch,
} from '@/lib/consent/healthProcessingEpoch';

// Actual Query, Shelf store, privateKV encryption/codecs, profile/consent receipts,
// intake provider, and account/current-grant admission run unchanged. Only native
// rendering/persistence hardware and absent external transport are controlled.
const native = vi.hoisted(() => ({
  bytes: new Map<string, string>(),
  failShelfReads: false,
  pushes: [] as unknown[],
}));
vi.mock('react-native-get-random-values', () => ({}));
vi.mock('react-native', () => ({
  Platform: { OS: 'web' },
  ActivityIndicator: 'ActivityIndicator', View: 'View', Text: 'Text',
  Pressable: 'Pressable', ScrollView: 'ScrollView', TextInput: 'TextInput',
  useWindowDimensions: () => ({ width: 430, height: 932, fontScale: 1 }),
}));
vi.mock('react-native-safe-area-context', () => ({
  SafeAreaView: 'SafeAreaView',
  useSafeAreaInsets: () => ({ top: 0, bottom: 0, left: 0, right: 0 }),
}));
vi.mock('expo-status-bar', () => ({ StatusBar: 'StatusBar' }));
vi.mock('expo-haptics', () => ({ selectionAsync: async () => undefined }));
vi.mock('expo-secure-store', () => ({}));
vi.mock('expo-crypto', () => ({
  randomUUID,
  CryptoDigestAlgorithm: { SHA256: 'SHA-256' },
  digestStringAsync: async (_algorithm: unknown, text: string) => createHash('sha256').update(text).digest('hex'),
}));
vi.mock('expo-router', () => ({
  router: { push: (route: unknown) => native.pushes.push(route), replace: vi.fn(), canGoBack: () => true, back: vi.fn() },
  useLocalSearchParams: () => ({}),
}));
vi.mock('@/lib/supabase/client', () => ({
  supabase: { from: () => { throw new Error('NO_EXTERNAL_TRANSPORT_IN_LOCAL_REPRO'); } },
}));
// Avoid eager import of unrelated UI barrel exports while keeping each used UI
// component's actual implementation. No application UI behavior is replaced.
vi.mock('@/components/ui', async () => ({
  ...(await import('@/components/ui/Button')),
  ...(await import('@/components/ui/Screen')),
  ...(await import('@/components/ui/Text')),
  ...(await import('@/components/ui/RouteIconButton')),
  ...(await import('@/components/ui/StateNotice')),
}));
vi.mock('@react-native-async-storage/async-storage', () => ({
  default: {
    getItem: async (key: string) => {
      if (native.failShelfReads && key === 'layerwell.shelf.v1') throw new Error('SYNTHETIC_NATIVE_SHELF_READ_FAILURE');
      return native.bytes.get(key) ?? null;
    },
    setItem: async (key: string, raw: string) => { native.bytes.set(key, raw); },
    getAllKeys: async () => [...native.bytes.keys()],
    multiGet: async (keys: string[]) => keys.map((key) => [key, native.bytes.get(key) ?? null]),
    removeItem: async (key: string) => { native.bytes.delete(key); },
    multiRemove: async (keys: string[]) => { keys.forEach((key) => native.bytes.delete(key)); },
  },
}));

let screen: ReactTestRenderer | undefined;
let client: QueryClient;
const delay = () => new Promise<void>((resolve) => setTimeout(resolve, 20));
async function flush() { await act(async () => { await delay(); }); }
function input(label: string) {
  return screen!.root.findAllByType('TextInput' as never).find((node) => node.props.accessibilityLabel === label)!;
}
async function mountAndType() {
  await act(async () => {
    screen = create(createElement(QueryClientProvider, { client },
      createElement(IntakeProvider, null,
        createElement(ShelfDataAvailabilityGate, null, createElement(ManualAddScreen)))));
  });
  await flush();
  expect(input('Product name')).toBeDefined();
  await act(async () => {
    input('Product name').props.onChangeText('Unsaved synthetic cleanser');
    input('Brand').props.onChangeText('Synthetic brand');
    input('Ingredients').props.onChangeText('Aqua, Glycerin');
  });
}

beforeEach(async () => {
  (globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
  native.bytes.clear();
  native.pushes = [];
  native.failShelfReads = false;
  clearActiveHealthProcessingEpoch();
  await setHealthDataCollectionConsentLocal({
    granted: true, version: HEALTH_DATA_CONSENT.version, consentText: HEALTH_DATA_CONSENT.fullText,
  });
  const accountGeneration = await runAccountGenerationOperation((lease) => lease.generation);
  setActiveHealthProcessingEpoch(25, { ownerUserId: 'synthetic-review-owner-a', accountGeneration });
  const answers = Object.fromEntries(ONBOARDING_QUIZ.map((question) => [
    question.id, question.multiSelect ? [question.options[0]!.id] : question.options[0]!.id,
  ])) as QuizAnswers;
  await setStoredSkinProfileFromExplicitQuiz({ result: scoreQuiz(answers), goals: ['clear_skin'], completedAt: new Date().toISOString() });
  await addProduct({ name: 'Existing synthetic owned balm', category: 'moisturiser', addedVia: 'manual', operationId: randomUUID() });
  expect(await loadShelf()).toHaveLength(1);
  expect(native.bytes.get('layerwell.shelf.v1')).not.toContain('Existing synthetic owned balm');
  client = new QueryClient({ defaultOptions: { queries: { retry: false, retryDelay: 0, gcTime: Infinity } } });
});

afterEach(async () => {
  native.failShelfReads = false;
  await act(async () => { screen?.unmount(); });
  screen = undefined;
  client.clear();
  clearActiveHealthProcessingEpoch();
});

it('retains an unsaved manual draft across same-grant encrypted Shelf read failure and retry', async () => {
  await mountAndType();
  const before = native.bytes.get('layerwell.shelf.v1');
  native.failShelfReads = true;
  await act(async () => { await client.refetchQueries({ queryKey: ['shelf'], exact: true }); });
  await flush();
  expect(client.getQueryState(['shelf'])?.status).toBe('error');
  expect(JSON.stringify(screen!.toJSON())).toContain('Shelf data unavailable');
  expect(native.bytes.get('layerwell.shelf.v1')).toBe(before);
  native.failShelfReads = false;
  await act(async () => { await client.refetchQueries({ queryKey: ['shelf'], exact: true }); });
  await flush();
  expect(client.getQueryState(['shelf'])?.status).toBe('success');
  expect(input('Product name').props.value).toBe('Unsaved synthetic cleanser');
  expect(input('Brand').props.value).toBe('Synthetic brand');
  expect(input('Ingredients').props.value).toBe('Aqua, Glycerin');
  expect(await loadShelf()).toHaveLength(1);
  expect(native.pushes).toEqual([]);
});

it('denies a captured Continue handler while the canonical Shelf read is unavailable', async () => {
  await mountAndType();
  const continueBeforeFailure = screen!.root.findAllByType(Button).find((node) => node.props.label === 'Continue')!.props.onPress;
  native.failShelfReads = true;
  await act(async () => { await client.refetchQueries({ queryKey: ['shelf'], exact: true }); });
  await flush();
  expect(client.getQueryState(['shelf'])?.status).toBe('error');
  await act(async () => { continueBeforeFailure(); });
  expect(native.pushes).toEqual([]);
});

it('denies an old Continue handler immediately after same-owner clear and regrant', async () => {
  await mountAndType();
  const oldContinue = screen!.root.findAllByType(Button).find((node) => node.props.label === 'Continue')!.props.onPress;
  const accountGeneration = await runAccountGenerationOperation((lease) => lease.generation);
  await act(async () => {
    clearActiveHealthProcessingEpoch();
    setActiveHealthProcessingEpoch(25, { ownerUserId: 'synthetic-review-owner-a', accountGeneration });
    oldContinue();
  });
  expect(native.pushes).toEqual([]);
});
