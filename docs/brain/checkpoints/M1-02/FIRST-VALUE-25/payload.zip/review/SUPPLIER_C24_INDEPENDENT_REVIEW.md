# Fresh independent Campaign24 return review

Result: actual supplier binary independently retrieved, authenticated, safely
extracted, and fully verified against a fresh complete exact-head remote clone.
This establishes artifact integrity and finite source governance only. It grants
no Security, database, J01, native, provider, clinical, Apple or release acceptance.

## Fresh download and independent bootstrap

Downloaded on 2026-10-29T01:31:02Z from the immutable URL authenticated in the
Campaign25 SOURCE_ANCHORS.json:

https://raw.githubusercontent.com/TasfiqJ/onSkin/33d361de216e92c5f05a978c5b7a64ccb54be3b0/onSkin_Campaign24_Security_Advisory_DB_Recovery_Return_2026-10-28.zip

- HTTP 200, no redirect; exactly 8,022,078 bytes.
- Outer ZIP SHA256: `1c0587b97a8876bb1a35954be59ca088433a1c055a2cf146c92f2a68af75414b`.
- Manifest SHA256: `0edfc416b5438c06188fa03b32c23b39f4567e384fc6b95d05a07efefad60dbf`.
- Return verifier SHA256: `eaa09de742c18eb090dfbe6ef8b2ecff64dacfe72525f1afe179719b22bb9fa4`.
- Nested checkpoint manifest SHA256: `ce4a2e34d070a1916d1957ff1cd6c6267fc54879d5e7a0485693eac034e8be9d`.
- 527 exact regular outer files, 27,029,673 expanded bytes.
- 353 exact authenticated checkpoint payload files, 10,232,015 expanded bytes.

The independent bootstrap bounded the fresh download and every expansion;
checked traversal/drive/absolute/Windows-reserved paths, NFKC/casefold aliases
including implicit parents, file/parent conflicts, duplicate members, regular
Unix/DOS modes, ZIP flags/extras, central/local framing/identity, gaps/overlaps,
trailing bytes, member counts and hashes. It authenticated all manifest members,
both verifier and nested checkpoint/payload inventory before exclusive extraction
into the new empty `campaign25-review/c24` directory. No stale archive was used.

## Actual authenticated verifier results

The verifier was read after hash authentication. Its artifact-only execution
returned exit 0 / VERIFIED. Its independent full Git execution returned exit 0 /
VERIFIED and actually checked:

- Final HEAD `d0ccef65bcbe0c90483e6c0f691ed95f92228c6c`.
- Tree `22f91455d651a81296ab8724f9db7cfead65af08`.
- Full pinned ancestry, single worklist child and single evidence tail.
- 23,489 tracked metadata entries, exact index/tree and checkout snapshots.
- 31 changed public working file blob identities.
- Exact checkpoint copies against committed blobs.
- Delta bundle prerequisites and strict pack dry-run, with no object writes.

The optional complete source execution initially refused with
`RELEASE24_SOURCE_CHECK_FAILED` because the fresh clone had no installed native
dependency sources required by the inherited Release13 installed-source guard.
That actual failed run is retained, not counted as PASS.

Normal `npm ci` with a new empty npm cache then ran successfully on Node22.21.0 /
npm11.20.0, including mandatory repository postinstall patches. It added 1,028
packages in 43 seconds. npm reported two package install scripts outside its
allowScripts list; no new approval was granted. The source checkout remained
clean. `node scripts/postinstall.mjs --check` and the original strict Phase4
producer passed.

The unchanged authenticated verifier was then run with all exact external hashes,
`--git-root`, `--expected-head`, `--expected-tree`, and
`--execute-source-checks`. It returned exit 0 / VERIFIED after 263.130934 seconds:

- Release24: `PASS_FINITE_SOURCE_GOVERNANCE_ONLY`.
- Phase4: `PASS_UNCHANGED_PRODUCER_STRICT_CHECK`.
- Phase4 producer SHA256:
  `b3882f954498008cd80fe57d50f75c358504bca99f5f97b7481239977af26d1e`.
- Execution: `INDEPENDENT_EXACT_HEAD_CHECKOUT_NO_CI_EVENT_CLAIM`.
- Release `NO_GO`; acceptanceGranted=false;
  sourceAcceptance=`SUBMITTED_REVIEW_REQUIRED`.

No source files were edited. No source tamper 0/1/0 or artifact corruption 0/1/0
was performed in this supplier-review subtask; the supplier's archived controls
are not reclassified as independently repeated controls here. Native/iPhone,
VoiceOver, remote provider and clinical evidence were not executed.

## Actual receipts outside source

- `supplier-c24-download-receipt.json`
- `supplier-c24-authentication-receipt.json`
- `supplier-c24-artifact-verifier-receipt.json`
- `supplier-c24-git-verifier-receipt.json`
- `supplier-c24-source-verifier-receipt.json` — initial missing-install failure.
- `supplier-c24-source-diagnosis-summary.json` — read-only stage diagnosis.
- `supplier-c24-npm-ci-receipt.json` and `supplier-c24-npm-ci.log`.
- `supplier-c24-source-after-install-verifier-receipt.json` — final complete PASS.

The large raw metadata diagnosis file is unnecessary for the return; use its
compact summary. The fresh supplier ZIP and clone can remain local review inputs
and need not be duplicated into the Campaign25 return. Public immutable supplier
URL plus verified download receipts preserve custody without another ZIP deliverable.

G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03
BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED. All protected
J01/native/VoiceOver/provider/clinical/legal/licensing/Apple/public gates remain
closed. USD0, no merges, no production access, SUBMITTED_REVIEW_REQUIRED.
