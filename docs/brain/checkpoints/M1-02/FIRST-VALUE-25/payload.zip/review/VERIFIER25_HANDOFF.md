# Campaign25 standalone verifier handoff

External drafts only. No repository files were edited by this worker.

Current reviewed input: exact committed plan `f25db3f5c74d0ad3ddd78ece70f79d315ab57662`, plan SHA256 `80c81b9f93b696f3d14bf99689ed9f592b18258fd7a96fe01a88de695033d136`, PR28 base `d0ccef65bcbe0c90483e6c0f691ed95f92228c6c`, tree `22f91455d651a81296ab8724f9db7cfead65af08`. The executed source checker is pinned to SHA256 `bcb0235eb05d653b27b0871c52f72f6300513c68f2de46a3e959194fb5cbc838`.

| File | SHA256 |
| --- | --- |
| `verify25.py` | `e12a0e3ae733b3c611ce9f6493502e1b454f41b4f3c14868e8a45a76af493a01` |
| `verify_return25.py` | `5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a` |
| `test_verifiers25.run11.log` | `4c38579ab1054e2a28bd70e508c173effa97b2afff1d4338690c57619aaac0ee` |

Do not reformat or independently edit one verifier. They deliberately use identical engine bytes except the first MODE assignment. The outer verifier checks that the embedded checkpoint verifier is exactly its paired checkpoint engine. Each CLI also checks that the packaged verifier equals the externally pinned executing verifier. `build_verifiers25.py` reproduces both from the Campaign24 primitives plus `verifier25_git_fragment.py`; those preparation helpers remain external.

## Trust and results

Authenticate the manifest and verifier against separately supplied SHA256 values before executing downloaded code. Passing their hashes as CLI arguments is a repeated assertion, not a way for a program to authenticate its own execution. The independently supplied hashes and exact final Git head/tree are the trust anchors.

Artifact-only verification checks full inventory, hashes, strict nonadmitting schema and recursive archive safety. It reports `sourceChecks.state=NOT_RUN`, and outer Git/history semantics `NOT_CHECKED_WITHOUT_GIT_ROOT`. It never labels source or release accepted.

Final `--git-root --execute-source-checks` verification requires a complete standalone clean checkout, exact externally pinned HEAD/tree, PR27 ancestry, pinned PR28 base, exact plan-first commit, finite per-commit and cumulative path/mode provenance, unchanged plan, one worklist-only child, one subsequent evidence-only tail, exact index/tree, no hidden index flags or unknown ignored/untracked source, and raw hashing of every tracked working blob. No source checker is run until these checks and all artifact hashes pass. The audited checker SHA is rechecked before execution. Its JSON must say `RELEASE25_FINITE_SCOPE_ONLY`, `source25.phase=TAIL`, `workingQualification=RAW_TRACKED_BLOBS_EXACT`, current endpoint/tree, `NO_GO`, `SUBMITTED_REVIEW_REQUIRED`, acceptance false and all six admissions strictly false. The original PR28 Phase4 producer must be byte-identical and pass `--strict --check`. Raw tracked blobs are rechecked after execution too.

Git delta verification requires the bundle's sole prerequisite to be exact PR28 and its sole advertised head to be the final candidate. PACK headers, every zlib stream and delta instruction/result are bounded before native Git. Native index-pack runs with one thread/cache limits in a task-owned temporary bare object store. The source object store is read-only. The original delivered pack object set must equal exactly final-head reachability minus PR28; any thin-pack bases appended by native Git must belong to PR28. A temporary alternate used solely for this parser is explicitly not an independent checkout. No such temporary parser counts toward final clean-checkout evidence.

Run6: **10 positive controls and 48 refusals PASS**. Includes checkpoint and outer corruption/restoration, recursive ZIP/path/implicit-directory aliases, traversal, links/special entries, local/central disagreement, adjusted ZIP prefix, expansion, duplicate/nonfinite JSON, real tiny native-Git exact delta and omitted/extra object refusals, oversized PACK object/delta/base/aggregate refusal before native parsing, and stat-cache-hidden raw working-body 0/1/0. These are synthetic controls, not final source/checkpoint acceptance. Native/clinical/legal/provider/Apple/public-release gates remain closed.

## Checkpoint schema and creation

Build the checkpoint outside the repository until the source/worklist freeze is committed. Its exact files are `README.md`, `REPORT.md`, `verify25.py`, `payload.zip`, `manifest.json`. Payload, outer and recursively nested ZIPs must contain regular file entries with Unix `S_IFREG|0644`, no extra/comment/encryption fields, and canonical unique names. All explicit ZIP directory entries are rejected; required directories remain implicit in regular file paths. Never include real accounts/photos/secrets or private finding stores.

`manifest.json` has exactly:

```json
{
  "schema": 1,
  "authority": "BRAIN-M1X-REAL-FIRST-VALUE25-SOURCE-CANDIDATE-01",
  "status": "SUBMITTED_REVIEW_REQUIRED",
  "acceptanceGranted": false,
  "release": "NO_GO",
  "inputManifestSHA256": "c539789e768f94fd0e79c6ab97c64dd247b0fbfb0918921f1d77ee3f20e19fc0",
  "source": {
    "base": "d0ccef65bcbe0c90483e6c0f691ed95f92228c6c",
    "baseTree": "22f91455d651a81296ab8724f9db7cfead65af08",
    "runtimeHead": "24b876fe068823c964c6796b0c8bf5a3bf4c090e",
    "runtimeTree": "00f59923f687c3152cdfc63b2cabf4632e107634",
    "sourceHead": "165055f1c840821d89df1d7673468c0a19f20185",
    "sourceTree": "576ac3809428e551b3821e8ce0d5b2bcb366eeb9"
  },
  "files": {
    "README.md": {"bytes": 0, "sha256": "ACTUAL_SHA256"},
    "REPORT.md": {"bytes": 0, "sha256": "ACTUAL_SHA256"},
    "verify25.py": {"bytes": 0, "sha256": "ACTUAL_SHA256"},
    "payload.zip": {"bytes": 0, "sha256": "ACTUAL_SHA256"}
  },
  "payload": {
    "schema": 1,
    "qualification": "SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE",
    "files": {"receipts/actual.json": {"bytes": 0, "sha256": "ACTUAL_SHA256"}}
  }
}
```

Replace all placeholders with exact byte counts/hashes and forty-character lowercase Git IDs. Hash raw saved files. Do not put the manifest in its own files inventory, or name the future evidence-tail head inside the checkpoint manifest/report. The source-head worklist child precedes the evidence tail, so no circular identity is necessary.

Use artifact-only CLI first and retain actual current/corrupted/restored 0/1/0 receipts outside the checkpoint staging directory. Then copy the five exact checkpoint files plus truthful root handoff into the one authorized evidence-only tail. Commit once. No source or second-tail changes afterward.

## Outer schema and post-tail creation

After the tail, produce the minimal bundle in an external staging directory:

```text
git bundle create ABSOLUTE_STAGING/source.delta.bundle HEAD ^d0ccef65bcbe0c90483e6c0f691ed95f92228c6c
```

Use `HEAD` as the advertised bundle ref. Do not add other refs. The final head must be the sole evidence tail. The outer `source` object extends the checkpoint's six fields with `candidateHead` and `candidateTree` for that exact tail.

Generate authenticated path history using the reviewed local outer verifier as a preparation library. Verify the library's SHA256 before importing; run Python with `-B`. Call `git_history(repo_path, outer_source)` and save its returned JSON in `path-history.json`. It includes every child commit's parent/tree, exact sorted changed paths, status, before/after `mode`, Git `blob`, raw `bytes` and SHA256, plus the full cumulative delta. Its qualification is `GIT_HISTORY_AND_BLOB_IDENTITIES_NOT_ACCEPTANCE`. The final outer verifier compares the entire document with actual Git when `--git-root` is given.

Outer files must include `FINAL_REPORT.md`, `verify_return25.py`, `source.delta.bundle`, `path-history.json`, and all five checkpoint files under `checkpoint/`. Additional sanitized post-tail CI/reproduction evidence is permitted only when included in the exact authenticated outer inventory.

The outer manifest has the same common schema/authority/status/false acceptance/NO_GO/input fields as the checkpoint, plus exactly:

```json
{
  "source": {"base": "...", "baseTree": "...", "runtimeHead": "...", "runtimeTree": "...", "sourceHead": "...", "sourceTree": "...", "candidateHead": "...", "candidateTree": "..."},
  "qualification": "SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE",
  "checkpoint": {"path": "checkpoint", "manifestSHA256": "ACTUAL_CHECKPOINT_MANIFEST_SHA256"},
  "gitDelta": {"path": "source.delta.bundle", "base": "d0ccef65bcbe0c90483e6c0f691ed95f92228c6c", "baseTree": "22f91455d651a81296ab8724f9db7cfead65af08", "head": "FINAL_TAIL_HEAD", "tree": "FINAL_TAIL_TREE"},
  "gitHistory": {"path": "path-history.json"},
  "files": {"EVERY_NONMANIFEST_OUTER_FILE": {"bytes": 0, "sha256": "ACTUAL_SHA256"}}
}
```

Do not add outer `payload` or other fields. All nonmanifest files, including the inner manifest, are inventoried. The outer manifest itself and ZIP hash belong in the external hash annex. The internal report is explicitly written before outer manifest/ZIP hashing; publish the complete final report/hash annex outside the ZIP afterward so it can truthfully include exact outer ZIP, both manifests and both verifier SHA256s without self-hashing.

## CLI

Both verifiers support the same options. Always use two ASCII hyphens:

```text
python -B verify25.py --root EXTERNAL_CHECKPOINT --expected-manifest-sha256 CHECKPOINT_MANIFEST_SHA256 --expected-verifier-sha256 CHECKPOINT_VERIFIER_SHA256
python -B verify_return25.py --archive RETURN.zip --expected-manifest-sha256 OUTER_MANIFEST_SHA256 --expected-verifier-sha256 OUTER_VERIFIER_SHA256
```

Exactly one of `--root` and `--archive` may be supplied. Root defaults to the executing verifier's directory. These artifact-only commands perform no source execution and truthfully report NOT_RUN.

For each genuinely independent full remote checkout at the final head:

```text
python -B EXTERNAL/verify_return25.py --archive RETURN.zip --expected-manifest-sha256 OUTER_MANIFEST_SHA256 --expected-verifier-sha256 OUTER_VERIFIER_SHA256 --git-root CLEAN_FINAL_CHECKOUT --expected-head FINAL_TAIL_HEAD --expected-tree FINAL_TAIL_TREE --execute-source-checks
```

The checkpoint verifier can use the same Git options with `--root EXTERNAL_CHECKPOINT`. A final Git run always requires the evidence tail; no pre-tail mode can be mistaken for final proof. Keep all command outputs outside the clean checkout. Run actual full-checkout source 0/1/0 separately and preserve exact restoration receipts. Capture two genuine remote-clone final results; synthetic tests and local scratch clones do not substitute. No merges, spend or release acceptance.

Latest supplemental run: `test_verifiers25.run8.log` passed **11 positive controls and 48 refusals**, adding a real native thin REF_DELTA bundle while leaving both verifier files unchanged. Log SHA256: `77e9a7a878b1a64928d3b2e88b3e7058a308461d09da00ba515535d8a506d66c`. Test script SHA256: `c5f875ceae90e3b5f7e533ad3ac111bb112301f7add3dbfee24e2c23bcc7d096`. Earlier failed preparation/fixture runs remain retained and are not counted as passing proof.

## Final independent directory and bundle-header repairs

Before copying evidence into the repository, an independent reviewer reproduced two additional format gaps in the old `6107...`/`9cf7...` pair. A zero-declared-byte explicit directory could hide a 2 MiB DEFLATE stream because directory entries were not read; the old bundle header predicate also admitted a v3 capability line under a v2 header, although native Git correctly refused it. Preserve `today-verifier-probe.json`, `today-bundle-probe.json` and the old `*.before-directory-fix.py` bytes as before evidence.

The current pair in the table rejects every explicit ZIP directory entry before processing, including ordinary empty entries. Bundle v2 permits no capability lines; v3 requires exactly the supported first `@object-format=sha1` capability. File-only writers remain compatible. Run10 passed **12 positive controls and 52 refusals**, including both independent regressions, a v3 SHA1 positive and unsupported SHA256 refusal. Current test script SHA256: `2d38eec834482ef2a5c0715e9bc28ce55919346064318a9964561f36fd8c106d`. The earlier runs remain retained; they do not supersede this repaired pair.

A further independent Python 3.9 probe found costly arbitrary-length default JSON integer conversion before schema checks. The current pair rejects numeric tokens longer than twenty decimal digits before calling `int()`, and rejects floats directly at parse time. Run11 passed **12 positive controls and 53 refusals**, including a 1.5-million-digit schema integer refused as `JSON_INTEGER_BOUND`. Final current test script SHA256: `547c1d1b62073aee97e59acc472e3541cf75d5ca53350d4b8b079322b0f70a00`. All previous findings and receipts remain retained.
