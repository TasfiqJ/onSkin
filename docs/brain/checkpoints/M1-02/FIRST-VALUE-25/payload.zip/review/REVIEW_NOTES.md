# Independent Campaign25 manual-draft reproduction

Read-only review of the source checkout. All added files and logs are outside the source tree.

`manualDraftRecovery.campaign25.test.ts` mounts the actual manual route, IntakeProvider, ShelfDataAvailabilityGate, and useShelf with real React Query. Actual Shelf store, encrypted privateKV, consent receipt, quiz scorer/profile receipt, account generation, and health grant implementations execute. Native storage/rendering/router/crypto and unavailable Supabase transport are controlled. Used UI components are actual implementations selected through the barrel to avoid eager unrelated imports.

Command, from this directory:

```
node ./node_modules/vitest/vitest.mjs run --config ./vitest.config.ts
```

Baseline run exited 1 with three distinct failing assertions:

1. After real encrypted Shelf refetch failure and successful recovery, unsaved name is the empty string instead of `Unsaved synthetic cleanser`. Existing encrypted Shelf bytes are unchanged during failure.
2. A Continue handler captured before the error still resets the intake and pushes `/shelf/opened` while the canonical Shelf query is in error.
3. A Continue handler captured under the previous grant still resets the intake and pushes `/shelf/opened` immediately after the same owner/epoch is cleared and regranted, before React commits.

The duplicate-add scenario previously described is a hypothesis, not a proved result. `invalidateQueries()` normally resolves even when a refetch fails, and `clearIfCurrent()` may finish after unmount. It must not be reported as reproduced without its own mounted test.

## Opened-only authorized reproduction

`intakeRecovery.campaign25.test.ts` uses the same actual application/runtime components and native ports. It opts into the proposed `preserveMountedDraft: true` boundary behavior; baseline ignores the currently unknown property. Its independent baseline run exited 1 with all three tests failing:

1. Exact opened-date selection and unconfirmed custom PAO text are lost after same-grant read failure/recovery.
2. A captured Add handler, invoked after canonical Query error but after native read hardware has recovered, writes a new product despite no canonical Query recovery. The actual Shelf has two products instead of the expected existing one.
3. A native add commits, then all following native Shelf reads fail. The actual source clears the intake session despite canonical readback remaining in error. The old session becomes null, losing the continuation/retry context.

These are actual before-failing assertions, not the duplicate-add hypothesis. `intakeRecovery.baseline.log` retains the full run. Manual findings remain separately recorded for UNAPPLIED/OPEN_REQUIRED treatment because manual.tsx is outside the committed finite path grant.

Keeping already-admitted children mounted can retain drafts, but only within the exact current authority generation. Hide them from layout, pointer/keyboard interaction, and accessibility when data is unavailable. Initial loading must not mount a form. Closing/regranting, expiry, owner A/B/A, or account-generation changes must retire old children synchronously. Hiding does not disable retained handlers or effects: route handlers must separately assert their captured grant and canonical Query status before resetting intake, writing, or navigating. Pending save settlements need an exact attempt/mounted authority fence. The new tests include stale-handler challenges so a visibility-only fix cannot pass.
