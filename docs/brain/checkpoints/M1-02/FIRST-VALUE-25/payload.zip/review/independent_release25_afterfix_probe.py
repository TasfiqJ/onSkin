"""Independent after-fix controls; original before receipts remain unchanged."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parent / 'campaign25-source'
DRAFT = BASE / 'check25-draft.py'
EXPECTED = 'bcb0235eb05d653b27b0871c52f72f6300513c68f2de46a3e959194fb5cbc838'
raw = DRAFT.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
namespace = {'__name__': 'independent_release25_review', '__file__': str(SOURCE / 'scripts/release/full-app-j01/check.py')}
exec(compile(raw, str(DRAFT), 'exec'), namespace)
namespace['validate25_checker'](raw)
lines = raw.splitlines(keepends=True)
target = next(node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef) and node.name == 'source25_guard')
mutated = b''.join(lines[:target.lineno-1]) + b'def source25_guard():\n    return {}\n' + b''.join(lines[target.end_lineno:])
try:
    namespace['validate25_checker'](mutated)
except ValueError as error:
    assert error.args == ('R25_APPENDIX_BYTES',)
    print(json.dumps({'case': 'disabled-source25-guard-body-refused', 'exit': 1, 'expectedExit': 1, 'code': error.args[0], 'draftSHA256': EXPECTED}))
else:
    raise AssertionError('Disabled Release25 source guard admitted')

with tempfile.TemporaryDirectory(prefix='release25-stat-afterfix-', dir=BASE) as temporary:
    root = Path(temporary)
    def git(*args):
        return subprocess.run(['git', '--no-replace-objects', '-c', 'core.hooksPath=', *args], cwd=root, capture_output=True, check=True).stdout
    git('init', '--quiet'); git('config', 'core.autocrlf', 'false'); git('config', 'core.trustctime', 'false')
    path = root / 'protected.py'
    path.write_bytes(b'allowed = False\n')
    os.utime(path, (1_600_000_000, 1_600_000_000))
    git('add', 'protected.py')
    git('-c', 'user.name=ExternalReview', '-c', 'user.email=review@example.invalid', 'commit', '--quiet', '-m', 'synthetic stat fixture')
    oid = git('rev-parse', 'HEAD:protected.py').decode().strip()
    git('status', '--porcelain=v1')
    previous_root = namespace['ROOT']; namespace['ROOT'] = root
    try:
        index = {'protected.py': ('100644', oid)}
        assert namespace['working25_guard'](index) == 1
        print(json.dumps({'case': 'raw-protected-blob-current', 'exit': 0, 'expectedExit': 0}))
        original = path.read_bytes(); before = path.stat()
        path.write_bytes(b'allowed = True \n')
        os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
        assert not git('status', '--porcelain=v1') and not git('diff', '--raw', '--no-abbrev', '--no-renames', '-z', 'HEAD')
        try:
            namespace['working25_guard'](index)
        except ValueError as error:
            assert error.args == ('R25_WORKING_BLOB',)
            print(json.dumps({'case': 'git-clean-stat-cache-protected-mutation-refused', 'exit': 1, 'expectedExit': 1, 'code': error.args[0]}))
        else:
            raise AssertionError('Raw changed protected body admitted')
        path.write_bytes(original)
        os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
        assert namespace['working25_guard'](index) == 1
        print(json.dumps({'case': 'raw-protected-blob-restored', 'exit': 0, 'expectedExit': 0}))
    finally:
        namespace['ROOT'] = previous_root
print(json.dumps({'status': 'PASS', 'qualification': 'INDEPENDENT_SYNTHETIC_AFTER_FIX_CONTROLS_NOT_FULL_CHECKOUT_OR_ACCEPTANCE', 'sourceEdited': False}))
