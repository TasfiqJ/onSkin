"""Synthetic controls for owned verifier drafts; not final source/acceptance proof."""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import struct
import subprocess
import sys
import tempfile
import warnings
import zipfile
import zlib
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
def load(name):
    spec = importlib.util.spec_from_file_location(name, HERE/(name+'.py'))
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module
checkpoint = load('verify25'); outer = load('verify_return25')
positive = refused = 0
def check(name, action, code=None, valid=False):
    global positive, refused
    try: result = action()
    except Exception as error:
        assert not valid and (code is None or type(error) is checkpoint.Refusal or type(error) is outer.Refusal), (name, type(error).__name__)
        if code is not None: assert error.args == (code,), (name, error.args)
        refused += 1; print(json.dumps(dict(case=name, exit=1, expectedExit=1, code=code)), flush=True)
    else:
        assert valid, name+' admitted'
        positive += 1; print(json.dumps(dict(case=name, exit=0, expectedExit=0)), flush=True)
        return result
def encoded(value): return (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()
def witness(raw): return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def archive(members):
    buffer = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as target:
            for name, raw, mode in members:
                info = zipfile.ZipInfo(name); info.create_system = 3; info.external_attr = mode << 16
                info.compress_type = zipfile.ZIP_DEFLATED; target.writestr(info, raw)
    return buffer.getvalue()
regular = stat.S_IFREG|0o644
def zip_files(files): return archive([(name, raw, regular) for name, raw in sorted(files.items())])
def write_files(root, files):
    for name, raw in files.items():
        path = root/name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(raw)

with tempfile.TemporaryDirectory(prefix='verifier25-controls-', dir=HERE) as temporary:
    scratch = Path(temporary)
    root = scratch/'checkpoint'; root.mkdir()
    source = dict(base=checkpoint.BASE, baseTree=checkpoint.BASE_TREE, runtimeHead=checkpoint.PLAN_COMMIT,
                  runtimeTree='1'*40, sourceHead='a'*40, sourceTree='2'*40)
    payload_files = {'receipts/synthetic.json': encoded(dict(state='NOT_RUN', qualification='SYNTHETIC_ONLY')),
                     'nested/controls.zip': zip_files({'record.txt': b'Synthetic nested regular artifact\n'})}
    files = {'README.md': b'Synthetic checkpoint NO_GO\n', 'REPORT.md': b'Synthetic source-only controls NOT_RUN\n',
             'verify25.py': (HERE/'verify25.py').read_bytes(), 'payload.zip': zip_files(payload_files)}
    manifest = dict(schema=1, authority=checkpoint.AUTHORITY, status='SUBMITTED_REVIEW_REQUIRED', acceptanceGranted=False,
                    release='NO_GO', inputManifestSHA256=checkpoint.INPUT, source=source,
                    files={name:witness(raw) for name, raw in files.items()},
                    payload=dict(schema=1, qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',
                                 files={name:witness(raw) for name, raw in payload_files.items()}))
    raw_manifest = encoded(manifest); files['manifest.json'] = raw_manifest; write_files(root, files)
    anchor = checkpoint.sha(raw_manifest)
    check('checkpoint-directory-current', lambda: checkpoint.checkpoint(checkpoint.Directory(root), anchor), valid=True)
    check('checkpoint-archive-current', lambda: checkpoint.checkpoint(checkpoint.Archive(zip_files(files)), anchor), valid=True)
    report = root/'REPORT.md'; original = report.read_bytes(); report.write_bytes(original+b'CORRUPT')
    check('checkpoint-artifact-corrupted', lambda: checkpoint.checkpoint(checkpoint.Directory(root), anchor), 'ARTIFACT_HASH_MISMATCH')
    report.write_bytes(original)
    check('checkpoint-artifact-restored', lambda: checkpoint.checkpoint(checkpoint.Directory(root), anchor), valid=True)
    check('external-manifest-mismatch', lambda: checkpoint.checkpoint(checkpoint.Directory(root), '0'*64), 'MANIFEST_SHA256_MISMATCH')
    for name, mutate, code in [
        ('acceptance', lambda v:v.update(acceptanceGranted=True), 'MANIFEST_AUTHORITY'),
        ('schema-bool', lambda v:v.update(schema=True), 'MANIFEST_AUTHORITY'),
        ('release-go', lambda v:v.update(release='GO'), 'MANIFEST_AUTHORITY'),
        ('wrong-authority', lambda v:v.update(authority='UNISSUED'), 'MANIFEST_AUTHORITY'),
        ('extra-top-field', lambda v:v.update(tailHead='b'*40), 'MANIFEST_SCHEMA'),
    ]:
        altered = copy.deepcopy(manifest); mutate(altered); altered_raw = encoded(altered)
        variant = dict(files); variant['manifest.json'] = altered_raw
        check(name, lambda d=variant,a=checkpoint.sha(altered_raw): checkpoint.checkpoint(checkpoint.Archive(zip_files(d)), a), code)
    for name in ('../escape', '/absolute', 'C:/drive', 'a\\file', 'a//file', 'a./file', 'NUL.txt', 'a/\uff0e\uff0e/file', 'a/\uff0ffile'):
        raw_unsafe = archive([(name,b'x',regular)])
        if name == 'a\\file': raw_unsafe = raw_unsafe.replace(b'a/file', b'a\\file')
        check('unsafe-path', lambda raw=raw_unsafe: checkpoint.Archive(raw))
    for names in [('A/one','a/two'), ('A/one','\uff21/two'), ('a','a/child'), ('same','same'), ('\u00df/one','\u1e9e/two')]:
        check('implicit-parent-alias-or-collision', lambda names=names: checkpoint.Archive(archive([(n,b'x',regular) for n in names])))
    for mode in (stat.S_IFLNK|0o777, stat.S_IFIFO|0o644, stat.S_IFCHR|0o644, stat.S_IFREG|0o4644):
        check('linked-or-special-zip-entry', lambda mode=mode: checkpoint.Archive(archive([('unsafe',b'x',mode)])), 'ZIP_NONREGULAR_OR_UNSUPPORTED')
    check('zip-expansion-bound', lambda: checkpoint.Archive(archive([('large',b'0'*(3*1024*1024),regular)])), 'ZIP_EXPANSION_BOUND')
    empty_directory=archive([('evidence/',b'',stat.S_IFDIR|0o755),('evidence/item.txt',b'file',regular)])
    check('all-explicit-directory-entries-refused',lambda:checkpoint.Archive(empty_directory),'ZIP_EXPLICIT_DIRECTORY_FORBIDDEN')
    directory_stream=bytearray(archive([('evidence/',b'0'*(2*1024*1024),stat.S_IFDIR|0o755),('evidence/item.txt',b'file',regular)]))
    struct.pack_into('<I',directory_stream,14,0);struct.pack_into('<I',directory_stream,22,0)
    central=directory_stream.index(b'PK\x01\x02');struct.pack_into('<I',directory_stream,central+16,0);struct.pack_into('<I',directory_stream,central+24,0)
    check('zero-declared-directory-hidden-compressed-expansion-refused',lambda:checkpoint.Archive(bytes(directory_stream)),'ZIP_EXPLICIT_DIRECTORY_FORBIDDEN')
    raw_zip = zip_files({'one.txt':b'one'})
    check('trailing-zip-bytes', lambda: checkpoint.Archive(raw_zip+b'extra'), 'ZIP_DIRECTORY_BOUND')
    altered = bytearray(raw_zip); altered[30:37] = b'two.txt'
    check('local-central-filename-mismatch', lambda: checkpoint.Archive(bytes(altered)), 'ZIP_LOCAL_NAME')
    prefix = b'UNACCOUNTED'; altered = bytearray(prefix+raw_zip)
    end = altered.rfind(b'PK\x05\x06'); directory = struct.unpack_from('<I',altered,end+16)[0]+len(prefix)
    struct.pack_into('<I',altered,end+16,directory)
    cursor = directory
    while cursor < end:
        local = struct.unpack_from('<I',altered,cursor+42)[0]; struct.pack_into('<I',altered,cursor+42,local+len(prefix))
        cursor += 46+sum(struct.unpack_from('<HHH',altered,cursor+28))
    check('adjusted-prefix-refused', lambda: checkpoint.Archive(bytes(altered)), 'ZIP_LOCAL_OVERLAP_OR_GAP')
    nested = zip_files({'bad.tar.gz': b'\x1f\x8bsynthetic'})
    variant_payload = {'nested.zip': nested}; variant = {name:raw for name,raw in files.items() if name != 'manifest.json'}
    variant['payload.zip'] = zip_files(variant_payload); changed = copy.deepcopy(manifest)
    changed['files']['payload.zip'] = witness(variant['payload.zip']); changed['payload']['files'] = {name:witness(raw) for name,raw in variant_payload.items()}
    variant['manifest.json'] = encoded(changed)
    check('recursive-unsupported-archive-refused', lambda: checkpoint.checkpoint(checkpoint.Archive(zip_files(variant)), checkpoint.sha(variant['manifest.json'])), 'UNSUPPORTED_NESTED_ARCHIVE')
    for raw in (b'{"x":1,"x":2}',b'{"x":NaN}',b'{"x":1.0}'):
        check('duplicate-or-nonfinite-json', lambda raw=raw: checkpoint.loads(raw))
    check('huge-decimal-before-Python-int-conversion',lambda:checkpoint.loads(b'{"schema":'+b'9'*1_500_000+b'}'),'JSON_INTEGER_BOUND')
    extra = root/'extra.txt'; extra.write_bytes(b'extra')
    check('extra-artifact-file', lambda: checkpoint.checkpoint(checkpoint.Directory(root), anchor), 'UNEXPECTED_FILE'); extra.unlink()
    hard = root/'hardlink'; os.link(report, hard)
    check('hardlink-refused', lambda: checkpoint.checkpoint(checkpoint.Directory(root), anchor), 'FILE_MODE_OR_BOUND'); hard.unlink()
    checkpoint_sha = checkpoint.sha((HERE/'verify25.py').read_bytes())
    command = [sys.executable,'-B',str(HERE/'verify25.py'),'--root',str(root),'--expected-manifest-sha256',anchor,'--expected-verifier-sha256',checkpoint_sha]
    result = subprocess.run(command,capture_output=True,check=True)
    status = checkpoint.loads(result.stdout); assert status['sourceChecks'] == {'state':'NOT_RUN'} and status['acceptanceGranted'] is False
    positive += 1; print(json.dumps(dict(case='CLI-checkpoint-integrity-no-source-claim',exit=0,expectedExit=0)),flush=True)
    result = subprocess.run(command[:-1]+['0'*64],capture_output=True)
    assert result.returncode == 1 and checkpoint.loads(result.stdout)['error'] == 'EXTERNAL_VERIFIER_ANCHOR'
    refused += 1; print(json.dumps(dict(case='CLI-external-verifier-hash-refused',exit=1,expectedExit=1)),flush=True)

    # Outer fixture is explicitly synthetic: artifact-only verification must
    # never claim these declared Git identities were executed or accepted.
    outer_source = dict(source, candidateHead='b'*40, candidateTree='3'*40)
    def blob(raw): return dict(mode='100644', blob=hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest(), **witness(raw))
    def change(name, after, before=None): return dict(path=name,status='A' if before is None else 'M',before=None if before is None else blob(before),after=blob(after))
    plan_raw = (HERE.parent/'campaign25-source'/checkpoint.PLAN).read_bytes()
    plan_rows = [change(checkpoint.PLAN,plan_raw)]
    freeze_rows = [change(name,b'synthetic new worklist\n',b'synthetic old worklist\n') for name in sorted(checkpoint.WORKLIST)]
    tail_rows = [change(checkpoint.CHECKPOINT+name,raw) for name,raw in sorted(files.items())]
    tail_rows.append(change('ONSKIN_BRAIN_HANDOFF.txt',b'synthetic handoff NO_GO\n',b'synthetic old handoff\n')); tail_rows.sort(key=lambda row:row['path'])
    history = dict(schema=1,qualification='GIT_HISTORY_AND_BLOB_IDENTITIES_NOT_ACCEPTANCE',base=checkpoint.BASE,baseTree=checkpoint.BASE_TREE,
        head=outer_source['candidateHead'],tree=outer_source['candidateTree'],scopeCommit=checkpoint.PLAN_COMMIT,scopePlanSHA256=checkpoint.PLAN_SHA256,
        commits=[dict(commit=source['runtimeHead'],parent=checkpoint.BASE,tree=source['runtimeTree'],changes=plan_rows),
                 dict(commit=source['sourceHead'],parent=source['runtimeHead'],tree=source['sourceTree'],changes=freeze_rows),
                 dict(commit=outer_source['candidateHead'],parent=source['sourceHead'],tree=outer_source['candidateTree'],changes=tail_rows)],
        delta=sorted(plan_rows+freeze_rows+tail_rows,key=lambda row:row['path']))
    pack = b'PACK'+struct.pack('>II',2,1)+b'\x33'+zlib.compress(b'abc'); pack += hashlib.sha1(pack).digest()
    bundle_raw = ('# v2 git bundle\n-'+checkpoint.BASE+' synthetic prerequisite\n'+outer_source['candidateHead']+' HEAD\n\n').encode()+pack
    outer_files = {'checkpoint/'+name:raw for name,raw in files.items()}
    outer_files.update({'FINAL_REPORT.md':b'SYNTHETIC CONTROL NOT_RUN NO_GO\n','verify_return25.py':(HERE/'verify_return25.py').read_bytes(),
                       'source.delta.bundle':bundle_raw,'path-history.json':encoded(history)})
    outer_manifest = dict(schema=1,authority=outer.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO',
        inputManifestSHA256=outer.INPUT,source=outer_source,qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
        checkpoint=dict(path='checkpoint',manifestSHA256=anchor),gitDelta=dict(path='source.delta.bundle',base=outer.BASE,baseTree=outer.BASE_TREE,
        head=outer_source['candidateHead'],tree=outer_source['candidateTree']),gitHistory=dict(path='path-history.json'),
        files={name:witness(raw) for name,raw in outer_files.items()})
    outer_manifest_raw = encoded(outer_manifest); outer_files['manifest.json'] = outer_manifest_raw; outer_anchor = outer.sha(outer_manifest_raw)
    check('outer-return-archive-current',lambda:outer.return_packet(outer.Archive(zip_files(outer_files)),outer_anchor),valid=True)
    outer_root = scratch/'return';outer_root.mkdir();write_files(outer_root,outer_files)
    outer_command = [sys.executable,'-B',str(HERE/'verify_return25.py'),'--root',str(outer_root),'--expected-manifest-sha256',outer_anchor,
                     '--expected-verifier-sha256',outer.sha((HERE/'verify_return25.py').read_bytes())]
    result = subprocess.run(outer_command,capture_output=True,check=True); status=outer.loads(result.stdout)
    assert status['sourceChecks'] == {'state':'NOT_RUN'} and status['gitDeltaSemantics'] == 'NOT_CHECKED_WITHOUT_GIT_ROOT' and status['gitHistorySemantics'] == 'NOT_CHECKED_WITHOUT_GIT_ROOT'
    positive+=1;print(json.dumps(dict(case='CLI-outer-integrity-no-Git-or-source-claim',exit=0,expectedExit=0)),flush=True)
    delta_path=outer_root/'source.delta.bundle';delta_path.write_bytes(bundle_raw+b'corrupt')
    check('outer-delta-corrupted',lambda:outer.return_packet(outer.Directory(outer_root),outer_anchor),'ARTIFACT_HASH_MISMATCH')
    delta_path.write_bytes(bundle_raw)
    check('outer-delta-restored',lambda:outer.return_packet(outer.Directory(outer_root),outer_anchor),valid=True)
    def altered_bundle(raw):
        altered_files=dict(outer_files);altered_files['source.delta.bundle']=raw
        altered_manifest=copy.deepcopy(outer_manifest);altered_manifest['files']['source.delta.bundle']=witness(raw)
        altered_files['manifest.json']=encoded(altered_manifest)
        return outer.return_packet(outer.Archive(zip_files(altered_files)),outer.sha(altered_files['manifest.json']))
    bad_capability=bundle_raw.replace(b'# v2 git bundle\n',b'# v2 git bundle\n@object-format=sha1\n',1)
    check('v2-bundle-v3-capability-refused',lambda:altered_bundle(bad_capability),'RETURN_GIT_BUNDLE_HEADER')
    supported_v3=bundle_raw.replace(b'# v2 git bundle\n',b'# v3 git bundle\n@object-format=sha1\n',1)
    check('supported-v3-sha1-bundle-header',lambda:altered_bundle(supported_v3),valid=True)
    unsupported_v3=bundle_raw.replace(b'# v2 git bundle\n',b'# v3 git bundle\n@object-format=sha256\n',1)
    check('v3-unsupported-object-format-refused',lambda:altered_bundle(unsupported_v3),'RETURN_GIT_BUNDLE_HEADER')
    altered=copy.deepcopy(history);altered['schema']=True
    check('outer-history-schema-bool-refused',lambda:outer.history_shape(altered,outer_source),'HISTORY_IDENTITY')
    altered=copy.deepcopy(history);altered['commits'][-1]['changes']=[]
    check('outer-history-tail-inventory-refused',lambda:outer.history_shape(altered,outer_source),'HISTORY_CHANGES')
    altered=copy.deepcopy(history);altered['commits'][0]['changes'][0]['after']['mode']='120000'
    check('outer-history-link-mode-refused',lambda:outer.history_shape(altered,outer_source),'HISTORY_BLOB_SCHEMA')

    # Real native Git pack controls in a tiny wholly synthetic repository.
    git_root = scratch/'git'; git_root.mkdir()
    def git(*args, data=None): return outer.git(git_root,*args,input_bytes=data)
    git('init','--quiet'); git('config','core.autocrlf','false')
    (git_root/'source.txt').write_bytes(b'synthetic before\n'); git('add','source.txt')
    git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','before')
    old = git('rev-parse','HEAD').decode().strip()
    (git_root/'source.txt').write_bytes(b'synthetic after\n'); git('add','source.txt')
    git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','after')
    head = git('rev-parse','HEAD').decode().strip(); bundle = scratch/'fixture.bundle'
    git('bundle','create',str(bundle),'HEAD','^'+old)
    body = bundle.read_bytes().partition(b'\n\n')[2]
    original_base = outer.BASE; outer.BASE = old
    try:
        check('native-git-exact-delta-pack',lambda:outer.verify_delta_pack(git_root,body,head),valid=True)
        pack = git('pack-objects','--stdout','--revs',data=(head+'\n').encode())
        check('native-git-extra-baseline-objects-refused',lambda:outer.verify_delta_pack(git_root,pack,head),'GIT_DELTA_OBJECT_COUNT')
        blob = git('rev-parse','HEAD:source.txt').decode().strip()
        pack = git('pack-objects','--stdout',data=(blob+'\n').encode())
        check('native-git-missing-advertised-head-refused',lambda:outer.verify_delta_pack(git_root,pack,head),'GIT_DELTA_OBJECT_COUNT')
    finally: outer.BASE = original_base

    def pack_header(kind,size):
        first=(kind<<4)|(size&15);size >>= 4;raw=bytearray([first|(128 if size else 0)])
        while size:
            value=size&127;size >>= 7;raw.append(value|(128 if size else 0))
        return bytes(raw)
    def varint(value):
        raw=bytearray()
        while True:
            byte=value&127;value >>= 7;raw.append(byte|(128 if value else 0))
            if not value:return bytes(raw)
    def pack_one(kind,declared,raw,base=b''):
        body=b'PACK'+struct.pack('>II',2,1)+pack_header(kind,declared)+base+zlib.compress(raw)
        return body+hashlib.sha1(body).digest()
    def metadata_only(_root,*arguments,**_kwargs):
        assert arguments[:3] == ('rev-list','--objects','--no-object-names'), 'native parser called before preflight'
        return (('a'*40 if '..' in arguments[3] else 'b'*40)+'\n').encode()
    malicious=pack_one(3,outer.MAX_FILE+1,b'')
    with patch.object(outer,'git',side_effect=metadata_only):
        check('overbound-PACK-object-before-native-Git',lambda:outer.verify_delta_pack(git_root,malicious,'a'*40),'GIT_PACK_EXPANSION_BOUND')
    instructions=varint(1)+varint(outer.MAX_FILE+1)
    malicious=pack_one(7,len(instructions),instructions,b'\0'*20)
    with patch.object(outer,'git',side_effect=metadata_only):
        check('overbound-delta-result-before-native-Git',lambda:outer.verify_delta_pack(git_root,malicious,'a'*40),'GIT_PACK_EXPANSION_BOUND')
    instructions=varint(outer.MAX_FILE+1)+varint(1)
    malicious=pack_one(7,len(instructions),instructions,b'\0'*20)
    check('overbound-delta-base-refused',lambda:outer.pack_safety(malicious),'GIT_PACK_EXPANSION_BOUND')
    malicious=pack_one(3,3,b'abc');malicious=malicious[:-20]+b'extra';malicious+=hashlib.sha1(malicious).digest()
    check('PACK-trailing-data-refused',lambda:outer.pack_safety(malicious),'GIT_PACK_TRAILING_BYTES')
    original_total=outer.MAX_TOTAL;outer.MAX_TOTAL=2
    try:check('PACK-summed-inflation-bound',lambda:outer.pack_safety(pack_one(3,3,b'abc')),'GIT_PACK_EXPANSION_BOUND')
    finally:outer.MAX_TOTAL=original_total

    # Raw working-byte 0/1/0 does not rely on Git stat-cache reporting.
    tree=outer.git_tree(git_root,'HEAD');target=git_root/'source.txt';saved=target.read_bytes()
    check('raw-working-current',lambda:outer.hash_worktree(git_root,tree),valid=True)
    git('config','core.trustctime','false');os.utime(target,(1_600_000_000,1_600_000_000));git('update-index','--really-refresh');git('status','--porcelain=v1');stamp=target.stat()
    target.write_bytes(saved.replace(b'after',b'other'));os.utime(target,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
    assert not git('status','--porcelain=v1')
    check('raw-working-stat-hidden-tamper',lambda:outer.hash_worktree(git_root,tree),'GIT_WORKING_BLOB_MISMATCH')
    target.write_bytes(saved);os.utime(target,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
    check('raw-working-restored',lambda:outer.hash_worktree(git_root,tree),valid=True)

    # Exercise a real native thin delta, not only tiny undeltified objects.
    large=git_root/'large.txt';large.write_bytes(bytes(range(256))*4096);git('add','large.txt')
    git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','large base')
    old=git('rev-parse','HEAD').decode().strip();raw=bytearray(large.read_bytes());raw[1000:1010]=b'newdelta25';large.write_bytes(raw);git('add','large.txt')
    git('-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','large delta')
    head=git('rev-parse','HEAD').decode().strip();delta_bundle=scratch/'thin.bundle';git('bundle','create',str(delta_bundle),'HEAD','^'+old)
    pack=delta_bundle.read_bytes().partition(b'\n\n')[2];saved_base=outer.BASE;outer.BASE=old
    try:
        safety=outer.pack_safety(pack);assert safety['references'], 'fixture did not exercise native REF_DELTA'
        check('native-real-thin-delta-preflight-and-exact-object-set',lambda:outer.verify_delta_pack(git_root,pack,head),valid=True)
    finally:outer.BASE=saved_base

print(json.dumps(dict(status='PASS',positiveControls=positive,refusals=refused,
    qualification='SYNTHETIC_ARTIFACT_AND_TINY_GIT_CONTROLS_NOT_FINAL_SOURCE_PROOF',acceptanceGranted=False,release='NO_GO')),flush=True)
