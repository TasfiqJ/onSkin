"""Read-only current-draft audit; synthetic Git fixture remains external."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parent / 'campaign25-source'
DRAFT = BASE / 'check25-draft.py'
raw = DRAFT.read_bytes()
namespace = {'__name__': 'independent_release25_review', '__file__': str(SOURCE / 'scripts/release/full-app-j01/check.py')}
exec(compile(raw, str(DRAFT), 'exec'), namespace)

namespace['validate25_checker'](raw)
lines = raw.splitlines(keepends=True)
target = next(node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef) and node.name == 'source25_guard')
mutated = b''.join(lines[:target.lineno-1]) + b'def source25_guard():\n    return {}\n' + b''.join(lines[target.end_lineno:])
namespace['validate25_checker'](mutated)
print(json.dumps({
    'case': 'pristine-checker-accepts-disabled-source25-guard',
    'observed': 'ACCEPTED', 'expected': 'REFUSED',
    'draftSHA256': hashlib.sha256(raw).hexdigest(),
    'mutatedSHA256': hashlib.sha256(mutated).hexdigest(),
    'qualification': 'PURE_MUTATED_BYTES_WITH_PRISTINE_CONSUMER_NO_SOURCE_WRITES',
}))

with tempfile.TemporaryDirectory(prefix='release25-stat-cache-audit-', dir=BASE) as temporary:
    root = Path(temporary)
    def git(*args):
        result = subprocess.run(['git', '--no-replace-objects', '-c', 'core.hooksPath=', *args], cwd=root, capture_output=True, check=True)
        return result.stdout
    git('init', '--quiet')
    git('config', 'core.autocrlf', 'false')
    git('config', 'core.trustctime', 'false')
    path = root / 'protected.py'
    path.write_bytes(b'allowed = False\n')
    os.utime(path, (1_600_000_000, 1_600_000_000))
    git('add', 'protected.py')
    git('-c', 'user.name=ExternalReview', '-c', 'user.email=review@example.invalid', 'commit', '--quiet', '-m', 'synthetic stat fixture')
    git('status', '--porcelain=v1')
    before = path.stat()
    original = path.read_bytes()
    path.write_bytes(b'allowed = True \n')
    os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
    status = git('status', '--porcelain=v1')
    delta = git('diff', '--raw', '--no-abbrev', '--no-renames', '-z', 'HEAD')
    assert original != path.read_bytes() and len(original) == path.stat().st_size
    assert not status and not delta
    print(json.dumps({
        'case': 'untouched-protected-working-bytes-hidden-by-stat-cache',
        'observed': 'STATUS_AND_RAW_DIFF_CLEAN_WITH_CHANGED_BODY', 'expected': 'REFUSED_BY_FULL_BLOB_PROOF',
        'originalSHA256': hashlib.sha256(original).hexdigest(),
        'changedSHA256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'qualification': 'SYNTHETIC_GIT_STAT_CONTROL_NO_SOURCE_WRITES',
    }))
