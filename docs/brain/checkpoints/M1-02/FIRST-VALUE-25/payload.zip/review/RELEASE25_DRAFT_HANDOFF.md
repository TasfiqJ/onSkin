# Release25 external implementation draft — ready for root review

No repository source was edited by this worker. These are external proposals
for the sole integration owner to review and copy into the already granted paths.

## Ready files

| External file | Destination / role | SHA256 |
| --- | --- | --- |
| `check25-draft.py` (313,635 bytes) | Exact replacement bytes for `scripts/release/full-app-j01/check.py` | `bcb0235eb05d653b27b0871c52f72f6300513c68f2de46a3e959194fb5cbc838` |
| `appendix25.py` (39,401 bytes) | Readable appended extension only; already included in composite | `d0751aa56459b2995d6b5d90c90cefd0bfb5d3d27af4288ed55e7ae45029e993` |
| `source_consumer25.proposal.py` (23,451 bytes) | `scripts/release/full-app-j01/source_consumer25.test.py` | `cfe4ff3959d8cfba1939711a86cc9ee961c8c66a762425684ac7cd002dacb28d` |
| `source25.v1.proposal.json` (673 bytes) | `docs/brain/contracts/M1X-25/source25.v1.json` | `66a5f6e2680817705944d300843bbb6da8a856f3c4f557b13873f8543810b4ad` |
| `source-consumer25-draft-run6.log` (13,607 bytes) | Actual latest synthetic consumer run | `bfd5cce2f782385e6ca1fa64ccc386d5ca0a6657d218066f50222bba2d1daf2b` |

The composite preserves every inherited byte except relocating the terminal
main guard below the appendix. All 163 inherited function ASTs remain exact.
The exact committed plan is `f25db3f5c74d0ad3ddd78ece70f79d315ab57662`, SHA256
`80c81b9f93b696f3d14bf99689ed9f592b18258fd7a96fe01a88de695033d136`.
Five existing and four new app paths are bound, without prefixes or expansion.

## Integration

Copy the exact composite bytes into the checker; do not reconstruct its spacing
or normalize CRLF manually. The new extension has a normalized byte digest whose
own literal is zeroed before hashing. `build25_draft.py` reproduces that value
and composite, but it is an external preparation helper, not a new source path.
The complete checker is ultimately authenticated by the separately anchored
return/checkpoint verifier and exact Git objects; its self-check is not an
independent trust anchor for arbitrary rewritten code.

Copy the consumer proposal into the authorized new consumer path. In that
location it defaults to the repository root and current checker, so execute:

```text
python -B scripts/release/full-app-j01/source_consumer25.test.py
```

Copy the proposed source contract and set its provisional `pr: null` to the
actual new draft PR number before the worklist freeze. The candidate may be
provisional during source work; frozen/tail checks require a positive integer.
CI strictly verifies exact pinned PR28 base/ref, candidate branch/ref/head,
repository, draft=true, maintainer_can_modify=false and auto_merge=null.

The exact new checker should be committed only after review and validation.
If its extension itself needs later committed revisions, earlier committed
versions need an exact immutable historic-blob allowance; do not weaken the
body digest to admit arbitrary self-rehashed earlier code. Ordinary app fixes
and contract PR-number updates do not change the extension digest.

## Actual results and independent findings

Run6 exited 0: **16 positive controls, 122 refusals, 163 inherited functions**.
Qualification is `SYNTHETIC_GIT_AND_SCHEMA_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_APP_PRIVACY_PROOF`.

The independent bootstrap reviewer found real early-draft gaps. Before/after
evidence is preserved; they are not hidden or counted as source acceptance:

- Early function-name-only checking admitted a replaced `source25_guard` body.
  Normalized full extension checking now refuses it as `R25_APPENDIX_BYTES`.
  `validate25` authenticates the extension before invoking the current guard.
- Git status/raw diff can be clean after same-size protected-file modification
  with original mtime restored and core.trustctime=false. The guard now streams
  and hashes **every tracked working blob** independently of Git's stat cache,
  checks stable file identities and cached directory identities, and compares
  all unpermitted bytes with index blob IDs. The exact mounted synthetic attack
  is refused as `R25_WORKING_BLOB`.
- Ignored untracked source names could evade --exclude-standard. Unknown ignored
  paths are now refused from metadata only; recognized dependency/cache/generated
  roots are excluded from source evidence explicitly. No private untracked body
  is opened. The synthetic `.env` source-name adversary is refused.
- Rehashed, committed payloads with adjusted prefixed bytes, trailing data or
  local/central filename disagreement are refused as `R25_PAYLOAD_FRAME`.

The raw full-blob check reads tracked checkout bytes locally. Its output says
so explicitly and emits neither file contents nor newly computed individual
hashes. Do not retain the old `NOT_OPENED` claim for tracked protected bodies.
External/private untracked finding stores are never opened, and unknown ignored
names are rejected from metadata. Review this boundary before integration.

## Contract and checkpoint schema

The proposed source contract uses exact fields:
schema, authority, status, base, tree, scopeCommit, scopePlanSHA256,
inputManifestSHA256, acceptanceGranted, admissions and pr. All admissions use
strict `is False`; bool/int/float/null/string confusion and duplicate JSON keys
are refused. Current external bundle fixtures delegate unchanged to Release24.

Checkpoint files are exactly `README.md`, `REPORT.md`, `manifest.json`,
`verify25.py` and `payload.zip`, plus the root handoff in the sole tail commit.
The manifest schema follows Campaign24, with authority25/input25 and the five
new checkpoint names. Its source object has only base/baseTree, runtimeHead/
runtimeTree and sourceHead/sourceTree. It must not circularly name its own tail.
`files` has four nonmanifest byte/hash records. `payload` has schema=1, files,
qualification=`SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE`.

Exactly one commit changes both worklist files and nothing else; its parent is
the frozen substantive runtime. Exactly one subsequent evidence-only tail adds
the five checkpoint files and changes root handoff. No later descendant is
accepted. Before freeze, only exact finite pending paths are allowed. Frozen
and tail modes require exact index/tree, clean status, positive PR number and
raw working blob matches with no permitted exceptions.

The source guard validates the committed checkpoint envelope, payload's bounded
regular-member inventory, local/central framing, names, offsets, adjacency,
decompression completion, CRC, byte sizes and SHA256s. It does **not execute or
establish the semantics of `verify25.py`**. The real standalone verifier must be
audited, externally hash-pinned, and independently run for recursive nested
archives and the complete return protocol. Synthetic envelope fixtures use an
unexecuted placeholder verifier and are labeled synthetic; they are not a real
checkpoint acceptance proof.

## Root execution still required

- Review/copy and execute the new consumer at actual integrated source.
- Run the original mounted/full app, safety, semantic, historical and source
  contracts; unchanged strict Phase4 and real unsigned exports.
- Final verifier source execution must require `RELEASE25_FINITE_SCOPE_ONLY`,
  `source25.phase=TAIL`, `workingQualification=RAW_TRACKED_BLOBS_EXACT`, exact
  expected head/tree, and all NO_GO/nonacceptance fields.
- Execute real complete-checkout source current/tampered/restored 0/1/0 and
  actual artifact current/corrupted/restored 0/1/0 with exact byte restoration.
- Two genuinely independent complete clean final clones, each actual unchanged
  strict Phase4 and checkpoint inventory, after the sole evidence tail.
- Collect final-head CI externally post-tail and publish the one actual return
  ZIP and complete report. No source changes or second tail after freeze.

Synthetic controls here do not substitute for those runs, app owner/race proof,
browser evidence, native iPhone/VoiceOver, provider/clinical/legal/licensing,
Apple or release acceptance. All protected gates remain NO_GO/NOT_ACCEPTED or
CLOSED, USD0, NO MERGES, SUBMITTED_REVIEW_REQUIRED.

## Independent after-fix review and retained failures

The bootstrap reviewer independently re-executed the repaired attacks against
the exact final composite `bcb0235e...cbc838` and reported PASS:

- Replacing the source guard body is refused by the pristine validator as
  `R25_APPENDIX_BYTES`.
- A tiny synthetic protected tracked file has actual current/tampered with
  Git-clean stat cache/restored exits **0/1/0** through `working25_guard`;
  tampering is refused as `R25_WORKING_BLOB`.
- Repaired local/central/name/offset adjacency, raw zlib EOF/CRC checks and the
  16-positive/122-refusal run6 were independently reviewed with no further
  concrete issue found. Standalone verifier semantics and real final full
  checkout proof remain separate root obligations.

Independent after-fix probe SHA256:
`bf1d92b3cb54eba56c893a453bd3acae0302afd5caa0b9cc943da1eb891b43c2`.
Its log SHA256:
`e969742ae836fee3bd9ac28b8542e6d82bbcd0cd69bfaca44e6d57b767c05382`.
Both files are in this external review directory with prefix
`independent_release25_afterfix_probe`. Original before-fix probe/log remain.

The first two consumer draft runs failed in the synthetic test harness because
the protected deletion fixture named a nonexistent healthConsent file. The
first run also exposed Windows readonly-object cleanup failure. The fixture
was corrected to an authentic protected path and cleanup handles readonly
task-created objects. Those failed logs remain as
`source-consumer25-draft-run.log` and `source-consumer25-draft-run2.log`.
Later complete runs3–6 passed as recorded, with increasing adversarial coverage.
No original assertion or source file was changed to obtain a pass.

Automatic approval review rejected a subsequent native PowerShell cleanup of
the verified task-owned temporary directory `release25-synthetic-kjl6l9k6`
as **blocked by policy**. It was left in place outside source and evidence;
there was no retry through another tool, wrapper or identity. Preserve this
explicit refusal in the final report and short final-response note.
