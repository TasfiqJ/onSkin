# Human-Simulated E2E Run Report

## Summary

- Date: 2026-10-29
- Codex task: First-session onboarding 375 x 667 run
- App surface: Headless Chrome Expo web
- Build/start command: `Existing Expo web at http://localhost:8295`
- Browser/device/simulator/OS: Headless Chrome or Edge, 375 x 667
- Feature or PR tested: First-run onboarding activation path
- Overall verdict: Pass

## Flows Executed

| Flow | Branch | Result | Evidence | Notes |
| ---- | ------ | ------ | -------- | ----- |
| First-run onboarding | Happy path plus age re-verification downgrade / launch-floor phone viewport | pass | `../campaign25-evidence/browser25/viewport375-attempt2` | Completed onboarding through the truthful free-plan path to Today without granting Pro, then proved an under-threshold re-verification immediately closed protected providers and remained closed across direct Today navigation and reload. |

## Bugs Found

None in this pass.

## Commands Run

```bash
npm run e2e:onboarding-first-session
```

## Remaining Risk

- Expo web verifies the supported phone geometry and flow logic; it does not replace native iPhone evidence.
- Native iOS/Android onboarding still needs simulator or physical-device QA for OS prompts and platform text settings.
