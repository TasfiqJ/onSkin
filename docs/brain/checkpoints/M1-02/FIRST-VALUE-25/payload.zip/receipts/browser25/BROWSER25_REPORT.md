# Campaign25 actual Expo web evidence

Source-only review candidate; NO_GO and SUBMITTED_REVIEW_REQUIRED. No acceptance granted.

The real current app completed adult/consent, twelve-question quiz, at least three
owned manual Shelf products, truthful pending review, explicit notification-OFF
confirmation, free-plan continuation, real Today AM/PM actions with encrypted
durable readback, failed-write retry and duplicate suppression. Native, live
account/provider, photos, clinical/legal/licensing, Apple and public release
remain closed or NOT_RUN.

## Per-surface results

| Viewport | Text | Actual exit | Scope | Duration |
| --- | --- | --- | --- | --- |
| 375×667 | 100% | 0 | FIRST_VALUE_DAILY_AND_RETAINED_SAFETY | 92.703s |
| 390×844 | 100% | 0 | FIRST_VALUE_DAILY_AND_RETAINED_SAFETY | 105.531s |
| 430×932 | 100% | 0 | FIRST_VALUE_DAILY_AND_RETAINED_SAFETY | 105.547s |
| 360×640 | 200% | 0 | FIRST_VALUE_AND_DAILY_LOOP | 96.734s |

All four selected runs bind the same actual app/runtime input inventory SHA256
`062a0f4b6dca36c1e94d8dfc9b8df9d3dd96acd58103bcda125372a10a1a1e08`.
Each before/after app runtime snapshot is stable. Source tests are excluded from
that runtime digest but retained in the full app inventory; full Git head/tree,
diff hash and index metadata are separately recorded. Normal-width runs were
fresh executions at b935bad3; the final 360 run spans the exact frozen substantive
runtime24b876fe to unchanged-producer worklist165055f1 with no app-path change.
This is byte-bound current app evidence, not a claim those earlier executions
ran under the final evidence-tail commit.

At375/390/430 the complete `--daily-loop --retained-safety` journeys passed,
including local Shelf duplicate save, write refusal/retry, archive/relaunch,
remove refusal/retry, encrypted corruption preservation/recovery, withdrawal
cleanup refusal, direct-private-route and age-denial/reload branches. At360 with
200% text, the complete core/daily loop passed; the extra removal-sheet branch
remains OPEN_REQUIRED below. AM/PM completion is confirmed by actual encrypted
days/journal readback and exactly one routine-day marker. No paid authority or
provider success is fabricated.

## Measured text, keyboard and visual checks

The external driver changes computed text font sizes and line heights, not page
zoom. DOM Range glyph bounds are measured before/after. Device pixel ratio2 is
the same across normal and enlarged runs. The final360 run records exact2×
computed font ratios, real glyph sizes with pixel rounding, actual Tab movement
Day of birth→Month of birth and Product name→Brand, Enter activation of the age
Continue, and focused manual-input layout at reduced400px viewport. Native
keyboard/DynamicType/VoiceOver remain NOT_RUN. Raw glyph metrics are in every
snapshot, with summary counts/ranges in BROWSER25_SUMMARY.json.

Visually inspected final PNGs include:

- `viewport360-text200-core-attempt5/C25-reveal-pending-body-visible.png` —
  actual scrolled full pending-review card and accessible Continue.
- `viewport360-text200-core-attempt5/C25-manual-keyboard-input.png` —
  focused real manual draft under keyboard viewport pressure.
- `viewport360-text200-core-attempt5/C25-opening-confirmation-10-products-after-1.png`
  — reachable Add to shelf action on the actual enlarged opening-date sheet;
  durable saved-state proof is the separately asserted encrypted readback.
- `viewport375-attempt2/M102-03-offline-duplicate-append-only.png` and
  `M102-06-pm.png` — real confirmed Today states.

Original capture assertions remain. The raw geometry auditor also reports
occluded background controls behind active modal overlays; those records are
retained and not blanket-relabelled actionable failures. Do not claim zero total
raw geometry issues. Runtime error/console counts and measured state waits are
reported numerically in the JSON. Wait timing includes intentional polling and
instrumentation; it is not a native performance benchmark.

## Real residual defect — UNAPPLIED

At360×640/text200%, product detail's “Remove from shelf?” header consumes the
sheet maximum height. Its action ScrollView has clientHeight0 while its content
is388px tall; Remove completely is y847..1035 and cannot be reached in640px.
The exact geometry and actual screenshot are under the final360 directory with
prefix `C25-product-options-text200`. The extended retained attempt3 reaches this
same real failure. The current file
`apps/mobile/src/app/shelf/[id].tsx` is outside the immutable finite grant.

UNAPPLIED proposal: make the entire title/body/actions content scroll within the
bounded sheet while retaining an independently reachable48px Close control.
Do not truncate the destructive-action explanation or change owner/privacy
authority. This requires independent Brain scope authorization; no patch was
applied and the defect remains OPEN_REQUIRED. It is not waived by core-loop PASS.

## Correctly preserved gate

Direct `/routine/adaptation` renders the actual unavailable-store Pro gate.
`C25-adaptation-paid-boundary.png` records this. The proposed browser private-read
fault assay is NOT_RUN/BLOCKED_CURRENT_PAID_AUTHORITY; no entitlement was created
to enter the route. Mounted real-hook tests remain separate source evidence,
not a substitute for an admitted browser or native path.

## Failed and corrected harness attempts

All originals remain:

1. Initial server used root cwd and generated a63-byte tsconfig. Root preserved
   exact bytes externally, corrected server2 uses apps/mobile; no UI journey ran
   against the first server.
2.375 attempt1 reached truthful reveal but expected Not now to navigate directly.
   Actual notification UI correctly saved OFF then exposed Continue. External
   runner now activates that real confirmation; app code was not changed.
3.360 attempt1 could not connect Chrome/CDP and ran no UI. Its cause is not proven;
   fresh profiles now include port/PID/time to remove possible collision.
4.360 attempt2 did not scroll an enlarged quiz choice into view. External runner
   now scrolls the real target before touch; no quiz result is injected.
5.360 attempt3 proves core/daily plus opening-date failure/retry and archive, then
   exposes the genuine product-options defect above.
6.360 core attempt4 passed but glyph-baseline measurement reset reveal scroll;
   its pending screenshot is not visible-card proof. Final attempt5 preserves
   scroll during measurement and captures the actual pending card.

The server used dotenv-disabled development anonymous Auth transport, blocked
Supabase placeholders, real app Query/current grant/encrypted local storage,
and synthetic platform IO failures only. Browser Fetch admits only the local
Expo origin; no external request bodies/headers are recorded, and all real
provider requests are blocked. Task-owned synthetic Chrome profiles remain
outside source/evidence and are excluded from delivery. No native/photo/vendor
or production account was used. No source files were edited by the browser
worker; the initial generated config setup issue is explicitly preserved.

Both task-owned servers are stopped. No listeners remain on the task's Expo or
Chrome-debug ports. Delivery files are frozen and indexed in
BROWSER25_FILE_INDEX.json; index excludes itself and both servers' raw logs and
stop-request signals. Server metadata JSON is retained. The untouched raw logs
remain local and are not part of the sanitized delivery inventory.
All acceptance/release gates remain unchanged, USD0, NO MERGES.
