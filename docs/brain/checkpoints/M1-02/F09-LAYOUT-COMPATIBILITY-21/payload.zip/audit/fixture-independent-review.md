# Independent read-only Campaign21 fixture review

Reviewed against pinned PR24 `3c8cb787f3770df09f0ae4507bca9ac49fb5a079`.

Result: no blocking findings in the repaired fixture or appended regressions.

- The entire original progressEmptyLayout describe block is byte-identical, including all 15 names, dimensions, thresholds, CTA/deletion assertions, CompareSlider count and Timeline SectionList/padding assertions. SHA256 `516445ae5f094829229e6b9ef951dd6c9c71467968810d5d3694792145648d21`.
- All original manualCompare20Route test bodies remain byte-identical. Original body SHA256 `1691e4a9348bacd4e012de74666a72aa926ed7ad21f50c25b0fde840fd32fec4`.
- The repaired fixture uses the actual usePhotos, PhotoStorageGate, PhotoTimelineLockGate, account-generation operation, health epoch and canonical consent-store API. Query lifecycle/currentness is real. No fake always-current predicate or gate bypass remains. AppLock is a fixed synthetic unlocked port for layout tests; mutable lock lifecycle is exercised by the unchanged route suite.
- The two synthetic front records contain every required PhotoRecord field, distinct IDs and canonical dates, without a PhotoRecord object cast. Added mount assertions require pair a/b.
- Only the empty fixture is seeded at the exact current authority/query key, using production timeline derivations. Stale/refetch-on-mount options prevent private photo reads, and mount requires loadPhotos zero calls. Populated fixtures go through the actual usePhotos query and health-data operation against an in-memory loadPhotos port.
- Cleanup unmounts the provider tree, cancels queries, clears the query cache, health epoch, canonical consent, and in-memory storage. No source production files were changed.
- The added deferred-refetch test proves the real query retains old data while invalidated/fetching, hides comparison and first-photo CTA, refuses old callbacks during and after refetch, and retains the valid pair only in the same grant. New owner/regrant cases start from a nondefault b/c pair before requiring a/c reset. Closed authority with populated retained cache does not read or display old photos.

Independent command: `npm --workspace apps/mobile run test -- src/features/photos/progressEmptyLayout.c08b2.test.ts src/features/photos/manualCompare20Route.test.ts --reporter=json --outputFile=../../../audit/fixture-independent-focused.json`.

Exit 0; two files, 43/43 cases passed: original layout 15/15 and route 28/28, zero failed/pending cases. Raw JSON and log retained beside this review. These tests establish synthetic source regression behavior, not installed-iPhone/VoiceOver or release acceptance.
