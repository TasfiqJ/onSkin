# Campaign21 independent source guard review

Read-only review of the source clone; no source edits or commits were made by this agent. Draft artifacts are outside the source clone.

The immutable PR24 checker prefix is byte-identical. The Release21 segment is inserted before the original terminal main block. Runtime files have no delta relative to pinned PR24. The finite existing/new/prefix grants match the authenticated directive. The candidate remains SOURCE_ONLY_CANDIDATE, acceptanceGranted false, all six protected admissions false, runtimeProof empty.

The guard validates actual Git raw path/mode/blob deltas in every linear intermediate commit plus index/worktree states, pinned ancestor/tree, Unicode/case aliases, staged changes hidden by worktree bytes, index flags, source-only draft CI event identity, original15 describe suffix, additive regression lines, and the single evidence child after a worklist-only freeze commit. Historical guards are evaluated against their immutable declared sources. The consumer uses real synthetic Git commits/index mutations; general segment tests isolate historical/evidence components, and evidence components have their own synthetic commit/tree tests. It does not stand for complete independent-checkout proof.

New21 hardening findings sent to parent before freeze:

- Python equality accepts numeric zero as False in candidate admissions; require every flag `is False` and test the refusal.
- Evidence manifest schema equality accepts True as 1; require `type(schema) is int`.

The external checkpoint manifest anchor must be supplied independently to its verifier. Structural source validation and internal artifact hashes cannot provide their own external trust anchor.

Historical commands/source identities are in historical-lineage.json. The original151 test_contract.py SHA256 is 191f74631da86413c687801c7a620bbe01c0bd7d98c83f6bdd72947faf2ec455 at both immutable Release08 and PR24. Run historical08 against its original checkout/checker and label any final-head successor replay separately. Older source consumers enforce their exact successor function scopes and must run with the matching immutable checker, not the extended21 checker.

An audit-only shared clone at audit/guard21-sandbox was checked out at PR24; no draft tests ran there after parent confirmed its own consumer was running. It is not a delivery or independent-checkout acceptance artifact.
