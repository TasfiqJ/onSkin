# Immutable Release08–20 lineage replay

All thirteen original historical endpoint consumers completed with exit0. This is bounded historical bundle/synthetic-fixture evidence. It is not independent final-checkout evidence, a final-head151 claim, or acceptance.

The original151 at exact Release08 d08347f0011672cd309d835628c094b5e9f4725d completed with authentic/tampered/restored0/1/0. The final-head successor151 is a separate parent-owned check; no cancelled replay is represented as passed.

| Release | Exact source commit | Original negative/refusal count | Wrapper exit |
| --- | --- | ---: | ---: |
| 08 | `d08347f0011672cd309d835628c094b5e9f4725d` | 151 | 0 |
| 09 | `8ac97c32901272d97d1bff05f2abc294811055a6` | 23 | 0 |
| 10 | `14805e7f708297e72419035f517acc41ba52da70` | 44 | 0 |
| 11 | `9e3ba80e09579ee4855948f13297049791c4d5d7` | 58 | 0 |
| 12 | `bbbd59073b7add22ac350bced0d9a34124c12ffb` | 55 | 0 |
| 13 | `d0c5ad49ba22c8da7136d59a399589af1cea0e82` | 68 | 0 |
| 14 | `53cf869c5fc5f13ecd18dc1ef9c3a6288eaae51a` | 89 | 0 |
| 15 | `b79e6d1e21a367be5cea5d0b333de9f2a144d41f` | 115 | 0 |
| 16 | `28953aa3a84fed0684b80b442d0cd9c2de0663b2` | 153 | 0 |
| 17 | `f9709e02420d6c03cc9b9586cf60d89bfde7d8a3` | 161 | 0 |
| 18 | `149d18f3ae3c49f966a9e2b1a679901d1d15b3b6` | 175 | 0 |
| 19 | `9b3b1781ad65b10ae6b3ade7c1a87a03a64374e4` | 163 | 0 |
| 20 | `3c8cb787f3770df09f0ae4507bca9ac49fb5a079` | 197 | 0 |

Original quality_projection10 and dependency_guard11/12/13 also completed exit0 (their full original qualifications and blocked dispositions remain in receipts).

Initial13 consumer+dependency,14 consumer and15 consumer attempts failed because the disposable historical checkout lacked authentic installed native source-pin files. All exit1 logs and receipts remain retained. A fresh previously absent npm cache was used for exact-lock npm ci at detached13 d0c5ad49ba22c8da7136d59a399589af1cea0e82; npm ci exited0, all10 native source-pin hashes matched the original manifest, package-lock and tracked source remained unchanged. Labeled second attempts13/14/15 completed; none of their original tests was weakened, skipped or cancelled.

At two orchestration boundaries, only the waiting Python orchestrator was suspended; its running original consumer finished naturally before the orchestrator was stopped. Boundary receipts preserve this distinction. The second boundary delegated14–17 to the independent ci_audit worker, while18–20 continued in the first disposable checkout. Every completed original consumer exit is retained.

See fixture-worker-historical-lineage-completion.json for selected exact receipts and initial failures, lineage-source-identities.json for all source commit/tree/mode/blob/SHA256 identities, per-release receipts for full commands/exits/checker/test/fixture hashes, and native-pins-install-result.json for the fresh-cache authentic native-pin installation. G97 and all protected acceptance gates remain unchanged; release NO_GO.
