import { router, useLocalSearchParams } from 'expo-router';
import {
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  useSyncExternalStore,
} from 'react';
import { NavigationContext } from 'expo-router/build/react-navigation/core/NavigationContext';
import {
  Platform,
  Keyboard,
  Pressable,
  ScrollView,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Button, Card, Chip, Screen, Text } from '@/components/ui';
import { useOnboarding } from '@/features/onboarding/OnboardingContext';
import { ONBOARDING_PRODUCT_CATEGORIES } from '@/features/onboarding/productCategories';
import { trackProductAddStarted } from '@/features/shelf/analytics';
import type { ProductCategory } from '@/features/shelf/categories';
import { useIntake } from '@/features/shelf/IntakeContext';
import { useShelfMutations } from '@/features/shelf/mutations';
import { SHELF_PRODUCT_NAME_MAX_LENGTH } from '@/features/shelf/limits';
import { useShelf } from '@/features/shelf/useShelf';
import { ShelfDataAvailabilityGate } from '@/features/shelf/ShelfDataAvailabilityGate';
import {
  motionAllowed,
  useReduceMotionPreference,
} from '@/lib/accessibility/useReduceMotionPreference';
import { track } from '@/lib/analytics/track';
import {
  activeHealthProcessingLeaseSnapshot,
  subscribeActiveHealthProcessingLeaseChanges,
} from '@/lib/consent/healthProcessingEpoch';
import { colors } from '@/theme/tokens';

const ONBOARDING_PRODUCT_TARGET = 3;

function CategoryPickerSheet({
  visible,
  selectedCategory,
  onSelect,
  onClose,
}: {
  visible: boolean;
  selectedCategory: ProductCategory | null;
  onSelect: (category: ProductCategory | null) => void;
  onClose: () => void;
}) {
  const { height: viewportHeight } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const sheetMaxHeight = Math.max(0, viewportHeight - 52);
  const sheetPaddingBottom = insets.bottom > 0 ? Math.max(40, insets.bottom + 24) : undefined;

  if (!visible) return null;

  return (
    <View
      className="absolute inset-0 justify-end"
      style={{ backgroundColor: 'rgba(32,27,21,0.4)', zIndex: 20, elevation: 20 }}
    >
      <View className="flex-1 justify-end">
        <Pressable
          className="flex-1"
          accessibilityLabel="Dismiss category picker"
          accessibilityRole="button"
          onPress={onClose}
        />
        <View
          aria-modal
          role="dialog"
          accessibilityLabel="Choose product category"
          accessibilityViewIsModal
          className="overflow-hidden rounded-t-sheet bg-paper px-6 pb-10 pt-4"
          style={
            sheetPaddingBottom === undefined
              ? { height: sheetMaxHeight, maxHeight: sheetMaxHeight }
              : {
                  height: sheetMaxHeight,
                  maxHeight: sheetMaxHeight,
                  paddingBottom: sheetPaddingBottom,
                }
          }
        >
          <View
            className="mx-auto mb-4 h-[5px] w-10 rounded-[3px]"
            style={{ backgroundColor: 'rgba(32,27,21,0.15)' }}
          />
          <View className="mb-4 flex-row items-center justify-between gap-3">
            <Text variant="titleSm" className="flex-1">
              Product category
            </Text>
            <Pressable
              accessibilityLabel="Close category picker"
              accessibilityRole="button"
              className="min-h-[48px] min-w-[64px] items-center justify-center rounded-pill px-3"
              onPress={onClose}
            >
              <Text variant="bodySm" className="font-sans-semibold" style={{ color: colors.clay }}>
                Close
              </Text>
            </Pressable>
          </View>
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={{ flexShrink: 1 }}
            contentContainerClassName="pb-6"
            keyboardShouldPersistTaps="handled"
          >
            <View className="flex-row flex-wrap gap-2">
              {ONBOARDING_PRODUCT_CATEGORIES.map((c) => (
                <Chip
                  key={c.id}
                  label={c.label}
                  selected={selectedCategory === c.id}
                  className="px-4"
                  onPress={() => onSelect(selectedCategory === c.id ? null : c.id)}
                />
              ))}
            </View>
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

// 06 · Current products intake (docs/01 §2 step 6, docs/04 §4.7). Seeds the shelf with
// addedVia:'onboarding' so the reveal and the first routine/conflict pass are built
// from the user's REAL products (the conflict engine tags off the name). Skip stays
// visible. The full barcode/OCR intake lives on the Shelf (docs/04); this is the
// lightweight first-population that was previously a dead skip-only screen.
export default function ProductsScreen() {
  const { addedProductId } = useLocalSearchParams<{ addedProductId?: string }>();
  const lease = useSyncExternalStore(
    subscribeActiveHealthProcessingLeaseChanges,
    activeHealthProcessingLeaseSnapshot,
    () => null,
  );
  const generation = lease?.generation ?? 'closed';

  return (
    <ShelfDataAvailabilityGate>
      <ProductsScreenContent key={`${generation}:${addedProductId ?? 'initial-add'}`} />
    </ShelfDataAvailabilityGate>
  );
}

function ProductsScreenContent() {
  const { addedProductId } = useLocalSearchParams<{ addedProductId?: string }>();
  const reduceMotion = useReduceMotionPreference();
  const navigation = useContext(NavigationContext);
  const { fontScale = 1, height, width } = useWindowDimensions();
  const scrollRef = useRef<ScrollView>(null);
  const inputRef = useRef<TextInput>(null);
  const onboarding = useOnboarding();
  const { goals } = onboarding;
  const { reset: resetIntake } = useIntake();
  const dataQuery = useShelf();
  const { data } = dataQuery;
  const m = useShelfMutations();
  const acceptedGeneration = activeHealthProcessingLeaseSnapshot()?.generation;
  const removing = useRef(new Set<string>());
  const [removingIds, setRemovingIds] = useState<ReadonlySet<string>>(new Set());
  const [removalError, setRemovalError] = useState(false);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ProductCategory | null>(null);
  const [categoryPickerOpen, setCategoryPickerOpen] = useState(false);
  const [pendingUnsavedName, setPendingUnsavedName] = useState<string | null>(null);
  const currentName = useRef('');
  const currentUnsavedChoice = useRef<string | null>(null);
  useLayoutEffect(() => {
    if (currentName.current === name) return;
    currentName.current = name;
    currentUnsavedChoice.current = null;
    setPendingUnsavedName(null);
  }, [name]);
  const confirmUnsaved = pendingUnsavedName !== null && pendingUnsavedName === name;
  const navigating = useRef(false);
  useEffect(() => {
    const focus = () => {
      navigating.current = false;
    };
    const blur = () => {
      navigating.current = true;
    };
    if (!navigation || navigation.isFocused()) focus();
    const offFocus = navigation?.addListener('focus', focus);
    const offBlur = navigation?.addListener('blur', blur);
    return () => {
      offFocus?.();
      offBlur?.();
      blur();
    };
  }, [navigation]);
  const added = data?.items ?? [];
  const supportFloorTextPressurePhone =
    width <= 430 && height >= 640 && height < 700 && (fontScale >= 1.3 || Platform.OS === 'web');
  const modernTextPressurePhone =
    width <= 390 && height >= 800 && height < 900 && (fontScale >= 1.3 || Platform.OS === 'web');
  const splitShortPhone = height < 460;
  const compactPhone =
    height < 640 || supportFloorTextPressurePhone || modernTextPressurePhone || splitShortPhone;
  const showIntroCopy = !modernTextPressurePhone && !splitShortPhone;
  const showProgressBody = !modernTextPressurePhone && !splitShortPhone;
  const compactFooterAdds = compactPhone && name.trim().length > 0;
  const showCompactCategoryFooter = compactFooterAdds && !splitShortPhone;
  const remainingToTarget = Math.max(ONBOARDING_PRODUCT_TARGET - added.length, 0);
  const hasTargetProducts = remainingToTarget === 0;
  const showContinueAnyway = added.length > 0 && !hasTargetProducts && !compactFooterAdds;
  const productsBottomPaddingClass =
    splitShortPhone && showContinueAnyway && added.length === 1
      ? 'pb-44'
      : showContinueAnyway
        ? 'pb-36'
        : 'pb-28';
  const remainingProductNoun = remainingToTarget === 1 ? 'product' : 'products';
  const continueAnywayLabel =
    added.length === 0
      ? 'Skip for now'
      : `Continue with ${added.length} ${added.length === 1 ? 'product' : 'products'}`;
  const footerPrimaryLabel = compactFooterAdds
    ? 'Add to shelf'
    : hasTargetProducts
      ? 'Continue'
      : added.length > 0
        ? `Add ${remainingToTarget} more`
        : 'Skip for now';
  const progressBody = hasTargetProducts
    ? 'Good. That is enough for a stronger first routine, and you can still add more later.'
    : added.length > 0
      ? `${remainingToTarget} more ${remainingProductNoun} gives your first insight more to work with.`
      : 'Three products gives your first routine enough context to spot useful gaps or timing notes.';
  const selectedCategoryLabel =
    ONBOARDING_PRODUCT_CATEGORIES.find((c) => c.id === category)?.label ?? null;

  useEffect(() => {
    trackProductAddStarted('onboarding');
  }, []);

  useEffect(() => {
    if (!addedProductId || added.length === 0) return;
    const frame = requestAnimationFrame(() => {
      scrollRef.current?.scrollToEnd({ animated: false });
    });
    return () => cancelAnimationFrame(frame);
  }, [added.length, addedProductId]);

  function focusNextProduct() {
    scrollRef.current?.scrollTo({ y: 0, animated: motionAllowed(reduceMotion) });
    requestAnimationFrame(() => inputRef.current?.focus());
  }

  function selectCategory(nextCategory: ProductCategory | null) {
    setCategory(nextCategory);
    setCategoryPickerOpen(false);
  }

  async function remove(id: string) {
    if (!onboarding.isCurrent()) return;
    if (removing.current.has(id)) return;
    removing.current.add(id);
    setRemovingIds(new Set(removing.current));
    setRemovalError(false);
    try {
      await m.remove(id);
    } catch {
      if (
        !mounted.current ||
        activeHealthProcessingLeaseSnapshot()?.generation !== acceptedGeneration
      )
        return;
      if (mounted.current) setRemovalError(true);
      // The result may be ambiguous. Reread the durable source before offering
      // another removal; the existing availability gate owns read failure.
      await dataQuery.refetch();
    } finally {
      removing.current.delete(id);
      if (
        mounted.current &&
        activeHealthProcessingLeaseSnapshot()?.generation === acceptedGeneration
      )
        setRemovingIds(new Set(removing.current));
    }
  }

  function add() {
    if (!canNavigate()) return;
    const trimmed = name.trim();
    if (!trimmed || trimmed.length > SHELF_PRODUCT_NAME_MAX_LENGTH) return;
    navigating.current = true;
    const intakeId = resetIntake({
      name: trimmed,
      category,
      addedVia: 'onboarding',
      catalogSource: 'user_local',
      catalogMatchQuality: 'manual',
      paoMonths: null,
      paoSource: 'unknown',
    });
    setCategoryPickerOpen(false);
    router.push({ pathname: '/shelf/opened', params: { intakeId, origin: 'onboarding' } });
  }

  function go() {
    if (
      !canNavigate() ||
      currentName.current !== name ||
      currentUnsavedChoice.current !== pendingUnsavedName
    )
      return;
    if (name.trim() && !confirmUnsaved) {
      Keyboard.dismiss();
      currentUnsavedChoice.current = name;
      setPendingUnsavedName(name);
      return;
    }
    if (goals.length === 0) {
      navigating.current = true;
      router.replace('/onboarding/goals');
      return;
    }
    navigating.current = true;
    track('screen_viewed', { screen_name: 'products_intake', count: added.length });
    router.push('/onboarding/analyzing');
  }

  function canNavigate() {
    return (
      onboarding.isCurrent() &&
      mounted.current &&
      !navigating.current &&
      removing.current.size === 0 &&
      acceptedGeneration !== undefined &&
      activeHealthProcessingLeaseSnapshot()?.generation === acceptedGeneration
    );
  }

  function footerAction() {
    if (compactFooterAdds) {
      add();
      return;
    }
    if (added.length === 0 || hasTargetProducts) {
      go();
      return;
    }
    focusNextProduct();
  }

  const categoryControl = (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={
        selectedCategoryLabel ? `Category, ${selectedCategoryLabel}` : 'Choose product category'
      }
      onPress={() => setCategoryPickerOpen((open) => !open)}
      className="mb-2 min-h-[48px] flex-row items-center justify-between rounded-card border border-hairline bg-paper-raised px-4 py-3"
      style={({ pressed }) => (pressed ? { opacity: 0.82 } : undefined)}
    >
      <View className="flex-1 pr-3">
        <Text variant="label" tone="muted">
          CATEGORY · OPTIONAL
        </Text>
        <Text variant="body" className="mt-0.5 font-sans-medium">
          {selectedCategoryLabel ?? 'Choose category'}
        </Text>
      </View>
      <Text variant="body" tone="muted" style={{ fontSize: 18 }}>
        &gt;
      </Text>
    </Pressable>
  );

  if (onboarding.privacyStatus !== 'ready') {
    return (
      <Screen>
        <View className="flex-1 justify-center">
          <Text variant="title">
            {onboarding.privacyStatus === 'checking'
              ? 'Checking your privacy choice'
              : 'Your privacy choice could not be confirmed'}
          </Text>
        </View>
        <Button label="Return to privacy" onPress={() => router.replace('/onboarding/consent')} />
      </Screen>
    );
  }

  return (
    <Screen>
      <View
        className="flex-1 overflow-hidden"
        aria-hidden={categoryPickerOpen || undefined}
        accessibilityElementsHidden={categoryPickerOpen}
        importantForAccessibility={categoryPickerOpen ? 'no-hide-descendants' : 'auto'}
        style={{ minHeight: 0 }}
      >
        <ScrollView
          ref={scrollRef}
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerClassName={productsBottomPaddingClass}
          keyboardShouldPersistTaps="handled"
        >
          <Text
            variant="title"
            className={splitShortPhone ? 'mt-3' : compactPhone ? 'mt-4' : 'mt-6'}
            style={splitShortPhone ? { fontSize: 27, lineHeight: 30 } : undefined}
          >
            What&apos;s on your shelf?
          </Text>
          {showIntroCopy ? (
            <Text variant="body" tone="muted" className={compactPhone ? 'mt-2' : 'mt-3'}>
              Add the products you already use so we build around them. Even just the name helps us
              spot conflicts. You can add more anytime from your Shelf.
            </Text>
          ) : null}
          <View
            className={
              splitShortPhone
                ? 'mt-3 rounded-2xl bg-greige-chip px-4 py-2.5'
                : compactPhone
                  ? 'mt-3 rounded-2xl bg-greige-chip px-4 py-3'
                  : 'mt-4 rounded-2xl bg-greige-chip px-4 py-3'
            }
            style={{ borderWidth: 1, borderColor: colors.hairline }}
          >
            <Text variant="label" tone="clay">
              {Math.min(added.length, ONBOARDING_PRODUCT_TARGET)} OF {ONBOARDING_PRODUCT_TARGET}{' '}
              PRODUCTS
            </Text>
            {showProgressBody ? (
              <Text variant="bodySm" tone="muted" className="mt-1">
                {progressBody}
              </Text>
            ) : null}
          </View>

          <Card
            className={
              splitShortPhone
                ? 'mt-3 p-4'
                : modernTextPressurePhone
                  ? 'mt-3 p-4'
                  : compactPhone
                    ? 'mt-4 p-4'
                    : 'mt-6'
            }
          >
            <Text variant="label" tone="muted" className="mb-2">
              PRODUCT NAME
            </Text>
            <TextInput
              ref={inputRef}
              accessibilityLabel="Product name"
              maxLength={SHELF_PRODUCT_NAME_MAX_LENGTH}
              value={name}
              onChangeText={setName}
              placeholder="e.g. Retinol serum"
              placeholderTextColor={colors.mutedLight}
              className="rounded-card border border-hairline bg-paper px-4 py-3.5 font-sans text-base text-ink"
              returnKeyType="done"
              onSubmitEditing={add}
            />
            {compactFooterAdds && splitShortPhone ? categoryControl : null}
            {!compactPhone ? (
              <>
                <Text variant="label" tone="muted" className="mb-2 mt-4">
                  CATEGORY · OPTIONAL
                </Text>
                <View className="flex-row flex-wrap gap-2">
                  {ONBOARDING_PRODUCT_CATEGORIES.map((c) => (
                    <Chip
                      key={c.id}
                      label={c.label}
                      selected={category === c.id}
                      onPress={() => setCategory(category === c.id ? null : c.id)}
                    />
                  ))}
                </View>
              </>
            ) : null}
            {!compactPhone ? (
              <Button
                className="mt-4"
                label="Add to shelf"
                variant="inverse"
                disabled={!name.trim()}
                onPress={add}
              />
            ) : null}
          </Card>

          {removalError ? (
            <View accessibilityRole="alert" accessibilityLiveRegion="polite" className="mt-4">
              <Text variant="bodySm" tone="muted">
                Removal could not be confirmed. Check your Shelf below and try again if the product
                is still there.
              </Text>
            </View>
          ) : null}
          {added.length > 0 ? (
            <View className="mt-5">
              <Text variant="label" tone="muted" className="mb-2">
                {added.length} ON YOUR SHELF
              </Text>
              <View className="gap-2">
                {added.map((it) => (
                  <View
                    key={it.id}
                    className="flex-row items-center justify-between rounded-card bg-paper-raised px-4 py-3"
                    style={{ borderWidth: 1, borderColor: colors.hairline }}
                  >
                    <Text variant="body" className="flex-1 font-sans-medium">
                      {it.name}
                    </Text>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel={`Remove ${it.name}`}
                      disabled={removingIds.has(it.id)}
                      accessibilityState={{
                        disabled: removingIds.has(it.id),
                        busy: removingIds.has(it.id),
                      }}
                      onPress={() => {
                        void remove(it.id);
                      }}
                      className="h-12 w-12 items-center justify-center rounded-full"
                      style={({ pressed }) => (pressed ? { opacity: 0.72 } : undefined)}
                    >
                      <Text variant="body" tone="muted" style={{ fontSize: 18 }}>
                        {removingIds.has(it.id) ? '…' : '×'}
                      </Text>
                    </Pressable>
                  </View>
                ))}
              </View>
            </View>
          ) : null}
        </ScrollView>
      </View>

      {compactPhone ? (
        <CategoryPickerSheet
          visible={categoryPickerOpen}
          selectedCategory={category}
          onSelect={selectCategory}
          onClose={() => setCategoryPickerOpen(false)}
        />
      ) : null}
      <ScrollView
        className="bg-paper pb-4 pt-2"
        style={{ flexGrow: 0, flexShrink: 1 }}
        keyboardShouldPersistTaps="handled"
        aria-hidden={categoryPickerOpen || undefined}
        accessibilityElementsHidden={categoryPickerOpen}
        importantForAccessibility={categoryPickerOpen ? 'no-hide-descendants' : 'auto'}
      >
        {confirmUnsaved ? (
          <>
            <Text
              accessibilityRole="alert"
              accessibilityLiveRegion="polite"
              variant="bodySm"
              className="mb-2"
            >
              This product has not been added. Continue with your saved Shelf, or keep editing.
            </Text>
            <Button
              label="Continue without adding it"
              disabled={removingIds.size > 0}
              onPress={go}
            />
            <Button
              label="Keep editing"
              variant="ghost"
              onPress={() => {
                currentUnsavedChoice.current = null;
                setPendingUnsavedName(null);
              }}
            />
          </>
        ) : (
          <>
            {showCompactCategoryFooter ? categoryControl : null}
            <Button
              label={footerPrimaryLabel}
              onPress={footerAction}
              disabled={removingIds.size > 0}
            />
            {compactFooterAdds || showContinueAnyway ? (
              <Button
                label={continueAnywayLabel}
                variant="ghost"
                className="mt-1 min-h-[48px] py-2"
                onPress={go}
                disabled={removingIds.size > 0}
              />
            ) : null}
          </>
        )}
      </ScrollView>
    </Screen>
  );
}
