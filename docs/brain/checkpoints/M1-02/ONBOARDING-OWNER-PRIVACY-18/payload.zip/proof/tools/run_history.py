import json, os, re, shutil, subprocess, sys, time
from pathlib import Path
RUN=Path(__file__).resolve().parents[1]
ROOT=RUN/'independent'; PRIMARY=RUN/'repo'; OUT=RUN/'commands'
versions=[(9,'8ac97c32901272d97d1bff05f2abc294811055a6'),(10,'14805e7f708297e72419035f517acc41ba52da70'),(11,'9e3ba80e09579ee4855948f13297049791c4d5d7'),(12,'bbbd59073b7add22ac350bced0d9a34124c12ffb'),(13,'d0c5ad49ba22c8da7136d59a399589af1cea0e82'),(14,'53cf869c5fc5f13ecd18dc1ef9c3a6288eaae51a'),(15,'b79e6d1e21a367be5cea5d0b333de9f2a144d41f'),(16,'28953aa3a84fed0684b80b442d0cd9c2de0663b2'),(17,'f9709e02420d6c03cc9b9586cf60d89bfde7d8a3')]
env={k:v for k,v in os.environ.items() if not re.search(r'TOKEN|SECRET|PASSWORD|API.?KEY|AUTHORIZATION|COOKIE|PRIVATE.?KEY|SUPABASE|DSN',k,re.I)}
env['PYTHONDONTWRITEBYTECODE']='1'
mapping=json.loads((PRIMARY/'docs/phase-9/ios-sdk-package-mapping.json').read_bytes())
for row in mapping['mappings']:
 for pin in row['notes']['sourcePins']:
  target=ROOT/pin['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PRIMARY/pin['path'],target)
results=[]
for number,sha in versions:
 assert subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=ROOT)==b''
 subprocess.run(['git','switch','--detach',sha],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 command=[sys.executable,'-B',f'scripts/release/full-app-j01/source_consumer{number:02}.test.py']
 start=time.time()
 with (OUT/f'historical{number:02}.log').open('wb') as f:result=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 row=dict(version=number,sha=sha,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT).decode().strip(),exit=result.returncode,seconds=round(time.time()-start,2),qualification='UNCHANGED_ORIGINAL_TEST_AND_CHECKER_AT_IMMUTABLE_HISTORICAL_SOURCE',argv=command)
 results.append(row)
 with (OUT/'historical-lineage.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(results,f,indent=2);f.write('\n')
 print(json.dumps(row),flush=True)
 print((OUT/f'historical{number:02}.log').read_text(encoding='utf-8',errors='replace')[-1300:],flush=True)
subprocess.run(['git','switch','--detach','f9709e02420d6c03cc9b9586cf60d89bfde7d8a3'],cwd=ROOT,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
