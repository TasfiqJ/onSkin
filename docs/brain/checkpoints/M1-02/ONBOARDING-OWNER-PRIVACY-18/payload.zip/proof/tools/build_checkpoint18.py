import hashlib,json,re,stat,subprocess,zipfile
from pathlib import Path
RUN=Path(__file__).resolve().parents[1];ROOT=RUN/'repo';PROOF=RUN/'proof';OUT=RUN/'checkpoint18'
SOURCE='0c3044920726080fbbd32f6d480bb5f71620cfe7';BASE='f9709e02420d6c03cc9b9586cf60d89bfde7d8a3'
AUTH='BRAIN-M1X-ONBOARDING-OWNER-PRIVACY18-REPAIR-01'
assert not OUT.exists();OUT.mkdir()
def digest(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,stderr=subprocess.PIPE)
members={}
def add(name,data):
    assert re.fullmatch(r'[A-Za-z0-9._/-]+',name) and all(x not in ('','.','..') and not x.startswith('.') for x in name.split('/'))
    assert name not in members and name.casefold() not in {x.casefold() for x in members}
    members[name]=data
redact_pairs=[(str(RUN).encode(),b'<RUN>'),(RUN.as_posix().encode(),b'<RUN>')]
def redacted(data):
    for old,new in redact_pairs:data=data.replace(old,new)
    return data
provenance=json.loads((PROOF/'source-provenance.json').read_bytes())
for row in provenance['source_delta']:add('source/'+row['path'],git('show',SOURCE+':'+row['path']))
proof_names=['SOURCE_REPORT.md','source-provenance.json','baseline-inventory.jsonl.gz','source-inventory.jsonl.gz','intake.json','pr21-live-intake.json','pinned-pr21-lineage.txt','historical-four-ast.json','pixel-review.json','source-ci-observed.json','source-pr22-raw-metadata.json','live-heads-before.txt','expo-ios-final-inventory.json','expo-android-final-inventory.json']
for name in proof_names:
    p=PROOF/name
    if p.exists():add('proof/'+name,redacted(p.read_bytes()) if p.suffix not in ('.gz','.png') else p.read_bytes())
completed=json.loads((RUN/'commands/historical-lineage.json').read_bytes())
complete_numbers={row['version'] for row in completed if row['exit']==0}
add('proof/historical-completed-at-seal.json',redacted((json.dumps(completed,indent=2)+'\n').encode()))
for p in sorted((RUN/'commands').iterdir()):
    if not p.is_file():continue
    if p.name in ['original151.log','historical-driver.log']:continue
    m=re.fullmatch(r'historical(\d+)\.log',p.name)
    if m and int(m.group(1)) not in complete_numbers:continue
    if p.name=='historical-lineage.json':continue
    add('commands/'+p.name,redacted(p.read_bytes()))
for folder in ['browser-first','browser-second','browser-third','browser-debug','browser-fourth','browser-final']:
    for p in sorted((RUN/folder).iterdir()):
        if p.is_file() and p.suffix in ('.png','.json','.log'):
            add('browser/'+folder+'/'+p.name,redacted(p.read_bytes()) if p.suffix!='.png' else p.read_bytes())
for p in sorted((RUN/'tools').iterdir()):
    if p.is_file():add('proof/tools/'+p.name,redacted(p.read_bytes()))
add('proof/tools/historical-four-proof.mjs',redacted((RUN/'historical-four-proof.mjs').read_bytes()))
readme=f"""# Campaign18 owner-bound onboarding privacy candidate

Authority: {AUTH}. Draft PR22 https://github.com/TasfiqJ/onSkin/pull/22 targets unchanged PR21.
SOURCE_ONLY_CANDIDATE / PARTIAL_BLOCKED / independent Brain review required / NO_GO.

Immutable base {BASE}, tree c735b32c667059ba1d6855b6896c70e42d6c6fd8.
Frozen source {SOURCE}, tree 65f77fe1c03aa123339aa696b99e88f2da4d9c6c.
The last source commit contains only outputs from the unmodified Phase4 producer.

Verify with the externally supplied checkpoint manifest SHA256:

    python -B docs/brain/checkpoints/M1-02/ONBOARDING-OWNER-PRIVACY-18/verify18.py --expected-manifest-sha256 <external-sha256> --git-root .

Without --git-root this authenticates only the finite artifact/member bytes. With a complete clean delivery checkout it also checks the original externally authenticated input, full baseline/source Git object and SHA256 inventories, finite grant, every intermediate linear source tree, protected identities and exactly one five-path evidence tail. It derives HEAD/tree and binds every delivered checkpoint file. VERIFIED never accepts the source or another axis. Run the unchanged source CLI separately.

See proof/SOURCE_REPORT.md inside payload.zip. 53 focused tests pass, including all four original historical test bodies unchanged. Forced root: 6,228 mobile passes / 21 protected test failures and 24 operator passes. Lint/typecheck, both source exports and Release18's 175 refusals/six positive controls pass. Actual Expo web: 66 final PNGs, four viewports, 360px text x2, simulated keyboard height, Back/reentry/manual Shelf/unsaved choices/current consent withdrawal, zero console errors. Native/VoiceOver/real OS delivery NOT_RUN.

The original 151 CLI negatives and complete immutable Release09-17 executions were still running at sealing; no unfinished command is claimed PASS. Subsequent completion receipts, independent full-checkout tamper/restoration, final-head artifact verification, derived HEAD/tree and exact final-head CI are delivered in the external FINAL_REPORT.md, verified return and PR description. The checkpoint is not rewritten to predict future facts.

G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED.
J01/native/provider/clinical/legal/Apple/public-release gates CLOSED. F09 private manual photo history required; F18 and J02-J27 deferred.
USD0. No merge, force push, maintainer edits, auto-merge, private Security custody/rotation or self-acceptance.
"""
(OUT/'README.md').write_bytes(readme.encode())
(OUT/'verify18.py').write_bytes((RUN/'templates/verify18.py').read_bytes())
with zipfile.ZipFile(OUT/'payload.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):
        i=zipfile.ZipInfo(name,(2026,10,26,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,data)
manifest=dict(schema=1,authority=AUTH,status='SOURCE_ONLY_CANDIDATE',release='NO_GO',acceptanceGranted=False,admissions=dict(G97=False,DB=False,M103=False,M2=False,J01=False,PUBLIC=False),base=provenance['base'],source=provenance['source'],files={p.name:dict(bytes=p.stat().st_size,sha256=digest(p.read_bytes()),mode='100644') for p in sorted(OUT.iterdir())},members={name:dict(bytes=len(data),sha256=digest(data),mode='100644') for name,data in sorted(members.items())})
(OUT/'manifest.json').write_bytes((json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
anchor=digest((OUT/'manifest.json').read_bytes())
(PROOF/'checkpoint-anchor.txt').write_bytes((anchor+'\n').encode())
print(json.dumps(dict(checkpoint=str(OUT),manifest_sha256=anchor,members=len(members),payload_bytes=(OUT/'payload.zip').stat().st_size,uncompressed=sum(len(x) for x in members.values()))))

