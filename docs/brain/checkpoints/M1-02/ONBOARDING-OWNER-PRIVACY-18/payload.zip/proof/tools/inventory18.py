import gzip,hashlib,importlib.util,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'repo';OUT=ROOT.parent/'proof'
BASE='f9709e02420d6c03cc9b9586cf60d89bfde7d8a3';SOURCE='0c3044920726080fbbd32f6d480bb5f71620cfe7'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,stderr=subprocess.PIPE)
def entries(commit):
 result={}
 for line in git('ls-tree','-r','-z',commit).split(b'\0'):
  if not line:continue
  meta,path=line.split(b'\t',1);mode,kind,blob=meta.decode().split();result[path.decode()]=dict(mode=mode,kind=kind,blob=blob)
 return result
spec=importlib.util.spec_from_file_location('c18',ROOT/'scripts/release/full-app-j01/check.py');check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
cache={}
with subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as batch:
 def witness(entry):
  if entry is None:return None
  oid=entry['blob']
  if oid not in cache:
   batch.stdin.write((oid+'\n').encode());batch.stdin.flush();header=batch.stdout.readline().decode().split();assert header[:2]==[oid,'blob'],header
   data=batch.stdout.read(int(header[2]));assert batch.stdout.read(1)==b'\n'
   assert hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest()==oid
   cache[oid]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  return dict(entry,**cache[oid])
 inventories={}
 for label,commit in [('baseline',BASE),('source',SOURCE)]:
  data=entries(commit);inventories[label]=data
  rows=[dict(commit=commit,path=path,**witness(entry)) for path,entry in sorted(data.items())]
  raw=b''.join((json.dumps(row,sort_keys=True,separators=(',',':'))+'\n').encode() for row in rows)
  (OUT/(label+'-inventory.jsonl.gz')).write_bytes(gzip.compress(raw,mtime=0))
  print(label,len(rows),'objects',len(cache),flush=True)
 baseline=inventories['baseline'];source=inventories['source']
 def delta(tree):
  rows=[]
  for path in sorted(set(baseline)|set(tree)):
   if baseline.get(path)!=tree.get(path):
    assert check.allowed18(path) and path in tree and tree[path]['mode']=='100644'
    rows.append(dict(path=path,before=witness(baseline.get(path)),after=witness(tree.get(path))))
  return rows
 commits=[];parent=BASE
 for commit in git('rev-list','--reverse',BASE+'..'+SOURCE).decode().splitlines():
  assert git('rev-list','--parents','-n','1',commit).decode().split()==[commit,parent]
  check.validate18_diff(git('diff','--raw','--no-abbrev','--no-renames','-z',BASE,commit),lambda p:git('show',commit+':'+p))
  commits.append(dict(sha=commit,parent=parent,tree=git('rev-parse',commit+'^{tree}').decode().strip(),changes=delta(entries(commit))))
  parent=commit
 record=dict(schema=1,authority='BRAIN-M1X-ONBOARDING-OWNER-PRIVACY18-REPAIR-01',base=dict(sha=BASE,tree=git('rev-parse',BASE+'^{tree}').decode().strip(),paths=len(baseline)),source=dict(sha=SOURCE,tree=git('rev-parse',SOURCE+'^{tree}').decode().strip(),paths=len(source)),runtimeFreeze=dict(sha='fcf6c1fb1d53692ea207d1d69ace6185955ba3a7',tree='106b5a5cdc6586a39ac286394390185790440f45'),commits=commits,source_delta=delta(source),added=sorted(set(source)-set(baseline)),protected_baseline_paths_unchanged=len(baseline)-sum(path in baseline for path in [r['path'] for r in delta(source)]),acceptanceGranted=False,release='NO_GO')
 with (OUT/'source-provenance.json').open('w',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
 batch.stdin.close();batch.wait();assert batch.returncode==0
print('INVENTORIES_AND_ALL_INTERMEDIATE_SOURCE_TREES_VERIFIED',flush=True)
