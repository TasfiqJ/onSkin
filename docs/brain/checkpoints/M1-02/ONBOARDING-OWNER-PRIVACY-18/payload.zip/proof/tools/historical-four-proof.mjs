import ts from './repo/node_modules/typescript/lib/typescript.js';
import {execFileSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const root=new URL('./repo/',import.meta.url);const path='apps/mobile/src/features/onboarding/quizNavigation.test.ts';
const old=execFileSync('git',['show','f9709e02420d6c03cc9b9586cf60d89bfde7d8a3:'+path],{cwd:root,encoding:'utf8'});
const current=readFileSync(new URL(path,root),'utf8');
function bodies(source){const file=ts.createSourceFile('test.ts',source,ts.ScriptTarget.Latest,true);const out=[];const printer=ts.createPrinter({removeComments:true});function walk(node){if(ts.isCallExpression(node)&&node.expression.getText(file)==='it'&&ts.isStringLiteral(node.arguments[0])){out.push({name:node.arguments[0].text,body:printer.printNode(ts.EmitHint.Unspecified,node.arguments[1],file)});}ts.forEachChild(node,walk)}walk(file);return out;}
const a=bodies(old),b=bodies(current);if(JSON.stringify(a)!==JSON.stringify(b)||a.length!==4)throw Error('Original historical test assertions/navigation changed');
writeFileSync(new URL('./proof/historical-four-ast.json',import.meta.url),JSON.stringify({passed:true,cases:4,qualification:'All original four it bodies including every assertion/navigation retain identical TypeScript printer output',tests:a.map(x=>({name:x.name,sha256:createHash('sha256').update(x.body).digest('hex')}))},null,2)+'\n');
console.log('ALL_FOUR_ORIGINAL_TEST_BODIES_IDENTICAL');
