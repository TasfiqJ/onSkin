# Campaign18 frozen-source report

Authority: BRAIN-M1X-ONBOARDING-OWNER-PRIVACY18-REPAIR-01. Source-only candidate; independent Brain review required. PARTIAL_BLOCKED / NO_GO. USD0. This report records facts available when the single evidence tail was sealed. Exact derived delivery identities, subsequent historical/semantic/independent-checkout verification and final-head CI are supplied in the external FINAL_REPORT.md and verified return; they are not predicted here.

## Authenticated source

Input manifest SHA256 d6ce18a12f444fd91da5820fdf4e67900fd8d062de2515d2ef916d08a77c53df. The safely extracted packet printed VERIFIED; all nine authenticated members and the three byte-identical internal prompts were checked. The rendered chat paste was not used for byte equality. The original packet is preserved under docs/brain/task-specs/M1X-18/inputs.

Live PR21 was independently confirmed open/draft/unmerged at f9709e02420d6c03cc9b9586cf60d89bfde7d8a3, tree c735b32c667059ba1d6855b6896c70e42d6c6fd8. A fresh GitHub clone and new one-writer stage/m1-onboarding-owner-privacy18 branch were used. Draft PR22 targets the unchanged PR21 branch; auto_merge=null and maintainer_can_modify=false were independently read from GitHub REST metadata.

Runtime/code freeze: fcf6c1fb1d53692ea207d1d69ace6185955ba3a7, tree 106b5a5cdc6586a39ac286394390185790440f45. Source including unchanged-producer Phase4 projections: 0c3044920726080fbbd32f6d480bb5f71620cfe7, tree 65f77fe1c03aa123339aa696b99e88f2da4d9c6c. The three source commits, every intermediate cumulative delta, and full baseline/source mode/kind/blob/SHA256 inventories are in proof/source-provenance.json and the two compressed inventories. No protected path is deleted or changed outside the explicit grant.

## Repair

The provider owns a per-instance external memory session, with useSyncExternalStore carrying only version snapshots through React. The exact existing health lease, account generation and actual canonical consent admit the session. Revocation, expiry, account transition, same-owner regrant, A→B→A and unmount synchronously retire the old object. Private getters and every setter/scoring/persist/reset function check their captured window; a pending or old context cannot acquire a later admission. Each consumer also has a local focus token. Every route focus starts a fresh consent read; only the newest exact-window completion publishes readiness.

Persistence captures goals, answers, revision and the exact lease at invocation. It reasserts that snapshot and actual consent before scoring/local dispatch, after durability, before remote dispatch, after asynchronous settlement and before returning success. The unchanged receipt store captures the identical lease synchronously and reasserts it in its queued private transaction. Local-first durability and best-effort mirror meaning are retained; raw quiz answers are cleared only after a valid durable receipt. Concurrent saves share one operation. Pending or inaccessible consent yields no private draft and no score.

Goals has no separate unowned mount-time navigation promise. Quiz preserves same-owner Back/re-answer/Products return. Products keeps same-window typed text and explicit Keep editing/discard choices, keys typed drafts to the health generation, and fences old continuation/removal callbacks. Analyzing timers and Reveal navigation require their original admitted view. Reveal/Analyzing now scroll under text pressure; Reveal axis labels use readable inverse colors.

The four original historical it bodies retain identical TypeScript-printer output, including every assertion/navigation action. Their fixture now mounts the real provider with a real synthetic account/health lease. No assertion was skipped, deleted, changed to green, or waived. assertHealthDataWriteLease is never mocked by the new suites.

## Measured checks at seal

- Focused: 53 tests / six files pass (17 independent provider, 15 real-route, original four, nine Quiz focus, seven Products draft, one former provider-limitation regression). All synthetic.
- Forced clean-cache root: mobile 6,228 passed / 21 failed / 6,249 total; operator 24 passed. Zero Turbo cache hits. The six protected test files causing failures are listed below. These are real FAILs.
- Root lint and typecheck pass with forced execution and zero cache hits.
- Release18: 175 refusal cases and six positive controls pass, explicitly synthetic Git controls. All inherited Release08–17 function/global semantics remain unchanged except the finite additive successor dispatch; original scripts/checkpoints are untouched.
- Source-only iOS test selection: 393 passed, five Windows skips; two additional workflow contract cases pass. These are source tests, not native device evidence.
- Clean-cache Expo iOS and Android exports pass. Bundle inventories and hashes are retained; no signed/native install or device claim.
- Local DB contract: 171 passed. Canonical credential-free verification failed because the Docker daemon is absent. Local PG15/17 NOT_RUN for the same reason. Source-head GitHub PG15/17 passed; canonical CI remains environmental until independently resolved.
- Actual Expo web/Chrome: final 66 PNGs, four required viewports, 360×640 text/line-height ×2, keyboard-height simulation, Back/reentry, all quiz steps, manual Shelf return, explicit unsaved choices and actual canonical consent withdrawal. 191 recorded clicks; zero console errors. DOM text pressure and keyboard height are browser simulations. Native iPhone, VoiceOver and real OS notifications NOT_RUN.

Original 151 CLI negatives and unchanged historical Release09–17 controls were still executing when this artifact was sealed. Their actual completion/failure receipts, the source CLI independent full-checkout tamper/restoration 0/1/0 and the final-head artifact verification are delivered externally after sealing; no PASS is claimed here for an unfinished command. Source-head and final-head CI are distinct and must be read with their exact head SHA.

## Protected blockers (UNAPPLIED)

- apps/mobile/src/features/onboarding/OnboardingContext.test.ts: wholesale authority mocks omit the new real lease APIs.
- apps/mobile/src/features/onboarding/quizNavigation16.test.ts: mock provider lacks private view/admission/reset semantics.
- apps/mobile/src/features/onboarding/productsFooter16.test.ts: mock provider lacks private view/admission semantics.
- apps/mobile/src/features/shelf/coreJourney.campaign06.test.ts: mock provider lacks private view/admission semantics.
- apps/mobile/src/features/onboarding/onboardingRoutes.test.ts: source-text assertions require the old destructuring/key/Promise layout rather than the repaired provider contract.
- apps/mobile/src/features/healthConsent/healthLifecycleRoutes.test.ts: source-text assertions require unbound useState drafts. The actual pre-consent provider performs no private I/O without a valid lease.

These files are outside the strict edit grant. Production privacy gates are not weakened to satisfy stale mocks/text matches. The full root/CI results remain nonpassing and require a separately issued test-fixture repair. This report does not issue or accept that work.

## Browser failures and correction

All exploratory failures are retained. The first pass revealed clipped large-text Reveal/Analyzing content and low-contrast axis labels; those views now scroll and use readable night tones. A locale-dependent text I/O mistake introduced mojibake during editing and was corrected using explicit UTF-8; final screenshots contain readable separators. The next pass exposed React Compiler caching of external memory views when the external-store snapshot was not an explicit input. Passing the snapshot version into view construction fixed the actual mounted browser flow; successful uncompiled unit tests were not treated as sufficient evidence. The final pass repeated every required viewport after the fix. A 430px harness assumption about a category-sheet control was corrected to use the actually rendered inline category choice; product behavior was not changed to fit the harness.

## Closed authority

G97 FAIL/NO_GO. DB06/DB08/R2B NOT_ACCEPTED. M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED. M2 NOT_AUTHORIZED. J01/native/provider/clinical/legal/Apple/public release CLOSED. Qualified Security custody/rotation and the private remediation workspace/3bc6b787 were not accessed. No merge, force push, other branch change, credential rotation, paid/provider action or public release.

First public release remains complete real non-Korean F01–F17/F19–F20 + all 12 C + all six P groups, F09 manual private photo history, and exactly J01 Visible Pores after qualified optical/rights/truth/fairness/privacy gates. F18 and J02–J27 remain deferred. Source/web/fixture passes do not accept another evidence axis.
