# Campaign26 candidate CI diagnosis

The actual candidate run 40824550384 checked out exact PR29 head 52a3d01ebb36a6845d0ac21935ad35520732633f, tree ef49a81ca814f3d82b8a868e0308b6dda09c9cca, on both platforms. This is separate from the temporary test-merge identity used by other workflows. GitHub connector job metadata and freshly fetched public candidate logs independently confirm the two ordinary governance failures at `source_consumer24.test.py`: `inherited-full-prefix-exact` / `R24_FUNCTION_SCOPE`.

The unchanged original Release24 consumer was also executed locally against the complete fresh exact PR29 checkout before source modification. It exited 1 at the same assertion. The failure occurs before its synthetic Git controls and does not prove those later controls failed. The authentic original test correctly expects the exact Release24 appendix function set; current PR29 legitimately also has Release25 functions. Deleting its assertion or redirecting its expected value would weaken the historical contract.

Both actual jobs separately completed the public component runner with exit 1, `candidateReady=false`, `acceptanceGranted=false`, `G97=FAIL/NO_GO`, and the same seven unresolved components: archive coverage, dependencies, original source contract, protected secret/history custody, protected static analysis, qualified custody, and working-byte coverage. The routing repair must preserve this result. Only allowlisted public summary fields were retained; original Security logs were not fetched.

## Minimal permitted routing

Keep current exact-head `actions/checkout` and all existing component steps, permissions, platform matrix, mandatory installation, scanner runner and upload redaction. Replace the single current-source Release24 consumer command with three independently identified runs:

1. Original Release24 consumer and checker from exact PR28 d0ccef65bcbe0c90483e6c0f691ed95f92228c6c / tree22f91455d651a81296ab8724f9db7cfead65af08.
2. Original Release25 consumer and checker from exact PR29 52a3d01ebb36a6845d0ac21935ad35520732633f / treeef49a81ca814f3d82b8a868e0308b6dda09c9cca.
3. New Release26 consumer and checker on the exact event head, current clean source, and newly sealed checkpoint.

Use newly created full remote clones for the historical runs in unique directories outside the candidate workspace. Separate object stores avoid object-alternate and hardlink ambiguities; do not switch the candidate checkout between historical and current work. The existing inherited full-source checker requires a standalone `.git` and refuses shared worktree metadata, shallow/partial stores, alternates, grafts and replacement refs. Original consumer synthetic fixtures intentionally use alternates internally and label that limitation; such fixture coverage must not be described as independent full-checkout proof.

The new allowed `source_consumer26.test.py` can own a bounded historical replay mode plus normal current refusal tests, with YAML retaining only invocation and evidence paths. Before execution, require exact historical head/tree, consumer/checker mode100644, Git blob and independent SHA256 from `pinned-consumer-identities.json`, clean raw tracked bytes/index/hidden flags, full object history and no aliases. Invoke the original script in its own pinned root with an explicit resolved Python executable. Scrub inherited current-PR `GITHUB_*` only in historical child environments, and record `INDEPENDENT_EXACT_HEAD_CHECKOUT_NO_CI_EVENT_CLAIM`; never invent a PR28/29 CI event. Original consumers generate explicitly synthetic event fixtures themselves. Keep current Release26 event identity checks active.

Bind each receipt to release, source head/tree, checker and consumer byte identity/mode, actual interpreter/Git executable SHA256 and version, current run ID/attempt/job, nonce, fresh clone path identity, start/end snapshots, real child exit, and expected terminal PASS control counts/qualification. Fail on missing, duplicate, malformed, stale or contradictory receipts and any skip/failed expected test. Write receipts with exclusive creation outside source and validate all three before claiming governance completion. Use `set -o pipefail`, preserve nonzero status across tee, and retain independent public checks even if governance fails.

Refusal tests should actively cover wrong checkout/tree, current source substituted for historical, swapped checker or consumer, altered mode/bytes, missing pinned ref/object, partial/shared store, reused workspace, stale nonce/run receipt, malformed/unknown fields, missing result, false success with nonzero exit, skip, and output that lacks authentic terminal counters. Prefix/suffix signatures alone are insufficient because an untouched script launched in the wrong cwd still uses the wrong authority.

## Release26 successor

Append new Release26 functions/constants and final dispatch before the preserved terminal guard, preserving every prior function AST and inherited bytes. Bind the full immutable PR29 checker prefix; separately authenticate the Release26 appendix and exact finite scope plan. Do not call `validate24_checker` or `validate25_checker` against appended current bytes: their original exact function-set meaning must stay historical. Replay them only in authenticated pinned historical roots. Current Release26 source governance must preserve all historical closures and unchanged historical tests.

This is a technical integration recommendation, not source acceptance or Security qualification. No source paths, branches, original tests, assertions, or protected findings were modified by this worker.
