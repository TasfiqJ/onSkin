# Campaign26 checkpoint staging builder

Status: outside-source tooling ready for root review. Real-source staging is **NOT_RUN_BY_SYNTHETIC_CONTROLS**; the separate actual seal receipt must supply the actual committed runtime body and sole unchanged-producer two-worklist child. The isolated controls are synthetic parser/artifact controls, not a real source freeze or final-clone proof. Acceptance remains false; release remains NO_GO.

`seal_checkpoint26.py` never writes source files, Git objects/refs/index, worklists or source checkpoint paths. It writes one **new** outside-source staging directory containing exactly `README.md`, `REPORT.md`, `manifest.json`, `payload.zip`, and `verify26.py`, plus a separate new sibling seal receipt. Root remains the only writer of the eventual checkpoint/tail in the integration checkout.

## Inputs and execution

Run only after the final runtime body is committed and the sole two-worklist child is current HEAD in a clean, standalone complete clone. The immutable first child must be `d970311fd0741414f9a96a15afc653f7e1cc39df`; its plan bytes must hash to `6c0f5f6d4f66612551e79216e49b698fe487b9d3cefc0c3f0cf1bb30b9fbd7e7`.

1. Regenerate the current verifier templates, DERIVATION and CONTROLS after the current source checker is locked. Review and externally pin the checkpoint template SHA256. The builder refuses a template whose external anchor, derivation, successful controls or committed checker identity differs.
2. Finish the outside `FINAL_REPORT.md` as a factual pre-tail snapshot and refresh the bounded explicit evidence catalog. Evidence inputs must remain stable for the entire seal. The catalog's original before-read witness, current read/hash and final reread/hash must agree. The builder deliberately refuses newly changed logs rather than silently replacing their witnesses.
3. Invoke the builder with the actual two source identities. The following variables are placeholders for root's reviewed actual values; no identities are inferred or fabricated:

```powershell
python -I -B .\packaging26\seal_checkpoint26.py `
  --git-root .\source `
  --runtime-head $actualRuntimeHead `
  --source-head $actualSoleWorklistChild `
  --output .\packaging26\checkpoint-stage-actual26 `
  --catalog .\packaging26\EVIDENCE_CATALOG_DRAFT.json `
  --report .\packaging26\FINAL_REPORT.md `
  --expected-verifier-sha256 $reviewedCurrentVerifierSHA256
```

The command is shown relative to the Campaign26 run directory. `--output` must not already exist and must be outside **every** checkout. Defaults use the sibling `verify26.py`, `DERIVATION.json` and `CONTROLS.json`; explicit alternate inputs are available in `--help`. The receipt defaults to `checkpoint-stage-actual26.seal-receipt.json`, outside the exact-five checkpoint. An incomplete/refused stage is never reused: inspect its refusal, preserve it as failed evidence, and choose a new output path after fixing the cause.

## What a successful receipt proves

The builder validates authentic PR29/PR28 ancestry/tree metadata, a standalone complete link-free object store, actual linear finite-grant body history, the sole immutable first-child scope plan, the exact nonadmitting PR30 contract, the current checker/template pin, and a sole two-worklist child whose producer blob/mode is unchanged from PR29. It checks the current source tree/index/flags and clean Git status with configured clean/smudge/process filters disabled. It opens only the three granted public committed plan/contract/checker blobs; protected source content is not read by the builder. Metadata is rechecked after staging.

It accepts only bounded explicitly named catalog entries under the approved task evidence directories/root names, verifies their exact hashes/byte lengths before and after staging, rejects links/reparse nodes/hardlinks/aliases/traversal and enforces total/file/count bounds. ZIP entries are deterministic sorted regular Unix 100644 files, with fixed timestamps, stored compression, no directories/extras/comments/ZIP64. Caches, source checkout contents, raw private Security material, photos, native binaries and the original large C25 archive are outside the allowlist. Their bounded public receipts/anchors remain eligible evidence.

The generated manifest source domain is exactly PR29 base/tree, runtime head/tree and sole worklist child/tree. It excludes a future tail identity and its own manifest hash. The manifest/verifier anchors are emitted in the **external** seal receipt. REPORT is prefixed as an immutable pre-tail snapshot. Final-head CI, two final independent clones, actual final source/artifact 0/1/0, and public outer ZIP/download proof remain explicitly NOT_RUN_EXTERNAL_POST_TAIL inside the checkpoint; a later outside FINAL_REPORT may record them.

A successful production command must actually run the staged standalone `verify26.py` in artifact-only mode using computed external anchors, return exit 0 with exactly five files, report source checks NOT_RUN, and retain false acceptance / NO_GO. This is artifact integrity and committed metadata proof. It does not claim raw protected working-byte equality, Phase4 execution, final-source verifier replay, native/device acceptance, database acceptance, Security acceptance or release authorization.

## Executed tooling controls

`python -I -B .\packaging26\seal_checkpoint26.py --help` and explicit `py_compile` checks pass. `test_seal_checkpoint26.py` executes isolated synthetic metadata/catalog/archive controls, including actual standalone artifact-only clean/corrupt/restored exits **0 / 1 / 0**. It records observed counts and the current builder/template hashes in `SEALER_SYNTHETIC_CONTROLS.json`. An actual hardlink input is refused; actual symlink creation is unavailable on this Windows host and is recorded as a platform SKIP, never a PASS. Tests write only an outside-source `seal26-synthetic-*` fixture directory and their outside-source receipt/log. The production CLI has no skip, synthetic, or bypass option.

Root must still execute the builder against the actual locked source identities, inspect the external receipt and exact-five stage, copy only the approved five files into the sole source evidence tail, and collect the final head/CI/two-clone/public-download proofs externally. No integration commit, copy, freeze, push or publication was performed by this worker.
