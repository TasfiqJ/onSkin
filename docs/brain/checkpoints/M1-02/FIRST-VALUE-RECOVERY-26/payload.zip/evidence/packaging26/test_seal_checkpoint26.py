"""Synthetic builder/parser controls; never real freeze or final-source proof."""
import argparse
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('sealer26_under_test', HERE / 'seal_checkpoint26.py')
sealer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sealer)
derivation = json.loads((HERE / 'DERIVATION.json').read_bytes())
args = argparse.Namespace(verifier=HERE / 'verify26.py', derivation=HERE / 'DERIVATION.json',
                         controls=HERE / 'CONTROLS.json',
                         expected_verifier_sha256=derivation['templates']['verify26.py']['sha256'])
verifier, helper, _, _ = sealer.template(args)
cases, skips = [], []
temporary = Path(tempfile.mkdtemp(prefix='seal26-synthetic-', dir=HERE)).resolve()
assert temporary.parent == HERE and not (temporary / '.git').exists()


def check(name, action, success=False):
    try:
        result = action()
    except BaseException as error:
        if success:
            raise
        cases.append({'case': name, 'exit': 1, 'expectedExit': 1,
                      'code': str(error.args[0]) if isinstance(error, sealer.Refusal) else type(error).__name__})
        return
    assert success, name + ' unexpectedly accepted'
    cases.append({'case': name, 'exit': 0, 'expectedExit': 0})
    return result


bad_args = copy.copy(args)
bad_args.expected_verifier_sha256 = '0' * 64
check('externally-anchored-template-refuses-identity-substitution', lambda: sealer.template(bad_args))

contract = {'schema': 1, 'authority': sealer.AUTHORITY, 'status': 'SUBMITTED_REVIEW_REQUIRED',
            'base': sealer.BASE, 'tree': sealer.BASE_TREE, 'scopeCommit': sealer.PLAN_COMMIT,
            'scopePlanSHA256': sealer.PLAN_SHA, 'inputManifestSHA256': sealer.INPUT_SHA,
            'acceptanceGranted': False,
            'admissions': {key: False for key in ('G97', 'DB', 'M103', 'M2', 'J01', 'PUBLIC')}, 'pr': 30}
check('exact-pr30-nonadmitting-contract', lambda: sealer.validate_contract(contract), True)
for key, value in [('schema', True), ('pr', 29), ('acceptanceGranted', 0), ('status', 'ACCEPTED'), ('base', '0' * 40)]:
    bad = {**contract, key: value}
    check('contract-refusal-' + key, lambda bad=bad: sealer.validate_contract(bad))
bad = copy.deepcopy(contract)
bad['admissions']['M2'] = True
check('false-M2-admission-refused', lambda: sealer.validate_contract(bad))

mode_add = (':000000', '100644', '0' * 40, 'a' * 40, 'A')
mode_edit = (':100644', '100644', 'a' * 40, 'b' * 40, 'M')
existing = {'docs/USER_FLOW_TREE.md', *sealer.WORKLIST}
new = {sealer.PLAN, 'scripts/release/full-app-j01/source_consumer26.test.py'}
records = [
    {'commit': sealer.PLAN_COMMIT, 'parent': sealer.BASE, 'tree': sealer.PLAN_TREE,
     'changes': {sealer.PLAN: mode_add}},
    {'commit': 'a' * 40, 'parent': sealer.PLAN_COMMIT, 'tree': 'b' * 40,
     'changes': {'docs/USER_FLOW_TREE.md': mode_edit}},
]
check('synthetic-metadata-valid-first-plan-linear-body', lambda: sealer.validate_history(records, existing, new), True)
for label, mutate in [
    ('wrong-first-plan', lambda value: value[0].update(commit='f' * 40)),
    ('nonlinear-parent', lambda value: value[1].update(parent=sealer.BASE)),
    ('protected-source', lambda value: value[1].update(changes={'supabase/protected.sql': mode_edit})),
    ('worklist-in-body', lambda value: value[1].update(changes={next(iter(sealer.WORKLIST)): mode_edit})),
    ('plan-mutation', lambda value: value[1].update(changes={sealer.PLAN: mode_edit})),
]:
    bad = copy.deepcopy(records)
    mutate(bad)
    check('synthetic-metadata-refuses-' + label, lambda bad=bad: sealer.validate_history(bad, existing, new))
new_records = copy.deepcopy(records)
new_path = 'scripts/release/full-app-j01/source_consumer26.test.py'
new_records[1]['changes'][new_path] = mode_add
new_records.append({'commit': 'c' * 40, 'parent': 'a' * 40, 'tree': 'd' * 40, 'changes': {new_path: mode_edit}})
check('task-new-file-may-change-again-before-freeze', lambda: sealer.validate_history(new_records, existing, new), True)

for value in (b'{"schema":1,"schema":1}', b'{"number":NaN}', b'{"number":1.0}', b'{' + b'"number":' + b'1' * 50 + b'}'):
    check('strict-malformed-JSON-refusal', lambda value=value: sealer.loads(value))
for path in ('source/supabase/private.json', 'manual-evidence/../secret.json', '.env.json',
             'adversarial26/vite-cache/results.json', 'c25-archive-independent/original.zip', 'browser-evidence/native.hbc'):
    assert not sealer.allowed_evidence(path), path
    cases.append({'case': 'allowlist-refuses-' + path, 'exit': 1, 'expectedExit': 1})

small = temporary / 'regular.txt'
small.write_bytes(b'SYNTHETIC outside-source test file\n')
check('bounded-regular-read', lambda: sealer.safe_read(small), True)
hard = temporary / 'hardlinked.txt'
os.link(small, hard)
check('actual-filesystem-hardlink-refused', lambda: sealer.safe_read(hard))
try:
    link = temporary / 'linked.txt'
    os.symlink(small, link)
except OSError:
    skips.append({'case': 'actual-filesystem-symlink', 'reason': 'Symlink creation unavailable on this host; not promoted to PASS.'})
else:
    check('actual-filesystem-symlink-refused', lambda: sealer.safe_read(link))
check('existing-output-refused', lambda: sealer.external_output(temporary))
check('output-inside-real-source-refused-without-writing', lambda: sealer.external_output(sealer.RUN / 'source' / 'SEAL26_MUST_NOT_CREATE'))

files = {'evidence/a.txt': b'SYNTHETIC A\n', 'evidence/b.json': b'{"synthetic":true}\n'}
first = sealer.deterministic_zip(files, helper)
assert first == sealer.deterministic_zip(files, helper)
with zipfile.ZipFile(io.BytesIO(first)) as archive:
    assert archive.namelist() == sorted(files)
    assert all(info.create_system == 3 and info.external_attr == 0o100644 << 16 and
               info.flag_bits == 0 and not info.extra and not info.comment and not info.is_dir() and
               info.compress_type == zipfile.ZIP_STORED for info in archive.infolist())
cases.append({'case': 'deterministic-regular100644-exact-no-extra-ZIP', 'exit': 0, 'expectedExit': 0})
for files_bad in ({'A/x': b'x', 'a/y': b'y'}, {'a': b'x', 'a/child': b'y'}, {'../escape': b'x'}):
    check('ZIP-path-parent-alias-or-traversal-refused', lambda bad=files_bad: sealer.deterministic_zip(bad, helper))

relative = 'browser-evidence/manual-read-error.json'
raw = sealer.safe_read(sealer.RUN / relative)
catalog = {'schema': 1, 'sourceRoot': str(sealer.RUN), 'acceptanceGranted': False, 'release': 'NO_GO',
           'count': 1, 'totalBytes': len(raw), 'omitted': [], 'files': [
               {'sourcePath': relative, 'suggestedReturnPath': 'evidence/' + relative,
                **sealer.witness(raw), 'mode': '100644', 'qualification': 'SYNTHETIC_CATALOG_PARSER_CONTROL'}]}
catalog_path = temporary / 'synthetic-catalog.json'
catalog_path.write_bytes(sealer.encode(catalog))
check('bounded-explicit-catalog-current-actual-public-file', lambda: sealer.catalog_payload(catalog_path, helper), True)
catalog['files'][0]['sha256'] = '0' * 64
catalog_path.write_bytes(sealer.encode(catalog))
check('catalog-byte-refutation-refused', lambda: sealer.catalog_payload(catalog_path, helper))

# These syntactically valid identities are deliberate parser fixtures. No Git
# validation is bypassable from the production CLI, and no real freeze is claimed.
source = {'base': sealer.BASE, 'baseTree': sealer.BASE_TREE, 'runtimeHead': sealer.PLAN_COMMIT,
          'runtimeTree': sealer.PLAN_TREE, 'sourceHead': '2' * 40, 'sourceTree': '3' * 40}
cp_files = sealer.checkpoint_files(source, {'qualification': 'SYNTHETIC_METADATA_NOT_ACTUAL_GIT_OR_FREEZE'},
    files, b'SYNTHETIC artifact controls only. SUBMITTED_REVIEW_REQUIRED / NO_GO\n', verifier, helper)
stage = sealer.external_output(temporary / 'synthetic-checkpoint')
stage.mkdir()
for name, body in cp_files.items():
    sealer.write_exclusive(stage / name, body)
assert {path.name for path in stage.iterdir()} == sealer.FILES
command = [sys.executable, '-I', '-B', str(stage / 'verify26.py'), '--root', str(stage),
           '--expected-manifest-sha256', sealer.sha(cp_files['manifest.json']),
           '--expected-verifier-sha256', sealer.sha(verifier)]
def artifact_cli(expected):
    code, stdout, stderr = helper['bounded'](command, temporary, os.environ.copy(), 1024 * 1024, 120)
    assert code == expected and not stderr
    result = json.loads(stdout)
    assert result['acceptanceGranted'] is False and result['release'] == 'NO_GO'
    if expected == 0:
        assert result['status'] == 'VERIFIED' and result['sourceChecks'] == {'state': 'NOT_RUN'} and 'git' not in result
    return code
triple = [artifact_cli(0)]
original = cp_files['payload.zip']
corrupt = bytearray(original)
corrupt[40] ^= 1
(stage / 'payload.zip').write_bytes(corrupt)
triple.append(artifact_cli(1))
(stage / 'payload.zip').write_bytes(original)
assert (stage / 'payload.zip').read_bytes() == original
triple.append(artifact_cli(0))
cases.append({'case': 'actual-synthetic-standalone-artifact-corruption-restoration', 'exit': 0, 'expectedExit': 0,
              'observedExits': triple, 'qualification': 'SYNTHETIC_ARTIFACT_ONLY_NO_GIT_OR_REAL_FREEZE_PROOF'})
receipt = {'status': 'PASS', 'qualification': 'SYNTHETIC_SEALER_METADATA_CATALOG_AND_ARTIFACT_CONTROLS_ONLY',
           'realSourceFreezeValidation': 'NOT_RUN_BY_SYNTHETIC_CONTROLS', 'productionBypassOrSyntheticFlag': False,
           'sourceWrites': False, 'positive': sum(value['exit'] == 0 for value in cases),
           'refusals': sum(value['exit'] == 1 for value in cases), 'cases': cases, 'platformSkips': skips,
           'actualSyntheticArtifactExits': triple, 'fixtureRoot': str(temporary),
           'builderSHA256': sealer.sha(sealer.safe_read(HERE / 'seal_checkpoint26.py')),
           'templateSHA256': sealer.sha(verifier), 'acceptanceGranted': False, 'release': 'NO_GO'}
(HERE / 'SEALER_SYNTHETIC_CONTROLS.json').write_bytes(sealer.encode(receipt))
print(json.dumps({'status': receipt['status'], 'qualification': receipt['qualification'],
                  'positive': receipt['positive'], 'refusals': receipt['refusals'], 'platformSkips': skips,
                  'actualSyntheticArtifactExits': triple, 'realSourceFreezeValidation': receipt['realSourceFreezeValidation']}))
