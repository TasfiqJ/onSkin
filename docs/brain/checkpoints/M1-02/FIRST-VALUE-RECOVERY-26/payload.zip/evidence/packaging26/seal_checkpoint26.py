"""Stage the sole Campaign26 checkpoint outside every source checkout.

No source files, Git objects, refs, index, worklists or checkpoint paths are
written. The production CLI has no bypass/synthetic mode. Artifact verification
is mandatory; complete final-source/two-clone/CI proof is external after tail.
"""
import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import zipfile

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
BASE = '52a3d01ebb36a6845d0ac21935ad35520732633f'
BASE_TREE = 'ef49a81ca814f3d82b8a868e0308b6dda09c9cca'
PR28 = 'd0ccef65bcbe0c90483e6c0f691ed95f92228c6c'
PR28_TREE = '22f91455d651a81296ab8724f9db7cfead65af08'
PLAN_COMMIT = 'd970311fd0741414f9a96a15afc653f7e1cc39df'
PLAN_TREE = 'f9aa3502e87fc5e8dc295a6a26eb243851adb9ba'
PLAN_SHA = '6c0f5f6d4f66612551e79216e49b698fe487b9d3cefc0c3f0cf1bb30b9fbd7e7'
INPUT_SHA = '9d87a26cb84ed81c5f0deb950a919ae0899c1f8805ebea7e386eace05a7db112'
AUTHORITY = 'BRAIN-M1X-FIRST-VALUE-RECOVERY26-REPAIR-01'
SUPPLIER_VERIFIER = '5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a'
PLAN = 'docs/brain/task-specs/M1X-26/SCOPE_PLAN.md'
CONTRACT = 'docs/brain/contracts/M1X-26/source26.v1.json'
CHECKER = 'scripts/release/full-app-j01/check.py'
PRODUCER = 'scripts/phase4/build-source-worklist.mjs'
CHECKPOINT = 'docs/brain/checkpoints/M1-02/FIRST-VALUE-RECOVERY-26/'
FILES = {'README.md', 'REPORT.md', 'manifest.json', 'payload.zip', 'verify26.py'}
WORKLIST = {'docs/phase-4/generated/source-worklist.json', 'docs/phase-4/generated/source-worklist.md'}
HEX40 = re.compile(r'[0-9a-f]{40}')
HEX64 = re.compile(r'[0-9a-f]{64}')
MAX_FILE = 4 * 1024 * 1024
MAX_TOTAL = 24 * 1024 * 1024
MAX_FILES = 512
ROOT_NAMES = {
    'preflight_receipt.json', 'npm-ci.log', 'full-tests26.log', 'full-tests26-event-lease.log',
    'operator26.log', 'typecheck26-final.log', 'typecheck26-event-lease.log',
    'lint26-final.log', 'lint26-event-lease.log', 'focused26-final.log', 'detail26-final.log',
    'detail26-event-lease.log', 'detail-query-sequence-before.log', 'photo15-97-26.log',
    'launch26.log', 'privacy26-tests.log', 'native26-strict.log', 'canonical-db26-local.log',
    'original151-26.log', 'consumer26-root-first.log', 'export26-ios-first-env-mismatch.log',
    'export26-ios-final.log', 'export26-android-final.log', 'pr30-policy-first.json',
    'phase4-producer26-freeze.stdout.log', 'phase4-producer26-freeze.stderr.log',
}
EVIDENCE_DIRS = {'browser-evidence', 'ci-baseline', 'manual-evidence', 'adversarial26',
                 'historical26', 'c25-archive-independent'}
PACKAGING_NAMES = {'CONTROLS.json', 'DERIVATION.json', 'C25_PHOTO_COMMANDS_AUTHENTICATED.json',
                   'REPORT_DRAFT_FACTS.json', 'SEALER_HANDOFF.md', 'SEALER_SYNTHETIC_CONTROLS.json',
                   'seal_checkpoint26.py', 'test_seal_checkpoint26.py',
                   'sealer-synthetic-controls.log', 'sealer-pycompile.log', 'SUBSTANTIVE_FREEZE26.json'}
EXPLICIT_NESTED_EVIDENCE = {
    'ci-baseline/actual-current-and-historical-replay/' + name for name in
    ('receipt.json', 'current-consumer.jsonl', 'current-source.json', 'historical-receipt.json',
     'historical-stderr.log', 'historical-stdout.jsonl')
} | {'ci-baseline/actual-helper24-executed-code/' + name for name in
     ('checker.py', 'consumer26.py', 'PROVENANCE.json')}


class Refusal(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode('utf-8')


def witness(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def safe_read(path, limit=MAX_FILE):
    """Bootstrap read before any template code executes; no links or hardlinks."""
    path = Path(os.path.abspath(path))
    for parent in path.parents:
        info = parent.lstat()
        need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
             not getattr(info, 'st_file_attributes', 0) & 1024, 'INPUT_PARENT_LINK_OR_MODE')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and not stat.S_ISLNK(before.st_mode) and
         not getattr(before, 'st_file_attributes', 0) & 1024 and before.st_nlink == 1 and
         not before.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX) and
         before.st_size <= limit, 'INPUT_FILE_MODE_OR_BOUND')
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    try:
        opened = os.fstat(descriptor)
        signature = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns,
                                   value.st_ctime_ns, value.st_mode, value.st_nlink,
                                   getattr(value, 'st_file_attributes', 0))
        need(signature(opened) == signature(before), 'INPUT_CHANGED')
        pieces, total = [], 0
        while True:
            chunk = os.read(descriptor, min(65536, limit + 1 - total))
            if not chunk:
                break
            total += len(chunk)
            need(total <= limit and total <= before.st_size, 'INPUT_CHANGED_OR_BOUND')
            pieces.append(chunk)
        need(total == before.st_size and signature(os.fstat(descriptor)) == signature(before) and
             signature(path.lstat()) == signature(before), 'INPUT_CHANGED')
        return b''.join(pieces)
    finally:
        os.close(descriptor)


def loads(raw):
    need(type(raw) is bytes and len(raw) <= MAX_FILE, 'JSON_BOUND')
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'JSON_DUPLICATE_KEY')
            result[key] = value
        return result
    def integer(value):
        need(len(value.lstrip('-')) <= 20, 'JSON_INTEGER_BOUND')
        return int(value)
    def rejected(_):
        raise Refusal('JSON_FLOAT_OR_NONFINITE')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_int=integer,
                           parse_float=rejected, parse_constant=rejected)
    except (UnicodeError, json.JSONDecodeError, RecursionError):
        raise Refusal('JSON_INVALID') from None
    return value


def template(args):
    raw = safe_read(args.verifier, 1024 * 1024)
    need(HEX64.fullmatch(args.expected_verifier_sha256) and sha(raw) == args.expected_verifier_sha256,
         'EXTERNAL_TEMPLATE_ANCHOR')
    derivation = loads(safe_read(args.derivation))
    controls = loads(safe_read(args.controls))
    need(derivation.get('supplierVerifierSHA256') == SUPPLIER_VERIFIER and
         derivation.get('scopePlanSHA256') == PLAN_SHA and
         derivation.get('templates', {}).get('verify26.py') == witness(raw), 'TEMPLATE_DERIVATION')
    need(controls.get('status') == 'PASS' and controls.get('acceptanceGranted') is False and
         controls.get('release') == 'NO_GO' and type(controls.get('positive')) is int and
         controls['positive'] >= 8 and type(controls.get('refusals')) is int and
         controls['refusals'] >= 60 and
         controls.get('templateDerivation', {}).get('verify26.py') == witness(raw), 'TEMPLATE_CONTROLS')
    constants = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in {'MODE', 'BASE', 'BASE_TREE', 'PLAN_COMMIT', 'PLAN_SHA256', 'INPUT', 'AUTHORITY', 'CHECKER_SHA256'}:
                constants[node.targets[0].id] = ast.literal_eval(node.value)
    expected = {'MODE': 'checkpoint', 'BASE': BASE, 'BASE_TREE': BASE_TREE, 'PLAN_COMMIT': PLAN_COMMIT,
                'PLAN_SHA256': PLAN_SHA, 'INPUT': INPUT_SHA, 'AUTHORITY': AUTHORITY,
                'CHECKER_SHA256': derivation.get('sourceCheckerSHA256')}
    need(constants == expected and HEX64.fullmatch(expected['CHECKER_SHA256'] or ''), 'TEMPLATE_IDENTITY')
    # The authenticated current template supplies the already-tested contained
    # subprocess, Git metadata, path/alias and archive parsers. No source checker
    # or private-working-byte hashing function is called by this builder.
    namespace = {'__name__': 'sealer26_authenticated_verifier', '__file__': str(args.verifier)}
    exec(compile(raw, str(args.verifier), 'exec'), namespace)
    need(safe_read(args.verifier, 1024 * 1024) == raw, 'TEMPLATE_CHANGED')
    return raw, namespace, derivation, controls


def validate_contract(value):
    expected = {'schema': 1, 'authority': AUTHORITY, 'status': 'SUBMITTED_REVIEW_REQUIRED',
                'base': BASE, 'tree': BASE_TREE, 'scopeCommit': PLAN_COMMIT,
                'scopePlanSHA256': PLAN_SHA, 'inputManifestSHA256': INPUT_SHA,
                'acceptanceGranted': False, 'admissions': {key: False for key in
                    ('G97', 'DB', 'M103', 'M2', 'J01', 'PUBLIC')}, 'pr': 30}
    need(type(value) is dict and value == expected and type(value.get('schema')) is int and
         type(value.get('pr')) is int and value.get('acceptanceGranted') is False and
         all(flag is False for flag in value.get('admissions', {}).values()), 'PR30_CONTRACT')


def validate_history(records, existing, new):
    need(1 <= len(records) <= 128, 'BODY_HISTORY_BOUND')
    prior = BASE
    for index, record in enumerate(records):
        need(record['parent'] == prior and HEX40.fullmatch(record['commit']) and
             HEX40.fullmatch(record['tree']), 'BODY_LINEAR_HISTORY')
        changed = set(record['changes'])
        need(changed and changed <= existing | new and not changed & WORKLIST and
             'ONSKIN_BRAIN_HANDOFF.txt' not in changed and
             not any(path.startswith(CHECKPOINT) for path in changed), 'BODY_FINITE_SCOPE')
        for path, change in record['changes'].items():
            need(change[1] == '100644' and change[0] in (':000000', ':100644') and
                 change[4] == ('A' if change[0] == ':000000' else 'M') and
                 (path not in existing or change[0] == ':100644'), 'BODY_PATH_MODE')
        if index == 0:
            need(record['commit'] == PLAN_COMMIT and record['tree'] == PLAN_TREE and
                 changed == {PLAN}, 'SOLE_FIRST_CHILD_PLAN')
        else:
            need(PLAN not in changed, 'IMMUTABLE_PLAN')
        prior = record['commit']


def metadata(root, runtime, source, helper, checker_sha):
    need(HEX40.fullmatch(runtime) and HEX40.fullmatch(source) and runtime != source, 'SOURCE_ARGUMENTS')
    git = lambda *args, **kwargs: helper['git'](root, *args, **kwargs)
    text = lambda *args: git(*args).decode('utf-8').strip()
    for path in (root, root / '.git', root / '.git/objects'):
        helper['node'](path, True)
    helper['standalone_git_store'](root)
    need(text('rev-parse', '--show-toplevel').replace('\\', '/').casefold() ==
         root.as_posix().casefold(), 'SOURCE_TOPLEVEL')
    need(text('rev-parse', '--is-shallow-repository') == 'false' and
         text('rev-parse', '--git-common-dir') == '.git' and text('rev-parse', '--git-dir') == '.git',
         'SOURCE_STANDALONE_COMPLETE')
    for name in ('objects/info/alternates', 'objects/info/http-alternates', 'shallow', 'info/grafts'):
        need(not os.path.lexists(root / '.git' / name), 'SOURCE_SHARED_OR_GRAFTED')
    need(not git('for-each-ref', '--format=%(refname)', 'refs/replace').strip(), 'SOURCE_REPLACEMENT_REF')
    environment = {key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')}
    code, output, _ = helper['bounded']([shutil.which('git'), 'config', '--get-regexp',
        r'^(extensions\.partialclone|remote\..*\.promisor)$'], root, environment, 65536, 30)
    need(code == 1 and not output, 'SOURCE_PARTIAL_CLONE')
    need(not any(line.startswith(b'?') for line in
         git('rev-list', '--objects', '--missing=print', 'HEAD').splitlines()),
         'SOURCE_MISSING_REACHABLE_OBJECT')
    need(text('rev-parse', 'HEAD') == source and text('rev-parse', BASE + '^{tree}') == BASE_TREE and
         text('rev-parse', PR28 + '^{tree}') == PR28_TREE and
         text('merge-base', PR28, BASE) == PR28 and text('merge-base', BASE, runtime) == BASE,
         'SOURCE_PINNED_IDENTITY')
    need(text('rev-list', '--parents', '-n', '1', source).split() == [source, runtime], 'SOLE_WORKLIST_PARENT')
    changes = helper['diff'](root, runtime, source)
    need(set(changes) == WORKLIST and all(value[0] == ':100644' and value[4] == 'M' for value in changes.values()),
         'SOLE_TWO_WORKLIST_CHILD')
    source_tree = helper['git_tree'](root, source)
    runtime_tree = helper['git_tree'](root, runtime)
    base_tree = helper['git_tree'](root, BASE)
    need(base_tree.get(PRODUCER) is not None and base_tree[PRODUCER][0] == '100644' and
         runtime_tree.get(PRODUCER) == base_tree[PRODUCER] == source_tree.get(PRODUCER), 'PRODUCER_CHANGED')
    for path in (PLAN, CONTRACT, CHECKER):
        need(runtime_tree.get(path) == source_tree.get(path) and source_tree[path][0] == '100644', 'PUBLIC_BLOB_MODE')
    def public_blob(path, limit):
        oid = source_tree[path][1]
        need(int(text('cat-file', '-s', oid)) <= limit, 'PUBLIC_BLOB_BOUND')
        return git('cat-file', 'blob', oid, limit=limit + 1)
    plan_raw = public_blob(PLAN, 65536)
    need(sha(plan_raw) == PLAN_SHA and git('show', PLAN_COMMIT + ':' + PLAN) == plan_raw, 'IMMUTABLE_PLAN_HASH')
    blocks = re.findall(rb'```json\s*(.*?)\s*```', plan_raw, re.S)
    need(len(blocks) == 1, 'PLAN_MACHINE_GRANT')
    grant = loads(blocks[0])
    existing = set(grant['existingAppPaths']) | set(grant['otherExistingPaths'])
    new = set(grant['newAppTestHelperPaths']) | set(grant['otherNewPaths'])
    helper['paths'](existing | new)
    need(len(grant['newAppTestHelperPaths']) <= 12 and not existing & new, 'PLAN_MACHINE_GRANT')
    validate_contract(loads(public_blob(CONTRACT, 65536)))
    need(sha(public_blob(CHECKER, 1024 * 1024)) == checker_sha, 'CURRENT_CHECKER_TEMPLATE_PIN')
    history = []
    for line in text('rev-list', '--reverse', '--parents', BASE + '..' + runtime).splitlines():
        pieces = line.split()
        need(len(pieces) == 2, 'BODY_MERGE_FORBIDDEN')
        history.append({'commit': pieces[0], 'parent': pieces[1], 'tree': text('rev-parse', pieces[0] + '^{tree}'),
                        'changes': helper['diff'](root, pieces[1], pieces[0])})
    validate_history(history, existing, new)
    need(history[-1]['commit'] == runtime, 'RUNTIME_HISTORY_ENDPOINT')
    cumulative = helper['diff'](root, BASE, runtime)
    need(set(cumulative) <= existing | new and
         all((change[0] == ':100644') == (path in existing) for path, change in cumulative.items()),
         'CUMULATIVE_PATH_MODES')
    # Disable configured clean/smudge/process filters before metadata status.
    code, names, _ = helper['bounded']([shutil.which('git'), 'config', '--null', '--name-only', '--get-regexp',
        r'^filter\..*\.(clean|smudge|process)$'], root, environment, 65536, 30)
    need(code in (0, 1), 'SOURCE_FILTER_CONFIG')
    overrides = []
    for key in names.decode('utf-8').split('\0'):
        if key:
            need(re.fullmatch(r'filter\.[A-Za-z0-9_. -]{1,128}\.(clean|smudge|process)', key), 'SOURCE_FILTER_CONFIG')
            overrides += [key + '=', key.rsplit('.', 1)[0] + '.required=false']
    need(not git('status', '--porcelain=v1', '--untracked-files=all', '-z', overrides=overrides), 'SOURCE_DIRTY')
    index = {}
    index_raw = git('ls-files', '--stage', '-z')
    for record in index_raw.split(b'\0'):
        if record:
            meta, path = record.split(b'\t', 1)
            mode, oid, stage = meta.decode('ascii').split()
            need(stage == '0', 'SOURCE_INDEX_STAGE')
            index[path.decode('utf-8')] = (mode, oid)
    need(index == source_tree and all(record.startswith(b'H ') for record in
         git('ls-files', '-v', '-z').split(b'\0') if record), 'SOURCE_INDEX_OR_HIDDEN_FLAGS')
    identity = {'base': BASE, 'baseTree': BASE_TREE, 'runtimeHead': runtime,
                'runtimeTree': text('rev-parse', runtime + '^{tree}'), 'sourceHead': source,
                'sourceTree': text('rev-parse', source + '^{tree}')}
    proof = {'qualification': 'ACTUAL_COMMITTED_GIT_METADATA_ONLY_NOT_PROTECTED_WORKING_BYTE_OR_PHASE4_EXECUTION_PROOF',
             'source': identity, 'scopeCommit': PLAN_COMMIT, 'scopePlanSHA256': PLAN_SHA,
             'contract': 'EXACT_PR30_NONADMITTING_CONTRACT', 'bodyHistory': history,
             'soleWorklistChanges': changes, 'unchangedProducerEntry': source_tree[PRODUCER],
             'sourceIndexSHA256': sha(index_raw), 'protectedWorkingBytes': 'NOT_OPENED_BY_BUILDER',
             'strictPhase4Execution': 'NOT_RUN_BY_BUILDER', 'finalTailAndClonesAndCI': 'NOT_RUN_EXTERNAL_POST_TAIL'}
    return identity, proof


def allowed_evidence(relative):
    try:
        relative.encode('ascii')
    except (AttributeError, UnicodeError):
        return False
    if relative in EXPLICIT_NESTED_EVIDENCE:
        return True
    parts = relative.split('/')
    if len(parts) == 1:
        return relative in ROOT_NAMES
    if parts[0] == 'packaging26':
        return len(parts) == 2 and parts[1] in PACKAGING_NAMES
    return (parts[0] in EVIDENCE_DIRS and len(parts) == 2 and
            Path(parts[1]).suffix.lower() in {'.json', '.log', '.md', '.txt', '.ts', '.png'})


def catalog_payload(catalog_path, helper):
    raw = safe_read(catalog_path)
    value = loads(raw)
    need(value.get('schema') == 1 and type(value.get('schema')) is int and
         value.get('acceptanceGranted') is False and value.get('release') == 'NO_GO' and
         Path(value.get('sourceRoot', '')).absolute() == RUN and type(value.get('files')) is list and
         type(value.get('count')) is int and value['count'] == len(value['files']) and
         0 < value['count'] <= MAX_FILES and not value.get('omitted'), 'CATALOG_SCHEMA_OR_ROOT')
    payload, inputs, total, sources = {}, [], 0, set()
    for entry in value['files']:
        need(type(entry) is dict and set(entry) == {'sourcePath', 'suggestedReturnPath', 'bytes', 'sha256', 'mode', 'qualification'},
             'CATALOG_ENTRY_SCHEMA')
        relative, target = entry['sourcePath'], entry['suggestedReturnPath']
        need(allowed_evidence(relative) and target == 'evidence/' + relative and
             relative not in sources and target not in payload and entry['mode'] == '100644' and
             type(entry['bytes']) is int and 0 <= entry['bytes'] <= MAX_FILE and
             type(entry['sha256']) is str and HEX64.fullmatch(entry['sha256']) and
             type(entry['qualification']) is str and entry['qualification'], 'CATALOG_ENTRY_REFUSED')
        helper['safe_path'](relative)
        helper['safe_path'](target)
        data = safe_read(RUN.joinpath(*relative.split('/')))
        need(witness(data) == {'bytes': entry['bytes'], 'sha256': entry['sha256']}, 'CATALOG_BYTES_CHANGED')
        total += len(data)
        need(total <= MAX_TOTAL, 'CATALOG_TOTAL_BOUND')
        payload[target] = data
        inputs.append((relative, witness(data)))
        sources.add(relative)
    need(total == value.get('totalBytes'), 'CATALOG_TOTAL_MISMATCH')
    helper['paths'](payload)
    payload['evidence/CATALOG_AT_SEAL.json'] = raw
    return payload, inputs, raw


def deterministic_zip(files, helper):
    helper['paths'](files)
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_STORED, allowZip64=False) as archive:
        for name, raw in sorted(files.items()):
            need(type(raw) is bytes and len(raw) <= MAX_FILE, 'PAYLOAD_FILE_BOUND')
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 29, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.internal_attr = 0
            info.extra = b''
            info.comment = b''
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, raw)
    result = stream.getvalue()
    need(len(result) <= MAX_TOTAL + 1024 * 1024, 'PAYLOAD_ZIP_BOUND')
    helper['Archive'](result).exact(files)
    return result


def checkpoint_files(source, metadata_proof, payload, report, verifier, helper):
    need(set(source) == {'base', 'baseTree', 'runtimeHead', 'runtimeTree', 'sourceHead', 'sourceTree'} and
         all(type(value) is str and HEX40.fullmatch(value) for value in source.values()), 'CP_SOURCE_SCHEMA')
    need(b'SUBMITTED_REVIEW_REQUIRED' in report and b'NO_GO' in report and len(report) <= 512 * 1024,
         'REPORT_QUALIFICATION_OR_BOUND')
    proof = {**metadata_proof, 'checkpointStage': 'BEFORE_SOLE_EVIDENCE_TAIL',
             'finalCI': 'NOT_RUN_EXTERNAL_POST_TAIL', 'twoFinalIndependentClones': 'NOT_RUN_EXTERNAL_POST_TAIL',
             'finalPublicOuterArchiveAndDownloadProof': 'NOT_RUN_EXTERNAL_POST_TAIL',
             'acceptanceGranted': False, 'release': 'NO_GO'}
    need('evidence/SEAL_PROVENANCE.json' not in payload, 'RESERVED_PAYLOAD_PATH')
    payload = {**payload, 'evidence/SEAL_PROVENANCE.json': encode(proof)}
    prefix = ('# Campaign26 checkpoint snapshot before the sole evidence tail\n\n'
        'SUBMITTED_REVIEW_REQUIRED / NO_GO. AcceptanceGranted=false.\n\n'
        'This immutable checkpoint narrative is a pre-tail source/evidence snapshot. '
        'Final-head CI, two final independent clones, final source/artifact 0/1/0, and '
        'public outer ZIP/download proof are NOT_RUN here and must be collected externally after the tail. '
        'The later outer FINAL_REPORT may fill those observations without amending this checkpoint.\n\n'
        'Pinned PR29: ' + BASE + '\nRuntime head/tree: ' + source['runtimeHead'] + ' / ' + source['runtimeTree'] +
        '\nSole worklist child/tree: ' + source['sourceHead'] + ' / ' + source['sourceTree'] +
        '\n\nThe actual candidate tail/head is deliberately outside this hash domain. '
        'The narrative below retains its original stage qualifications.\n\n---\n\n').encode('utf-8')
    readme = ('# Campaign26 source-only checkpoint\n\nSUBMITTED_REVIEW_REQUIRED / NO_GO. '
        'No acceptance is granted. Exactly five files form this checkpoint.\n\n'
        'This checkpoint binds authentic PR29, the committed finite substantive body, and its sole '
        'two-worklist child. It does not contain a future candidate-tail identity or its own manifest hash. '
        'Obtain manifest/verifier SHA256 from the external seal receipt.\n\n'
        'The builder checked committed Git metadata, the immutable first-child plan, PR30 contract, '
        'finite linear history, index/flags and unchanged producer identity. It did not open protected '
        'working bytes or execute Phase4/source checks. Artifact-only VERIFIED is integrity, not full '
        'source, app, Security, database, native, professional or release acceptance.\n\n'
        'Final CI, independent final clones and actual final source/artifact corruption/restoration '
        'proof belong externally after the sole tail. Preserve all recorded failures/skips/qualifications.\n\n'
        'G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; '
        'M2 NOT_AUTHORIZED. All other qualified release closures remain closed. USD0. NO MERGES.\n').encode()
    result = {'README.md': readme, 'REPORT.md': prefix + report,
              'payload.zip': deterministic_zip(payload, helper), 'verify26.py': verifier}
    manifest = {'schema': 1, 'authority': AUTHORITY, 'status': 'SUBMITTED_REVIEW_REQUIRED',
                'acceptanceGranted': False, 'release': 'NO_GO', 'inputManifestSHA256': INPUT_SHA,
                'source': source, 'files': {name: witness(raw) for name, raw in sorted(result.items())},
                'payload': {'schema': 1, 'qualification': 'SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',
                            'files': {name: witness(raw) for name, raw in sorted(payload.items())}}}
    result['manifest.json'] = encode(manifest)
    need(set(result) == FILES, 'EXACT_FIVE_CHECKPOINT_FILES')
    return result


def external_output(path):
    path = Path(os.path.abspath(path))
    need(not os.path.lexists(path) and path.parent.is_dir(), 'OUTPUT_MUST_BE_NEW')
    for parent in (path.parent, *path.parent.parents):
        info = parent.lstat()
        need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
             not getattr(info, 'st_file_attributes', 0) & 1024 and parent.name != '.git' and
             not os.path.lexists(parent / '.git'), 'OUTPUT_INSIDE_SOURCE_OR_LINK')
    return path


def write_exclusive(path, raw):
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0)
    descriptor = os.open(path, flags, 0o644)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(descriptor, raw[offset:])
            need(count > 0, 'OUTPUT_WRITE_FAILED')
            offset += count
    finally:
        os.close(descriptor)
    need(safe_read(path, MAX_TOTAL + 1024 * 1024) == raw, 'OUTPUT_WRITE_MISMATCH')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--git-root', type=Path, required=True)
    parser.add_argument('--runtime-head', required=True)
    parser.add_argument('--source-head', required=True, help='The sole worklist child, currently checked out; no tail yet.')
    parser.add_argument('--output', type=Path, required=True, help='A NEW staging directory outside every checkout.')
    parser.add_argument('--catalog', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--verifier', type=Path, default=HERE / 'verify26.py')
    parser.add_argument('--derivation', type=Path, default=HERE / 'DERIVATION.json')
    parser.add_argument('--controls', type=Path, default=HERE / 'CONTROLS.json')
    parser.add_argument('--expected-verifier-sha256', required=True,
                        help='External, root-reviewed identity of the CURRENT regenerated checkpoint template.')
    parser.add_argument('--receipt', type=Path, help='NEW sibling receipt; default OUTPUT.seal-receipt.json. Never inside checkpoint.')
    args = parser.parse_args()
    try:
        need(sys.flags.optimize == 0, 'OPTIMIZED_PYTHON_REFUSED')
        verifier, helper, derivation, controls = template(args)
        root = Path(os.path.abspath(args.git_root))
        output = external_output(args.output)
        receipt_path = external_output(args.receipt or output.with_name(output.name + '.seal-receipt.json'))
        need(receipt_path.parent != output and receipt_path != output, 'RECEIPT_OUTSIDE_CHECKPOINT')
        source, proof = metadata(root, args.runtime_head, args.source_head, helper, derivation['sourceCheckerSHA256'])
        payload, inputs, catalog_raw = catalog_payload(args.catalog, helper)
        report = safe_read(args.report, 512 * 1024)
        proof.update(builderSHA256=sha(safe_read(Path(__file__), 1024 * 1024)),
                     inputCatalogSHA256=sha(catalog_raw), narrativeInputSHA256=sha(report),
                     verifierTemplate=witness(verifier), currentCheckerSHA256=derivation['sourceCheckerSHA256'])
        files = checkpoint_files(source, proof, payload, report, verifier, helper)
        output.mkdir(mode=0o755)
        for name, raw in sorted(files.items()):
            write_exclusive(output / name, raw)
        anchor = sha(files['manifest.json'])
        command = [sys.executable, '-I', '-B', str(output / 'verify26.py'), '--root', str(output),
                   '--expected-manifest-sha256', anchor, '--expected-verifier-sha256', sha(verifier)]
        environment = {key: value for key, value in os.environ.items()
                       if not key.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_')) and
                       key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
        code, stdout, stderr = helper['bounded'](command, output.parent, environment, 1024 * 1024, 120)
        result = loads(stdout)
        need(code == 0 and not stderr and result.get('status') == 'VERIFIED' and
             result.get('filesIncludingManifest') == 5 and result.get('acceptanceGranted') is False and
             result.get('release') == 'NO_GO' and result.get('sourceChecks') == {'state': 'NOT_RUN'} and
             'git' not in result, 'ARTIFACT_ONLY_STANDALONE_VERIFIER_FAILED')
        for relative, expected in inputs:
            need(witness(safe_read(RUN.joinpath(*relative.split('/')))) == expected, 'CATALOG_CHANGED_DURING_SEAL')
        need(safe_read(args.catalog) == catalog_raw and safe_read(args.report, 512 * 1024) == report and
             safe_read(args.verifier, 1024 * 1024) == verifier, 'SEAL_INPUT_CHANGED')
        final_source, final_proof = metadata(root, args.runtime_head, args.source_head, helper, derivation['sourceCheckerSHA256'])
        need(final_source == source and final_proof == {key: value for key, value in proof.items() if key not in
             {'builderSHA256', 'inputCatalogSHA256', 'narrativeInputSHA256', 'verifierTemplate', 'currentCheckerSHA256'}},
             'SOURCE_CHANGED_DURING_SEAL')
        helper['Directory'](output).exact(FILES)
        receipt = {'status': 'STAGED_ARTIFACT_VERIFIED_ROOT_COPY_REVIEW_REQUIRED',
                   'qualification': 'ACTUAL_GIT_METADATA_AND_ARTIFACT_INTEGRITY_ONLY_NOT_FULL_SOURCE_ACCEPTANCE',
                   'source': source, 'output': str(output), 'manifestSHA256': anchor,
                   'verifierSHA256': sha(verifier), 'files': {name: witness(raw) for name, raw in sorted(files.items())},
                   'payloadFiles': len(loads(files['manifest.json'])['payload']['files']),
                   'artifactVerification': result, 'standaloneVerifierExit': code,
                   'standaloneVerifierStdoutSHA256': sha(stdout), 'sourceWrites': False,
                   'fullFinalGitAndPhase4': 'NOT_RUN_EXTERNAL_POST_TAIL',
                   'twoFinalClonesAndCIAndPublicOuterProof': 'NOT_RUN_EXTERNAL_POST_TAIL',
                   'acceptanceGranted': False, 'release': 'NO_GO'}
        write_exclusive(receipt_path, encode(receipt))
        print(json.dumps(receipt, sort_keys=True))
        return 0
    except BaseException as error:
        code = (error.args[0] if len(error.args) == 1 and type(error.args[0]) is str and
                re.fullmatch(r'[A-Z][A-Z0-9_]{1,100}', error.args[0]) else 'SEAL_INCOMPLETE')
        print(json.dumps({'status': 'SEAL_REFUSED', 'error': code, 'sourceWrites': False,
                          'acceptanceGranted': False, 'release': 'NO_GO'}, sort_keys=True))
        return 1


if __name__ == '__main__':
    sys.exit(main())
