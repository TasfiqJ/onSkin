import { createElement, StrictMode, useLayoutEffect } from 'react';
import { act, create, type ReactTestRenderer } from 'react-test-renderer';
import { QueryClientProvider, type QueryClient } from '@tanstack/react-query';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

import {
  close26,
  flush26,
  grant26,
  ports26,
  profile26,
  reset26,
  shelf26,
} from '@/features/shelf/firstValue26TestPorts';
import ManualAddScreen from '@/app/shelf/manual';
import OpenedDateScreen from '@/app/shelf/opened';
import ShelfLayout from '@/app/shelf/_layout';
import { Button } from '@/components/ui/Button';
import { IntakeProvider, useIntake } from '@/features/shelf/IntakeContext';
import { addProduct, loadShelf } from '@/features/shelf/store';
import {
  activeHealthProcessingLeaseSnapshot,
  clearActiveHealthProcessingEpoch,
  setActiveHealthProcessingEpoch,
} from '@/lib/consent/healthProcessingEpoch';
import {
  beginAccountGenerationBoundary,
  endAccountGenerationBoundary,
  runAccountGenerationOperation,
} from '@/lib/auth/accountGeneration';

// Only native navigator/rendering/storage boundaries are controlled. Actual
// layout, UI, Query, encrypted stores/mutations, consent and intake execute.
let screen: ReactTestRenderer | undefined;
let client: QueryClient;
let intake: ReturnType<typeof useIntake>;
function Probe() {
  const value = useIntake();
  useLayoutEffect(() => {
    intake = value;
  }, [value]);
  return null;
}
function tree() {
  return createElement(
    StrictMode,
    null,
    createElement(
      QueryClientProvider,
      { client },
      createElement(IntakeProvider, null, createElement(Probe), createElement(ShelfLayout)),
    ),
  );
}
async function mount() {
  ports26.routeChild = createElement(ManualAddScreen);
  await act(async () => {
    screen = create(tree());
  });
  await flush26();
}
function input(label: string) {
  return screen!.root
    .findAllByType('TextInput' as never)
    .find((node) => node.props.accessibilityLabel === label);
}
function action(label: string) {
  return screen!.root
    .findAllByType('Pressable' as never)
    .find((node) => node.props.accessibilityLabel === label)!;
}
function button(label: string) {
  return screen!.root.findAllByType(Button).find((node) => node.props.label === label)!;
}
function picker() {
  return screen!.root
    .findAllByType('View' as never)
    .find((node) => node.props.accessibilityLabel === 'Choose product category');
}
async function typeDraft() {
  await act(async () => {
    input('Product name')!.props.onChangeText('Unsaved synthetic cleanser');
    input('Brand')!.props.onChangeText('Synthetic brand');
    input('Barcode, optional')!.props.onChangeText('96385074');
    input('Ingredients')!.props.onChangeText('Aqua, Glycerin');
  });
  await act(async () => {
    action('Eight-digit barcode type, EAN-8').props.onPress();
    action('Category').props.onPress();
  });
  await act(async () => action('Category, Cleanser').props.onPress());
}
function callbacks() {
  return {
    next: button('Continue').props.onPress as () => void,
    cancel: action('Cancel').props.onPress as () => void,
    name: input('Product name')!.props.onChangeText as (text: string) => void,
    brand: input('Brand')!.props.onChangeText as (text: string) => void,
    barcode: input('Barcode, optional')!.props.onChangeText as (text: string) => void,
    ingredients: input('Ingredients')!.props.onChangeText as (text: string) => void,
    format: action('Eight-digit barcode type, UPC-E').props.onPress as () => void,
    category: action('Category, Cleanser').props.onPress as () => void,
  };
}
function invokeAll(captured: ReturnType<typeof callbacks>) {
  captured.name('STALE NAME');
  captured.brand('STALE BRAND');
  captured.barcode('00425261');
  captured.ingredients('STALE INCI');
  captured.format();
  captured.category();
  captured.next();
  captured.cancel();
}
function expectDraft() {
  expect(input('Product name')?.props.value).toBe('Unsaved synthetic cleanser');
  expect(input('Brand')?.props.value).toBe('Synthetic brand');
  expect(input('Barcode, optional')?.props.value).toBe('96385074');
  expect(input('Ingredients')?.props.value).toBe('Aqua, Glycerin');
  expect(action('Eight-digit barcode type, EAN-8').props.accessibilityState.checked).toBe(true);
  expect(action('Category, Cleanser')).toBeDefined();
}
async function refetch() {
  await act(async () => {
    await client.refetchQueries({ queryKey: ['shelf'], exact: true });
  });
  await flush26();
}
beforeEach(async () => {
  client = await reset26();
  await profile26();
  await shelf26();
});
afterEach(async () => {
  vi.restoreAllMocks();
  ports26.release?.();
  await act(async () => {
    screen?.unmount();
  });
  screen = undefined;
  await close26(client);
});


it('does not let an accepted manual session cross same-owner regrant and save via actual Opened route', async () => {
  await mount();
  await typeDraft();
  await act(async () => button('Continue').props.onPress());
  const staleToken = intake.sessionId!;
  expect(staleToken).toBeTruthy();
  await act(async () => grant26());
  await refetch();
  ports26.params = { intakeId: staleToken };
  ports26.routeName = 'opened';
  ports26.routeChild = createElement(OpenedDateScreen);
  await act(async () => screen!.update(tree()));
  await flush26();
  await act(async () => action('Not opened yet').props.onPress());
  await act(async () => button('Add to shelf').props.onPress());
  await flush26();
  const products = await loadShelf();
  expect(products.filter((product) => product.name === 'Unsaved synthetic cleanser')).toHaveLength(0);
  expect(products).toHaveLength(3);
});
