import { randomUUID } from 'node:crypto';
import { createElement, StrictMode } from 'react';
import { QueryClientProvider, type QueryClient } from '@tanstack/react-query';
import { act, create, type ReactTestInstance, type ReactTestRenderer } from 'react-test-renderer';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

import { close26, flush26, grant26, ports26, profile26, reset26 } from '@/features/shelf/firstValue26TestPorts';
import ProductDetailScreen from '@/app/shelf/[id]';
import ShelfLayout from '@/app/shelf/_layout';
import { IntakeProvider } from '@/features/shelf/IntakeContext';
import { addProduct, loadShelf } from '@/features/shelf/store';
import type { useShelf } from '@/features/shelf/useShelf';
import { clearActiveHealthProcessingEpoch } from '@/lib/consent/healthProcessingEpoch';

// Actual route, layout, Query, authority, encrypted Shelf and mutations. Only
// native rendering/storage/router/absent external transport are platform ports.
let client: QueryClient;
let screen: ReactTestRenderer | undefined;
let id: string;
type Source = NonNullable<ReturnType<typeof useShelf>['data']>;
const productName = 'Synthetic long product name '.repeat(4).trim();
function button(label: string): ReactTestInstance {
  const found = screen!.root
    .findAllByType('Pressable' as never)
    .find(
      (node) =>
        node.props.accessibilityLabel === label ||
        node.findAllByType('Text' as never).some((text) => text.props.children === label),
    );
  expect(found, label).toBeDefined();
  return found!;
}
async function press(label: string) {
  await act(async () => {
    button(label).props.onPress();
  });
  await flush26();
}
async function mount() {
  ports26.params = { id };
  ports26.routeName = '[id]';
  ports26.routeChild = createElement(ProductDetailScreen);
  await act(async () => {
    screen = create(
      createElement(
        StrictMode,
        null,
        createElement(
          QueryClientProvider,
          { client },
          createElement(IntakeProvider, null, createElement(ShelfLayout)),
        ),
      ),
    );
  });
  for (let n = 0; n < 10 && !client.getQueryData(['shelf']); n++) await flush26();
  await flush26();
}
async function open() {
  await press('More options');
}
async function rows() {
  return loadShelf();
}
beforeEach(async () => {
  client = await reset26();
  await profile26();
  const product = await addProduct({
    operationId: randomUUID(),
    name: productName,
    category: 'moisturiser',
    addedVia: 'manual',
  });
  id = product.id;
});
afterEach(async () => {
  if (screen)
    await act(async () => {
      screen!.unmount();
    });
  screen = undefined;
  vi.restoreAllMocks();
  await close26(client);
});


it('permanently retires a confirmation across actual same-Query reset and exact cached-source/count restoration', async () => {
  await mount(); await open();
  const remove = button('Remove completely').props.onPress;
  const before = ports26.bytes.get('layerwell.shelf.v1');
  const query = client.getQueryCache().find({ queryKey: ['shelf'], exact: true })!;
  const data = client.getQueryData<Source>(['shelf'])!;
  const admittedCounts = { data: query.state.dataUpdateCount, error: query.state.errorUpdateCount };
  await act(async () => {
    query.reset();
    client.setQueryData(['shelf'], data);
    expect(client.getQueryCache().find({ queryKey: ['shelf'], exact: true })).toBe(query);
    expect(client.getQueryData(['shelf'])).toBe(data);
    expect({ data: query.state.dataUpdateCount, error: query.state.errorUpdateCount }).toEqual(admittedCounts);
    remove();
  });
  await flush26(); await flush26();
  expect(await rows()).toHaveLength(1);
  expect(ports26.bytes.get('layerwell.shelf.v1')).toBe(before);
  expect(ports26.back).not.toHaveBeenCalled();
});

it('allows a fresh explicit confirmation after the retired confirmation is closed and actual source is restored', async () => {
  await mount(); await open();
  const oldRemove = button('Remove completely').props.onPress;
  const query = client.getQueryCache().find({ queryKey: ['shelf'], exact: true })!;
  const data = client.getQueryData<Source>(['shelf'])!;
  await act(async () => { query.reset(); client.setQueryData(['shelf'], data); });
  await flush26();
  if (screen!.root.findAllByType('Modal' as never).length) await press('Close product options');
  await open();
  await act(async () => oldRemove()); await flush26();
  expect(await rows()).toHaveLength(1);
  await press('Remove completely'); await flush26();
  expect(await rows()).toEqual([]); expect(ports26.back).toHaveBeenCalledTimes(1);
});
