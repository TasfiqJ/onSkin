import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { registerHooks } from 'node:module';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const target = pathToFileURL(resolve('scripts/e2e/onboarding-first-session.mjs')).href;
const fragment = readFileSync(new URL('./ui-fragment.txt', import.meta.url), 'utf8');
registerHooks({ load(url, context, next) {
  const result = next(url, context);
  if (url !== target) return result;
  const original = String(result.source);
  let source = original;
  const replace = (anchor, value) => {
    if (source.split(anchor).length !== 2) throw new Error('Driver anchor mismatch: ' + anchor);
    source = source.replace(anchor, value);
  };
  replace('`npm --workspace apps/mobile run web -- --port ${appPort} --host localhost`,', '`npm --workspace apps/mobile run web -- --port ${appPort} --host localhost --max-workers 1`,');
  replace('async function screenshot(client, name) {', `async function screenshot(client, name) {
    const w=viewport.width;
    const keep=w===375 ? /^(04-consent|14-reveal|20-shelf|M102-03|J06-|FAILURE)/ : /^(J06-(01|03|06|08|09|10|11)|FAILURE|CO-03|CO-13)/;
    if (!keep.test(name)) return;`);
  replace('async function clickByText(client, label, { exact = true, timeoutMs = 30_000 } = {}) {', `async function clickByText(client, label, { exact = true, timeoutMs = 30_000 } = {}) {
    writeFileSync(path.join(evidenceDir,'actions.jsonl'),JSON.stringify({action:'tap',label})+'\\n',{flag:'a'});`);
  if(process.env.ONBOARDING_E2E_CLIENT_ENTRY) replace("      welcome = await captureStep(client, '01-welcome');\n      await client.send('Page.navigate', { url: `${baseUrl}/today` });", "      welcome = await captureStep(client, '01-welcome');\n      await evaluate(client, `history.pushState({}, '', '/today'); dispatchEvent(new PopStateEvent('popstate'));`);");
  if (!process.argv.includes('--cross-owner')) replace('    let ageReverificationBefore = null;', fragment + '\n    let ageReverificationBefore = null;');
  process.once('exit', () => {
    writeFileSync(resolve(process.env.ONBOARDING_E2E_EVIDENCE_DIR,'executed-driver.mjs'),source);
    writeFileSync(resolve(process.env.ONBOARDING_E2E_EVIDENCE_DIR,'driver-binding.json'),JSON.stringify({
      originalSha256:createHash('sha256').update(original).digest('hex'),
      executedSha256:createHash('sha256').update(source).digest('hex'),
      changes:['bounded screenshots/actions','saved-only finder and actual encrypted local failure/recovery UI'],
    },null,2)+'\n');
  });
  return {...result,source};
} });
await import(target);
