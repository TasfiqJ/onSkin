from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time,os
sys.stdout.reconfigure(encoding="utf-8")
root=Path(__file__).parent
repo=Path(os.environ.get("M1X06_CHECKOUT",r"C:\Users\jasim\Desktop\WeddingCards\work\m102-retained-resilience"))
name,*cmd=sys.argv[1:]
def git(*a):return subprocess.check_output(["git",*a],cwd=repo).decode().strip()
log=root/(name+".log")
assert not log.exists()
t=time.time()
r={"cwd":str(repo),"command":cmd,"start":datetime.datetime.now(datetime.timezone.utc).isoformat(),"head":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status_before":git("status","--porcelain=v1")}
with log.open("wb") as out:
 p=subprocess.run(cmd,cwd=repo,stdout=out,stderr=subprocess.STDOUT)
r.update(exit=p.returncode,seconds=round(time.time()-t,2),status_after=git("status","--porcelain=v1"),sha256=hashlib.sha256(log.read_bytes()).hexdigest(),bytes=log.stat().st_size)
(root/(name+".json")).write_text(json.dumps(r,indent=2)+"\n",encoding="utf-8")
print(json.dumps(r,indent=2));print(log.read_text(encoding="utf-8",errors="replace")[-3500:])
sys.exit(p.returncode)
