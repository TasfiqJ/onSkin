from pathlib import Path
import subprocess,json,hashlib
repo=Path(r'C:\Users\jasim\Desktop\WeddingCards\work\m102-retained-resilience')
run=Path(__file__).parent
anchor='f78e3d4662b0a1b886544435b6bf4d8101d7cc3c'
source='92aee6b2cfe058c144698a3f935ed7f31e643747'
checkpoint='docs/brain/checkpoints/M1-02/LEAN-V1-CORE-JOURNEY-06'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
assert git('rev-parse','HEAD').decode().strip()==source
assert git('status','--porcelain=v1')==b''
paths=git('diff','--name-only',anchor,source).decode().splitlines()
assert len(paths)==13
def entry(ref,path):
 raw=git('ls-tree','-z',ref,'--',path)
 if not raw:return None
 fields=raw.rstrip(b'\0').split(b'\t',1)[0].decode().split()
 mode,kind,blob=fields
 data=git('cat-file','blob',blob)
 return dict(mode=mode,blob=blob,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
changes=[dict(path=p,before=entry(anchor,p),after=entry(source,p)) for p in paths]
exempt=paths+[checkpoint,'ONSKIN_BRAIN_HANDOFF.txt']
witnesses=[]
def walk(prefix=''):
 tree=anchor+(':'+prefix if prefix else '')
 for line in git('ls-tree','-z',tree).split(b'\0'):
  if not line:continue
  meta,name=line.split(b'\t',1);mode,kind,oid=meta.decode().split()
  path=(prefix+'/' if prefix else '')+name.decode()
  if path in exempt:continue
  if any(p.startswith(path+'/') for p in exempt):
   assert kind=='tree';walk(path)
  else:
   actual=git('ls-tree','-z',source,'--',path)
   assert actual.split(b'\t',1)[0].decode()==meta.decode(),path
   witnesses.append(dict(path=path,mode=mode,kind=kind,object=oid))
walk()
absent=['apps/mobile/ios','apps/mobile/android','apps/mobile/app.config.ts']
for p in absent:assert not git('ls-tree',source,'--',p)
commits=git('rev-list','--reverse',anchor+'..'+source).decode().splitlines()
history=[]
for c in commits:
 changed=git('diff-tree','--no-commit-id','--name-only','-r',c).decode().splitlines()
 assert set(changed)<=set(paths),(c,changed)
 history.append(dict(commit=c,tree=git('rev-parse',c+'^{tree}').decode().strip(),changed=changed))
out=dict(anchor=anchor,anchor_tree=git('rev-parse',anchor+'^{tree}').decode().strip(),source=source,source_tree=git('rev-parse',source+'^{tree}').decode().strip(),changes=changes,protected_objects=witnesses,protected_absence=absent,intermediate_commits=history,partition_note='Unchanged Git tree/blob frontier covers every preexisting repository object outside exact source deltas, the new checkpoint and the separately manifest-bound handoff. No protected source was edited.')
(run/'source-scope.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'source_paths':len(changes),'protected_partition_witnesses':len(witnesses),'protected_absences':len(absent),'commits':len(history)}))
