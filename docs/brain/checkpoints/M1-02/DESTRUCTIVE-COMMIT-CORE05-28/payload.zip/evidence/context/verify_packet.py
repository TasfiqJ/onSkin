#!/usr/bin/env python3
"""Externally anchored Campaign28 context only, never product/release acceptance."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import unicodedata

ROOT = Path(__file__).absolute().parent
AUTHORITY = 'BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01'
HEX64 = re.compile(r'[0-9a-f]{64}\Z')
MAX_FILE = 8 * 1024 * 1024
MAX_TOTAL = 24 * 1024 * 1024


def fail(reason):
    raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    value = {}
    for k, v in pairs:
        if k in value:
            fail('DUPLICATE_JSON_KEY')
        value[k] = v
    return value


def safe(name):
    if not isinstance(name, str) or len(name) < 1 or len(name) > 4096:
        fail('UNSAFE_PATH')
    if name.startswith('/') or '\\' in name or ':' in name or '\x00' in name:
        fail('UNSAFE_PATH')
    components = name.split('/')
    for part in components:
        n = unicodedata.normalize('NFKC', part)
        if not part or part in ('.', '..') or n in ('.', '..') or n != part or part.rstrip(' .') != part:
            fail('UNSAFE_PATH')
        if any(ord(c) < 32 or 127 <= ord(c) < 160 for c in part):
            fail('UNSAFE_PATH')
    return components


def observed(root):
    result = {}
    pending = [root]
    while pending:
        parent = pending.pop()
        try:
            entries = list(os.scandir(parent))
        except OSError:
            fail('UNREADABLE_DIRECTORY')
        for entry in entries:
            item = Path(entry.path)
            rel = item.relative_to(root).as_posix()
            parts = safe(rel)
            try:
                info = item.lstat()
            except OSError:
                fail('UNREADABLE_MEMBER')
            if stat.S_ISLNK(info.st_mode) or not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)):
                fail('NONREGULAR_MEMBER')
            if stat.S_ISREG(info.st_mode) and info.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX):
                fail('SPECIAL_FILE_MODE')
            kind = 'file' if stat.S_ISREG(info.st_mode) else 'directory'
            key = '/'.join(p.casefold() for p in parts)
            if key in result:
                fail('DUPLICATE_OR_CASE_ALIAS')
            result[key] = (rel, kind)
            if len(result) > 200:
                fail('MEMBER_LIMIT')
            if kind == 'directory':
                pending.append(item)
    return result


def verify(root, manifest_sha):
    if not isinstance(manifest_sha, str) or not HEX64.fullmatch(manifest_sha):
        fail('EXTERNAL_ANCHOR_INVALID')
    if root.is_symlink() or not root.is_dir():
        fail('ROOT_INVALID')
    manifest_path = root / 'manifest.json'
    if manifest_path.is_symlink() or not manifest_path.is_file():
        fail('MANIFEST_MISSING')
    manifest_bytes = manifest_path.read_bytes()
    if len(manifest_bytes) > MAX_FILE or sha(manifest_bytes) != manifest_sha:
        fail('EXTERNAL_MANIFEST_SHA256_MISMATCH')
    data = json.loads(manifest_bytes.decode('utf-8'), object_pairs_hook=unique)
    if type(data) is not dict or set(data) != {'schema', 'authority', 'qualification', 'files', 'triad'}:
        fail('MANIFEST_SCHEMA')
    if type(data['schema']) is not int or data['schema'] != 1 or data['authority'] != AUTHORITY or data['qualification'] != 'CONTEXT_ONLY_NO_ACCEPTANCE':
        fail('MANIFEST_AUTHORITY')
    files = data['files']
    if type(files) is not dict or not 8 <= len(files) <= 64 or 'verify_packet.py' not in files:
        fail('MANIFEST_FILES')
    expected = set(files) | {'manifest.json'}
    expected_tree = {}
    for name in sorted(expected):
        parts = safe(name)
        for i in range(1, len(parts) + 1):
            rel = '/'.join(parts[:i]); key = rel.casefold()
            kind = 'file' if i == len(parts) else 'directory'
            if key in expected_tree and expected_tree[key] != (rel, kind):
                fail('PARENT_ALIAS_OR_COLLISION')
            expected_tree[key] = (rel, kind)
    actual = observed(root)
    if actual != expected_tree:
        fail('EXACT_MEMBER_INVENTORY')
    total = len(manifest_bytes)
    for name, row in sorted(files.items()):
        if type(row) is not dict or set(row) != {'bytes', 'sha256'}:
            fail('FILE_RECORD')
        size, digest = row['bytes'], row['sha256']
        if type(size) is not int or not 0 <= size <= MAX_FILE or type(digest) is not str or not HEX64.fullmatch(digest):
            fail('FILE_RECORD')
        path = root / name
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size != size:
            fail('FILE_MODE_OR_SIZE')
        with path.open('rb') as f:
            raw = f.read(size + 1)
        if len(raw) != size or sha(raw) != digest:
            fail('FILE_HASH_MISMATCH')
        total += size
        if total > MAX_TOTAL:
            fail('EXPANDED_BOUND')
    triad = ('TASK_DIRECTIVE.md', 'PROMPT_TEMPLATE.md', 'EXACT_PROMPT.md')
    if data['triad'] != {'files': list(triad), 'identical': True}:
        fail('DIRECTIVE_SCHEMA')
    originals = [(root / n).read_bytes() for n in triad]
    if originals[0] != originals[1] or originals[1] != originals[2]:
        fail('DIRECTIVE_MISMATCH')
    return {'status': 'VERIFIED', 'qualification': 'CONTEXT_ONLY_NO_ACCEPTANCE',
            'authority': AUTHORITY, 'manifestSHA256': manifest_sha,
            'filesIncludingManifest': len(expected), 'triadIdentical': True,
            'acceptanceGranted': False, 'release': 'NO_GO'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-manifest-sha256', required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(verify(ROOT, args.expected_manifest_sha256), sort_keys=True))
    except Exception as exc:
        print('CONTEXT_INVALID:' + type(exc).__name__ + ':' + str(exc), file=sys.stderr)
        sys.exit(1)
