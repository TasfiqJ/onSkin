# Campaign28 finite source grant — no wildcard authorization

Permission is limited to these **named paths** and the explicit behavior scope below. Codex must choose exact subset, record in committed first-child `docs/brain/task-specs/M1X-28/SCOPE_PLAN.md`, and never expand silently. Protected original `.github/workflows/security.yml`, health consent/account authority, photo/F09, SQL/migrations, clinical/paid/native/Apple/professional and original151 fixtures are READ-ONLY.

```json
{
  "schema": 1,
  "authority": "BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01",
  "baseHead": "517b50413b136639413b783cf3e899a6bc6c19ed",
  "baseTree": "497f248472f775cef2a9922475fa9f3f62b75060",
  "existingAppPaths": [
    "apps/mobile/src/app/shelf/[id].tsx",
    "apps/mobile/src/features/shelf/mutations.ts",
    "apps/mobile/src/features/shelf/store.ts",
    "apps/mobile/src/lib/storage/privateKV.ts"
  ],
  "newAppTestHelperPaths": [
    "apps/mobile/src/features/shelf/confirmedDestructive28.test.ts",
    "apps/mobile/src/features/shelf/postDispatchCommit28.test.ts",
    "apps/mobile/src/features/shelf/destructiveCommit28TestPorts.ts",
    "apps/mobile/src/lib/storage/privateKVCommitFence28.test.ts"
  ],
  "otherExistingPaths": [
    "scripts/core05/adherence-source-contract.test.mjs",
    ".github/workflows/security-candidate22.yml",
    "scripts/release/full-app-j01/check.py",
    "docs/USER_FLOW_TREE.md",
    "docs/phase-4/generated/source-worklist.json",
    "docs/phase-4/generated/source-worklist.md",
    "ONSKIN_BRAIN_HANDOFF.txt"
  ],
  "otherNewPaths": [
    "scripts/core05/adherence-source-contract28.test.mjs",
    "scripts/release/full-app-j01/replay28.py",
    "scripts/release/full-app-j01/replay28.test.py",
    "scripts/release/full-app-j01/source_consumer28.test.py",
    "docs/brain/task-specs/M1X-28/SCOPE_PLAN.md",
    "docs/brain/task-specs/M1X-28/TASK.md",
    "docs/brain/contracts/M1X-28/source28.v1.json",
    "docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/README.md",
    "docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/REPORT.md",
    "docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/manifest.json",
    "docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/payload.zip",
    "docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/verify28.py"
  ]
}
```

The app grant is **conditional narrow opt-in API only**: no new privateKV global default, no health/consent override, no broad storage rewrite, no hidden native/prod installation. Existing core05 test file is allowed only an authentically stronger **structural assertion replacing one brittle spelling check**, with negative mutation proof; original source route/notification tests otherwise unchanged. Old Release27 runner/checker/historical sources may not be weakened. The technical public candidate workflow may add new source controls but must remain non-ready and nonzero for real Security findings/custody.

Prior full public product scope unchanged: genuine F01–F17/F19–F20, C01–C12, P01–P06, F09 private diary/manual compare, exactly independently qualified J01 Visible Pores; F18 and J02–J27 incl J05 deferred. No qualified release gate changes.
