# Campaign28 — Read first

**Authority** `BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01`. Context is for NEW Codex Ultra chat; founder has no engineering decisions. USD0, NO MERGES, G97 FAIL/NO_GO.

Before executing any packet script, safely inspect the external ZIP and hash its manifest against the **external SHA256 pasted by the Brain**. The verifier `verify_packet.py` is itself authenticated as a member. The exact command is pasted outside the archive. Require `VERIFIED` before using the directives. A read changing `st_atime`/`st_atime_ns` is not file mutation; do not require those fields to remain equal. Still enforce all other applicable identities, complete reads and SHA. On Windows compare compatible path/handle metadata, not different ctime semantics.

Read 00→06, SOURCE_ANCHORS.json, the exact Brain audit and prior return. TASK_DIRECTIVE.md / PROMPT_TEMPLATE.md / EXACT_PROMPT.md have identical bytes. The prior Campaign27 nested ZIP is authentic **artifact-only** Brain evidence and includes original report/source pack; it does NOT establish an independent Brain full-Git source execution. Use live repo and CI for source truth.

One new draft PR stacked on exact draft PR31; no merges, production, credentials or release. Primary goal: strong truthful **pre-commit destructive-operation** fence, not false rollback, plus CORE-05 assertion structural repair preserving current lifecycle. All product, Security and native gates remain closed.
