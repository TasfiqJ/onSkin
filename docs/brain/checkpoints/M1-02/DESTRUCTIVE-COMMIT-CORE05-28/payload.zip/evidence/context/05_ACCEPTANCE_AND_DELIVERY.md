# Campaign28 validation, freeze and return

- Independently authenticate source PR31 SHA/tree/branch and all applicable repository instructions. Read previous authenticated Campaign27 return from nested background and source/CI live.
- Document first-child immutable SCOPE_PLAN before code changes. Follow exact existing/new file grants. One integration writer; review workers run adversarial separate worktrees.
- R28-A: before-failure/after tests for two original pending Remove/Discard, genuine user confirmation, Query/lease/unmount timing, partial/decrypt/key/crypto/native write cases, mirror outbox, readback, A→B→A and same-owner regrant. Do not count an already committed write as cancelled. If unable to distinguish boundary, explicit PARTIAL/UNAPPLIED.
- R28-B: original current core05 spelling failure 35/1, corrected AST+mutation safeguards, ordinary reminder native-source and lifecycle tests; historical source untouched.
- All original Campaign25–27 public positives, original 151 semantic negatives, authentic Release09–27, photo layout15/focused97, forced mobile baseline6370+new tests, operator24, typecheck/lint with zero task cache, source/launch/native/privacy contracts, normal npm ci plus mandatory patches, clear-cache unsigned iOS/Android exports, canonical SQL DB/PG15/17 when available.
- Linux and Windows historical/current technical candidate CI must execute genuine checks while preserving actual Security findings, candidateReady=false and nonzero readiness, original Security unchanged and red.
- Freeze clean substantive source; run untouched Phase4 producer exactly once, sole two-file worklist child, sole five-file checkpoint + root handoff evidence tail. No source after freeze.
- Two independent complete final-head Git clones, separate objects, pass full source/checkpoint/strict Phase4, historical identity, actual protected-source and artifact 0/1/0 with exact restoration and clean status. Supplier receipts never imply independent Brain replay unless Brain itself reruns them.
- One actual public return ZIP with external ZIP/manifest/verifier SHA256, fresh-download bytes checked, minimal Git bundle requiring exact PR31 and complete final report/blocked items/CI metadata. No local-only paths; no self-approval.

G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED; J01 optical and longitudinal gates NOT_ACCEPTED; native/VoiceOver/provider/paid/professional/clinical/legal/licensing/Apple/public release CLOSED. USD0. NO MERGES.
