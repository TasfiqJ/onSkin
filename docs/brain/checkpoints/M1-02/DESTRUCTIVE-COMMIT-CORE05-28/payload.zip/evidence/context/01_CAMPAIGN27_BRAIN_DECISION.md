# Campaign27 independent Brain decision

**ACCEPTED_SCOPED_R27_01_TECHNICAL_SOURCE_ONLY / PARTIAL_BLOCKED / NO_GO.**

The independent Brain fetched the actual `onSkin_Campaign27_Postdispatch_Safety_Windows_CI_Return_2026-10-29.zip` bytes via exact Google Drive source, verified ZIP SHA256 `d44e701ef98d2c6879b21ce8d6958fa580bd4bcf51304e6c6713c279c78111bc`, exact 2,160,274 bytes, 122 safe regular members (121 manifest-listed), manifest `9c5d9cd0606763d66a62d651e0c3f4457e28608abcf7b6dfba611830508baf11`, verifier `dece962df8b3b1eeac3d32ccda1665e87d4fc0faf8f0736adc7318ac22e561ce`, and 305 nested checkpoint payload files. Original validator returned artifact-only VERIFIED; independent compressed-byte tamper/restoration returned 0/1/0. Report/receipts and source paths were read.

Live GitHub PR31 open/draft/unmerged, head `517b50413b136639413b783cf3e899a6bc6c19ed`, tree `497f248472f775cef2a9922475fa9f3f62b75060`, base PR30 exact `8c02a02afd7f2e9775dcc512c800d4f71f733234`. Five linear children, first plan, substantive source, diagnostic, only worklist child, one evidence tail. The 17 changed files are finite and contain no application or original Security edit. `replay27.py` compares compatible Windows timestamp domains while preserving same-domain mutation checks, and live final Linux/Windows jobs executed original Release24/25/26 and current27 before exiting NONZERO because genuine public Security evidence is missing. Final Quality, canonical DB/PG15/17, unsigned exports and iOS launch all succeeded; 6,370 mobile and 24 operator tests passed. Original Security remains FAILED.

**Limit:** independent full final-head Git clone/Phase4 could not be repeated in Brain environment because direct GitHub DNS is unavailable. The two clone receipts are supplier-conducted and corroborated by live GitHub commit/CI observations, not personally rerun in this environment. No source or release approval beyond scoped engineering.

**Open:** R27-02 two actual stronger postdispatch Remove/Discard tests, R27-03 brittle core05 text assertion (original 35/1), physical/native/browser measurements NOT_RUN, original Security/custody blocked. Preserve original red historical evidence.

Full details: `BACKGROUND/Campaign27_Brain_Audit.md` and immutable nested C27 return with user-supplied anchors. The Brain's acceptance is solely a safe base for continued DRAFT work.
