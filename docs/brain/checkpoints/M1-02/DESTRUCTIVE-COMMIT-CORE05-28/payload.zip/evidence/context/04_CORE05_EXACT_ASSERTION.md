# R28-B: precise source-contract correction

Original `scripts/core05/adherence-source-contract.test.mjs` line **595** asserts a literal compact one-arg string:

`acceptRoutineReminderSoftAsk(PROPOSED_ROUTINE_REMINDER_TIMES)`

Actual final PR31 `apps/mobile/src/app/onboarding/notifications.tsx` line approximately 145 calls `acceptRoutineReminderSoftAsk` with ordered arguments `PROPOSED_ROUTINE_REMINDER_TIMES`, `undefined` (default dependency lane), and `assertLifecycle` (current onboarding/owner/consent guard). These additional guard arguments were intentionally added in Campaign17. Original PR28/29 source and original test return 35 PASS/1 FAIL; subsequent body assertions were not executed after first failure. Canonical database CORE-05 structural SQL is a **different** passing suite.

New Campaign28 grant may replace only the brittle exact spelling assertion with a source-grounded typed AST assertion in the original current core05 test. Prove exact callee and all three arguments, current `assertLifecycle` definition, no replacement with a no-op, no unrelated function call; mutation regressions in a separate new test file should fail after removal/reordering/replacement of lifecycle guard. Do not edit the production onboarding route, other original tests or historical branch. Preserve the historical test's original red identity and distinguish current corrected source contract from actual delivered notification consent, native/OS reminders and Security acceptance.
