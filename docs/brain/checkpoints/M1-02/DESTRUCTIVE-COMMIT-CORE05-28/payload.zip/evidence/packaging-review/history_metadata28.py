"""Compatible metadata helpers for the NEW external historical executor only."""
import os
from pathlib import Path
import stat
import hashlib


def stable(a, b):
    fields = [n for n in dir(a) if n.startswith('st_') and n not in ('st_atime', 'st_atime_ns')]
    return fields == [n for n in dir(b) if n.startswith('st_') and n not in ('st_atime', 'st_atime_ns')] and all(
        getattr(a, n) == getattr(b, n) for n in fields)


def compatible28(path, named, opened):
    fields = ('st_dev', 'st_ino', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_uid', 'st_gid')
    if not all(getattr(named, field) == getattr(opened, field) for field in fields):
        return False
    if os.name != 'nt':
        return named.st_mode == opened.st_mode and named.st_ctime_ns == opened.st_ctime_ns
    execute = 0o111 if Path(path).suffix.lower() in ('.exe', '.com', '.bat', '.cmd') else 0
    if opened.st_mode & 0o111 or named.st_mode != opened.st_mode | execute:
        return False
    for field in ('st_file_attributes', 'st_reparse_tag'):
        if hasattr(named, field) != hasattr(opened, field):
            return False
        if hasattr(named, field) and getattr(named, field) != getattr(opened, field):
            return False
    if hasattr(named, 'st_birthtime_ns') and hasattr(opened, 'st_birthtime_ns'):
        return named.st_birthtime_ns == opened.st_birthtime_ns
    return True


def regular28(info):
    return stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0) & 1024 and not (
        info.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX)) and 0 <= info.st_size <= 128*1024*1024


def inventory(root, commit):
    assert git(root, 'rev-parse', 'HEAD').decode().strip() == commit
    assert not git(root, 'status', '--porcelain=v1', '--untracked-files=all', '-z')
    tree = git(root, 'ls-tree', '-r', '-z', commit)
    records = []
    parents = set(root.parents) | {root}
    for row in tree.split(b'\0'):
        if not row:
            continue
        meta, name = row.split(b'\t', 1)
        mode, kind, oid = meta.split()
        assert kind == b'blob' and mode in (b'100644', b'100755')
        target = root/name.decode('utf-8')
        records.append((target, mode, oid))
        parent = target.parent
        while parent not in parents:
            parents.add(parent)
            parent = parent.parent
    identities = {}
    for parent in parents:
        info = parent.lstat()
        assert stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024
        identities[parent] = (info.st_dev, info.st_ino, info.st_mode,
                              getattr(info, 'st_file_attributes', None), getattr(info, 'st_reparse_tag', None))
    count = total = 0
    for target, mode, oid in records:
        before = target.lstat()
        assert regular28(before)
        if os.name != 'nt':
            assert bool(before.st_mode & 0o111) == (mode == b'100755')
        digest = hashlib.sha1(b'blob '+str(before.st_size).encode()+b'\0')
        size = 0
        with target.open('rb') as stream:
            opened = os.fstat(stream.fileno())
            assert regular28(opened) and compatible28(target, before, opened)
            while True:
                block = stream.read(min(1024*1024, before.st_size-size+1))
                if not block:
                    break
                size += len(block)
                assert size <= before.st_size
                digest.update(block)
            finished = os.fstat(stream.fileno())
        after = target.lstat()
        assert regular28(finished) and regular28(after) and stable(opened, finished) and stable(before, after) and (
            compatible28(target, after, finished)) and size == before.st_size and digest.hexdigest() == oid.decode()
        count += 1
        total += size
    for parent, identity in identities.items():
        info = parent.lstat()
        assert stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024 and (
            info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_file_attributes', None),
            getattr(info, 'st_reparse_tag', None)) == identity
    assert not git(root, 'status', '--porcelain=v1', '--untracked-files=all', '-z')
    return {'trackedFiles': count, 'trackedBytes': total, 'treeMetadataSHA256': sha(tree),
            'tree': git(root, 'rev-parse', 'HEAD^{tree}').decode().strip()}
