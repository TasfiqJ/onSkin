"""Prepare reviewed-template Campaign28 proposals externally; never writes integration.

No worklist producer, Git mutation, checkpoint seal, ZIP assembly or upload runs here.
The bound stage requires the actual sole committed first-child plan and current
clean substantive source. Re-run into a NEW proposal directory after source changes.
"""
import argparse
import ast
import hashlib
import json
import pathlib
import re
import subprocess

HERE = pathlib.Path(__file__).resolve().parent
WORKSPACE = HERE.parent
OUTER = WORKSPACE / "Campaign28_bootstrap/prior-return-authenticated-r0bf2irz"
PAYLOAD = WORKSPACE / "Campaign28_bootstrap/prior-payload-authenticated-fpgp5ndh"
AUTHORITY = "BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01"
INPUT = "6bcd248c67f4db0eeb27691c34bcef5ebdc4bcaabf300e24f5e3dc7a3b941c81"
BASE = "517b50413b136639413b783cf3e899a6bc6c19ed"
BASE_TREE = "497f248472f775cef2a9922475fa9f3f62b75060"
PLAN = "docs/brain/task-specs/M1X-28/SCOPE_PLAN.md"
CHECKPOINT = "docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/"
CHECKPOINT_FILES = {"README.md", "REPORT.md", "manifest.json", "payload.zip", "verify28.py"}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def git(root, *arguments):
    return subprocess.check_output(["git", "--no-replace-objects", "-c", "core.hooksPath=", "-C", str(root), *arguments])


def assignment(source, values):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    seen = set()
    for node in reversed(tree.body):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in values:
                value = values[name]
                if type(value) in (set, frozenset):
                    literal = "{" + ", ".join(repr(x) for x in sorted(value)) + "}"
                    if type(value) is frozenset:
                        literal = "frozenset(" + literal + ")"
                else:
                    literal = repr(value)
                lines[node.lineno - 1:node.end_lineno] = [name + " = " + literal + "\n"]
                seen.add(name)
    need(seen == set(values), "template constant missing: " + repr(set(values) - seen))
    return "".join(lines)


def authenticate_templates():
    outer_manifest = json.loads((OUTER / "manifest.json").read_bytes())
    need(sha((OUTER / "manifest.json").read_bytes()) == "9c5d9cd0606763d66a62d651e0c3f4457e28608abcf7b6dfba611830508baf11", "prior manifest changed")
    checkpoint = json.loads((OUTER / "checkpoint/manifest.json").read_bytes())
    templates = {
        "verify_return27.py": OUTER / "verify_return27.py",
        "build_return27.py": OUTER / "evidence/final-verification/return-builder-used.py",
        "build_final_receipts27.py": OUTER / "evidence/final-verification/build_final_receipts27.py",
        "verify_postassembly_return27.py": OUTER / "evidence/final-verification/verify_postassembly_return27.py",
        "build_checkpoint27.py": PAYLOAD / "evidence/local/build_checkpoint27.py",
        "final_clone27.py": PAYLOAD / "evidence/app-evidence/final_clone27.py",
        "github_ci_reader27.py": PAYLOAD / "evidence/app-evidence/github_ci_reader27.py",
        "github_ci_reader27.test.py": PAYLOAD / "evidence/app-evidence/github_ci_reader27.test.py",
    }
    result, witnesses = {}, {}
    for name, path in templates.items():
        if OUTER in path.parents:
            record = outer_manifest["files"][path.relative_to(OUTER).as_posix()]
        else:
            record = checkpoint["payload"]["files"][path.relative_to(PAYLOAD).as_posix()]
        raw = path.read_bytes()
        need(len(raw) == record["bytes"] and sha(raw) == record["sha256"], "authenticated template changed: " + name)
        result[name] = raw.decode("utf-8")
        witnesses[name] = dict(source=str(path), **record)
    return result, witnesses


def rename28(source):
    # Only new successor labels/names are changed. PR27/PR28 ancestry constants
    # and immutable historical source objects remain at their authentic pins.
    for old, new in (
        ("Campaign27", "Campaign28"), ("campaign27", "campaign28"),
        ("FIRST-VALUE-SAFETY-CI-27", "DESTRUCTIVE-COMMIT-CORE05-28"),
        ("verify_return27", "verify_return28"), ("verify27", "verify28"),
        ("verify-return27-", "verify-return28-"),
        ("build_checkpoint27", "build_checkpoint28"), ("build_return27", "build_return28"),
        ("final_clone27", "final_clone28"), ("github_ci_reader27", "github_ci_reader28"),
        ("EXTERNAL_ANCHORS27", "EXTERNAL_ANCHORS28"),
        ("postassembly-return27", "postassembly-return28"),
        ("source_consumer27", "source_consumer28"), ("source27", "source28"),
        ("release27", "release28"), ("RELEASE27", "RELEASE28"),
        ("M1X-27", "M1X-28"), ("security27", "security28"),
        ("EXACT_PR30_DELTA_OBJECTS", "EXACT_PR31_DELTA_OBJECTS"),
        ("pr30-required", "pr31-required"),
        ("stage/m1-first-value-safety-ci27", "stage/m1-destructive-commit-core05-28"),
        ("Postdispatch_Safety_Windows_CI", "Destructive_Commit_CORE05"),
    ):
        source = source.replace(old, new)
    return source


def compatible_reader28(source):
    old = """    if hasattr(named, 'st_birthtime_ns') != hasattr(opened, 'st_birthtime_ns'): return False
    field = 'st_birthtime_ns' if hasattr(named, 'st_birthtime_ns') else 'st_ctime_ns'
    return getattr(named, field) == getattr(opened, field)"""
    new = """    # Windows pathname ctime and handle ctime may represent different clock
    # domains. Birthtime is comparable only when both APIs expose it; no ctime
    # fallback is valid. All fields remain checked within each API family.
    if hasattr(named, 'st_birthtime_ns') and hasattr(opened, 'st_birthtime_ns'):
        return named.st_birthtime_ns == opened.st_birthtime_ns
    return True"""
    need(source.count(old) == 1, "authenticated compatible-reader anchor")
    changed = source.replace(old, new, 1)
    # The full same-domain comparison must survive this narrow successor edit.
    before = next(node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name == "stable_metadata")
    after = next(node for node in ast.parse(changed).body if isinstance(node, ast.FunctionDef) and node.name == "stable_metadata")
    need(ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False), "same-domain metadata guard changed")
    return changed


def current_ci_names28(source):
    # The new workflow deliberately retains original27 hosted diagnostics.
    source = source.replace('security28-hosted-reader.jsonl', 'security27-hosted-reader.jsonl')
    source = source.replace('security28-python312-reader.jsonl', 'security27-python312-reader.jsonl')
    for node in ast.parse(source).body:
        if not (isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)):
            continue
        name = node.targets[0].id
        if name not in ('PUBLIC_FILES', 'ALLOWLIST'):
            continue
        value = ast.literal_eval(node.value.args[0] if isinstance(node.value, ast.Call) else node.value)
        value = set(value) | {'security28-reader.jsonl', 'security28-core05.tap'}
        source = assignment(source, {name: frozenset(value) if name == 'ALLOWLIST' else value})
        break
    source = source.replace("('security27-python312-reader.jsonl','python312Reader')):",
        "('security27-python312-reader.jsonl','python312Reader'),\n                               ('security28-reader.jsonl','currentReader28')):")
    return source


def final_clone_layout28(source, original):
    target = 'apps/mobile/src/lib/consent/healthDataWriteAdmission.ts'
    if original == 'final_clone27.py':
        source = assignment(source, {'PRIVATE_SOURCE': target})
        old = "        self.clone, self.artifact = self.workspace/'checkout', self.workspace/'checkpoint-copy'"
        new = """        self.artifact = self.workspace/'checkpoint-copy'
        self.short_clone_root = args.clone_parent is not None
        if self.short_clone_root:
            clone_parent = Path(args.clone_parent)
            need(clone_parent.is_absolute(), 'CLONE_PARENT_ABSOLUTE_REQUIRED')
            clone_parent = Path(os.path.abspath(clone_parent))
            for parent in (clone_parent, *clone_parent.parents):
                verifier.node(parent, True)
                need(not os.path.lexists(parent/'.git'), 'CLONE_PARENT_OUTSIDE_GIT_REQUIRED')
            suffix = self.workspace.name.removeprefix(args.label+'-')
            self.clone = clone_parent/('c28'+args.label[-1]+'-'+suffix)
            self.clone.mkdir()
            verifier.node(self.clone, True)
            need(not any(self.clone.iterdir()), 'FRESH_EMPTY_CLONE_DIRECTORY_REQUIRED')
        else:
            clone_parent = self.workspace
            self.clone = self.workspace/'checkout'"""
        need(source.count(old) == 1, 'final clone layout anchor')
        source = source.replace(old, new, 1)
        source = source.replace("            source='FRESH_FULL_REMOTE_CLONE', sourceTamperSequence=[], artifactTamperSequence=[],",
            "            source='FRESH_FULL_REMOTE_CLONE', checkoutPath=str(self.clone), cloneParent=str(clone_parent),\n            receiptWorkspacePath=str(self.workspace), artifactCopyPath=str(self.artifact), shortCloneRoot=self.short_clone_root,\n            sourceTamperSequence=[], artifactTamperSequence=[],", 1)
        source = source.replace("        private_mode, private_blob = tracked[PRIVATE_SOURCE]",
            "        need(PRIVATE_SOURCE not in v.EXISTING|v.NEW, 'TAMPER_TARGET_MUST_BE_UNGRANTED')\n        private_mode, private_blob = tracked[PRIVATE_SOURCE]", 1)
        source = source.replace("    args = parser.parse_args()", "    parser.add_argument('--clone-parent')\n    args = parser.parse_args()", 1)
    elif original == 'build_return27.py':
        old = """    need(Path(command[3])==workspace/'checkpoint-copy/verify28.py' and Path(command[5])==workspace/'checkpoint-copy' and
         Path(command[7])==workspace/'checkout','FINAL_CLONE_COMMAND_PATHS')"""
        new = """    checkout=Path(receipt.get('checkoutPath',''))
    clone_parent=Path(receipt.get('cloneParent',''))
    need(checkout.is_absolute() and clone_parent.is_absolute() and
         Path(receipt.get('receiptWorkspacePath',''))==workspace and
         Path(receipt.get('artifactCopyPath',''))==workspace/'checkpoint-copy','FINAL_CLONE_COMMAND_PATHS')
    if receipt.get('shortCloneRoot') is True:
        need(checkout.parent==clone_parent and re.fullmatch('c28'+receipt['label'][-1]+r'-[a-z0-9_]+',checkout.name) is not None,
             'FINAL_CLONE_COMMAND_PATHS')
    else:
        need(receipt.get('shortCloneRoot') is False and checkout==workspace/'checkout' and clone_parent==workspace,
             'FINAL_CLONE_COMMAND_PATHS')
    need(Path(command[3])==workspace/'checkpoint-copy/verify28.py' and Path(command[5])==workspace/'checkpoint-copy' and
         Path(command[7])==checkout,'FINAL_CLONE_COMMAND_PATHS')
    protected=receipt.get('protectedTarget')
    need(type(protected) is dict and protected.get('path')=='apps/mobile/src/lib/consent/healthDataWriteAdmission.ts' and
         protected['path'] not in v.EXISTING|v.NEW and protected.get('gitMode')=='100644' and
         type(protected.get('gitBlob')) is str and HEX40.fullmatch(protected['gitBlob']) and
         protected.get('rawBytesAndAdditionalHashesPublished') is False,'FINAL_CLONE_UNGRANTED_PROTECTED_TARGET')"""
        need(source.count(old) == 1, 'return builder clone path anchor')
        source = source.replace(old, new, 1)
    elif original == 'verify_postassembly_return27.py':
        old = "                need(root==RUN/'final-clones'/receipt_path.parent.name/'checkout','CLONE_RECEIPT_PATH_BINDING')"
        new = """                workspace=RUN/'final-clones'/receipt_path.parent.name
                checkout=Path(receipt.get('checkoutPath',''))
                need(root.is_absolute() and root==checkout and Path(receipt.get('receiptWorkspacePath',''))==workspace and
                     Path(receipt.get('artifactCopyPath',''))==workspace/'checkpoint-copy','CLONE_RECEIPT_PATH_BINDING')
                if receipt.get('shortCloneRoot') is True:
                    need(root.parent==Path(receipt.get('cloneParent','')) and re.fullmatch('c28'+label[-1]+r'-[a-z0-9_]+',root.name) is not None,
                         'CLONE_RECEIPT_PATH_BINDING')
                else:
                    need(receipt.get('shortCloneRoot') is False and root==workspace/'checkout','CLONE_RECEIPT_PATH_BINDING')"""
        need(source.count(old) == 1, 'postassembly clone path anchor')
        source = source.replace(old, new, 1)
    return source


def write_new(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        need(stream.write(raw) == len(raw), "incomplete proposal write")
    need(path.read_bytes() == raw, "proposal readback mismatch")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--plan-commit", required=True)
    parser.add_argument("--proposal-name", required=True)
    parser.add_argument("--inherited-functions", type=int, default=202)
    args = parser.parse_args()
    need(re.fullmatch("[a-z0-9-]{1,80}", args.proposal_name) is not None, "proposal name")
    root = pathlib.Path(args.source_root).resolve()
    need(root.is_dir() and (root / ".git").is_dir(), "full integration checkout required")
    need(re.fullmatch("[0-9a-f]{40}", args.plan_commit) is not None, "actual plan commit required")
    need(git(root, "rev-parse", BASE + "^{tree}").decode().strip() == BASE_TREE, "pinned base tree")
    need(git(root, "rev-list", "--parents", "-n", "1", args.plan_commit).decode().split() == [args.plan_commit, BASE], "sole first child plan required")
    need(git(root, "diff-tree", "--no-commit-id", "--name-only", "-r", args.plan_commit).decode().splitlines() == [PLAN], "first child must only add plan")
    plan = git(root, "show", args.plan_commit + ":" + PLAN)
    need((root / PLAN).read_bytes() == plan, "immutable plan current mismatch")
    need(not git(root, "status", "--porcelain=v1", "--untracked-files=all"), "clean substantive source required")
    fences = re.findall(rb"```json\r?\n(.*?)\r?\n```", plan, re.S)
    need(len(fences) == 1, "one finite JSON grant required in committed plan")
    chosen = json.loads(fences[0])
    need(type(chosen) is list and len(chosen) == len(set(chosen)) == 27 and all(type(path) is str for path in chosen), "immutable exact27 flat chosen grant")
    base_paths = {row.decode("utf-8") for row in git(root, "ls-tree", "-r", "--name-only", "-z", BASE).split(b"\0") if row}
    existing = set(chosen) & base_paths
    new = set(chosen) - base_paths
    finite_text = (WORKSPACE / "campaign28-context-i5sa4mb8/02_FINITE_IMPLEMENTATION_GRANT.md").read_text()
    finite = json.loads(re.search(r"```json\n(.*?)\n```", finite_text, re.S)[1])
    allowed_existing = set(finite["existingAppPaths"] + finite["otherExistingPaths"])
    allowed_new = set(finite["newAppTestHelperPaths"] + finite["otherNewPaths"])
    need(existing <= allowed_existing and new <= allowed_new and not existing & new, "plan exceeds authenticated named grant")
    need({CHECKPOINT + name for name in CHECKPOINT_FILES} <= new and PLAN in new, "checkpoint/plan grant missing")
    checker = (root / "scripts/release/full-app-j01/check.py").read_bytes()
    consumer = (root / "scripts/release/full-app-j01/source_consumer28.test.py").read_bytes()
    need(args.inherited_functions == 202, "authenticated inherited function count")
    templates, template_witnesses = authenticate_templates()
    output = HERE / args.proposal_name
    output.mkdir()
    for name, source in templates.items():
        write_new(output / "authenticated-templates" / name, source.encode())
    source = compatible_reader28(rename28(templates["verify_return27.py"]))
    source = assignment(source, {
        "AUTHORITY": AUTHORITY, "INPUT": INPUT, "BASE": BASE, "BASE_TREE": BASE_TREE,
        "CHECKPOINT": CHECKPOINT, "CHECKPOINT_FILES": CHECKPOINT_FILES,
        "EXISTING": existing, "NEW": new, "PLAN": PLAN, "PLAN_COMMIT": args.plan_commit,
        "PLAN_SHA256": sha(plan), "CHECKER_SHA256": sha(checker),
    })
    source = source.replace("CHECKER_SHA256 = " + repr(sha(checker)) + "\n", "CHECKER_SHA256 = " + repr(sha(checker)) + "\nCONSUMER_SHA256 = " + repr(sha(consumer)) + "\n")
    old = "    node_cli = shutil.which('node'); need(node_cli is not None, 'NODE_UNAVAILABLE')"
    new_code = """    consumer = 'scripts/release/full-app-j01/source_consumer28.test.py'
    need(sha(read_regular(root/consumer)) == CONSUMER_SHA256, 'RELEASE28_CONSUMER_IDENTITY')
    code, consumer_output, _ = bounded([sys.executable, '-I', '-B', consumer], root,
        environment, 8*1024*1024, 900)
    need(code == 0, 'RELEASE28_CONSUMER_FAILED')
    consumer_lines = consumer_output.splitlines()
    need(consumer_lines, 'RELEASE28_CONSUMER_SEMANTICS')
    consumer_result = loads(consumer_lines[-1])
    need(type(consumer_result) is dict and consumer_result.get('status') == 'PASS' and
         consumer_result.get('qualification') == 'SYNTHETIC_GIT_AND_SCHEMA_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_APP_PRIVACY_PROOF' and
         type(consumer_result.get('positiveControls')) is int and consumer_result['positiveControls'] > 0 and
         type(consumer_result.get('refusals')) is int and consumer_result['refusals'] > 0 and
         consumer_result.get('inheritedFunctions') == 202 and
         consumer_result.get('acceptanceGranted') is False and consumer_result.get('release') == 'NO_GO',
         'RELEASE28_CONSUMER_SEMANTICS')
    node_cli = shutil.which('node'); need(node_cli is not None, 'NODE_UNAVAILABLE')"""
    need(source.count(old) == 1, "source-check insertion anchor")
    source = source.replace(old, new_code, 1)
    source = source.replace("return dict(release28='PASS_FINITE_SOURCE_GOVERNANCE_ONLY', phase4=", "return dict(release28='PASS_FINITE_SOURCE_GOVERNANCE_ONLY', consumer28='PASS_AUTHENTICATED_CURRENT_CONSUMER', phase4=", 1)
    source = source.replace("PUBLIC_CODES = PUBLIC_CODES | frozenset(", "PUBLIC_CODES = PUBLIC_CODES | frozenset(['RELEASE28_CONSUMER_IDENTITY', 'RELEASE28_CONSUMER_FAILED', 'RELEASE28_CONSUMER_SEMANTICS'])\nPUBLIC_CODES = PUBLIC_CODES | frozenset(", 1)
    compile(source, "verify_return28.py", "exec")
    write_new(output / "packaging/verify_return28.py", source.encode())
    checkpoint_source = source.replace("MODE = 'return'", "MODE = 'checkpoint'", 1)
    write_new(output / "packaging/verify28.py", checkpoint_source.encode())
    # Actual proposals preserve audited template logic; all future identities
    # are read from separately supplied binding files after their events occur.
    for original, destination in (
        ("build_return27.py", "build_return28.py"),
        ("final_clone27.py", "app-evidence/final_clone28.py"),
        ("verify_postassembly_return27.py", "final-verification/verify_postassembly_return28.py"),
        ("github_ci_reader27.py", "app-evidence/github_ci_reader28.py"),
        ("github_ci_reader27.test.py", "app-evidence/github_ci_reader28.test.py"),
    ):
        proposal = current_ci_names28(rename28(templates[original]))
        proposal = final_clone_layout28(proposal, original)
        if original == "build_return27.py":
            proposal = proposal.replace("root=run/'source'", "root=Path(json.loads((run/'proposal-binding.json').read_text())['sourceRoot'])", 1)
            proposal = proposal.replace("b'# Campaign28 final engineering return", "b'# Campaign28 final engineering return", 1)
        if original == "github_ci_reader27.py":
            proposal = assignment(proposal, {"VERIFIER_SHA256": sha(checkpoint_source.encode())})
        compile(proposal, destination, "exec")
        write_new(output / destination, proposal.encode())
    for template, destination in (("build_checkpoint28.template.py", "build_checkpoint28.py"),
                                  ("bind_final28.template.py", "bind_final28.py")):
        proposal = (HERE / template).read_bytes()
        compile(proposal, destination, "exec")
        write_new(output / destination, proposal)
    config = dict(schema=1, qualification="BOUND_EXTERNAL_PROPOSALS_NOT_EXECUTED_OR_ACCEPTED", sourceRoot=str(root),
        sourceHead=git(root, "rev-parse", "HEAD").decode().strip(), sourceTree=git(root, "rev-parse", "HEAD^{tree}").decode().strip(),
        authority=AUTHORITY, base=BASE, baseTree=BASE_TREE, inputManifestSHA256=INPUT,
        planCommit=args.plan_commit, planSHA256=sha(plan), checkerSHA256=sha(checker), consumerSHA256=sha(consumer),
        checkpointVerifierSHA256=sha(checkpoint_source.encode()), returnVerifierSHA256=sha(source.encode()),
        templates=template_witnesses, noPhase4ProducerExecuted=True, noIntegrationWrites=True, noFinalArtifactCreated=True,
        acceptanceGranted=False, release="NO_GO")
    write_new(output / "proposal-binding.json", encoded(config))
    print(json.dumps(dict(proposalDirectory=str(output), checkpointVerifierSHA256=config["checkpointVerifierSHA256"], returnVerifierSHA256=config["returnVerifierSHA256"], qualification=config["qualification"])))


if __name__ == "__main__":
    main()
