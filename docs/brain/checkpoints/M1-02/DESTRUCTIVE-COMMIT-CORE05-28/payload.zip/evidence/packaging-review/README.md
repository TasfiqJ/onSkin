# Campaign28 external packaging proposals

All code here is a proposal until bound to actual clean substantive source, reviewed and executed. No integration source or Git commits are changed by these helpers. No Phase4 producer is executed here. No final ZIP, CI result, final clone or upload is presently claimed.

The authenticated adopted Campaign27 verifier and return builder are the base. `prepare28.py` authenticates every template against the prior anchored manifests before copying it. The proposed verifier retains strict local/central/CRC/bounds/path/metadata checks, Windows-compatible reader identity, full independent Git objects/history/finite scope/raw tracked blob reconciliation, immutable first plan, sole two-worklist child and sole five-checkpoint-plus-handoff tail. It additionally authenticates and executes the current source28 consumer, alongside checker and unchanged strict Phase4. It pins actual checker and consumer hashes from clean substantive source; regenerate into a NEW proposal directory after any substantive change and review the diff before freeze.

New successor metadata handling compares Windows birthtime only when both APIs expose it and never falls back to cross-domain ctime; same-domain every st_* field except only atime/atime_ns remains checked. Actual focused controls and qualification are in METADATA_REVIEW.md. This correction never rewrites the authenticated original27 files.

The immutable plan's fenced flat JSON list contains 27 paths and controls over its earlier prose count typo. The generator derives existing/new classification from exact PR31 tree. Exact first child is `fda89d90e92b05a094018f07d83077659f847509`; observed plan SHA256 is `cd862ff6be2e30332f9e3810d565fd55402353fe016e4e684acaaa30b3a6222d`.

## Bound preparation after substantive source is committed clean

```powershell
python -B campaign28-packaging\prepare28.py --source-root C:\Users\jasim\Documents\ChatGPT\MasterV2Code\campaign28-source --plan-commit fda89d90e92b05a094018f07d83077659f847509 --proposal-name reviewed-substantive-01
```

This refuses absent consumer28, dirty source, wrong first-child/base identity, changed plan, or expanded finite paths. It creates a new external proposal directory containing exact original templates, new checkpoint/return verifiers, reviewed-template return builder, fresh-clone 0/1/0 harness, public CI reader/tests, postassembly helper, binding inputs and five-file checkpoint builder. It compiles proposal syntax but does not count that as behavioral verification.

Actual output locations under that proposal directory:

- `packaging/verify28.py` and `packaging/verify_return28.py`: root must inspect and independently challenge before freezing. Checkpoint verifier enters integration only as one of the five final checkpoint files.
- `app-evidence/final_clone28.py`: after final tail is pushed, invoke twice with actual final head/tree/checkpoint anchors and authenticated npm prefix. Each creates a fresh complete remote clone with separate objects and actual source/artifact 0/1/0, exact restoration, normal fresh-cache npm installation and mandatory hooks. No prior receipts become current proof.
- `app-evidence/github_ci_reader28.py` and its test: public artifact framing/readout only; update proposed security28 filenames if actual workflow uses additional names. Existing original Security logs remain unopened.
- `final-verification/verify_postassembly_return28.py`: full outer-return verification against both completed clones, then artifact verification of separately freshly downloaded bytes. Its supplied-download mode explicitly does not perform network download.

## Checkpoint after root's sole Phase4 producer/freeze

Root alone runs the unchanged producer exactly once and commits only its two generated worklists. This packaging layer never invokes generation. Write an explicit external input JSON with exactly `schema:1`, `qualification:"EXPLICIT_REVIEWED_CHECKPOINT_INPUTS_NOT_ACCEPTANCE"`, and `files:{"evidence/portable-name": "absolute input path"}`. This avoids scanning arbitrary workspace/private finding directories. Review every included path and bytes, preserve historical failures and all qualifications; pass the actual SHA256 of that reviewed JSON.

```powershell
python -B build_checkpoint28.py --inputs <actual-explicit-inputs.json> --report <complete-current-report.md> --reviewed-inputs-sha256 <actual-sha256> --review-only
python -B build_checkpoint28.py --inputs <same-inputs.json> --report <same-report.md> --reviewed-inputs-sha256 <same-sha256>
```

`--review-only` reads and prints actual inventory. Build requires the actual source HEAD to be exactly the sole two-worklist child of the bound substantive head, unchanged producer/checker/consumer/plan, full raw tracked bytes and clean status. It creates an external `packaging/checkpoint` with exactly README.md, REPORT.md, manifest.json, payload.zip, verify28.py. The manifest includes prefreeze/runtime and frozen source identities only. Final tail/head/CI/clones are deliberately external. Root then applies those five files plus root handoff in the sole evidence tail. No later source edits.

## Final evidence and one return

After final tail push, execute both fresh-clone harnesses and collect actual candidate/Quality/launch public API metadata, public artifact bytes and qualified observations under `ci-final` and `final-verification`. The root records actual TAIL_RECEIPT.json with status `COMMITTED_SOLE_SIX_PATH_EVIDENCE_TAIL`. Final CI is observed externally with no second evidence commit.

Once both actual clone receipts and Linux actual artifact API/export exist, `bind_final28.py` accepts their actual names and expected head/tree and writes the final-receipts helper with those observed constants. It authenticates the prior helper template and refuses incomplete clones, wrong head/tree, non-0/1/0 sequences or absent matching Linux API bytes. No final identities are invented or prefilled. `python -B bind_final28.py --help` gives arguments.

The inherited receipt helper stages remain: `check-inputs`, `write-receipts`, `prepare-inventory`, and `accept-inventory --reviewed-inventory-sha256 <actual reviewed digest>`. The adopted builder binds complete final logs, inventories, both clones and actual CI. New `build_return28.py` then assembles exactly one ZIP with complete FINAL_REPORT, history/mode/blob/byte witnesses, authenticated checkpoint, final observations, external return verifier and a minimal bundle requiring exact PR31. It refuses incomplete report markers and existing output/bundle. It independently verifies actual bundle/Git transition before the sole ZIP write; later outer-return source execution and fresh-download receipts remain outside the immutable ZIP to avoid circular hashes.

The draft PR number, current HEAD/tree, source28 count, full test outcomes, CI platform conclusions, browser/native limitations and blocked gates must come from actual observations in the final report. All results retain acceptanceGranted=false, SUBMITTED_REVIEW_REQUIRED / NO_GO. Engineering supplier receipts never imply Brain replay or qualified-gate acceptance.

## Available Drive flow, no upload performed

Connector metadata exposes `google_drive_upload_file(file_uri=<absolute local ZIP path>, file_name=<actual ZIP name>, mime_type="application/zip", parent_folder_id=<verified optional folder ID>)`. After a real upload, read back Drive metadata including id/name/mimeType/size/checksums/web links, and fetch the stored non-native ZIP with `download_raw_file=true, include_base64=false`; rehash materialized complete download bytes against external ZIP length/SHA256 and run the authenticated artifact verifier. Do not claim freshness from reading a local supplied file alone.

The connected `google_drive_share_file` supports a specific user or Workspace domain, not public-anyone access. It cannot itself prove a public unauthenticated download. If the actual upload is private, either a verified inherited public folder, a supported public-sharing UI, or another authorized hosting channel must establish public access. Do not substitute a private link or claim public delivery without an actual fresh download. No credentials were read; no upload/share action occurred during proposal preparation. The Google Drive skill was read for this tool-routing assessment; actual file work should use the connected plugin first.
