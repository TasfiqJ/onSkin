"""External synthetic rejection controls, no product source writes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import zlib

ROOT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('public_ci_reader27', ROOT/'github_ci_reader28.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
results = []


def archive(entries, flags=8, mode=0o100644):
    local, central = bytearray(), bytearray()
    for name, data in entries:
        rawname = name.encode('utf-8')
        compressor = zlib.compressobj(wbits=-15)
        packed = compressor.compress(data)+compressor.flush()
        crc, size, csize = zlib.crc32(data), len(data), len(packed)
        offset = len(local)
        triple = (0, 0, 0) if flags & 8 else (crc, csize, size)
        local += struct.pack('<4s5H3I2H', b'PK\x03\x04', 20, flags, 8, 0, 33, *triple, len(rawname), 0)
        local += rawname+packed
        if flags & 8:
            local += struct.pack('<4sIII', b'PK\x07\x08', crc, csize, size)
        central += struct.pack('<4s6H3I5H2I', b'PK\x01\x02', 3*256+20, 20, flags, 8, 0, 33,
                               crc, csize, size, len(rawname), 0, 0, 0, 0, mode*65536+32, offset)+rawname
    return bytes(local+central+struct.pack('<4s4H2IH', b'PK\x05\x06', 0, 0, len(entries), len(entries), len(central), len(local), 0))


def check(label, raw, expected=None, platform='linux'):
    try:
        obj = reader.PublicArchive(raw, platform)
        for name in obj.members:
            obj.read(name)
        observed = 'PASS'
    except reader.Refusal as error:
        observed = str(error)
    results.append({'label': label, 'expected': expected or 'PASS', 'observed': observed,
                    'pass': observed == (expected or 'PASS')})


def altered(raw, at, fmt, value):
    data = bytearray(raw)
    struct.pack_into(fmt, data, at, value)
    return bytes(data)


normal = archive([('security22-public.json', b'{"status":"synthetic"}')])
descriptor = normal.index(b'PK\x07\x08')
central = normal.index(b'PK\x01\x02')
check('SIGNED_DESCRIPTOR_VALID', normal)
windows_normal = archive([('security22-public.json', b'{}')], mode=0o100666)
check('WINDOWS_EXACT_666_VALID', windows_normal, platform='windows')
check('LINUX_REJECTS_WINDOWS_666', windows_normal, 'ZIP_NONREGULAR_OR_UNSUPPORTED')
check('WINDOWS_REJECTS_LINUX_644', normal, 'ZIP_NONREGULAR_OR_UNSUPPORTED', platform='windows')
check('LINUX_REJECTS_OTHER_REGULAR_600', archive([('a', b'{}')], mode=0o100600), 'ZIP_NONREGULAR_OR_UNSUPPORTED')
check('WINDOWS_REJECTS_OTHER_REGULAR_600', archive([('a', b'{}')], mode=0o100600), 'ZIP_NONREGULAR_OR_UNSUPPORTED', platform='windows')
check('PROFILE_REQUIRED_ENUM', normal, 'PLATFORM_PROFILE_SCHEMA', platform='other')
check('NO_DESCRIPTOR_VALID', archive([('security22-public.json', b'{}')], flags=0))
check('UTF8_SIGNED_DESCRIPTOR_VALID', archive([('security22-public.json', b'{}')], flags=2056))
check('DESCRIPTOR_SIGNATURE', altered(normal, descriptor, '<I', 0), 'ZIP_DESCRIPTOR_SIGNATURE')
check('DESCRIPTOR_CRC', altered(normal, descriptor+4, '<I', 1), 'ZIP_DESCRIPTOR_IDENTITY')
check('DESCRIPTOR_COMPRESSED_SIZE', altered(normal, descriptor+8, '<I', 1), 'ZIP_DESCRIPTOR_IDENTITY')
check('DESCRIPTOR_UNCOMPRESSED_SIZE', altered(normal, descriptor+12, '<I', 1), 'ZIP_DESCRIPTOR_IDENTITY')
for field, at in [('CRC', 14), ('COMPRESSED', 18), ('UNCOMPRESSED', 22)]:
    check('NONZERO_DESCRIPTOR_LOCAL_'+field, altered(normal, at, '<I', 1), 'ZIP_DESCRIPTOR_LOCAL_FIELDS')
check('TIMESTAMP_DISAGREEMENT', altered(normal, 10, '<H', 1), 'ZIP_LOCAL_IDENTITY')
check('FLAGS_DISAGREEMENT', altered(normal, 6, '<H', 0), 'ZIP_LOCAL_IDENTITY')
check('LOCAL_NAME_DISAGREEMENT', altered(normal, 30, '<B', ord('x')), 'ZIP_LOCAL_NAME')
check('LOCAL_EXTRA_UNSUPPORTED', altered(normal, 28, '<H', 1), 'ZIP_LOCAL_IDENTITY')
check('TRAILING_BYTES', normal+b'x', 'ZIP_DIRECTORY_BOUND')
check('CENTRAL_NONZERO_DISK', altered(normal, central+34, '<H', 1), 'ZIP64_OR_MULTIDISK_UNSUPPORTED')
check('CENTRAL_UNSUPPORTED_METHOD', altered(normal, central+10, '<H', 99), 'ZIP_NONREGULAR_OR_UNSUPPORTED')
check('ENCRYPTION_FLAG', archive([('security22-public.json', b'{}')], flags=9), 'ZIP_NONREGULAR_OR_UNSUPPORTED')
check('SYMLINK_MODE', archive([('security22-public.json', b'x')], mode=0o120777), 'ZIP_NONREGULAR_OR_UNSUPPORTED')
check('EXECUTABLE_MODE', archive([('security22-public.json', b'x')], mode=0o100755), 'ZIP_NONREGULAR_OR_UNSUPPORTED')
for label, name in [('TRAVERSAL', '../x'), ('ABSOLUTE', '/x'), ('DRIVE', 'C:x'), ('BACKSLASH', 'a\\x'),
                    ('DEVICE', 'nul.txt'), ('TRAILING_DOT', 'a.'), ('DIRECTORY', 'a/')]:
    check(label, archive([(name, b'x')]), 'UNSAFE_PATH')
for label, entries, expected in [
    ('DUPLICATE', [('a', b'1'), ('a', b'2')], 'ZIP_DUPLICATE_MEMBER'),
    ('CASEFOLD_ALIAS', [('A/x', b'1'), ('a/y', b'2')], 'PATH_ALIAS_OR_COLLISION'),
    ('NFKC_ALIAS', [('Ａ/x', b'1'), ('A/y', b'2')], 'PATH_ALIAS_OR_COLLISION'),
    ('PARENT_FILE_ALIAS', [('a', b'1'), ('a/b', b'2')], 'PATH_ALIAS_OR_COLLISION'),
    ('PARENT_FILE_ALIAS_REVERSED', [('a/b', b'1'), ('a', b'2')], 'PATH_ALIAS_OR_COLLISION')]:
    check(label, archive(entries, flags=2056), expected)
# CRC disagreement remains refused even if local descriptor agrees with the lie.
badcrc = altered(altered(normal, central+16, '<I', 1), descriptor+4, '<I', 1)
check('PAYLOAD_CRC', badcrc, 'ZIP_READ_INVALID')
badpayload = bytearray(normal)
badpayload[30+len('security22-public.json')] = 0
check('DEFLATE_INVALID', bytes(badpayload), 'ZIP_READ_INVALID')
check('EXPANSION_BOUND', archive([('a', b'a'*(2*1024*1024))]), 'ZIP_EXPANSION_BOUND')

fixture = Path(tempfile.mkdtemp(prefix='ci-reader-controls-', dir=ROOT))
source = fixture/'input.zip'
raw = archive([('security22-public.json', b'{"fixture":true}'),
               ('security27-hosted-reader.jsonl', b'{"fixture":true}\n'),
               ('original-security.log', b'EXCLUDED_SYNTHETIC_TEXT')])
source.write_bytes(raw)
target, receipt = reader.inspect_and_extract(source, hashlib.sha256(raw).hexdigest(), fixture, 'linux')
results.append({'label': 'EXACT_PUBLIC_ALLOWLIST_AND_METADATA', 'pass':
                {p.name for p in target.iterdir()} == {'security22-public.json', 'security27-hosted-reader.jsonl', 'ci-artifact-metadata.json'}
                and receipt['excludedMemberCount'] == 1 and receipt['archive']['members'] == 3})
before = {p.name for p in fixture.iterdir()}
try:
    reader.inspect_and_extract(source, '0'*64, fixture, 'linux')
    refused = False
except reader.Refusal as error:
    refused = str(error) == 'ARCHIVE_EXTERNAL_SHA256'
results.append({'label': 'WRONG_ANCHOR_NO_EXTRACTION', 'pass': refused and {p.name for p in fixture.iterdir()} == before})
report = {'helperSha256': hashlib.sha256((ROOT/'github_ci_reader28.py').read_bytes()).hexdigest(),
          'dependencySha256': reader.VERIFIER_SHA256, 'controls': results,
          'passed': sum(item['pass'] for item in results), 'total': len(results),
          'sourceAcceptance': False, 'decision': 'NO_GO'}
(ROOT/'github_ci_reader28-controls.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'passed': report['passed'], 'total': report['total'],
                  'failed': [item for item in results if not item['pass']]}))
raise SystemExit(0 if all(item['pass'] for item in results) else 1)
