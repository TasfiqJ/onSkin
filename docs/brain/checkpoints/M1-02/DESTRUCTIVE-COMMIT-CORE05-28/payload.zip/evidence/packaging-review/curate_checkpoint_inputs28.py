"""Explicit portable evidence map, never source writes or Phase4 execution.

Draft mode emits a review object that the checkpoint builder cannot accept.
Final mode refuses until all sixteen actual original historical runs exist.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re

WORKSPACE = Path(__file__).resolve().parent.parent
BOOT = WORKSPACE/'Campaign28_bootstrap'
APP = WORKSPACE/'campaign28-review-app'
GOV = WORKSPACE/'campaign28-review-governance'
PACK = WORKSPACE/'campaign28-packaging'
PROPOSAL = PACK/'reviewed-substantive-03'
HISTORY = WORKSPACE/'campaign28-history/substantive-78f3198c-recovered'
REPORT = WORKSPACE/'campaign28-report'
FILES = {}
WITNESSES = {}
OMISSIONS = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def add(path, name, reason, empty_complete=False):
    path = path.resolve(strict=True)
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    if not raw:
        assert empty_complete and name.endswith('.stderr.log'), ('empty/incomplete input', name)
    if path.suffix == '.json':
        json.loads(raw)
    assert name.startswith('evidence/') and name not in FILES and not any(part in ('', '.', '..') for part in name.split('/'))
    FILES[name] = str(path)
    WITNESSES[name] = dict(bytes=len(raw),sha256=sha(raw),reason=reason,source=str(path),
                           completeEmptyStderr=not raw and empty_complete)


def named(directory, names, area, reason):
    for name in names:
        add(directory/name,'evidence/'+area+'/'+name,reason,empty_complete=name.endswith('.stderr.log'))


def public_core05_baseline():
    path = GOV/'core05-baseline-original.tap'
    raw = path.read_bytes()
    text = raw.decode('utf8')
    identity = json.loads((GOV/'core05-baseline-identity.json').read_bytes())
    summary = [line for line in text.splitlines() if re.match(r'^# (tests|pass|fail|skipped|cancelled|suites) ',line)]
    assert '# tests 36' in summary and '# pass 35' in summary and '# fail 1' in summary and '# skipped 0' in summary
    assert identity['head']=='517b50413b136639413b783cf3e899a6bc6c19ed'
    value = dict(schema=1,qualification='LABELLED_PUBLIC_DERIVATIVE_ORIGINAL_RAW_ASSERTION_LOG_RETAINED_PRIVATELY',
        head=identity['head'],tree=identity['tree'],exit=1,tests=36,passed=35,failed=1,skipped=0,
        failingTest='notification opt-in is exact-time, authorization-aware, local-only, and cap-safe',
        diagnosis='Original one-argument spelling assertion rejects unchanged actual three-argument proposed-times, undefined-dependencies, assertLifecycle call.',
        rawOriginalLogBytes=len(raw),rawOriginalLogSHA256=sha(raw),
        rawOriginalRouteDumpPublished=False,newUnchangedRouteHashPublished=False,
        historicalPR28PR29Original35Pass1Fail='PRESERVED_IN_AUTHENTICATED_NESTED_PRIOR_RETURN',
        acceptanceGranted=False,release='NO_GO')
    target = PACK/'CORE05_ORIGINAL_FAILING_EVIDENCE_PUBLIC28.json'
    body=(json.dumps(value,indent=2)+'\n').encode()
    if target.exists():
        assert target.read_bytes()==body
    else:
        target.write_bytes(body)
    return target


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--draft',action='store_true')
    parser.add_argument('--include-freeze',action='store_true')
    args=parser.parse_args()
    context=WORKSPACE/'campaign28-context-i5sa4mb8'
    manifest=json.loads((context/'manifest.json').read_bytes())
    assert sha((context/'manifest.json').read_bytes())=='6bcd248c67f4db0eeb27691c34bcef5ebdc4bcaabf300e24f5e3dc7a3b941c81'
    for name in sorted(set(manifest['files'])|{'manifest.json'}):
        path=context/name
        if name!='manifest.json':
            record=manifest['files'][name]
            assert len(path.read_bytes())==record['bytes'] and sha(path.read_bytes())==record['sha256']
        add(path,'evidence/context/'+name,'Exact authenticated16-file context including safely authenticated nested prior return')
    named(BOOT,[
        'intake.py','intake_receipt.json','independent_archive_audit.py','independent_archive_audit.json','verification.json',
        'audit_prior_return.py','prior_return_audit.json','prior_return_artifact_verifier_receipt.json',
        'prior_return_artifact_verifier.stdout.log','prior_return_artifact_verifier.stderr.log','PRIOR_RETURN_REVIEW.md',
        'context-verifier28-persisted-repeat.log','context-verifier28-persisted-repeat.receipt.json',
        'baseline-fresh-receipt.json','baseline-fresh-results.json','baseline-fresh.config.mjs',
        'baseline-fresh.stdout.log','baseline-fresh.stderr.log','after-original-results.json','after-original.log',
        'focused28-results.json','focused28.log','browser28-availability.json','docker28-availability.json',
        'governance-integration28.json','source28-before-commit.log','source28-before-commit.receipt.json',
        'run_command28.py','run_contracts28.py','run_baseline28.py' if (BOOT/'run_baseline28.py').exists() else 'check_tools28.py',
        'index_local_validation28.py','LOCAL_VALIDATION28.json','freeze_worklists28.py',
    ],'local','Actual bootstrap, original failures, observed root command receipts and qualifications')
    local=json.loads((BOOT/'LOCAL_VALIDATION28.json').read_bytes())
    for row in local['records']:
        for key in ('log','receipt'):
            name=row[key]
            assert Path(name).name==name
            target='evidence/local/'+name
            if target not in FILES:
                add(BOOT/name,target,'Exact referenced actual local validation record; failed/cached/NOT_RUN qualifications retained')
    add(public_core05_baseline(),'evidence/core05/ORIGINAL35_1_PUBLIC28.json','Original35/1 preserved without raw unchanged notification-route dump')
    named(APP,[
        'baseline-receipt.json','baseline-results.json','baseline.config.mjs','baseline.stdout.log','baseline.stderr.log',
        'historical-pending-retirement.test.ts','discard-pending-retirement.test.ts','historical-commit-boundary.test.ts',
        'proposed-baseline-receipt.json','proposed-baseline-results.json','proposed-baseline.stdout.log','proposed-baseline.stderr.log',
        'proposed-after-results.json','proposed-after.stdout.log','proposed-after.stderr.log',
        'proposed-corrected-results.json','proposed-corrected.stdout.log','proposed-corrected.stderr.log',
        'proposed-health-results.json','proposed-health.stdout.log','proposed-health.stderr.log',
        'restart-complete-results.json','restart-complete.stdout.log','restart-complete.stderr.log',
        'final-original-regression-results.json','final-original-regression.stdout.log','final-original-regression.stderr.log',
        'original-regression-results.json','original-regression.stdout.log','original-regression.stderr.log','original-regression.config.mjs',
        'final-byte-matched-results.json','final-byte-matched.stdout.log','final-byte-matched.stderr.log',
        'independent-app-review.json','independent-app-review106.json','INDEPENDENT_APP_REVIEW.md','TECHNICAL_REPORT_ANNEX_DRAFT.md',
        'reviewed-production.diff','run_baseline.py','stage_proposed_tests.py','write_review.py',
    ],'app-review','Real mounted encrypted-store/Query controls with explicit platform-port and reused-install limits; intermediate failures retained')
    named(GOV,[
        'build_governance28.py','REVIEW.md','proposal-review-receipt.json',
        'source_consumer28.provisional.log','source_consumer28.test.py.provisional.log',
        'source_consumer28.test.py.robust.log','source_consumer28-metadata.log','source_consumer28-metadata-final.log',
        'replay28.test.py.provisional.log','replay28.test.py.robust.log','core05-proposal-controls.txt',
    ],'governance-review','Actual new source consumer29/216/202 and reader controls; prior provisional/interrupted results labelled')
    named(PACK,[
        'prepare28.py','prepare_history28.py','history_metadata28.py','test_metadata28.py',
        'build_checkpoint28.template.py','bind_final28.template.py','README.md','METADATA_REVIEW.md',
        'BOUND_SUBSTANTIVE_REVIEW_RECEIPT.json','CI_MEMORY_CONTROLS_RECEIPT.json',
        'existing-standalone-toolchain.stdout.json','existing-standalone-toolchain.stderr.log',
        'FRESH_PRIOR_DRIVE_NETWORK_MEMORY_RECEIPT.json','curate_checkpoint_inputs28.py',
    ],'packaging-review','Actual bounded proposal checks; no final-tail/source/readiness acceptance claimed')
    for directory in ('metadata-bound-substantive-01','metadata-bound-python312-03'):
        add(PACK/directory/'metadata-controls-receipt.json','evidence/packaging-review/'+directory+'/metadata-controls-receipt.json',
            'Actual bound verifier12positive/47refusal controls, qualified reader unit proof only')
    named(PROPOSAL,['proposal-binding.json','SHORT_CLONE_LAYOUT_CONTROLS.json','build_checkpoint28.py','build_return28.py','bind_final28.py'],
          'packaging-review/proposal03','Exact external helper proposal identities; future final events not preclaimed')
    for name in ('final_clone28.py','github_ci_reader28.py','github_ci_reader28.test.py'):
        add(PROPOSAL/'app-evidence'/name,'evidence/packaging-review/proposal03/app-evidence/'+name,'Actual reviewed helper source')
    add(PROPOSAL/'final-verification/verify_postassembly_return28.py','evidence/packaging-review/proposal03/verify_postassembly_return28.py','Actual reviewed postassembly helper')
    add(PACK/'reviewed-substantive-02/app-evidence/github_ci_reader28-controls.json','evidence/packaging-review/CI_READER43_ACTUAL_CONTROLS.json','Actual43/43 complete extraction and wrong-anchor controls after capacity recovery; helper bytes identical to proposal03')
    for name in ('early-small-recovered-receipt.json','late-small-recovered-receipt.json'):
        add(WORKSPACE/'campaign28-history/compression28'/name,'evidence/resource-recovery/'+name,'Aggregate lossless compression proof; no per-file protected hash catalogue')
    add(WORKSPACE/'campaign28-history/substantive-78f3198c/FAILED_ATTEMPT.json','evidence/history/FAILED_ENOSPC_ATTEMPT.json','Original ENOSPC attempt before any consumer launched; never relabelled pass')
    named(WORKSPACE/'campaign28-history/history-review',['execute_original_history28.py','PREPARATION.json'],'history','Actual unchanged-original execution harness and recovery qualifications')
    observer=APP/'ci-observer28'
    named(observer,[
        'CI_OBSERVER_PLAN.md','PREFREEZE_CI_REPORT.md','observer28-preparation-receipt.json','reader28-provenance.json',
        'inspect_receipts28.py','observe_metadata28.js','download_artifact28.py','github_ci_reader28.py','github_ci_reader28.test.py','github_ci_reader28-controls.json',
        'prefreeze-pr32-raw.json','prefreeze-test-merge-identity.json','prefreeze-metadata-initial.json','prefreeze-observation-correction.json',
        'prefreeze-candidate-run-complete.json','prefreeze-candidate-jobs-complete.json','prefreeze-candidate-artifacts-complete.json',
        'prefreeze-quality-run-report-seal-snapshot.json','prefreeze-quality-jobs-report-seal-snapshot.json',
        'prefreeze-ios-launch-run-cached-1.json','prefreeze-ios-launch-jobs-cached-1.json',
        'prefreeze-original-security-run-cached-2.json','prefreeze-original-security-jobs-cached-2.json',
        'prefreeze-linux-log-inspection.json','prefreeze-windows-log-inspection.json',
        'prefreeze-linux-receipts-inspection.json','prefreeze-windows-receipts-inspection.json',
        'prefreeze-linux-public.log','prefreeze-windows-public.log','prefreeze-canonical-db-public.log',
        'prefreeze-postgres15-public.log','prefreeze-postgres17-public.log','prefreeze-ios-launch-public.log','prefreeze-quality-public.log',
    ],'ci-prefreeze','Actual current Linux/Windows/public/DB mechanics; original Security metadata only, no original Security logs')
    for directory in ('public-ci-verified-b1jmh523','public-ci-verified-wtcn0dws'):
        folder=observer/directory
        metadata=json.loads((folder/'ci-artifact-metadata.json').read_bytes())
        add(folder/'ci-artifact-metadata.json','evidence/ci-prefreeze/'+directory+'/ci-artifact-metadata.json','Actual authenticated current public artifact framing and exported-byte metadata')
        assert 'security28-current-source.json' in {row['name'] for row in metadata['exported']}
        for row in metadata['exported']:
            raw=(folder/row['name']).read_bytes()
            assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
            add(folder/row['name'],'evidence/ci-prefreeze/'+directory+'/'+row['name'],'Exact current allowlisted public evidence; native/scanner/admission limits retained')
    named(REPORT,[
        'build_prefreeze_index.py','PREFREEZE_SOURCE_DELTA.json','PREFREEZE_SOURCE_PROOF_INDEX.json',
        'PRESEAL_PR31_LIVE.json','PRESEAL_PR32_LIVE.json','PRESEAL_REPORT_DRAFT.md','RESOURCE_RECOVERY_SUMMARY.json',
    ],'report','Root-reviewed actual prefreeze source/PR/report/index snapshots; final-tail events remain unproved')
    missing=[]
    for release in ['08-original151']+[str(i).zfill(2) for i in range(9,24)]:
        receipt=HISTORY/('release'+release+'.receipt.json')
        if not receipt.exists():
            missing.append(release)
            continue
        row=json.loads(receipt.read_bytes())
        assert row['exit']==0 and row['timeout'] is False and row['cleanAfter'] is True and row['before']==row['after']
        for suffix in ('receipt.json','stdout.log','stderr.log'):
            name='release'+release+'.'+suffix
            add(HISTORY/name,'evidence/history/'+name,'Actual original consumer/checker identity, complete raw before/after equality, original internal fixture qualifications',empty_complete=suffix=='stderr.log')
    if not missing:
        named(HISTORY,['SUMMARY.json','current-toolchain.json','early-provenance.json','late-provenance.json'],'history','Complete actual original151/09–23 supplier receipts; no current source/native acceptance')
    if args.include_freeze:
        freeze=json.loads((BOOT/'WORKLIST_FREEZE_RECEIPT.json').read_bytes())
        assert freeze.get('producerInvocations')==1 and freeze.get('status')=='COMMITTED_SOLE_WORKLIST_CHILD'
        named(BOOT,['WORKLIST_FREEZE_RECEIPT.json','phase4-producer28.stdout.log','phase4-producer28.stderr.log','PREFREEZE_GATE.json'],
              'freeze','Actual sole unchanged producer invocation and sole two-worklist child',)
        named(BOOT,['prepare_freeze_gate28.py','write_checkpoint_report28.py'],
              'freeze','Exact root-authored external prefreeze/report helpers; no producer invoked by curator')
        add(REPORT/'PRESEAL_REPORT.md','evidence/report/PRESEAL_REPORT.md',
            'Root-authored report at actual sole worklist child; future final-tail/CI/clone checks explicitly NOT_RUN_AT_SEAL')
        add(GOV/'final-clone-layout-review.json','evidence/governance-review/final-clone-layout-review.json',
            'Independent read-only external final-helper review; no final clone or native pass preclaimed')
    OMISSIONS.extend([
        'Large per-file protected raw-hash catalogues, incomplete early-after.json and zero-byte compression receipts excluded; small failure/aggregate proof retained.',
        'Raw original failing CORE-05 TAP contains unchanged production-route dump and is retained privately; labelled35/1 derivative and authentic prior nested receipts included.',
        'Raw public CI ZIP downloads and temporary provider download URL material omitted; current authenticated exported-byte metadata/12-file allowlist/public logs included.',
        'Old Campaign27 preparation artifact export is not counted as current Campaign28 CI.',
        'Generated npm caches, node_modules, full checkouts, unsigned export binaries and temporary fixtures omitted; their actual logs/metadata remain included.',
        'Legitimate complete empty stderr files are included where actual receipt/log proof requires them; invalid empty/partial JSON is excluded.',
    ])
    review=dict(schema=1,status='DRAFT_HISTORY_PENDING' if missing else 'READY_FOR_ROOT_TECHNICAL_REVIEW',
        qualification='EXPLICIT_CURATED_EVIDENCE_MAP_NOT_ACCEPTANCE',historicalPending=missing,files=WITNESSES,
        selectedFiles=len(FILES),selectedBytes=sum(row['bytes'] for row in WITNESSES.values()),
        includedActualFreeze=args.include_freeze,omittedWithReasons=OMISSIONS,producerExecutedByThisHelper=False,
        acceptanceGranted=False,release='NO_GO')
    (PACK/'CHECKPOINT_SELECTION_REVIEW28.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf8')
    if not args.draft:
        assert not missing,'HISTORICAL_EXECUTION_INCOMPLETE'
        inputs=dict(schema=1,qualification='EXPLICIT_REVIEWED_CHECKPOINT_INPUTS_NOT_ACCEPTANCE',files=FILES)
        (PACK/'CHECKPOINT_INPUTS28.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
    print(json.dumps({key:review[key] for key in ('status','historicalPending','selectedFiles','selectedBytes','includedActualFreeze','release')}))


if __name__=='__main__':main()
