"""External five-file checkpoint builder; never runs producer or writes source."""
import argparse
import importlib.util
import io
import json
from pathlib import Path
import stat
import zipfile

run = Path(__file__).resolve().parent
binding = json.loads((run / "proposal-binding.json").read_text())
root = Path(binding["sourceRoot"])
spec = importlib.util.spec_from_file_location("checkpoint28_verifier", run / "packaging/verify28.py")
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


def witness(raw):
    return dict(bytes=len(raw), sha256=v.sha(raw))


def zip_bytes(files):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, raw in sorted(files.items()):
            v.safe_path(name)
            entry = zipfile.ZipInfo(name, (2026, 10, 29, 0, 0, 0))
            entry.create_system = 3
            entry.external_attr = (stat.S_IFREG | 0o644) << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, raw)
    return stream.getvalue()


def git(*args):
    return v.git(root, *args).decode().strip()


def selection(path):
    raw = v.read_regular(path)
    # This external input deliberately separates filesystem locations from the
    # final portable inventory, which contains only archive paths and witnesses.
    value = json.loads(raw)
    v.need(type(value) is dict and set(value) == {"schema", "qualification", "files"}, "CHECKPOINT_SELECTION_SCHEMA")
    v.need(value["schema"] == 1 and type(value["schema"]) is int and
           value["qualification"] == "EXPLICIT_REVIEWED_CHECKPOINT_INPUTS_NOT_ACCEPTANCE" and
           type(value["files"]) is dict and value["files"], "CHECKPOINT_SELECTION_SCHEMA")
    v.paths(value["files"])
    evidence = {}
    for name, source in sorted(value["files"].items()):
        v.safe_path(name)
        v.need(name.startswith("evidence/") and type(source) is str and Path(source).is_absolute(), "CHECKPOINT_SELECTION_PATH")
        v.need(not any(part in (".git", "node_modules", "npm-cache", "checkout") for part in Path(name).parts), "CHECKPOINT_SELECTION_PATH")
        evidence[name] = v.read_regular(Path(source))
    return raw, evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--reviewed-inputs-sha256", required=True)
    parser.add_argument("--review-only", action="store_true")
    args = parser.parse_args()
    inputs_path = Path(args.inputs).resolve()
    raw, evidence = selection(inputs_path)
    v.need(v.sha(raw) == args.reviewed_inputs_sha256, "REVIEWED_CHECKPOINT_INPUTS_CHANGED")
    inventory = {name: witness(body) for name, body in sorted(evidence.items())}
    review = dict(schema=1, qualification="EXACT_REVIEWED_TECHNICAL_EVIDENCE_INVENTORY_NOT_ACCEPTANCE",
                  files=inventory, inputsSHA256=v.sha(raw), acceptanceGranted=False, release="NO_GO")
    if args.review_only:
        print(json.dumps(review, sort_keys=True))
        return
    v.need(not git("status", "--porcelain=v1", "--untracked-files=all"), "CHECKPOINT_SOURCE_DIRTY")
    frozen, runtime = git("rev-parse", "HEAD"), git("rev-parse", "HEAD^")
    v.need(runtime == binding["sourceHead"] and git("rev-parse", runtime + "^{tree}") == binding["sourceTree"], "CHECKPOINT_SUBSTANTIVE_IDENTITY")
    v.need(set(v.diff(root, runtime, frozen)) == v.WORKLIST, "CHECKPOINT_SOLE_WORKLIST_CHILD")
    producer = "scripts/phase4/build-source-worklist.mjs"
    v.need(v.read_regular(root / producer) == v.git(root, "show", v.BASE + ":" + producer), "PHASE4_PRODUCER_CHANGED")
    v.need(v.sha(v.read_regular(root / v.PLAN)) == v.PLAN_SHA256 and
           v.sha(v.read_regular(root / "scripts/release/full-app-j01/check.py")) == v.CHECKER_SHA256 and
           v.sha(v.read_regular(root / "scripts/release/full-app-j01/source_consumer28.test.py")) == v.CONSUMER_SHA256,
           "CHECKPOINT_BOUND_SOURCE_CHANGED")
    v.hash_worktree(root, v.git_tree(root, "HEAD"))
    source = dict(base=v.BASE, baseTree=v.BASE_TREE, runtimeHead=runtime, runtimeTree=git("rev-parse", runtime + "^{tree}"),
                  sourceHead=frozen, sourceTree=git("rev-parse", frozen + "^{tree}"))
    evidence["evidence/SEAL_PROVENANCE.json"] = encoded(dict(source=source, planCommit=v.PLAN_COMMIT,
        planSHA256=v.PLAN_SHA256, checkpointVerifierSHA256=binding["checkpointVerifierSHA256"],
        checkerSHA256=v.CHECKER_SHA256, consumerSHA256=v.CONSUMER_SHA256,
        qualification="PREFREEZE_EXECUTION_AND_WORKLIST_FREEZE_NOT_FINAL_HEAD_CI", acceptanceGranted=False, release="NO_GO"))
    evidence["evidence/CATALOG_AT_SEAL.json"] = encoded({name: witness(body) for name, body in sorted(evidence.items())})
    report = v.read_regular(Path(args.report).resolve())
    v.need(b"SUBMITTED_REVIEW_REQUIRED" in report and b"NO_GO" in report, "CHECKPOINT_REPORT_QUALIFICATION")
    report += b"\n## Source seal identities\n\n```json\n" + encoded(source) + b"```\n"
    readme = ("# Campaign28 source checkpoint\n\nSUBMITTED_REVIEW_REQUIRED / NO_GO. Exactly five files. USD0. NO MERGES.\n\n"
        "External manifest/verifier anchors authenticate this checkpoint. It binds exact PR31, immutable first-child plan, "
        "substantive source and sole two-worklist child. Final evidence-tail head/tree, final CI, independent clones and "
        "fresh-download evidence occur later and remain external to avoid circular claims. Artifact VERIFIED means integrity only; "
        "full Git/source28 checker/consumer/strict Phase4 checks require separately supplied exact final head/tree and "
        "--execute-source-checks. Read all remaining blockers and qualifications. Native durability and all qualified gates remain unproved/closed.\n").encode()
    files = {"README.md": readme, "REPORT.md": report, "payload.zip": zip_bytes(evidence),
             "verify28.py": v.read_regular(run / "packaging/verify28.py")}
    manifest = dict(schema=1, authority=v.AUTHORITY, status="SUBMITTED_REVIEW_REQUIRED", acceptanceGranted=False, release="NO_GO",
        inputManifestSHA256=v.INPUT, source=source, files={name: witness(body) for name, body in sorted(files.items())},
        payload=dict(schema=1, qualification="SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE",
                     files={name: witness(body) for name, body in sorted(evidence.items())}))
    files["manifest.json"] = encoded(manifest)
    target = run / "packaging/checkpoint"
    target.mkdir()
    for name, body in files.items():
        with (target / name).open("xb") as output:
            v.need(output.write(body) == len(body), "CHECKPOINT_PARTIAL_WRITE")
    anchor = v.sha(files["manifest.json"])
    v.checkpoint(v.Directory(target), anchor)
    seal = dict(source=source, manifestSHA256=anchor, verifierSHA256=v.sha(files["verify28.py"]), payloadFiles=len(evidence),
        files={name: witness(body) for name, body in sorted(files.items())}, status="ARTIFACT_PREFLIGHT_PASS_NOT_FULL_SOURCE",
        acceptanceGranted=False, release="NO_GO")
    with (run / "packaging/checkpoint-seal.json").open("xb") as output:
        output.write(encoded(seal))
    v.need(not git("status", "--porcelain=v1", "--untracked-files=all") and git("rev-parse", "HEAD") == frozen,
           "CHECKPOINT_SOURCE_CHANGED")
    print(json.dumps(seal, sort_keys=True))


if __name__ == "__main__":
    main()
