"""External post-assembly checks; run only after root authorizes the final ZIP.

Full mode executes one actual return-verifier command per completed final clone.
Downloaded-artifact mode checks a supplied download; it does not perform or
attest a network download. All result files stay outside the single return ZIP.
"""
import sys
if sys.flags.optimize:
    raise RuntimeError('ASSERTIONS_MUST_BE_ENABLED')

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
import types

RUN=Path(__file__).resolve().parents[1]
NPM_MODEL='c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9'


class Stop(ValueError):pass


def need(ok,code):
    if not ok:raise Stop(code)


def encode(value):return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()


def load_verifier(path,anchor):
    with path.open('rb') as stream:raw=stream.read(100001)
    need(len(raw)<=100000 and hashlib.sha256(raw).hexdigest()==anchor,'EXTERNAL_VERIFIER_ANCHOR')
    module=types.ModuleType('postassembly_anchored_return27');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    need(module.read_regular(path,100000)==raw,'VERIFIER_CHANGED')
    return module,raw


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=('full','downloaded-artifact'),required=True)
    parser.add_argument('--archive',required=True)
    parser.add_argument('--verifier',default=str(RUN/'packaging/verify_return28.py'))
    for name in ('zip-sha256','manifest-sha256','verifier-sha256','head','tree'):
        parser.add_argument('--expected-'+name,required=True)
    parser.add_argument('--expected-zip-bytes',type=int,required=True)
    parser.add_argument('--npm-prefix')
    parser.add_argument('--git-root',action='append',default=[])
    parser.add_argument('--clone-receipt',action='append',default=[])
    args=parser.parse_args()
    for name in ('zip_sha256','manifest_sha256','verifier_sha256'):
        need(re.fullmatch('[0-9a-f]{64}',getattr(args,'expected_'+name)) is not None,'EXTERNAL_HASH_SCHEMA')
    for name in ('head','tree'):
        need(re.fullmatch('[0-9a-f]{40}',getattr(args,'expected_'+name)) is not None,'EXTERNAL_SOURCE_SCHEMA')
    need(0<args.expected_zip_bytes<=128*1024*1024,'EXTERNAL_ZIP_SIZE_SCHEMA')
    need(sys.version_info>=(3,12),'PYTHON312_REQUIRED')
    if args.mode=='full':
        need(len(args.git_root)==len(args.clone_receipt)==2 and args.npm_prefix is not None,'TWO_COMPLETED_CLONES_REQUIRED')
    else:
        need(not args.git_root and not args.clone_receipt,'ARTIFACT_MODE_HAS_NO_SOURCE_CHECK')
    verifier_path=Path(os.path.abspath(args.verifier))
    archive_path=Path(os.path.abspath(args.archive))
    v,verifier_raw=load_verifier(verifier_path,args.expected_verifier_sha256)
    raw=v.read_regular(archive_path)
    need(len(raw)==args.expected_zip_bytes and v.sha(raw)==args.expected_zip_sha256,'EXTERNAL_ZIP_IDENTITY')
    archive=v.Archive(raw)
    manifest_raw=archive.read('manifest.json')
    need(v.sha(manifest_raw)==args.expected_manifest_sha256,'EXTERNAL_MANIFEST_ANCHOR')
    manifest=v.loads(manifest_raw)
    need(manifest.get('source',{}).get('candidateHead')==args.expected_head and
         manifest.get('source',{}).get('candidateTree')==args.expected_tree and
         manifest.get('acceptanceGranted') is False and manifest.get('release')=='NO_GO','EXTERNAL_CANDIDATE_IDENTITY')
    need(archive.read('verify_return28.py')==verifier_raw,'ARCHIVED_VERIFIER_IDENTITY')
    parent=RUN/'postassembly-return28';parent.mkdir(exist_ok=True);v.node(parent,True)
    output=Path(tempfile.mkdtemp(prefix=args.mode+'-',dir=parent))
    summary=dict(schema=1,mode=args.mode,status='STARTED',head=args.expected_head,tree=args.expected_tree,
        zipSHA256=args.expected_zip_sha256,zipBytes=args.expected_zip_bytes,
        manifestSHA256=args.expected_manifest_sha256,verifierSHA256=args.expected_verifier_sha256,
        helperSHA256=v.sha(v.read_regular(Path(__file__))),acceptanceGranted=False,release='NO_GO',records=[],clones=[],
        qualification='POSTASSEMBLY_OBSERVED_EXECUTION_OUTSIDE_SEALED_ZIP',
        networkDownloadPerformedByHelper=False,downloadFreshness='NOT_ATTESTED_BY_THIS_HELPER')
    def persist():(output/'postassembly-return-receipt.json').write_bytes(encode(summary))
    persist()
    environment={key:value for key,value in os.environ.items()
        if not key.upper().startswith(('GIT_','NPM_','PYTHON','GITHUB_','PHASE4_')) and
        key.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
    if args.npm_prefix:environment['PATH']=str(Path(args.npm_prefix).absolute())+os.pathsep+environment['PATH']
    def execute(label,command,cwd,timeout=2400):
        record=dict(label=label,argv=[str(x) for x in command],exit=None)
        summary['records'].append(record);persist();start=time.monotonic()
        try:
            code,stdout,stderr=v._execute(record['argv'],cwd,timeout,32*1024*1024,supplied_env=environment)
            record.update(exit=code,elapsedMilliseconds=round((time.monotonic()-start)*1000))
            for name,data in (('stdout.log',stdout),('stderr.log',stderr)):
                target=output/(label+'.'+name)
                with target.open('xb') as stream:stream.write(data)
                record[name]=dict(path=target.name,bytes=len(data),sha256=v.sha(data))
            persist();need(code==0,'RETURN_COMMAND_FAILED')
            return v.loads(stdout)
        except BaseException:
            record['failedOrInterrupted']=True;persist();raise
    def git(root,*arguments):return v.git(root,*arguments).decode().strip()
    def snapshot(root):
        need(git(root,'rev-parse','HEAD')==args.expected_head and git(root,'rev-parse','HEAD^{tree}')==args.expected_tree,
             'CLONE_FINAL_IDENTITY')
        need(not git(root,'status','--porcelain=v1','--untracked-files=all'),'CLONE_DIRTY')
        v.standalone_git_store(root)
        tree=v.git_tree(root,'HEAD');count=v.hash_worktree(root,tree)
        obj=(root/'.git/objects').lstat()
        return dict(tree=tree,count=count,index=v.git(root,'ls-files','--stage','-z'),store=(obj.st_dev,obj.st_ino))
    def verify_result(result,full):
        need(result.get('status')=='VERIFIED' and result.get('manifestSHA256')==args.expected_manifest_sha256 and
             result.get('acceptanceGranted') is False and result.get('release')=='NO_GO','RETURN_RESULT_SCHEMA')
        if full:
            need(result.get('git',{}).get('head')==args.expected_head and result.get('git',{}).get('tree')==args.expected_tree and
                 result.get('gitBundlePrerequisites')=='VERIFIED' and
                 result.get('gitHistorySemantics')=='VERIFIED_ALL_CHANGED_PATH_HISTORY_MODES_BLOBS_HASHES' and
                 type(result.get('gitDeltaSemantics')) is dict and
                 result['gitDeltaSemantics'].get('qualification')=='EXACT_PR31_DELTA_OBJECTS_NO_SOURCE_OBJECT_WRITES' and
                 result.get('sourceChecks',{}).get('release28')=='PASS_FINITE_SOURCE_GOVERNANCE_ONLY' and
                 result.get('sourceChecks',{}).get('phase4')=='PASS_UNCHANGED_PRODUCER_STRICT_CHECK','FULL_RETURN_PROOF_REQUIRED')
        else:
            need(result.get('sourceChecks',{}).get('state')=='NOT_RUN' and
                 result.get('gitBundlePrerequisites')=='NOT_CHECKED_WITHOUT_GIT_ROOT' and
                 result.get('gitHistorySemantics')=='NOT_CHECKED_WITHOUT_GIT_ROOT','ARTIFACT_ONLY_QUALIFICATION')
    command=[sys.executable,'-I','-B',str(verifier_path),'--archive',str(archive_path),
        '--expected-manifest-sha256',args.expected_manifest_sha256,'--expected-verifier-sha256',args.expected_verifier_sha256]
    try:
        if args.mode=='downloaded-artifact':
            result=execute('downloaded-artifact-verifier',command,output)
            verify_result(result,False)
            summary['status']='PASS_PROVIDED_DOWNLOAD_BYTES_AND_ARTIFACT_ONLY_VERIFIER'
        else:
            pairs=[];stores=set();labels=set()
            # Both runs must be complete before either return verification starts.
            for root_arg,receipt_arg in zip(args.git_root,args.clone_receipt):
                root=Path(os.path.abspath(root_arg));receipt_path=Path(os.path.abspath(receipt_arg))
                receipt_raw=v.read_regular(receipt_path);receipt=v.loads(receipt_raw)
                label=receipt.get('label')
                need(label in ('clone-a','clone-b') and label not in labels and
                     receipt.get('status')=='PASS_FINAL_CLONE_SOURCE_CHECKPOINT_PHASE4_AND_REAL_CONTROLS' and
                     receipt.get('head')==receipt.get('finalHead')==args.expected_head and
                     receipt.get('tree')==receipt.get('finalTree')==args.expected_tree and
                     receipt.get('cleanAfter') is True and receipt.get('acceptanceGranted') is False and receipt.get('release')=='NO_GO',
                     'COMPLETED_CLONE_RECEIPT_REQUIRED')
                need(receipt.get('manifestSHA256')==manifest['checkpoint']['manifestSHA256'],'CLONE_CHECKPOINT_ANCHOR')
                workspace=RUN/'final-clones'/receipt_path.parent.name
                checkout=Path(receipt.get('checkoutPath',''))
                need(root.is_absolute() and root==checkout and Path(receipt.get('receiptWorkspacePath',''))==workspace and
                     Path(receipt.get('artifactCopyPath',''))==workspace/'checkpoint-copy','CLONE_RECEIPT_PATH_BINDING')
                if receipt.get('shortCloneRoot') is True:
                    need(root.parent==Path(receipt.get('cloneParent','')) and re.fullmatch('c28'+label[-1]+r'-[a-z0-9_]+',root.name) is not None,
                         'CLONE_RECEIPT_PATH_BINDING')
                else:
                    need(receipt.get('shortCloneRoot') is False and root==workspace/'checkout','CLONE_RECEIPT_PATH_BINDING')
                need(receipt_path==RUN/'final-verification'/receipt_path.parent.name/'final-clone-receipt.json',
                     'CLONE_RECEIPT_PATH_BINDING')
                before=snapshot(root)
                need(before['store'] not in stores,'DISTINCT_CLONE_STORES_REQUIRED')
                labels.add(label);stores.add(before['store']);pairs.append((label,root,receipt_path,receipt_raw,before))
            need(labels=={'clone-a','clone-b'},'TWO_COMPLETED_CLONES_REQUIRED')
            loader="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
            for label,root,receipt_path,receipt_raw,before in pairs:
                clone=dict(label=label,completedCloneReceiptSHA256=v.sha(receipt_raw),cleanBefore=True,
                    trackedRawBlobsReconciledBefore=before['count'],objectStoreIdentity=dict(device=before['store'][0],inode=before['store'][1]),
                    protectedContentAndNewHashesPublished=False)
                summary['clones'].append(clone);persist()
                tools=execute(label+'-toolchain-before',[sys.executable,'-I','-B','-c',loader],root,180)
                need(tools.get('tools',{}).get('npm',{}).get('version')=='11.20.0' and
                     tools['tools']['npm'].get('installationModelSHA256')==NPM_MODEL,'VALIDATED_NPM_PREFIX_REQUIRED')
                prefix=Path(args.npm_prefix).absolute()
                node=prefix/('node.exe' if os.name=='nt' else 'bin/node')
                npm=prefix/('node_modules/npm/bin/npm-cli.js' if os.name=='nt' else 'lib/node_modules/npm/bin/npm-cli.js')
                need(v.sha(v.read_regular(node))==tools['tools']['node']['executableSHA256'] and
                     v.sha(v.read_regular(npm))==tools['tools']['npm']['cliSHA256'],'VALIDATED_NPM_PREFIX_REQUIRED')
                complete=False
                try:
                    result=execute(label+'-full-return',command+['--git-root',str(root),'--expected-head',args.expected_head,
                        '--expected-tree',args.expected_tree,'--execute-source-checks'],root)
                    verify_result(result,True);complete=True
                finally:
                    after=snapshot(root)
                    need(after==before and v.read_regular(receipt_path)==receipt_raw,'CLONE_CHANGED_DURING_RETURN_CHECK')
                    clone.update(cleanAfter=True,exactHeadTreeIndexAndRawBlobsPreserved=True,
                        trackedRawBlobsReconciledAfter=after['count'],fullReturnVerified=complete)
                    persist()
                tools_after=execute(label+'-toolchain-after',[sys.executable,'-I','-B','-c',loader],root,180)
                need(tools_after==tools,'TOOLCHAIN_CHANGED')
            summary['status']='PASS_TWO_FULL_RETURN_VERIFICATIONS'
        need(v.read_regular(archive_path)==raw and v.read_regular(verifier_path)==verifier_raw,'POSTASSEMBLY_BYTES_CHANGED')
        summary['zipAndVerifierBytesUnchanged']=True;persist()
        print(json.dumps(dict(status=summary['status'],receiptDirectory=output.name,acceptanceGranted=False,release='NO_GO')))
        return 0
    except BaseException as error:
        code=error.args[0] if isinstance(error,Stop) else 'POSTASSEMBLY_EXECUTION_INCOMPLETE'
        summary.update(status='FAILED_OR_INCOMPLETE',failureCategory=code);persist()
        print(json.dumps(dict(status='FAILED_OR_INCOMPLETE',category=code,receiptDirectory=output.name)))
        return 1


if __name__=='__main__':
    try:raise SystemExit(main())
    except (Stop,OSError,ValueError):
        print(json.dumps(dict(status='FAILED_OR_INCOMPLETE',category='POSTASSEMBLY_BOOTSTRAP')))
        raise SystemExit(1)
