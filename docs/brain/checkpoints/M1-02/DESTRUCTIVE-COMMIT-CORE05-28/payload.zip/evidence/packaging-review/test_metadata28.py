"""Focused executed reader controls; no integration writes, Git commits or native claim."""
import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import tempfile
import types
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


def module_from(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def proxy_os(**changes):
    result = types.SimpleNamespace(**{name: getattr(os, name) for name in dir(os)})
    for name, value in changes.items():
        setattr(result, name, value)
    return result


def record(value, drop_birthtime=False):
    return types.SimpleNamespace(**{name: getattr(value, name) for name in dir(value) if name.startswith('st_') and
        not (drop_birthtime and name.startswith('st_birthtime'))})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verifier')
    parser.add_argument('--output-name', required=True)
    args = parser.parse_args()
    assert __import__('re').fullmatch('[a-z0-9-]{1,80}', args.output_name)
    output = HERE / args.output_name
    output.mkdir()
    qualification = 'ACTUAL_BOUND_VERIFIER_METADATA_CONTROLS_NOT_FULL_SOURCE_OR_RELEASE_PROOF'
    if args.verifier:
        verifier_path = Path(args.verifier).resolve()
        verifier_raw = verifier_path.read_bytes()
    else:
        prepare = module_from(HERE/'prepare28.py', 'prepare28_metadata_controls')
        templates, _ = prepare.authenticate_templates()
        source = prepare.compatible_reader28(prepare.rename28(templates['verify_return27.py']))
        verifier_path = output / 'generated-verifier28-metadata-proposal.py'
        verifier_raw = source.encode()
        verifier_path.write_bytes(verifier_raw)
        qualification = 'ACTUAL_GENERATED_METADATA_PROPOSAL_ONLY_NOT_FINAL_VERIFIER_SOURCE_OR_RELEASE_PROOF'
    v = types.ModuleType('actual_generated_verifier28_metadata')
    v.__file__ = str(verifier_path)
    exec(compile(verifier_raw, str(verifier_path), 'exec'), v.__dict__)
    base = dict(st_dev=9, st_ino=20, st_nlink=1, st_size=7, st_mtime_ns=3000, st_mtime=0.000003,
        st_uid=0, st_gid=0, st_mode=stat.S_IFREG|0o666, st_ctime_ns=1000, st_ctime=0.000001,
        st_atime_ns=100, st_atime=0.0000001, st_file_attributes=32, st_reparse_tag=0)
    events = []
    def positive(label, action):
        assert action() is not False, label
        events.append(dict(case=label, result='PASS_POSITIVE'))
    def refusal(label, action, expected=None):
        try:
            result = action()
        except v.Refusal as error:
            assert expected is None or error.args[0] == expected, (label, error.args)
            events.append(dict(case=label, result='PASS_REFUSAL', category=error.args[0]))
            return
        except AssertionError:
            assert expected == 'HISTORY_ASSERTION', label
            events.append(dict(case=label, result='PASS_REFUSAL', category='HISTORY_ASSERTION'))
            return
        assert result is False, label
        events.append(dict(case=label, result='PASS_REFUSAL', category='COMPATIBLE_FIELD_MISMATCH'))
    v.os = proxy_os(name='nt')
    named, opened = record(types.SimpleNamespace(**base)), record(types.SimpleNamespace(**base))
    opened.st_ctime_ns += 9000
    opened.st_ctime += 0.009
    positive('windows-no-birthtime-different-ctime-admitted', lambda: v.cross_metadata(Path('fixture.bin'), named, opened))
    named.st_birthtime_ns = opened.st_birthtime_ns = 44
    positive('windows-birthtime-same-different-ctime-admitted', lambda: v.cross_metadata(Path('fixture.bin'), named, opened))
    opened.st_birthtime_ns += 1
    refusal('windows-comparable-birthtime-change-refused', lambda: v.cross_metadata(Path('fixture.bin'), named, opened))
    del named.st_birthtime_ns
    del opened.st_birthtime_ns
    for field in ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mtime_ns', 'st_size', 'st_nlink', 'st_file_attributes', 'st_reparse_tag'):
        changed = copy.copy(opened)
        setattr(changed, field, getattr(changed, field)+1)
        refusal('windows-cross-'+field, lambda changed=changed: v.cross_metadata(Path('fixture.bin'), named, changed))
    changed = copy.copy(opened)
    changed.st_mode ^= stat.S_IWUSR
    refusal('windows-cross-mode', lambda: v.cross_metadata(Path('fixture.bin'), named, changed))
    exe_named = copy.copy(named)
    exe_named.st_mode |= 0o111
    positive('windows-compatible-pathname-executable-presentation', lambda: v.cross_metadata(Path('fixture.cmd'), exe_named, opened))
    for field in ('st_dev', 'st_ino', 'st_uid', 'st_gid', 'st_mtime_ns', 'st_mtime', 'st_size', 'st_mode',
                  'st_nlink', 'st_file_attributes', 'st_reparse_tag', 'st_ctime_ns', 'st_ctime'):
        left, right = copy.copy(named), copy.copy(named)
        setattr(right, field, getattr(right, field)+1)
        refusal('same-domain-'+field, lambda left=left,right=right: v.stable_metadata(left,right))
    atime = copy.copy(named)
    atime.st_atime += 77
    atime.st_atime_ns += 888
    positive('same-domain-only-atime-changes-admitted', lambda: v.stable_metadata(named,atime))
    no_uid = copy.copy(named)
    del no_uid.st_uid
    refusal('same-domain-field-set-change-refused', lambda: v.stable_metadata(named,no_uid))
    v.os = proxy_os()
    with tempfile.TemporaryDirectory(prefix='reader28-', dir=output) as temporary:
        directory = Path(temporary)
        fixture = directory/'fixture.bin'
        original = bytes(range(256))*19
        fixture.write_bytes(original)
        positive('real-complete-read-exact-hash', lambda: hashlib.sha256(v.read_regular(fixture)).digest()==hashlib.sha256(original).digest())
        real_read = os.read
        v.os = proxy_os(read=lambda descriptor,size: real_read(descriptor,min(size,17)))
        positive('real-multiple-short-chunks-complete-read-exact-hash', lambda: v.read_regular(fixture)==original)
        v.os = proxy_os(read=lambda descriptor,size: b'')
        refusal('premature-eof-refused', lambda: v.read_regular(fixture), 'R27_REPLAY_CHANGED')
        v.os = proxy_os(read=lambda descriptor,size: b'x'*(len(original)+1))
        refusal('overlong-read-refused', lambda: v.read_regular(fixture), 'R27_REPLAY_READ_SIZE')
        v.os = proxy_os()
        real_lstat = Path.lstat
        real_fstat = os.fstat
        def path_stamp(path, *p_args, **p_kwargs):
            result = real_lstat(path,*p_args,**p_kwargs)
            return record(result,True) if path==fixture else result
        def handle_stamp(descriptor):
            result = record(real_fstat(descriptor),True)
            result.st_ctime_ns += 1234567
            result.st_ctime += 0.1234567
            return result
        v.os = proxy_os(name='nt', fstat=handle_stamp)
        with patch.object(Path,'lstat',path_stamp):
            positive('actual-reader-windows-no-birthtime-different-ctime-domains', lambda: v.read_regular(fixture)==original)
        for field in ('st_uid','st_gid','st_mtime_ns','st_size','st_mode','st_nlink','st_file_attributes','st_reparse_tag','st_ctime_ns'):
            calls = [0]
            def changed_handle(descriptor, field=field):
                result = handle_stamp(descriptor)
                calls[0] += 1
                if calls[0] == 2:
                    setattr(result,field,getattr(result,field)+1)
                return result
            v.os = proxy_os(name='nt',fstat=changed_handle)
            with patch.object(Path,'lstat',path_stamp):
                refusal('actual-reader-handle-same-domain-'+field, lambda: v.read_regular(fixture))
        v.os = proxy_os()
        artifact = directory/'artifact'
        artifact.mkdir()
        (artifact/'manifest.json').write_text('{}')
        target = artifact/'payload.bin'
        target.write_bytes(original)
        declaration = {'payload.bin':dict(bytes=len(original),sha256=hashlib.sha256(original).hexdigest())}
        positive('actual-artifact-original-bytes-pass', lambda: v.check_files(v.Directory(artifact),declaration)==2)
        stamp = target.stat()
        target.write_bytes(b'Z'+original[1:])
        os.utime(target,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
        refusal('actual-artifact-same-size-restored-mtime-hash-corruption-refused', lambda: v.check_files(v.Directory(artifact),declaration),'ARTIFACT_HASH_MISMATCH')
        target.write_bytes(original)
        os.utime(target,ns=(stamp.st_atime_ns,stamp.st_mtime_ns))
        positive('actual-artifact-exact-restored-bytes-pass', lambda: v.check_files(v.Directory(artifact),declaration)==2)
        # New historical executor helpers are extracted without executing its
        # CLI, cloning, writing Git objects or running a historical consumer.
        history_path = HERE.parent/'campaign28-history/history-review/execute_original_history28.py'
        history_raw = history_path.read_bytes()
        tree = ast.parse(history_raw)
        selected = [node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in ('stable','compatible28','regular28','inventory')]
        assert len(selected)==4
        h = dict(os=proxy_os(name='nt',fstat=handle_stamp),Path=Path,stat=stat,hashlib=hashlib,sha=lambda raw:hashlib.sha256(raw).hexdigest())
        exec(compile(ast.Module(body=selected,type_ignores=[]),str(history_path),'exec'),h)
        positive('history-no-birthtime-different-ctime-admitted', lambda: h['compatible28'](fixture,named,opened))
        for field in ('st_uid','st_gid','st_mtime_ns','st_size','st_mode','st_nlink','st_file_attributes','st_reparse_tag','st_ctime_ns'):
            changed = copy.copy(named)
            setattr(changed,field,getattr(changed,field)+1)
            refusal('history-same-domain-'+field,lambda changed=changed:h['stable'](named,changed))
        positive('history-only-atime-admitted',lambda:h['stable'](named,atime))
        blob=hashlib.sha1(b'blob '+str(len(original)).encode()+b'\0'+original).hexdigest()
        def fake_git(root,*arguments):
            if arguments==('rev-parse','HEAD'):return b'a'*40
            if arguments==('rev-parse','HEAD^{tree}'):return b'b'*40
            if arguments==('ls-tree','-r','-z','a'*40):return ('100644 blob '+blob+'\tfixture.bin\0').encode()
            if arguments[:2]==('status','--porcelain=v1'):return b''
            raise AssertionError(arguments)
        h['git']=fake_git
        with patch.object(Path,'lstat',path_stamp):
            positive('history-actual-reader-byte-hash-with-synthetic-git-metadata',lambda:h['inventory'](directory,'a'*40)['trackedFiles']==1)
        fixture.write_bytes(b'Y'+original[1:])
        with patch.object(Path,'lstat',path_stamp):
            refusal('history-real-read-wrong-git-blob-refused',lambda:h['inventory'](directory,'a'*40),'HISTORY_ASSERTION')
    result = dict(schema=1,status='PASS_FOCUSED_METADATA_AND_READ_CONTROLS',qualification=qualification,
        verifierPath=str(verifier_path),verifierSHA256=hashlib.sha256(verifier_raw).hexdigest(),
        historyReaderSHA256=hashlib.sha256(history_raw).hexdigest(),positiveControls=sum(event['result']=='PASS_POSITIVE' for event in events),
        refusals=sum(event['result']=='PASS_REFUSAL' for event in events),events=events,
        actualFinalHeadSourceChecks='NOT_RUN',historicalConsumers='NOT_RUN_BY_THIS_UNIT_SUITE',
        physicalNativeDurability='NOT_RUN',acceptanceGranted=False,release='NO_GO')
    (output/'metadata-controls-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    print(json.dumps({key:result[key] for key in ('status','qualification','positiveControls','refusals','verifierSHA256','historyReaderSHA256','release')}))


if __name__=='__main__':
    main()
