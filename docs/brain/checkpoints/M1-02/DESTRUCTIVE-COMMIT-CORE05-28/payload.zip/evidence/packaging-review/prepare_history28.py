"""Prepare external original151/Release09-23 executor from authenticated prior tool."""
from pathlib import Path
import hashlib
import json

WORKSPACE = Path(__file__).resolve().parent.parent
PAYLOAD = WORKSPACE / "Campaign28_bootstrap/prior-payload-authenticated-fpgp5ndh"
CHECKPOINT = WORKSPACE / "Campaign28_bootstrap/prior-return-authenticated-r0bf2irz/checkpoint/manifest.json"
DESTINATION = WORKSPACE / "campaign28-history/history-review/execute_original_history28.py"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert sha(CHECKPOINT.read_bytes()) == "1a8fc2026c557c4e41192f5dc755627f8ce6e392cc791141fbe1444bc7929907"
manifest = json.loads(CHECKPOINT.read_bytes())
path = PAYLOAD / "evidence/history-review/execute_original_history.py"
raw = path.read_bytes()
record = manifest["payload"]["files"][path.relative_to(PAYLOAD).as_posix()]
assert len(raw) == record["bytes"] and sha(raw) == record["sha256"]
source = raw.decode()
start = source.index("RUN = Path(__file__).resolve().parent.parent")
end = source.index("\n\ndef sha(raw):", start)
source = source[:start] + '''import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', required=True)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--expected-tree', required=True)
parser.add_argument('--node-prefix', required=True)
parser.add_argument('--output-name', required=True)
args = parser.parse_args()
assert __import__('re').fullmatch('[a-z0-9-]{1,80}', args.output_name)
assert all(__import__('re').fullmatch('[0-9a-f]{40}', value) for value in (args.expected_head,args.expected_tree))
RUN = Path(__file__).resolve().parent.parent
OUT = RUN/args.output_name
SOURCE_ROOT = Path(args.source_root).resolve()
PAYLOAD = RUN.parent/'Campaign28_bootstrap/prior-payload-authenticated-fpgp5ndh'
CHECKPOINT = RUN.parent/'Campaign28_bootstrap/prior-return-authenticated-r0bf2irz/checkpoint/manifest.json'
def authenticated_prior(name):
    body=(PAYLOAD/name).read_bytes()
    checkpoint_raw=CHECKPOINT.read_bytes()
    assert hashlib.sha256(checkpoint_raw).hexdigest()=='1a8fc2026c557c4e41192f5dc755627f8ce6e392cc791141fbe1444bc7929907'
    record=json.loads(checkpoint_raw)['payload']['files'][name]
    assert len(body)==record['bytes'] and hashlib.sha256(body).hexdigest()==record['sha256']
    return json.loads(body)
prior=authenticated_prior('evidence/history-execution/SUMMARY.json')
PINS=[]
for row in prior['runs']:
    PINS.append(dict(release=row['release'],source=row['source'],tree=row['tree'],script=row['argv'][-1],
        scriptIdentity=row['scriptIdentity'],checkerIdentity=row['checkerIdentity'],expectedTerminal=row['terminalResult']))
assert [row['release'] for row in PINS]==['08-original151']+[str(i).zfill(2) for i in range(9,24)]
NATIVE=authenticated_prior('evidence/history-execution/early-provenance.json')['nativeInputs']
assert len(NATIVE)==10
PYTHON=sys.executable
ENV={key:value for key,value in os.environ.items() if not key.upper().startswith(('GIT_','GITHUB_','PYTHON','NPM_')) and key.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
ENV['GIT_TERMINAL_PROMPT']='0'
ENV['PATH']=str(Path(args.node_prefix).resolve())+os.pathsep+ENV['PATH']
''' + source[end:]
source = source.replace("(RUN/'source'/row['path'])", "(SOURCE_ROOT/row['path'])")
source = source.replace("'stage/m1-first-value-recovery26'", "'stage/m1-first-value-safety-ci27'")
source = source.replace("'HISTORY_GIT_FAILED'", "'CAMPAIGN28_HISTORY_GIT_FAILED'")
start = source.index("def stable(a,b):")
end = source.index("def run_case(root, pin):", start)
source = source[:start] + (Path(__file__).parent / "history_metadata28.py").read_text() + "\n\n" + source[end:]
source = source.replace("    after=inventory(root,pin['source'])", "    after=inventory(root,pin['source'])")
source = source.replace("    receipt={'release':release", "    receipt={'campaign28ContextHead':args.expected_head,'campaign28ContextTree':args.expected_tree,'release':release", 1)
source = source.replace("    return receipt\n", "    assert exit_code==0 and timeout is False and terminal==pin['expectedTerminal']\n    return receipt\n", 1)
start = source.index("def main():")
source = source[:start] + '''def main():
    assert sys.flags.optimize==0 and sys.version_info[:2]==(3,9)
    assert git(SOURCE_ROOT,'rev-parse','HEAD').decode().strip()==args.expected_head
    assert git(SOURCE_ROOT,'rev-parse','HEAD^{tree}').decode().strip()==args.expected_tree
    assert not git(SOURCE_ROOT,'status','--porcelain=v1','--untracked-files=all')
    assert hashlib.sha256((SOURCE_ROOT/'package-lock.json').read_bytes()).hexdigest()=='1485297ffa6cc20367a5f2fda35bc33e12dc11ef422c813f5f28a4e339cb3b95'
    loader="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
    tools_raw=subprocess.check_output([PYTHON,'-I','-B','-c',loader],cwd=SOURCE_ROOT,env=ENV,timeout=180)
    tools=json.loads(tools_raw)
    assert tools['tools']['npm']['version']=='11.20.0' and tools['tools']['npm']['installationModelSHA256']=='c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9'
    OUT.mkdir(exist_ok=False)
    (OUT/'current-toolchain.json').write_bytes(tools_raw)
    pins=PINS[1:]
    semantic=PINS[0]
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(worker,'early',[semantic]+pins[:7]),pool.submit(worker,'late',pins[7:])]
        for future in concurrent.futures.as_completed(futures):results.extend(future.result())
    endpoints=[]
    for label in ('early','late'):
        root=OUT/label
        assert not git(root,'status','--porcelain=v1','--untracked-files=all')
        info=(root/'.git/objects').lstat()
        endpoints.append(dict(group=label,head=git(root,'rev-parse','HEAD').decode().strip(),clean=True,objectDirectoryDevice=info.st_dev,objectDirectoryInode=info.st_ino))
    assert len({(row['objectDirectoryDevice'],row['objectDirectoryInode']) for row in endpoints})==2
    summary={'status':'PASS_ORIGINAL151_AND_AUTHENTIC_ORIGINAL09_TO23','runs':sorted(results,key=lambda p:p['release']),
        'contextHead':args.expected_head,'contextTree':args.expected_tree,'endpoints':endpoints,
        'scriptSHA256':sha(Path(__file__).read_bytes()),'priorPinFileSHA256':sha((PAYLOAD/'evidence/history-execution/SUMMARY.json').read_bytes()),
        'nativePins':NATIVE,'nativeInputs':'TEN_AUTHENTICATED_PUBLIC_SOURCE_PINS_FROM_CURRENT_REAL_INSTALL;NOT_A_HISTORICAL_NPM_INSTALL',
        'qualification':'ACTUAL_UNCHANGED_ORIGINAL_EXECUTION_AT_AUTHENTIC_FULL_REMOTE_CHECKOUTS;ORIGINAL_TEST_QUALIFICATIONS_RETAINED;NOT_CURRENT_ACCEPTANCE',
        'acceptanceGranted':False,'release':'NO_GO'}
    (OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\\n',encoding='utf-8')
    print(json.dumps({'status':summary['status'],'completed':len(results),'failed':sum(r['exit']!=0 for r in results),'release':'NO_GO'}),flush=True)

if __name__=='__main__':main()
'''
compile(source, str(DESTINATION), "exec")
DESTINATION.parent.mkdir(parents=True, exist_ok=True)
with DESTINATION.open("xb") as output:
    output.write(source.encode())
metadata = dict(schema=1, status="PREPARED_NOT_EXECUTED", authenticatedTemplatePath=str(path),
    authenticatedTemplateSHA256=sha(raw), preparedPath=str(DESTINATION), preparedSHA256=sha(source.encode()),
    qualification="EXTERNAL_ADAPTATION_WITH_UNCHANGED_HISTORICAL_TESTS_AND_NATIVE_FIXTURE_ONLY_LIMITATION", acceptanceGranted=False, release="NO_GO")
(DESTINATION.parent / "PREPARATION.json").write_text(json.dumps(metadata, indent=2)+"\n", encoding="utf-8")
print(json.dumps(metadata))
