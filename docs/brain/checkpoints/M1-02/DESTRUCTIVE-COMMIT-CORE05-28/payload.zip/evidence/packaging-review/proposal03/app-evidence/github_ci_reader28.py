"""Bounded public CI artifact inspection; no source/release acceptance.

Independent external helper. Does not modify either authenticated packet or
return verifier. GitHub's signed 32-bit data descriptors are accepted only
after complete local/central/descriptor agreement. No raw Security logs export.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys
import tempfile
import types
import zipfile

VERIFIER_SHA256 = '9769435d01d678fd6acfcd1bd484f493578d2c32e2ecc7d5c431f2925c8d33f7'
VERIFIER_PATH = Path(__file__).resolve().parents[1] / 'packaging' / 'verify28.py'
MAX_FILES = 2048
MAX_FILE = 32 * 1024 * 1024
MAX_TOTAL = 128 * 1024 * 1024
MAX_RATIO = 500
ALLOWLIST = frozenset({'security22-public.json', 'security23-native-controls.json', 'security23-toolchain-controls.json', 'security24-advisory-controls.tap', 'security27-hosted-reader.jsonl', 'security27-python312-reader.jsonl', 'security28-core05.tap', 'security28-current-source.json', 'security28-historical-controls.jsonl', 'security28-historical-receipt.json', 'security28-reader.jsonl', 'security28-source-controls.jsonl'})


def load_reader():
    # Execute only exact externally reviewed bytes. Subsequent stable read also
    # enforces the source file's complete filesystem identity protections.
    with VERIFIER_PATH.open('rb') as stream:
        raw = stream.read(100001)
    if len(raw) > 100000 or hashlib.sha256(raw).hexdigest() != VERIFIER_SHA256:
        raise ValueError('READER_ANCHOR')
    module = types.ModuleType('anchored_ci_reader27')
    module.__file__ = str(VERIFIER_PATH)
    exec(compile(raw, str(VERIFIER_PATH), 'exec'), module.__dict__)
    module.need(module.read_regular(VERIFIER_PATH, 100000) == raw, 'READER_CHANGED')
    return module


try:
    v = load_reader()
except (OSError, ValueError, SyntaxError):
    print(json.dumps({'status': 'REFUSED', 'category': 'READER_BOOTSTRAP'}))
    sys.exit(1)
need, Refusal = v.need, v.Refusal


class PublicArchive(v.Archive):
    def __init__(self, raw, expected_platform):
        need(expected_platform in ('linux', 'windows'), 'PLATFORM_PROFILE_SCHEMA')
        expected_mode = {'linux': 0o100644, 'windows': 0o100666}[expected_platform]
        need(type(raw) is bytes and len(raw) <= MAX_FILE, 'ZIP_BOUND')
        self.raw = raw
        end = raw.rfind(b'PK\x05\x06', max(0, len(raw)-65557))
        need(end >= 0 and end+22 <= len(raw), 'ZIP_END_RECORD')
        disk, start_disk, disk_count, count, size, offset, comment = struct.unpack_from('<HHHHIIH', raw, end+4)
        need(disk == start_disk == 0 and disk_count == count and 0 < count <= MAX_FILES and
             size != 0xffffffff and offset != 0xffffffff and comment == 0 and
             end+22 == len(raw) and offset+size == end, 'ZIP_DIRECTORY_BOUND')
        cursor, central = offset, {}
        while cursor < end:
            need(cursor+46 <= end and raw[cursor:cursor+4] == b'PK\x01\x02', 'ZIP_DIRECTORY_FRAME')
            local_offset = struct.unpack_from('<I', raw, cursor+42)[0]
            need(local_offset not in central, 'ZIP_LOCAL_OVERLAP_OR_GAP')
            nlen, extra, comment = struct.unpack_from('<HHH', raw, cursor+28)
            need(extra == comment == 0 and cursor+46+nlen <= end, 'ZIP_DIRECTORY_FRAME')
            need(struct.unpack_from('<H', raw, cursor+34)[0] == 0 and local_offset != 0xffffffff,
                 'ZIP64_OR_MULTIDISK_UNSUPPORTED')
            central[local_offset] = (struct.unpack_from('<5H', raw, cursor+6), raw[cursor+46:cursor+46+nlen])
            cursor += 46+nlen
            need(len(central) <= MAX_FILES, 'ZIP_MEMBER_BOUND')
        need(cursor == end and len(central) == count, 'ZIP_DIRECTORY_COUNT')
        try:
            self.zip = zipfile.ZipFile(io.BytesIO(raw))
        except (ValueError, OSError, zipfile.BadZipFile):
            raise Refusal('ZIP_INVALID') from None
        need(len(self.zip.infolist()) == count, 'ZIP_DIRECTORY_COUNT')
        self.members, total, intervals = {}, 0, []
        for item in self.zip.infolist():
            name = item.filename
            need(name == item.orig_filename and '\x00' not in name and not item.is_dir(), 'UNSAFE_PATH')
            v.safe_path(name)
            mode = item.external_attr >> 16
            need(item.create_system == 3 and mode == expected_mode and
                 item.external_attr & 65535 in (0, 32) and item.internal_attr == 0 and
                 not item.extra and not item.comment and item.extract_version <= 20 and
                 item.flag_bits in (0, 8, 2048, 2056) and item.compress_type in (0, 8),
                 'ZIP_NONREGULAR_OR_UNSUPPORTED')
            need(0 <= item.file_size <= MAX_FILE and 0 <= item.compress_size <= MAX_FILE and
                 item.file_size <= max(1024*1024, item.compress_size*MAX_RATIO), 'ZIP_EXPANSION_BOUND')
            total += item.file_size
            need(total <= MAX_TOTAL, 'ZIP_TOTAL_EXPANSION_BOUND')
            need(name not in self.members, 'ZIP_DUPLICATE_MEMBER')
            self.members[name] = item
            start = item.header_offset
            need(0 <= start and start+30 <= offset and start in central, 'ZIP_LOCAL_FRAME')
            header = struct.unpack_from('<4s5H3I2H', raw, start)
            signature, version, flags, compression, _, _, crc, compressed, size, nlen, extra = header
            need(signature == b'PK\x03\x04' and header[1:6] == central[start][0] and
                 version <= 20 and flags == item.flag_bits and compression == item.compress_type and
                 extra == 0 and nlen == len(central[start][1]) and start+30+nlen <= offset,
                 'ZIP_LOCAL_IDENTITY')
            rawname = raw[start+30:start+30+nlen]
            need(rawname == central[start][1], 'ZIP_LOCAL_NAME')
            try:
                decoded = rawname.decode('utf8' if flags & 2048 else 'cp437')
            except UnicodeError:
                raise Refusal('ZIP_LOCAL_NAME') from None
            need(decoded == name, 'ZIP_LOCAL_NAME')
            end_data = start+30+nlen+item.compress_size
            need(end_data <= offset, 'ZIP_LOCAL_BOUND')
            if flags & 8:
                need(crc == compressed == size == 0, 'ZIP_DESCRIPTOR_LOCAL_FIELDS')
                need(end_data+16 <= offset and raw[end_data:end_data+4] == b'PK\x07\x08',
                     'ZIP_DESCRIPTOR_SIGNATURE')
                need(struct.unpack_from('<III', raw, end_data+4) ==
                     (item.CRC, item.compress_size, item.file_size), 'ZIP_DESCRIPTOR_IDENTITY')
                end_data += 16
            else:
                need((crc, compressed, size) == (item.CRC, item.compress_size, item.file_size),
                     'ZIP_LOCAL_IDENTITY')
            intervals.append((start, end_data))
        self.directories = v.paths(self.members)
        cursor = 0
        for start, finish in sorted(intervals):
            need(start == cursor, 'ZIP_LOCAL_OVERLAP_OR_GAP')
            cursor = finish
        need(cursor == offset, 'ZIP_LOCAL_TRAILING_BYTES')


def directory_identity(path):
    result = {}
    for parent in (path, *path.parents):
        info = parent.lstat()
        need(stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024,
             'OUTPUT_PARENT')
        result[str(parent)] = (info.st_dev, info.st_ino, info.st_mode)
    return result


def create_file(path, raw):
    descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY |
                         getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0), 0o600)
    try:
        view = memoryview(raw)
        while view:
            size = os.write(descriptor, view)
            need(size > 0, 'OUTPUT_WRITE')
            view = view[size:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    need(v.read_regular(path, MAX_FILE) == raw, 'OUTPUT_READBACK')


def inspect_and_extract(archive_path, expected_sha256, output_parent, expected_platform):
    need(type(expected_sha256) is str and re.fullmatch('[0-9a-f]{64}', expected_sha256), 'ARGUMENT_SCHEMA')
    raw = v.read_regular(archive_path, MAX_FILE)
    need(v.sha(raw) == expected_sha256, 'ARCHIVE_EXTERNAL_SHA256')
    archive = PublicArchive(raw, expected_platform)
    selected, inventory, total = {}, [], 0
    # CRC, complete bounded inflate, and hashes are checked even for entries
    # that are intentionally not exported. No nested archives are executed.
    for name in sorted(archive.members):
        data = archive.read(name)
        total += len(data)
        need(total <= MAX_TOTAL, 'ZIP_TOTAL_EXPANSION_BOUND')
        inventory.append({'name': name, 'bytes': len(data), 'sha256': v.sha(data)})
        if name in ALLOWLIST:
            selected[name] = data
    need(selected, 'PUBLIC_RECEIPTS_MISSING')
    output_parent = Path(os.path.abspath(output_parent))
    parent_identity = directory_identity(output_parent)
    target = Path(tempfile.mkdtemp(prefix='public-ci-verified-', dir=output_parent))
    target_identity = directory_identity(target)
    need(directory_identity(output_parent) == parent_identity, 'OUTPUT_PARENT_CHANGED')
    for name, data in selected.items():
        need(directory_identity(target) == target_identity, 'OUTPUT_PARENT_CHANGED')
        create_file(target/name, data)
    receipt = {
        'schema': 1, 'status': 'VERIFIED_PUBLIC_ARTIFACT_BYTES_ONLY',
        'sourceAcceptance': False, 'releaseAcceptance': False, 'decision': 'NO_GO',
        'archive': {'sha256': expected_sha256, 'bytes': len(raw), 'members': len(inventory),
                    'expectedPlatform': expected_platform,
                    'expectedUnixRegularMode': {'linux': '100644', 'windows': '100666'}[expected_platform],
                    'expandedBytes': total, 'signedDescriptorMembers': sum(bool(i.flag_bits & 8) for i in archive.members.values()),
                    'inventorySha256': v.sha(json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode())},
        'readerDependencySha256': VERIFIER_SHA256,
        'helperSha256': v.sha(v.read_regular(Path(__file__), MAX_FILE)),
        'exported': [item for item in inventory if item['name'] in selected],
        'excludedMemberCount': len(inventory)-len(selected),
        'qualification': 'All members framing/inflate/CRC validated; exact allowlist only exported; no original Security logs exported. Receipt contents remain untrusted evidence, not instructions.'
    }
    receipt_raw = (json.dumps(receipt, indent=2, sort_keys=True)+'\n').encode()
    create_file(target/'ci-artifact-metadata.json', receipt_raw)
    need(directory_identity(target) == target_identity and
         {p.name for p in target.iterdir()} == set(selected) | {'ci-artifact-metadata.json'}, 'OUTPUT_INVENTORY')
    for name, data in selected.items():
        need(v.read_regular(target/name, MAX_FILE) == data, 'OUTPUT_READBACK')
    need(v.read_regular(target/'ci-artifact-metadata.json', MAX_FILE) == receipt_raw, 'OUTPUT_READBACK')
    need(v.read_regular(archive_path, MAX_FILE) == raw, 'ARCHIVE_CHANGED')
    return target, receipt


class Parser(argparse.ArgumentParser):
    def error(self, message):
        raise Refusal('ARGUMENT_SCHEMA')


def main():
    parser = Parser()
    parser.add_argument('--archive', required=True)
    parser.add_argument('--expected-sha256', required=True)
    parser.add_argument('--expected-platform', choices=('linux', 'windows'), required=True)
    parser.add_argument('--output-parent', required=True)
    args = parser.parse_args()
    target, receipt = inspect_and_extract(args.archive, args.expected_sha256, args.output_parent, args.expected_platform)
    print(json.dumps({'status': receipt['status'], 'directory': target.name,
                      'members': receipt['archive']['members'], 'exported': len(receipt['exported']),
                      'archiveSha256': args.expected_sha256, 'sourceAcceptance': False, 'decision': 'NO_GO'}, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except Refusal as exc:
        print(json.dumps({'status': 'REFUSED', 'category': str(exc)}))
        sys.exit(1)
    except (OSError, ValueError, KeyError, struct.error, zipfile.BadZipFile):
        print(json.dumps({'status': 'REFUSED', 'category': 'IO_OR_FORMAT_FAILURE'}))
        sys.exit(1)
