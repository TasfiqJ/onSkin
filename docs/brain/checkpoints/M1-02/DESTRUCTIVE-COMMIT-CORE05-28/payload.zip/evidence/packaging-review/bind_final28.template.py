"""Bind actual final clone/API identities; no ZIP, upload, source writes or claims."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re

RUN = Path(__file__).resolve().parent


def need(ok, code):
    if not ok:
        raise ValueError(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def assign(source, values):
    tree = ast.parse(source)
    lines = source.splitlines(keepends=True)
    seen = set()
    for node in reversed(tree.body):
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in values:
                lines[node.lineno - 1:node.end_lineno] = [name + " = " + repr(values[name]) + "\n"]
                seen.add(name)
    need(seen == set(values), "FINAL_TEMPLATE_CONSTANTS")
    return "".join(lines)


def renamed(source):
    for before, after in (("Campaign27", "Campaign28"), ("campaign27", "campaign28"),
        ("verify_return27", "verify_return28"), ("verify27", "verify28"),
        ("build_checkpoint27", "build_checkpoint28"), ("build_return27", "build_return28"),
        ("source27", "source28"), ("release27", "release28"), ("RELEASE27", "RELEASE28"),
        ("security27", "security28"), ("EXACT_PR30_DELTA_OBJECTS", "EXACT_PR31_DELTA_OBJECTS")):
        source = source.replace(before, after)
    source = source.replace('security28-hosted-reader.jsonl', 'security27-hosted-reader.jsonl')
    source = source.replace('security28-python312-reader.jsonl', 'security27-python312-reader.jsonl')
    return source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--expected-head", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--clone-a", required=True)
    parser.add_argument("--clone-b", required=True)
    parser.add_argument("--linux-artifact-directory", required=True)
    parser.add_argument("--candidate-artifacts-api", required=True)
    args = parser.parse_args()
    need(all(re.fullmatch("[0-9a-f]{40}", item) for item in (args.expected_head, args.expected_tree)), "FINAL_ANCHORS")
    proposal = json.loads((RUN / "proposal-binding.json").read_text())
    seal = json.loads((RUN / "packaging/checkpoint-seal.json").read_bytes())
    clones = []
    stores = set()
    for label, name in (("clone-a", args.clone_a), ("clone-b", args.clone_b)):
        need(re.fullmatch(label + "-[a-z0-9_]+", name) is not None, "ACTUAL_CLONE_DIRECTORY")
        path = RUN / "final-verification" / name / "final-clone-receipt.json"
        value = json.loads(path.read_bytes())
        need(value.get("status") == "PASS_FINAL_CLONE_SOURCE_CHECKPOINT_PHASE4_AND_REAL_CONTROLS" and
             value.get("head") == value.get("finalHead") == args.expected_head and
             value.get("tree") == value.get("finalTree") == args.expected_tree and
             value.get("manifestSHA256") == seal["manifestSHA256"] and value.get("verifierSHA256") == seal["verifierSHA256"] and
             value.get("sourceTamperSequence") == value.get("artifactTamperSequence") == [0, 1, 0] and
             value.get("cleanAfter") is True and value.get("acceptanceGranted") is False and value.get("release") == "NO_GO",
             "ACTUAL_COMPLETED_FINAL_CLONE_REQUIRED")
        checkout = value.get("checkoutPath")
        need(type(checkout) is str and Path(checkout).is_absolute(), "ACTUAL_CLONE_CHECKOUT_PATH")
        identity = value.get("cloneProof", {}).get("objectStoreDirectoryIdentity")
        need(type(identity) is dict and set(identity) == {"device", "inode"}, "ACTUAL_CLONE_OBJECT_STORE")
        if identity is not None:
            key = json.dumps(identity, sort_keys=True)
            need(key not in stores, "CLONE_OBJECT_STORES_MUST_DIFFER")
            stores.add(key)
        clones.append(dict(directory=name, checkoutPath=checkout, receiptSHA256=sha(path.read_bytes())))
    need(re.fullmatch("public-ci-verified-[a-z0-9_]+", args.linux_artifact_directory) is not None, "LINUX_DIRECTORY")
    metadata_path = RUN / "ci-final" / args.linux_artifact_directory / "ci-artifact-metadata.json"
    metadata = json.loads(metadata_path.read_bytes())
    need(metadata.get("status") == "VERIFIED_PUBLIC_ARTIFACT_BYTES_ONLY" and
         metadata.get("archive", {}).get("expectedPlatform") == "linux", "ACTUAL_LINUX_EXPORT")
    api_path = Path(args.candidate_artifacts_api).resolve()
    api = json.loads(api_path.read_bytes())
    if type(api) is dict and api.get("status") == "fulfilled" and "value" in api:
        api = api["value"]
    if type(api) is dict and "structuredContent" in api:
        need(api.get("isError") is not True, "ARTIFACT_API_ERROR")
        api = api["structuredContent"]
    records = api.get("artifacts", [])
    archive = metadata["archive"]
    matches = [row for row in records if row.get("digest") == "sha256:" + archive["sha256"] and
        row.get("size_in_bytes") == archive["bytes"] and row.get("workflow_run", {}).get("head_sha") == args.expected_head and
        "ubuntu-latest" in row.get("name", "") and row.get("expired") is False]
    need(len(matches) == 1, "ACTUAL_LINUX_API_BINDING")
    actual = matches[0]
    linux = dict(id=actual["id"], size=actual["size_in_bytes"], digest=actual["digest"], directory=args.linux_artifact_directory)
    template_path = RUN / "authenticated-templates/build_final_receipts27.py"
    template_raw = template_path.read_bytes()
    need(sha(template_raw) == proposal["templates"]["build_final_receipts27.py"]["sha256"], "AUTHENTICATED_RECEIPT_TEMPLATE")
    source = renamed(template_raw.decode())
    source = assign(source, dict(HEAD=args.expected_head, TREE=args.expected_tree,
        RETURN_VERIFIER_SHA=proposal["returnVerifierSHA256"], CLONES=tuple(item["directory"] for item in clones), LINUX=linux))
    compile(source, "build_final_receipts28.py", "exec")
    target = RUN / "build_final_receipts28.py"
    with target.open("xb") as stream:
        stream.write(source.encode())
    binding = dict(schema=1, qualification="ACTUAL_FINAL_IDENTITY_BINDING_NOT_ACCEPTANCE", head=args.expected_head,
        tree=args.expected_tree, clones=clones, linuxArtifact=linux, apiSHA256=sha(api_path.read_bytes()),
        linuxExportMetadataSHA256=sha(metadata_path.read_bytes()), helperSHA256=sha(source.encode()),
        acceptanceGranted=False, release="NO_GO")
    with (RUN / "final-binding.json").open("xb") as stream:
        stream.write((json.dumps(binding, sort_keys=True, indent=2) + "\n").encode())
    print(json.dumps(binding, sort_keys=True))


if __name__ == "__main__":
    main()
