# Campaign28 technical report annex — R28-A and R28-B

**Draft factual annex for integration into FINAL_REPORT.md.**
Authority: BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01.
**SUBMITTED_REVIEW_REQUIRED / NO_GO.** This is a supplier engineering report;
the independent Brain retains source acceptance. USD0. NO MERGES. No qualified
Security, database, native, provider, clinical/legal, J01 or release gate opens.

This annex records executed application and source-contract evidence. Final
source HEAD/tree, clean freeze, worklist child, checkpoint tail, final CI,
independent remote final-head clones, artifact/source tamper controls and outer
return ZIP/download evidence are **PENDING_IN_ROOT_FINAL_REPORT**. No claim about
those pending identities or results is made here. The final report must replace
these pending items with actual receipts, refusals or NOT_RUN classifications.

## Classification and exact claims

| Work item | Engineering classification | Bound of the claim |
| --- | --- | --- |
| Confirmed Remove/Discard retires before native invocation when its exact UI/source lease changes | FIXED_AND_PROVED within source and delayed-adapter controls | Latest synchronous admission immediately before native storage invocation; no physical native durability claim |
| Product/outbox preservation for a denied precommit operation | FIXED_AND_PROVED within encrypted adapter controls | Exact previous encrypted Shelf bytes; no native Shelf write or outbox notification |
| UI retirement after native storage invocation | FIXED_AND_PROVED as a refusal to claim cancellation | Committed or still-unsettled native invocation is allowed to settle; no UI-based compensation added; stale publication is suppressed |
| Original health/account/additional-guard and ambiguous-write compensation | PRESERVED_AND_EXERCISED | Existing exact-byte/readback semantics retained; compensation is distinct from UI cancellation |
| Current CORE-05 brittle assertion | FIXED_AND_PROVED as a source-contract correction | Actual TypeScript/TSX structure and lifecycle/import bindings; notification/OS delivery remains outside this claim |
| Physical storage atomicity/durability, termination/relaunch interruption or guaranteed cancellation after native invocation | OPEN_REQUIRED / UNAPPLIED | Requires separately qualified installed-native evidence or atomic native primitives; not established by in-memory ports |
| Current browser dimensions, measured200% text, keyboard/focus/scroll | NOT_RUN | Actual browser-control entry point reported browser use disabled in Work settings |

The broad destructive-operation safety objective therefore retains native and
qualified-owner limitations. FIXED_AND_PROVED identifies only the explicit
source/adapter boundary proved below; it is not self-acceptance or a release
decision.

## Authenticated source and baseline failures

All before evidence uses exact PR31 HEAD
`517b50413b136639413b783cf3e899a6bc6c19ed`, tree
`497f248472f775cef2a9922475fa9f3f62b75060`. Live PR31 was authenticated as
open/draft/unmerged before branch work. Context authentication and the sole
first-child scope plan are covered by the main report, rather than repeated as
implied source acceptance here.

The unchanged historical pending-retirement test has SHA256
`f968bce0a790de48a1ed619af4bfa7bf7ceeb63fa00a5cb61f396d616faa1f9d`.
Its two stronger cases both use Remove: the current user confirms, the first
private Shelf read is held, then either the exact Query source is replaced or
the management UI is unmounted. On original PR31 the item is still removed
after the held read resumes. Separate Discard equivalents reproduce the same
failure interval while checking that the product wrongly becomes discarded.

The independent local separate-object baseline reports **63 tests:59 PASS,
4 FAIL**. All53 original mounted Campaign26 controls, four original primitive
boundary probes and two health-grant controls pass; only the two original
Remove and two additional Discard cases fail. This first review lane reused
existing installed C26 dependencies through explicit test-only junctions; it
did not claim a fresh install.

Root independently repeated this exact baseline after normal fresh `npm ci`
at pinned PR31: **59 PASS/4 FAIL**, exit1, the same four failure titles. Its
receipt records npm-ci exit0 and SHA256 of the actual installation log.
Mandatory postinstall ran and reported view-shot, widgets and tooling-security
patches applied. No package/lockfile/dependency change is part of R28-A/R28-B.

An extended new suite run on unchanged PR31 reported **99 total:66 PASS,
33 FAIL**. It isolates missing pre-native admission and additional stale
publication after native dispatch/canonical refetch. All original failing
receipts and test bytes remain evidence. They are not relabeled as passing.

The unmodified CORE-05 suite was independently run at exact PR31 and returned
**36 tests:35 PASS/1 FAIL**, exit1, zero skips. The original file SHA256 is
`563ef0c862cb57dda6f832af8a20f3f1b84636845b9a2ef115777d53e2c80dff`, Git blob
`880be16d287890c24e3d4e5b3d8de04ccaf7142f`. The failure is the line595 literal
one-argument assertion. The authentic production route SHA256 is
`251ce80f1909871c662948bb33633cb50fa52958615a68be771266f4cb6b4d0b`, blob
`5b1678c414c463575f38a959d501447bcbd21ef5`. Its actual awaited call supplies
`PROPOSED_ROUTINE_REMINDER_TIMES`, `undefined` and `assertLifecycle` in order.
Historical original PR28/PR29 red observations remain unchanged and distinct
from both this PR31 reproduction and canonical SQL CORE-05 checks.

## R28-A state machine and native invocation boundary

The source-grounded state machine is:

1. Capture the current UI, exact Query/snapshot and current health/owner lease
   when the management sheet opens; explicit confirmation admits one operation.
2. Queue behind the original per-key serialized private mutation lock.
3. Read exact encrypted bytes through the original failed-read preservation
   gate; obtain the content key and decrypt under original authority checks.
4. Run the synchronous Shelf transform, preparing the product change and its
   owner-free mirror outbox operation in the same encoded Shelf state.
5. Reread exact raw bytes for serialized conflict detection, then prepare
   key/encryption/envelope data.
6. Reassert original authority and the opt-in current UI/source predicate at
   the final synchronous point immediately before calling native storage.
7. After native storage has been invoked, wait for fulfillment or ambiguous
   rejection. Preserve the existing health/account/additional-guard and
   ambiguous-I/O compensation rules.
8. Reconcile canonical Query readback. Publish success only for the admitted
   current screen after one verified readback transition.

States1–6 are potentially cancellable preparation. The new optional fourth
privateKV callback is asserted during preparation and at the final point with
no intervening await. The callback is threaded only through Shelf
Remove/Discard; unrelated callers retain the prior default behavior.

State7 has already invoked the native API. Neither a pending Promise nor an
adapter-visible value proves physical durability. A later UI/source retirement
does not call the precommit predicate in the original postwrite guard and does
not cause new UI-based compensation. Existing health/account authority and
ambiguous-native failure compensation remain operational, including exact
prior ciphertext preservation and uncertain-readback failure surfacing.

For a denied preparation, actual Shelf setItem calls remain zero, the prior
encrypted product/outbox bytes are identical and no outbox notifier fires. For
an admitted native invocation followed by UI retirement, tests separately hold
the adapter before it writes bytes and after bytes become visible. Both lanes
retain the admitted item/outbox result after settlement with one native Shelf
write and no UI rollback. Stale success navigation is refused.

Canonical publication has a separate lifecycle. After storage fulfillment and
health reassertion, the UI snapshots eligibility before its own invalidation.
Only the same Query object's ordered invalidate→fetch→one nonmanual success
sequence may confirm it, with exactly one dataUpdateCount increment and no
errorUpdateCount change. Query replacement, reset/ABA, manual snapshot writes,
canceled/restarted readback, unmount, errors and health retirement permanently
retire publication. This avoids rejecting valid operations merely because
their own canonical refresh changes the Query source.

An idempotent reinvalidation while that Query is already invalidated produces
no Query state or event transition. Tests explicitly prove unchanged state
identity and zero updated/removed events, then permit the actual canonical
readback to finish. It is not presented as an observable source retirement.
Interception of global QueryClient API intent was not added.

## R28-A executed controls and test-scope audit

The independently repeated original lane passes **192/192**, including the
unchanged historical pending tests and primitive probes, separate Discard
equivalents, all53 original mounted Campaign26 tests and original privateKV,
content-key, Shelf store and mutation-recovery suites. These runs use exact
formatted root production bytes copied into the separate-object PR31 review
checkout; hashes are in `independent-app-review.json`. No reviewer production
source edits occurred.

The new focused suite passed **106/106** before the dedicated restart additions:
52 confirmed/precommit,34 postdispatch/readback and20 storage-boundary cases.
It covers queued-key admission, first read, conflict reread, content-key await,
post-encryption serialization immediately before invocation, native invoked
but unsettled before/after adapter-visible bytes, completed-write stability,
canonical refetch, exact item/outbox bytes, duplicate taps, owner ABA,
same-owner regrant, withdrawal, expiry and actual account-generation transition.
Read/decrypt/key/partial-envelope/encryption failures, serialized conflict,
reject-before-store, store-then-reject and uncertain compensation readback all
have distinct controls.

Original user-cancellation evidence is concrete: Remove callbacks are refused
after Close, backdrop dismissal and native Escape, including callbacks queued
before unmount; closing/reopening does not revive the old callback. A failed
encrypted write permits a fresh explicit Remove retry. Both new actions have
zero-write queued-key retirement controls and repeated-tap controls while
native storage is unsettled. The latter prove one native write and one
additional durable outbox operation, not merely one callback invocation.

**Dedicated pending-operation restart controls: PASS, complete suite108/108.**
Two new test-only controls, one per Remove/Discard, explicitly confirm then
hold the first private read, replace the actual Query snapshot, resume and
require unchanged raw/outbox bytes with zero writes. They then close/reopen
options, prove the old captured callback inert and require one fresh explicit
confirmation, one item/outbox change and canonical success. The actual
`restart-complete-results.json` records108/108:52 confirmed/precommit,
36 postdispatch/readback and20 storage cases. No production edit was required
for these additions. The prior106-case receipts remain separately preserved.

The isolated Close/backdrop/Escape permutations were originally exercised for
Remove; Discard uses the same reviewed close/lifecycle implementation, but
this annex does not invent a separately executed Discard Escape permutation.
This is a test-scope qualification, not evidence of a known source defect.

## R28-B structural correction and runtime preservation

Only the brittle assertion call in the original current contract is replaced;
the other original assertions remain. The appended TypeScript compiler AST
helper binds the actual `NotificationsScreen.finish` enable try-block, exact
awaited callee, exactly three ordered arguments and actual unshadowed imports.
It requires the const accepted authority capture and a synchronous const
lifecycle callback with direct ordered `assertCurrent()` and
`assertHealthDataWriteLease(accepted)` calls. It also verifies the meaningful
current focus/token/navigation/authority refusal predicate and current health
assertion. No production onboarding route or reminder implementation changes.

Mutation controls deny missing/reordered/replaced lifecycle arguments, wrong
proposed times, wrong/missing/unawaited calls, no-op/async/dead lifecycle or
current assertions, missing/reordered/wrong-lease checks, removed focus/token/
navigation predicates, shadowed callee/guard/import/default-dependency bindings,
wrong/aliased imports and a dead enable branch. Each mutation asserts that it
actually changes the authentic route before requiring a structural refusal.
Two positive controls accept the authentic route and harmless call-boundary
whitespace/comments.

The hardened combined Node TAP reports **105/105 pass**, zero skips or todos.
Its unique coverage is the corrected original **36/36** plus **33 new controls**
(31 negative mutations and2 positives). The combined count105 includes the
original36 being registered a second time because the focused test imports
the original test module to reuse its helper. It is not105 unique cases.

The full mobile run also executes the original reminder/notification/runtime
lifecycle suites, including onboarding, reminderBoundary17, preference
read-race, native mutation inventory, delivery and notification response
controls. Source structure and synthetic native adapters do not prove actual
OS permission, scheduling or notification delivery. Canonical SQL CORE-05 is
a separate database suite and does not confer either source or native consent
acceptance.

## Full runtime regression receipt and preserved failures

Root's actual precommit forced repository test command
`node node_modules/turbo/bin/turbo run test --force` returned exit0:
**6,476 mobile tests across499 files;24 operator tests across7 files;2 successful
tasks,0 cache hits**. Its receipt records elapsed49.031 seconds and unchanged
HEAD/tracked diff throughout execution. It identifies a dirty working
candidate above plan HEAD `fda89d90e92b05a094018f07d83077659f847509`, rather than
claiming this as an already frozen final source commit. This full result is
the6370 baseline plus the then-current106 new cases. The two subsequent
restart tests require the root's later full committed-source rerun; **a6478
pass is not inferred here**.

An intermediate100-case review run reported97 pass/3 fail. Its receipts remain.
Two new assertions incorrectly treated the no-op reinvalidation described
above as source retirement; they were transparently replaced with an explicit
unchanged-state/no-event positive plus actual canceled/restarted-refetch
negative. The third attempted an unsupported spy on a nonconfigurable native
ESM export. Its replacement fault-injection wrapper delegates actual chacha
behavior and substitutes only one controlled encryption rejection. No
historical assertion was weakened. The corrected106-case result and original
192-case result were repeated against exact formatted candidate bytes.

Browser control was actually attempted through `await cua.getState()`. The
tool returned no enabled browsers and reported local browser use disabled in
Work settings. Current browser viewport, measured200% text, focus, keyboard,
scroll/confirmation and manual-draft visual execution remain **NOT_RUN**.
Historical browser screenshots and mounted structural geometry are not
current browser or installed-native measurements.

## Evidence index for final packaging

The root packager should assign final manifest-listed paths to these actual
records; their current filenames identify evidence, not public download URLs:

- `baseline-results.json`, `baseline-receipt.json`, original pending/boundary
  test bytes and separate Discard test: independent immutable63-case baseline.
- Root `baseline-fresh-results.json` and `baseline-fresh-receipt.json`:
  fresh-install pinned-PR31 reproduction and normal npm-ci receipt.
- `proposed-baseline-results.json`, `proposed-after-results.json` and
  `proposed-corrected-results.json`: retained extended baseline/intermediate
  test defects and transparent corrections.
- `final-byte-matched-results.json`, `final-original-regression-results.json`,
  `independent-app-review.json`, `INDEPENDENT_APP_REVIEW.md` and
  `reviewed-production.diff`: exact-byte106/192 application review.
- `restart-complete-results.json` and current `independent-app-review.json`:
  actual108/108 including the dedicated fresh restart controls; earlier106
  review receipt remains as `independent-app-review106.json`.
- Governance `core05-baseline-original.tap` and
  `core05-baseline-identity.json`: original35/1 execution and source identities.
- Root `core05-current-hardened28.tap`: actual105 combined executions with
  duplicate-registration qualification above.
- Root `full-test28-precommit.log` and receipt: actual6476+24 forced runtime run.
- Root `npm-ci28.log`, corrected pinned-toolchain receipt and
  `browser28-availability.json`: installation/toolchain/browser qualifications.

All final source/CI/freeze/artifact/bundle/download results remain pending in
this annex. G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03
BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED; J01 optical and
longitudinal gates NOT_ACCEPTED; physical native/VoiceOver, provider, paid,
professional, clinical/legal/licensing, Apple and public release CLOSED.
