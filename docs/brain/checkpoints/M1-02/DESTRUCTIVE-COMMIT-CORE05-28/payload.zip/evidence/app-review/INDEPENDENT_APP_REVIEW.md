# Campaign28 bounded application/storage review

PASS_BOUNDED_TECHNICAL_REVIEW_NOT_BRAIN_ACCEPTANCE. SUBMITTED_REVIEW_REQUIRED / NO_GO.
The independent Brain retains source acceptance. This review grants no native,
Security, clinical, database, provider or release gate. USD0; no merges.

## Source and before evidence

The reviewer created a separate complete local `git clone --no-hardlinks`
checkout, detached at PR31 HEAD `517b50413b136639413b783cf3e899a6bc6c19ed`, tree
`497f248472f775cef2a9922475fa9f3f62b75060`. Git objects are separate. Before any
production-copy edit, tracked status was clean. This independently exercises
the pinned source; it is not a fresh remote final-head clone.

The original Campaign27 `detail-pending-retirement.test.ts` was copied with
identical SHA256 `f968bce0a790de48a1ed619af4bfa7bf7ceeb63fa00a5cb61f396d616faa1f9d`.
Both original stronger Remove cases fail: a confirmed operation waiting inside
its first private Shelf read still writes after exact Query replacement or
modal unmount. A separate Discard translation fails at the same two intervals.
Original53 mounted controls, four original commit-boundary probes and two grant
controls pass. Baseline result: **63 total,59 pass,4 fail**.

The extended new test baseline exercised99 cases against unchanged PR31:
**66 pass,33 fail**. Its failures identify missing pre-native UI admission and
real stale publication during native settlement/canonical refetch. Source was
not altered to manufacture either baseline.

All runs here use the existing C26 root/mobile installed dependency trees via
explicit local junctions. The actual Query, route, Shelf stores/mutations,
owner/consent leases, encryption and codecs run. Native rendering, native
storage, router and absent external transport are test ports. This does not
claim normal fresh installation or installed-device proof.

## Reviewed state machine and source change

Accepted UI/source/health lease → per-key serialized queue → private raw read
and failed-read gate → content-key/decrypt → synchronous transform including
owner-free outbox → conflict reread → key/encryption preparation → final
synchronous admission → native storage invocation → fulfillment or ambiguous
rejection → original authority/compensation handling → canonical Query readback
→ permitted current-screen publication.

The four root-written production files were copied byte-identically into this
review checkout. The reviewer did not edit production source. Exact reviewed
bytes and the root bytes observed when this receipt was written are separately
hashed in `independent-app-review.json`; subsequent formatting or changes
require fresh evidence rather than implying this receipt covers other bytes.

The new fourth optional privateKV callback composes only during preparation.
The latest callback runs synchronously immediately before native setItem, with
no await in between. The original health/additional postwrite guard remains
separate. UI retirement after native invocation does not trigger compensation.
Original account/health and ambiguous-native failure compensation remains.
Old callers omit the new callback; unrelated storage format, keys and account
authority remain unchanged.

Only Remove/Discard threads this optional predicate through the route,
mutation and Shelf store. The same encrypted transaction retains product and
outbox changes together. A denied preparation writes neither and sends no
outbox notification. Once invocation happened, tests distinguish native
unsettled-before-adapter-store and already-adapter-visible bytes; both complete
without UI rollback while stale publication is refused.

Postwrite publication admits only the same Query object's ordered
invalidate→fetch→one nonmanual success transition, with exactly one increment
to dataUpdateCount and unchanged errorUpdateCount. Manual snapshot updates,
Query replacement/reset/ABA, cancellation/restart, errors, unmount and health
retirement prevent stale success. Canonical readback failure never reports
success even when bytes remain committed.

## Executed after evidence

The corrected new suite passes **106/106**. Controls cover queued admission,
first read, conflict read, content-key preparation, final encrypted-envelope
serialization immediately before invocation; Query replacement/ABA, unmount,
owner ABA/same-owner regrant, grant expiry/withdrawal and actual account
generation transition; native invocation before/after adapter-visible storage;
postfulfillment stability, duplicate taps and exact item/outbox transactions;
canonical refetch retirement, no-op reinvalidation and uncertain readback;
partial/missing/invalid-key/tampered-ciphertext/read/encryption failures;
serialized conflict refusal; original additional/health compensation and
native reject-before-store/store-then-reject/uncertain-compensation behavior.

An independently executed original regression lane passes **192/192**: the
unchanged historical pending tests and boundary probes, separate Discard
equivalents, all53 original C26 mounted tests, and original privateKV,
content-key, Shelf store and mutation-recovery suites.

Both lanes were then repeated against exact formatted production bytes copied
from root: `final-byte-matched-results.json` **106/106**, and
`final-original-regression-results.json` **192/192**. The formatted versions
also matched the earlier reviewed TypeScript ASTs. Final receipt source hashes
refer to these repeated executions, not to the preceding formatting variant.

Two dedicated restart controls were then added without production edits. The
complete focused suite now passes **108/108**, preserved in
`restart-complete-results.json`. For both Remove and Discard, an explicitly
confirmed private-read operation is retired by a real Query snapshot change;
resumption preserves exact raw/outbox bytes with zero writes. Close/reopen
cannot revive its old callback, while one fresh explicit confirmation commits
one item/outbox change and publishes canonical success. The earlier106 receipt
is retained separately as `independent-app-review106.json`.

An intermediate100-case run reported97 pass/3 fail. Those bytes/results remain
preserved. Two new assertions treated an idempotent reinvalidation of an
already-invalidated Query as source retirement; actual Query state identity
and event counters prove this request produces no observable transition. The
corrected suite retains an explicit no-op positive and separately tests a
real canceled/restarted refetch negative. The third attempted to spy on a
nonconfigurable native ESM export; its corrected fault-injection wrapper
delegates all actual chacha behavior and substitutes only one controlled
encryption rejection. No original historical assertion was edited.

## Remaining limits

The guarantee ends at native API invocation. Adapter tests do not establish
physical iOS/Android durability, native atomic transactions, process-death
behavior or installed-native rollback. Previously existing health/account or
ambiguous-I/O compensation is not recast as UI cancellation. A no-op API call
with no Query transition cannot be classified as source retirement through the
granted route-local source API. Full fresh installs, final source/CI/governance,
independent remote final clones and Brain acceptance remain separate root
validation; this review does not replace them. All qualified gates remain
closed and G97 remains FAIL/NO_GO.
