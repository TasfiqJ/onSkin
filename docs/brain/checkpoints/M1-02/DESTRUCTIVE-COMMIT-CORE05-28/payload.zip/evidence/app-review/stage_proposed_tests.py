import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
mobile=SOURCE/'apps/mobile'
for name in ['confirmedDestructive28.test.ts','postDispatchCommit28.test.ts','destructiveCommit28TestPorts.ts','privateKVCommitFence28.test.ts']:
    dest=mobile/'src'/('lib/storage' if name.startswith('privateKV') else 'features/shelf')/name
    dest.write_bytes((ROOT/'proposed'/name).read_bytes())
config=json.loads((ROOT/'baseline.config.mjs').read_text().removeprefix('export default ').removesuffix(';\n'))
config['cacheDir']=(ROOT/'proposed-vite-cache').as_posix()
config['test']['include']=[(mobile/'src/features/shelf'/n).as_posix() for n in ['confirmedDestructive28.test.ts','postDispatchCommit28.test.ts']]+[(mobile/'src/lib/storage/privateKVCommitFence28.test.ts').as_posix()]
(ROOT/'proposed.config.mjs').write_text('export default '+json.dumps(config,indent=2)+';\n',encoding='utf-8')
print('STAGED_DISPOSABLE_REVIEW_TESTS_ONLY')
