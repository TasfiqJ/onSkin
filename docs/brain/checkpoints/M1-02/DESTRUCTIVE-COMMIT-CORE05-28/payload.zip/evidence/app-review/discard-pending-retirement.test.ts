import { randomUUID } from 'node:crypto';
import { createElement, StrictMode } from 'react';
import { QueryClientProvider, type QueryClient } from '@tanstack/react-query';
import { act, create, type ReactTestInstance, type ReactTestRenderer } from 'react-test-renderer';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

import { close26, flush26, grant26, ports26, profile26, reset26 } from '@/features/shelf/firstValue26TestPorts';
import ProductDetailScreen from '@/app/shelf/[id]';
import ShelfLayout from '@/app/shelf/_layout';
import { IntakeProvider } from '@/features/shelf/IntakeContext';
import { addProduct, loadShelf } from '@/features/shelf/store';
import type { useShelf } from '@/features/shelf/useShelf';
import { clearActiveHealthProcessingEpoch } from '@/lib/consent/healthProcessingEpoch';

// Actual route, layout, Query, authority, encrypted Shelf and mutations. Only
// native rendering/storage/router/absent external transport are platform ports.
let client: QueryClient;
let screen: ReactTestRenderer | undefined;
let id: string;
type Source = NonNullable<ReturnType<typeof useShelf>['data']>;
const productName = 'Synthetic long product name '.repeat(4).trim();
function button(label: string): ReactTestInstance {
  const found = screen!.root
    .findAllByType('Pressable' as never)
    .find(
      (node) =>
        node.props.accessibilityLabel === label ||
        node.findAllByType('Text' as never).some((text) => text.props.children === label),
    );
  expect(found, label).toBeDefined();
  return found!;
}
async function press(label: string) {
  await act(async () => {
    button(label).props.onPress();
  });
  await flush26();
}
async function mount() {
  ports26.params = { id };
  ports26.routeName = '[id]';
  ports26.routeChild = createElement(ProductDetailScreen);
  await act(async () => {
    screen = create(
      createElement(
        StrictMode,
        null,
        createElement(
          QueryClientProvider,
          { client },
          createElement(IntakeProvider, null, createElement(ShelfLayout)),
        ),
      ),
    );
  });
  for (let n = 0; n < 10 && !client.getQueryData(['shelf']); n++) await flush26();
  await flush26();
}
async function open() {
  await press('More options');
}
async function rows() {
  return loadShelf();
}
beforeEach(async () => {
  client = await reset26();
  await profile26();
  const product = await addProduct({
    operationId: randomUUID(),
    name: productName,
    category: 'moisturiser',
    addedVia: 'manual',
  });
  id = product.id;
});
afterEach(async () => {
  if (screen)
    await act(async () => {
      screen!.unmount();
    });
  screen = undefined;
  vi.restoreAllMocks();
  await close26(client);
});


it('cancels a previously confirmed pending private write when its owner/grant retires before commit', async () => {
  await mount(); await open();
  const before = ports26.bytes.get('layerwell.shelf.v1');
  ports26.holdRead = 'layerwell.shelf.v1';
  await act(async () => button('Mark discarded').props.onPress());
  await flush26();
  expect(ports26.release).toBeTypeOf('function');
  await act(async () => grant26());
  ports26.release?.();
  await flush26(); await flush26();
  expect(ports26.bytes.get('layerwell.shelf.v1')).toBe(before);
  expect(ports26.back).not.toHaveBeenCalled();
});

it('cancels a pending Discard commit if the exact source Query retires after confirmation but before private read finishes', async () => {
  await mount(); await open();
  const before = ports26.bytes.get('layerwell.shelf.v1');
  const data = client.getQueryData<Source>(['shelf'])!;
  ports26.holdRead = 'layerwell.shelf.v1';
  await act(async () => button('Mark discarded').props.onPress());
  await flush26();
  expect(ports26.release).toBeTypeOf('function');
  await act(async () => {
    client.removeQueries({ queryKey: ['shelf'], exact: true });
    client.setQueryData(['shelf'], data);
  });
  ports26.release?.();
  await flush26(); await flush26();
  const stored = await rows();
  expect(stored).toHaveLength(1);
  expect(stored[0]?.status).toBe('active');
  expect(ports26.bytes.get('layerwell.shelf.v1')).toBe(before);
});

it('cancels a pending Discard commit when the confirmation is unmounted before private read finishes', async () => {
  await mount(); await open();
  ports26.holdRead = 'layerwell.shelf.v1';
  await act(async () => button('Mark discarded').props.onPress());
  await flush26();
  expect(ports26.release).toBeTypeOf('function');
  await act(async () => screen!.unmount()); screen = undefined;
  ports26.release?.();
  await flush26(); await flush26();
  expect((await rows())[0]?.status).toBe('active');
  expect(ports26.back).not.toHaveBeenCalled();
});
