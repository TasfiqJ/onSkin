import hashlib
import json
import subprocess
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
PRIOR=ROOT.parent/'campaign27-run-taxf1ogb'/'app-evidence'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git','-C',str(SOURCE),*args],text=True).strip()
assert git('rev-parse','HEAD')=='517b50413b136639413b783cf3e899a6bc6c19ed'
assert git('rev-parse','HEAD^{tree}')=='497f248472f775cef2a9922475fa9f3f62b75060'
assert not git('status','--porcelain=v1','--untracked-files=all')
original=(PRIOR/'detail-pending-retirement.test.ts').read_bytes()
assert hashlib.sha256(original).hexdigest()=='f968bce0a790de48a1ed619af4bfa7bf7ceeb63fa00a5cb61f396d616faa1f9d'
(ROOT/'historical-pending-retirement.test.ts').write_bytes(original)
discard=original.decode().replace("button('Remove completely')", "button('Mark discarded')").replace('pending destructive commit', 'pending Discard commit')
discard=discard.replace('expect(stored).toHaveLength(1);',"expect(stored).toHaveLength(1);\n  expect(stored[0]?.status).toBe('active');")
discard=discard.replace('expect(await rows()).toHaveLength(1);',"expect((await rows())[0]?.status).toBe('active');")
(ROOT/'discard-pending-retirement.test.ts').write_text(discard,encoding='utf-8')
(ROOT/'historical-commit-boundary.test.ts').write_bytes((PRIOR/'commit-boundary.test.ts').read_bytes())
mobile=SOURCE/'apps/mobile'
config={'root':mobile.as_posix(),'cacheDir':(ROOT/'vite-cache').as_posix(),'resolve':{'alias':{'@':(mobile/'src').as_posix(),**{n:(SOURCE/'node_modules'/n).as_posix() for n in ['react','react-test-renderer','@tanstack/react-query']},'vitest':(SOURCE/'node_modules/vitest/dist/index.js').as_posix()}},'test':{'environment':'node','include':[(ROOT/n).as_posix() for n in ['historical-pending-retirement.test.ts','discard-pending-retirement.test.ts','historical-commit-boundary.test.ts']]+[(mobile/'src/features/shelf'/n).as_posix() for n in ['detailActionSheet.campaign26.test.ts','manualDraftRecovery.campaign26.test.ts']]}}
(ROOT/'baseline.config.mjs').write_text('export default '+json.dumps(config,indent=2)+';\n',encoding='utf-8')
argv=['node',str(SOURCE/'node_modules/vitest/vitest.mjs'),'run','--config',str(ROOT/'baseline.config.mjs'),'--reporter=json','--outputFile',str(ROOT/'baseline-results.json')]
start=time.monotonic()
with (ROOT/'baseline.stdout.log').open('w',encoding='utf-8') as out,(ROOT/'baseline.stderr.log').open('w',encoding='utf-8') as err:
    proc=subprocess.run(argv,cwd=SOURCE,stdout=out,stderr=err)
receipt={'argv':argv,'returncode':proc.returncode,'elapsedSeconds':time.monotonic()-start,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'tracked_diff':git('diff','--stat'),'freshInstall':False,'dependencyQualification':'Existing c26-final-a-8c02r2 root/mobile installed dependencies through explicit local junctions; independent exact PR31 source clone with separate objects; not fresh installed or native proof.','hashes':{p.name:sha(p) for p in ROOT.iterdir() if p.is_file() and p.name!='baseline-receipt.json'}}
(ROOT/'baseline-receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({'returncode':proc.returncode,'head':receipt['head'],'tree':receipt['tree'],'results':str(ROOT/'baseline-results.json')}))
