"""Emit reviewed Release28 proposal files OUTSIDE the integration checkout.

Root alone copies reviewed proposals into its source tree. Rerun after any
reviewed substantive commit so its exact immutable predecessor is registered.
"""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import textwrap

BASE = '517b50413b136639413b783cf3e899a6bc6c19ed'
TREE = '497f248472f775cef2a9922475fa9f3f62b75060'
PLAN_COMMIT = 'fda89d90e92b05a094018f07d83077659f847509'
TERMINAL = b"if __name__ == '__main__':\n    sys.exit(main())\n"
CHECK = 'scripts/release/full-app-j01/check.py'
HERE = Path(__file__).resolve().parent

def sha(raw): return hashlib.sha256(raw).hexdigest()
def git(root, *args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root)
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value.encode() if isinstance(value, str) else value)
def literal(value):
    if isinstance(value,set): return '{'+', '.join(repr(item) for item in sorted(value))+'}' if value else 'set()'
    if isinstance(value,dict): return '{'+', '.join(repr(key)+': '+literal(item) for key,item in sorted(value.items()))+'}'
    return repr(value)
def replace_assignment(source, name, value):
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
    lines = source.splitlines(keepends=True)
    lines[node.lineno-1:node.end_lineno] = [name+' = '+literal(value)+'\n']
    return ''.join(lines)
def replace_function(source, name, replacement):
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = source.splitlines(keepends=True)
    lines[node.lineno-1:node.end_lineno] = [replacement.rstrip()+'\n']
    return ''.join(lines)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-root', type=Path, default=HERE.parent/'campaign28-source')
    parser.add_argument('--output', type=Path, default=HERE/'proposal28')
    args = parser.parse_args(); root=args.source_root.resolve(); out=args.output.resolve()
    assert not out.is_relative_to(root)
    before=git(root,'show',BASE+':'+CHECK)
    assert before.endswith(TERMINAL)
    old=before.decode()
    extension=old[old.index('# Release27 successor.'): -len(TERMINAL)]
    names={node.name for node in ast.parse(old).body if isinstance(node,ast.FunctionDef) and '27' in node.name}
    runner=git(root,'show',BASE+':scripts/release/full-app-j01/replay27.py').decode()
    names |= {node.name for node in ast.parse(runner).body if isinstance(node,ast.FunctionDef) and '27' in node.name}
    names |= {'PINNED27','LOCK27_SHA256','POSTINSTALL27_SHA256','NATIVE27_PINS_SHA256','original_reader_domain27','source27'}
    def rename(source):
        for name in sorted(names,key=len,reverse=True):
            source=re.sub(r'\b'+name+r'\b',name.replace('27','28'),source)
        return source.replace('RELEASE27_','RELEASE28_').replace('R27_','R28_').replace('Release27','Release28').replace('release27','release28').replace('M1X-27','M1X-28').replace('FIRST-VALUE-SAFETY-CI-27','DESTRUCTIVE-COMMIT-CORE05-28').replace('verify27.py','verify28.py').replace('source27.v1','source28.v1').replace('source_consumer27','source_consumer28')
    extension=rename(extension)
    extension=extension.replace('Every inherited Release08-26 byte/definition','Every inherited Release08-27 byte/definition')
    extension=extension.replace('stage/m1-first-value-safety-ci27','stage/m1-destructive-commit-core05-28').replace('stage/m1-first-value-recovery26','stage/m1-first-value-safety-ci27')
    extension=extension.replace('if not current: return validate26(bundle)','if not current: return validate27(bundle)')
    extension=extension.replace("inherited_release26='IMMUTABLE_PR30_DEFINITIONS", "inherited_release27='IMMUTABLE_PR31_DEFINITIONS")
    plan_path='docs/brain/task-specs/M1X-28/SCOPE_PLAN.md'
    plan=git(root,'show',PLAN_COMMIT+':'+plan_path)
    blocks=re.findall(rb'```json\n(.*?)\n```',plan,re.S); assert len(blocks)==1
    paths=json.loads(blocks[0]); assert isinstance(paths,list) and len(paths)==len(set(paths))==27
    existing=set(git(root,'ls-tree','-r','--name-only',BASE).decode().splitlines())
    app={p for p in paths if p.startswith('apps/')};newapp=app-existing;oldapp=app&existing
    other=set(paths)-app
    def scope():
        return '''def scope28_guard(raw):
    require(type(raw) is bytes and len(raw) == PLAN_BYTES and sha(raw) == RELEASE28_PLAN_SHA256, 'R28_PLAN_IDENTITY')
    blocks = re.findall(rb'```json\\n(.*?)\\n```', raw, re.S)
    require(len(blocks) == 1, 'R28_PLAN_SCHEMA')
    value = json.loads(blocks[0], object_pairs_hook=pairs,
        parse_constant=lambda _: require(False, 'R28_NONFINITE_JSON'))
    expected = RELEASE28_EXISTING_APP | RELEASE28_NEW_APP | RELEASE28_OTHER_EXISTING | RELEASE28_OTHER_NEW
    require(type(value) is list and all(type(p) is str for p in value) and
        len(value) == len(set(value)) == len(expected) and set(value) == expected, 'R28_AUTHENTIC_FINITE_GRANT')
    identities = {}
    for path in value: name28(path, identities)
    require(len(RELEASE28_EXISTING_APP) == 4 and len(RELEASE28_NEW_APP) == 4, 'R28_APP_PATH_BUDGET')
    return value
'''.replace('PLAN_BYTES',str(len(plan)))
    extension=replace_function(extension,'scope28_guard',scope())
    working='''def working28_guard(index, permitted=()):
    """Raw tracked bytes and same-API metadata; access times alone may change."""
    def snapshot(info):
        return {name: getattr(info, name) for name in dir(info) if name.startswith('st_') and
            name not in ('st_atime', 'st_atime_ns') and isinstance(getattr(info, name), (int, float))}
    def compatible(path, named, opened):
        fields = ('st_dev', 'st_ino', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_uid', 'st_gid')
        if not all(getattr(named, name) == getattr(opened, name) for name in fields): return False
        if os.name == 'nt':
            execute = 0o111 if path.suffix.lower() in ('.exe', '.com', '.bat', '.cmd') else 0
            if opened.st_mode & 0o111 or named.st_mode != opened.st_mode | execute: return False
        elif named.st_mode != opened.st_mode: return False
        for name in ('st_file_attributes', 'st_reparse_tag', 'st_birthtime_ns'):
            if hasattr(named, name) and hasattr(opened, name) and getattr(named, name) != getattr(opened, name): return False
        # ctime is compared within each API domain below. On Windows pathname
        # creation time and handle change time need not represent the same event.
        return True
    permitted = set(permitted); checked = 0; directories = set(ROOT.parents) | {ROOT}
    for path in index:
        parent = (ROOT/path).parent
        while parent not in directories:
            directories.add(parent); parent = parent.parent
    parents = {}
    for parent in directories:
        info = parent.lstat()
        require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
            not getattr(info, 'st_file_attributes', 0) & 1024, 'R28_WORKING_PATH')
        parents[parent] = (info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None))
    for path, (mode, oid) in index.items():
        target = ROOT/path; before = target.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and not stat.S_ISLNK(before.st_mode) and
            not getattr(before, 'st_file_attributes', 0) & 1024 and before.st_size <= 128*1024*1024, 'R28_WORKING_REGULAR')
        descriptor = os.open(target, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
        try:
            opened = os.fstat(descriptor)
            require(compatible(target, before, opened), 'R28_WORKING_CHANGED')
            digest = hashlib.sha1(('blob '+str(before.st_size)+'\\0').encode()); total = 0
            while True:
                block = os.read(descriptor, min(1024*1024, before.st_size-total+1))
                if not block: break
                total += len(block)
                require(total <= before.st_size, 'R28_WORKING_CHANGED')
                digest.update(block)
            finished = os.fstat(descriptor)
        finally: os.close(descriptor)
        after = target.lstat()
        require(total == before.st_size and snapshot(opened) == snapshot(finished) and
            snapshot(before) == snapshot(after) and compatible(target, after, finished), 'R28_WORKING_CHANGED')
        actual = digest.hexdigest()
        require(actual == oid or path in permitted, 'R28_WORKING_BLOB')
        checked += 1
    for parent, expected in parents.items():
        info = parent.lstat()
        require((info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None)) == expected and
            not getattr(info, 'st_file_attributes', 0) & 1024, 'R28_WORKING_PATH')
    return checked
'''
    start=working.index('    def snapshot(info):')
    finish=working.index('    permitted = set(permitted);',start)
    helpers=textwrap.dedent(working[start:finish]).replace('def snapshot(', 'def snapshot28(').replace('def compatible(', 'def compatible28_metadata(')
    working=working[:start]+working[finish:]
    working=working.replace('snapshot(', 'snapshot28(').replace('compatible(', 'compatible28_metadata(')
    regular='''def regular28(path, limit=128*1024*1024):
    """New current public reader; inherited readers remain immutable."""
    require(isinstance(path, Path) and path.is_absolute() and type(limit) is int and
        0 <= limit <= 128*1024*1024, 'R23_PUBLIC_BOUND')
    try:
        ancestors = []
        for parent in path.parents:
            info = parent.lstat()
            require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
                not getattr(info, 'st_file_attributes', 0) & 1024, 'R23_PUBLIC_PATH')
            ancestors.append((parent, info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None)))
        before = path.lstat()
        require(stat.S_ISREG(before.st_mode) and not stat.S_ISLNK(before.st_mode) and before.st_nlink == 1 and
            not getattr(before, 'st_file_attributes', 0) & 1024, 'R23_PUBLIC_FILE')
        require(0 <= before.st_size <= limit, 'R23_PUBLIC_BOUND')
        descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
        try:
            opened = os.fstat(descriptor)
            require(compatible28_metadata(path, before, opened), 'R23_PUBLIC_CHANGED')
            pieces = []; total = 0
            while True:
                chunk = os.read(descriptor, min(65536, before.st_size-total+1))
                if not chunk: break
                total += len(chunk)
                require(total <= before.st_size and total <= limit, 'R23_PUBLIC_BOUND')
                pieces.append(chunk)
            finished = os.fstat(descriptor)
        finally: os.close(descriptor)
        current = path.lstat()
        require(snapshot28(opened) == snapshot28(finished) and snapshot28(before) == snapshot28(current) and
            compatible28_metadata(path, current, finished) and total == before.st_size, 'R23_PUBLIC_CHANGED')
        for parent, device, inode, mode, reparse in ancestors:
            info = parent.lstat()
            require((info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None)) ==
                (device, inode, mode, reparse) and not getattr(info, 'st_file_attributes', 0) & 1024, 'R23_PUBLIC_PATH')
        return b''.join(pieces)
    except OSError:
        raise ValueError('R23_PUBLIC_READ_INCOMPLETE') from None
'''
    extension=replace_function(extension,'working28_guard',working)
    extension=extension.replace('regular23(', 'regular28(')
    extension=helpers+'\n'+regular+'\n'+extension
    extension=extension.replace("functions = {'name28',", "functions = {'snapshot28', 'compatible28_metadata', 'regular28', 'name28',")
    # Known old source versions are exact authenticated Git transitions, never
    # arbitrary working bytes or an unregistered prior authority escape hatch.
    previous={}
    for commit in git(root,'rev-list','--reverse',BASE+'..HEAD').decode().splitlines():
        if commit==PLAN_COMMIT: continue
        parent=git(root,'rev-parse',commit+'^').decode().strip()
        changed=set(git(root,'diff','--name-only',BASE,commit).decode().splitlines())
        assert changed <= set(paths)
        files={}
        for path in sorted(changed):
            raw=git(root,'show',commit+':'+path)
            meta=git(root,'ls-tree',commit,'--',path).decode().strip().split(maxsplit=3)
            assert meta[0]=='100644'
            if path==CHECK: assert raw.startswith(before[:-len(TERMINAL)]) and raw.endswith(TERMINAL)
            files[path]=dict(mode=meta[0],blob=meta[2],sha256=sha(raw))
        previous[commit]=dict(commit=commit,tree=git(root,'rev-parse',commit+'^{tree}').decode().strip(),parent=parent,
            parentTree=git(root,'rev-parse',parent+'^{tree}').decode().strip(),files=files)
    extension=extension.replace("previous = RELEASE28_PREVIOUS_GOVERNANCE\n    prior = at_commit == previous['commit']",
        "previous = RELEASE28_PREVIOUS_GOVERNANCE.get(at_commit)\n    prior = previous is not None")
    # Keep the existing per-path provenance and exact original checker-prefix
    # checks even for the literal historical registry.
    extension=extension.replace("if prior and path in previous['files']:\n            pin", "if prior and path in previous['files']:\n            if path == 'scripts/release/full-app-j01/check.py':\n                inherited = git23('show', RELEASE28_BASE+':'+path)\n                terminal = b\"if __name__ == '__main__':\\n    sys.exit(main())\\n\"\n                require(data.startswith(inherited[:-len(terminal)]) and data.endswith(terminal), 'R28_INHERITED_BYTES')\n            pin")
    extension=extension.replace("        permitted = RELEASE28_EXISTING_APP | RELEASE28_NEW_APP | {'docs/USER_FLOW_TREE.md',\n            'scripts/release/full-app-j01/check.py', RELEASE28_CANDIDATE, 'scripts/release/full-app-j01/source_consumer28.test.py',\n            '.github/workflows/security-candidate22.yml', 'docs/brain/task-specs/M1X-28/TASK.md',\n            'scripts/release/full-app-j01/replay28.py', 'scripts/release/full-app-j01/replay28.test.py'}",
        "        permitted = (RELEASE28_EXISTING_APP | RELEASE28_NEW_APP | RELEASE28_OTHER_EXISTING | RELEASE28_OTHER_NEW) - (RELEASE28_WORKLIST | {RELEASE28_CHECKPOINT+n for n in RELEASE28_CHECKPOINT_FILES} | {RELEASE28_PLAN, 'ONSKIN_BRAIN_HANDOFF.txt'})")
    consumer=rename(git(root,'show',BASE+':scripts/release/full-app-j01/source_consumer27.test.py').decode())
    consumer=consumer.replace('stage/m1-first-value-safety-ci27','stage/m1-destructive-commit-core05-28').replace('stage/m1-first-value-recovery26','stage/m1-first-value-safety-ci27')
    consumer=consumer.replace("with patch.object(check,'validate26',return_value=", "with patch.object(check,'validate27',return_value=")
    start=consumer.index('    # Published f20a58c')
    end=consumer.index("    common=Path(check.git23",start)
    registry_controls='''    for prior in check.RELEASE28_PREVIOUS_GOVERNANCE.values():
        prior_raw=check.git23('diff','--raw','--no-abbrev','--no-renames','-z',prior['parent'],prior['commit'])
        old_read=lambda path:check.git23('show',prior['commit']+':'+path)
        expect('authentic-published-prior-transition-only',lambda:check.validate28_diff(prior_raw,old_read,prior['parent'],at_commit=prior['commit']),success=True)
        cumulative=check.git23('diff','--raw','--no-abbrev','--no-renames','-z',check.RELEASE28_BASE,prior['commit'])
        expect('authentic-published-prior-cumulative-only',lambda:check.validate28_diff(cumulative,old_read,at_commit=prior['commit']),success=True)
        expect('prior-transition-cannot-be-working',lambda:check.validate28_diff(prior_raw,old_read,prior['parent'],working=True,at_commit=prior['commit']),'R28_PRIOR_CONTEXT')
        expect('prior-transition-wrong-parent',lambda:check.validate28_diff(prior_raw,old_read,'0'*40,at_commit=prior['commit']),'R28_PRIOR_CONTEXT')
        expect('prior-transition-raw-byte-corruption',lambda:check.validate28_diff(prior_raw+b'\\0',old_read,prior['parent'],at_commit=prior['commit']),'R28_PRIOR_TRANSITION')
        with patch.dict(prior,{'tree':'0'*40}):
            expect('prior-tree-identity-refuted',lambda:check.validate28_diff(prior_raw,old_read,prior['parent'],at_commit=prior['commit']),'R28_PRIOR_IDENTITY')

'''
    consumer=consumer[:start]+registry_controls+consumer[end:]
    metadata_controls='''    # Exercise the actual new current readers with a real file and descriptor.
    # Synthetic stat observations challenge metadata domains; bytes are real.
    with tempfile.TemporaryDirectory(prefix='release28-working-metadata-') as temp:
        metadata_root=Path(temp);target=metadata_root/'fixture.txt';body=b'actual complete tracked bytes\\n';target.write_bytes(body)
        oid=hashlib.sha1(('blob '+str(len(body))+'\\0').encode()+body).hexdigest()
        index={'fixture.txt':('100644',oid)}
        def info28(info, **changed):
            result=Module();result.__dict__={name:getattr(info,name) for name in dir(info) if name.startswith('st_')}
            result.__dict__.update(changed);return result
        real_os=check.os
        with patch.object(check,'ROOT',metadata_root):
            expect('actual-working-complete-read-positive',lambda:check.working28_guard(index),success=True)
            for field in ('st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_file_attributes','st_reparse_tag','st_birthtime_ns','st_added_numeric_canary'):
                calls=[0]
                def changed_handle(descriptor,field=field):
                    info=real_os.fstat(descriptor);calls[0]+=1
                    return info28(info,**{field:getattr(info,field,0)+1}) if calls[0]==2 else info
                proxy=Module();proxy.__dict__={**real_os.__dict__,'fstat':changed_handle}
                with patch.object(check,'os',proxy):
                    expect('same-domain-handle-metadata-mutation:'+field,lambda:check.working28_guard(index),'R28_WORKING_CHANGED')
            calls=[0]
            def accessed_handle(descriptor):
                info=real_os.fstat(descriptor);calls[0]+=1
                return info28(info,st_atime=info.st_atime+1,st_atime_ns=info.st_atime_ns+1) if calls[0]==2 else info
            proxy=Module();proxy.__dict__={**real_os.__dict__,'fstat':accessed_handle}
            with patch.object(check,'os',proxy):
                expect('only-read-induced-access-time-change-admitted',lambda:check.working28_guard(index),success=True)
            def different_ctime_domain(descriptor):
                info=real_os.fstat(descriptor);result=info28(info,st_ctime=info.st_ctime+100,st_ctime_ns=info.st_ctime_ns+100000000000)
                for field in ('st_birthtime','st_birthtime_ns'):result.__dict__.pop(field,None)
                return result
            proxy=Module();proxy.__dict__={**real_os.__dict__,'name':'nt','fstat':different_ctime_domain}
            with patch.object(check,'os',proxy):
                expect('Windows-distinct-ctime-domains-without-birthtime-admitted',lambda:check.working28_guard(index),success=True)
            proxy=Module();proxy.__dict__={**real_os.__dict__,'read':lambda *_:b''}
            with patch.object(check,'os',proxy):
                expect('actual-working-incomplete-read-refused',lambda:check.working28_guard(index),'R28_WORKING_CHANGED')
            expect('actual-regular-complete-read-positive',lambda:check.require(check.regular28(target)==body,'R23_PUBLIC_CHANGED'),success=True)
            for field in ('st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_file_attributes','st_reparse_tag','st_birthtime_ns','st_added_numeric_canary'):
                calls=[0]
                def changed_regular_handle(descriptor,field=field):
                    info=real_os.fstat(descriptor);calls[0]+=1
                    return info28(info,**{field:getattr(info,field,0)+1}) if calls[0]==2 else info
                proxy=Module();proxy.__dict__={**real_os.__dict__,'fstat':changed_regular_handle}
                with patch.object(check,'os',proxy):
                    expect('regular-same-domain-handle-metadata-mutation:'+field,lambda:check.regular28(target),'R23_PUBLIC_CHANGED')
            calls=[0]
            proxy=Module();proxy.__dict__={**real_os.__dict__,'fstat':accessed_handle}
            with patch.object(check,'os',proxy):
                expect('regular-access-time-only-admitted',lambda:check.require(check.regular28(target)==body,'R23_PUBLIC_CHANGED'),success=True)
            proxy=Module();proxy.__dict__={**real_os.__dict__,'name':'nt','fstat':different_ctime_domain}
            with patch.object(check,'os',proxy):
                expect('regular-Windows-ctime-domains-without-birthtime-admitted',lambda:check.require(check.regular28(target)==body,'R23_PUBLIC_CHANGED'),success=True)
            proxy=Module();proxy.__dict__={**real_os.__dict__,'read':lambda *_:b''}
            with patch.object(check,'os',proxy):
                expect('actual-regular-incomplete-read-refused',lambda:check.regular28(target),'R23_PUBLIC_CHANGED')

'''
    consumer=consumer.replace("    common=Path(check.git23",metadata_controls+"    common=Path(check.git23",1)
    anchor="        put(check.RELEASE28_PLAN,plan+b'\\n');changed=commit(authentic);head(changed)"
    extra='''        weakened=copy.deepcopy(candidate);weakened['admissions']['G97']=True
        put(check.RELEASE28_CANDIDATE,encoded(weakened));changed=commit(authentic)
        git('read-tree',authentic_tree);restored=commit(changed);head(restored)
        expect('intermediate-policy-weakened-then-restored',check.source28_history,'R28_NO_ADMISSION');restore_index()
        git('update-index','--force-remove','.github/workflows/security.yml');deleted=commit(authentic)
        git('read-tree',authentic_tree);readded=commit(deleted);head(readded)
        expect('protected-deletion-readdition-history',check.source28_history,'R28_FINITE_SCOPE');restore_index()
'''
    assert anchor in consumer;consumer=consumer.replace(anchor,extra+anchor)
    # The original reader diagnostics retain the unchanged24/25/26 pins. Add
    # original27 as the fourth authentic full-checkout historical execution.
    runner=rename(runner)
    pin27=dict(release=27,head=BASE,tree=TREE,branch='stage/m1-first-value-safety-ci27',
        checkerSHA256=sha(before),checkerBlob=git(root,'rev-parse',BASE+':'+CHECK).decode().strip(),
        consumerSHA256=sha(git(root,'show',BASE+':scripts/release/full-app-j01/source_consumer27.test.py')),
        consumerBlob=git(root,'rev-parse',BASE+':scripts/release/full-app-j01/source_consumer27.test.py').decode().strip(),
        positiveControls=26,refusals=198,qualification='SYNTHETIC_GIT_AND_SCHEMA_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_APP_PRIVACY_PROOF')
    # PINNED source uses dict(...) calls; preserve its original24/25/26 literal
    # spelling rather than evaluating packet code to collect them.
    pin_node=next(n for n in ast.parse(runner).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='PINNED28')
    lines=runner.splitlines(keepends=True)
    lines[pin_node.end_lineno-1:pin_node.end_lineno-1]=['    '+repr(pin27)+',\n']
    runner=''.join(lines)
    runner=runner.replace("len(records)==3,'R28_RECEIPT_RECORDS'", "len(records)==4,'R28_RECEIPT_RECORDS'")
    runner=replace_function(runner,'cross28','''def cross28(path, named, opened):
    fields = ('st_dev', 'st_ino', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_uid', 'st_gid')
    if not all(getattr(named, field) == getattr(opened, field) for field in fields): return False
    if os.name == 'nt':
        execute = 0o111 if Path(path).suffix.lower() in ('.exe', '.com', '.bat', '.cmd') else 0
        if opened.st_mode & 0o111 or named.st_mode != opened.st_mode | execute: return False
    elif named.st_mode != opened.st_mode: return False
    for field in ('st_file_attributes', 'st_reparse_tag', 'st_birthtime_ns'):
        if hasattr(named, field) and hasattr(opened, field) and getattr(named, field) != getattr(opened, field): return False
    # All ctime mutation checks remain within the pathname or handle API domain.
    return True
''')
    test=rename(git(root,'show',BASE+':scripts/release/full-app-j01/replay27.test.py').decode())
    test=test.replace("case('comparable-ctime-mismatch',lambda:replay.require28(not replay.cross28(target,before,altered(opened,st_ctime_ns=opened.st_ctime_ns+1)),'R28_TEST'))",
        "case('ctime-domains-independent-without-birthtime',lambda:replay.require28(replay.cross28(target,before,altered(opened,st_ctime_ns=opened.st_ctime_ns+1)),'R28_TEST'))")
    reader_extra='''        no_birth=altered(opened,st_ctime_ns=opened.st_ctime_ns+100000000000)
        for field in ('st_birthtime','st_birthtime_ns'):no_birth.__dict__.pop(field,None)
        proxy=SimpleNamespace(**{**os.__dict__,'name':'nt'})
        with patch.object(replay,'os',proxy):
            case('explicit-Windows-no-birthtime-distinct-ctime',lambda:replay.require28(replay.cross28(target,before,no_birth),'R28_TEST'))
        named_birth=altered(before,st_birthtime_ns=123)
        opened_birth=altered(opened,st_birthtime_ns=124)
        case('both-exposed-birthtime-mismatch',lambda:replay.require28(not replay.cross28(target,named_birth,opened_birth),'R28_TEST'))
'''
    test=test.replace('        original_fstat=os.fstat\n',reader_extra+'        original_fstat=os.fstat\n',1)
    workflow=git(root,'show',BASE+':.github/workflows/security-candidate22.yml').decode()
    workflow=workflow.replace('name: Security candidate27','name: Security candidate28')
    workflow=workflow.replace('      - name: Authenticated original Release24 Release25 and Release26 source controls',
        '      - name: Campaign28 reader controls preserving original Campaign27 diagnostics\n        if: ${{ !cancelled() && steps.install.outcome == \'success\' }}\n        run: |\n          set -o pipefail\n          python -I -B scripts/release/full-app-j01/replay28.test.py | tee "$RUNNER_TEMP/security28-reader.jsonl"\n      - name: Authenticated original Release24 Release25 Release26 and Release27 source controls')
    workflow=workflow.replace('replay27.py --receipt "$RUNNER_TEMP/security27-historical-receipt.json" | tee "$RUNNER_TEMP/security27-historical-controls.jsonl"',
        'replay28.py --receipt "$RUNNER_TEMP/security28-historical-receipt.json" | tee "$RUNNER_TEMP/security28-historical-controls.jsonl"')
    workflow=workflow.replace('      - name: Current Campaign27 finite source governance controls','      - name: Current Campaign28 finite source governance and CORE-05 structural controls')
    workflow=workflow.replace('source_consumer27.test.py | tee "$RUNNER_TEMP/security27-source-controls.jsonl"','source_consumer28.test.py | tee "$RUNNER_TEMP/security28-source-controls.jsonl"')
    workflow=workflow.replace('check.py | tee "$RUNNER_TEMP/security27-current-source.json"','check.py | tee "$RUNNER_TEMP/security28-current-source.json"\n          node --test scripts/core05/adherence-source-contract28.test.mjs | tee "$RUNNER_TEMP/security28-core05.tap"')
    workflow=workflow.replace('            ${{ runner.temp }}/security27-historical-receipt.json\n            ${{ runner.temp }}/security27-historical-controls.jsonl\n            ${{ runner.temp }}/security27-source-controls.jsonl\n            ${{ runner.temp }}/security27-current-source.json',
        '            ${{ runner.temp }}/security28-reader.jsonl\n            ${{ runner.temp }}/security28-historical-receipt.json\n            ${{ runner.temp }}/security28-historical-controls.jsonl\n            ${{ runner.temp }}/security28-source-controls.jsonl\n            ${{ runner.temp }}/security28-current-source.json\n            ${{ runner.temp }}/security28-core05.tap')
    consumer=consumer.replace("'replay28.py --receipt ' in workflow", "'replay28.py --receipt ' in workflow")
    values={
        'RELEASE28_BASE':BASE,'RELEASE28_TREE':TREE,'RELEASE28_AUTHORITY':'BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01',
        'RELEASE28_INPUT':'6bcd248c67f4db0eeb27691c34bcef5ebdc4bcaabf300e24f5e3dc7a3b941c81',
        'RELEASE28_PLAN_COMMIT':PLAN_COMMIT,'RELEASE28_PLAN_SHA256':sha(plan),'RELEASE28_APPENDIX_SHA256':'0'*64,
        'RELEASE28_EXISTING_APP':oldapp,'RELEASE28_NEW_APP':newapp,'RELEASE28_OTHER_EXISTING':other&existing,'RELEASE28_OTHER_NEW':other-existing,
        'RELEASE28_PREVIOUS_GOVERNANCE':previous,'RELEASE28_CONSUMER_SHA256':sha(consumer.encode()),
        'RELEASE28_WORKFLOW_SHA256':sha(workflow.encode()),'RELEASE28_REPLAY_SHA256':sha(runner.encode()),'RELEASE28_REPLAY_TEST_SHA256':sha(test.encode())}
    for key,value in values.items():extension=replace_assignment(extension,key,value)
    extension=replace_assignment(extension,'RELEASE28_APPENDIX_SHA256',sha(extension.encode()))
    final=before[:-len(TERMINAL)]+extension.encode()+TERMINAL
    inherited=[ast.dump(n,include_attributes=False) for n in ast.parse(before).body if isinstance(n,ast.FunctionDef)]
    current=[ast.dump(n,include_attributes=False) for n in ast.parse(final).body if isinstance(n,ast.FunctionDef)]
    assert current[:len(inherited)]==inherited and len(inherited)==202
    write(out/CHECK,final)
    write(out/'scripts/release/full-app-j01/source_consumer28.test.py',consumer)
    write(out/'scripts/release/full-app-j01/replay28.py',runner)
    write(out/'scripts/release/full-app-j01/replay28.test.py',test)
    write(out/'.github/workflows/security-candidate22.yml',workflow)
    candidate=dict(schema=1,authority=values['RELEASE28_AUTHORITY'],status='SUBMITTED_REVIEW_REQUIRED',base=BASE,tree=TREE,
        scopeCommit=PLAN_COMMIT,scopePlanSHA256=sha(plan),inputManifestSHA256=values['RELEASE28_INPUT'],acceptanceGranted=False,
        admissions=dict(G97=False,DB=False,M103=False,M2=False,J01=False,PUBLIC=False),pr=32)
    write(out/'docs/brain/contracts/M1X-28/source28.v1.json',json.dumps(candidate,indent=2)+'\n')
    print(json.dumps(dict(proposals=str(out),inheritedFunctions=len(inherited),scopePaths=len(paths),knownPriorVersions=list(previous),
        checkerSHA256=sha(final),consumerSHA256=sha(consumer.encode()),replaySHA256=sha(runner.encode()),workflowSHA256=sha(workflow.encode())),indent=2))

if __name__=='__main__':main()
