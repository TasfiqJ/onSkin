"""Locally authored intake; no packet code runs before authentication."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import tempfile
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE = Path(r'C:\Users\jasim\.codex\codex-remote-attachments\01a18a80-11b4-7fc2-8a54-b05c4fe670c4\D2B0EBA3-93B8-496E-A3D6-432953738024\1-onSkin_Campaign28_Destructive_Commit_CORE05_Context_2026-10-29.zip')
EXPECTED = '6bcd248c67f4db0eeb27691c34bcef5ebdc4bcaabf300e24f5e3dc7a3b941c81'
NAMES = {'00_READ_FIRST.md','01_CAMPAIGN27_BRAIN_DECISION.md','02_FINITE_IMPLEMENTATION_GRANT.md','03_COMMIT_BOUNDARY_AND_THREAT_MODEL.md','04_CORE05_EXACT_ASSERTION.md','05_ACCEPTANCE_AND_DELIVERY.md','06_SOURCE_ANCHORS_AND_LIMITATIONS.md','BACKGROUND/Campaign27_Actual_Verified_Return.zip','BACKGROUND/Campaign27_Brain_Audit.md','BACKGROUND/Campaign27_Brain_Review_Receipt.json','EXACT_PROMPT.md','PROMPT_TEMPLATE.md','SOURCE_ANCHORS.json','TASK_DIRECTIVE.md','manifest.json','verify_packet.py'}
def sha(b): return hashlib.sha256(b).hexdigest()
def metadata(s):
    return {k:getattr(s,k) for k in dir(s) if k.startswith('st_') and k not in ('st_atime','st_atime_ns') and isinstance(getattr(s,k),(int,float))}
def read_stable(p):
    a=p.lstat()
    assert stat.S_ISREG(a.st_mode) and a.st_nlink == 1
    assert not getattr(a,'st_file_attributes',0) & 0x400
    with p.open('rb') as f:
        b=os.fstat(f.fileno()); data=f.read(); c=os.fstat(f.fileno())
    d=p.lstat()
    assert metadata(a)==metadata(d), ('pathname metadata changed',str(p))
    assert metadata(b)==metadata(c), ('handle metadata changed',str(p))
    # Windows pathname ctime can mean creation, while fstat ctime can mean change.
    for k in ('st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_nlink'):
        assert getattr(a,k)==getattr(b,k), ('incompatible identity',k)
    for k in ('st_file_attributes','st_reparse_tag','st_birthtime_ns'):
        if hasattr(a,k) and hasattr(b,k): assert getattr(a,k)==getattr(b,k)
    assert len(data)==a.st_size
    return data, {'pathname_before':metadata(a),'pathname_after':metadata(d),'handle_before':metadata(b),'handle_after':metadata(c),'complete_read':True,'sha256':sha(data)}
def unique_object(pairs):
    result={}
    for k,v in pairs:
        assert k not in result, ('duplicate JSON key',k)
        result[k]=v
    return result

raw, archive_metadata = read_stable(ARCHIVE)
assert len(raw)<16*1024*1024
assert raw[:4]==b'PK\x03\x04'
e=raw.rfind(b'PK\x05\x06')
assert e>=0 and e+22==len(raw), 'EOCD/trailing/comment'
sig,disk,cd_disk,on_disk,count,cd_size,cd_start,comment=struct.unpack_from('<4s4H2IH',raw,e)
assert disk==cd_disk==comment==0 and on_disk==count==16
assert cd_start+cd_size==e
assert b'PK\x06\x06' not in raw[e-20:e], 'ZIP64 unsupported'
central=[]; pos=cd_start
while pos<e:
    row=struct.unpack_from('<4s6H3I5H2I',raw,pos)
    assert row[0]==b'PK\x01\x02'
    _,made,need,flags,method,tm,dt,crc,cs,us,nl,xl,cl,ds,internal,external,offset=row
    name=raw[pos+46:pos+46+nl]
    assert xl==cl==ds==0 and need<=20 and flags==0 and method in (0,8)
    central.append((name,flags,method,tm,dt,crc,cs,us,external,offset))
    pos+=46+nl+xl+cl
assert pos==e and len(central)==16
cursor=0; inventory=[]; blobs={}; aliases=set()
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    entries=z.infolist()
    assert len(entries)==16 and {i.filename for i in entries}==NAMES
    assert sum(i.file_size for i in entries)<64*1024*1024
    for i,c in zip(entries,central):
        name,flags,method,tm,dt,crc,cs,us,external,offset=c
        assert i.filename.encode('ascii')==name and i.header_offset==offset==cursor
        p=PurePosixPath(i.filename)
        assert not p.is_absolute() and all(x not in ('','..','.') for x in i.filename.split('/'))
        assert '\\' not in i.filename and ':' not in i.filename and '\x00' not in i.filename
        assert i.filename==unicodedata.normalize('NFC',i.filename)==unicodedata.normalize('NFKC',i.filename)
        assert all(not x.endswith((' ','.')) and not re.match(r'(?i)^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)',x) for x in p.parts)
        alias=unicodedata.normalize('NFKC',i.filename).casefold()
        assert alias not in aliases
        aliases.add(alias)
        assert not i.is_dir() and stat.S_ISREG(external>>16) and not (external & 0x10)
        assert 0<us<32*1024*1024 and 0<cs and us/cs<=200
        local=struct.unpack_from('<4s5H3I2H',raw,offset)
        ls,ln,lf,lm,lt,ld,lc,lcs,lus,lnl,lxl=local
        assert ls==b'PK\x03\x04' and ln<=20 and lxl==0
        assert (lf,lm,lt,ld,lc,lcs,lus)==(flags,method,tm,dt,crc,cs,us)
        assert raw[offset+30:offset+30+lnl]==name and lnl==len(name)
        cursor=offset+30+lnl+lxl+cs
        assert cursor<=cd_start
        content=z.read(i)  # complete decompression and CRC check, bounded above
        assert len(content)==us==i.file_size and cs==i.compress_size and crc==i.CRC
        blobs[i.filename]=content
        inventory.append({'name':i.filename,'bytes':us,'compressed_bytes':cs,'sha256':sha(content),'local_offset':offset,'local_central_match':True,'regular_file':True})
assert cursor==cd_start
assert sha(blobs['manifest.json'])==EXPECTED
m=json.loads(blobs['manifest.json'],object_pairs_hook=unique_object)
assert set(m['files'])==NAMES-{'manifest.json'}
for n,v in m['files'].items():
    assert len(blobs[n])==v['bytes'] and sha(blobs[n])==v['sha256'], n
assert blobs['TASK_DIRECTIVE.md']==blobs['PROMPT_TEMPLATE.md']==blobs['EXACT_PROMPT.md']
again, after=read_stable(ARCHIVE)
assert again==raw
target=Path(tempfile.mkdtemp(prefix='campaign28-context-',dir=str(ROOT.parent)))
assert not any(target.iterdir())
for n,b in blobs.items():
    p=target.joinpath(*PurePosixPath(n).parts)
    p.parent.mkdir(parents=True,exist_ok=True)
    assert p.resolve().is_relative_to(target.resolve())
    for parent in (p.parent, target): assert not parent.is_symlink() and not getattr(parent.lstat(),'st_file_attributes',0)&0x400
    with p.open('xb') as f: assert f.write(b)==len(b)
    observed, _=read_stable(p)
    assert observed==b
assert len([p for p in target.rglob('*') if p.is_file()])==16
receipt={'status':'AUTHENTICATED_BEFORE_PACKET_EXECUTION','archive':str(ARCHIVE),'archive_sha256':sha(raw),'external_manifest_sha256':EXPECTED,'file_count':16,'limits':{'archive_bytes':16*1024*1024,'total_uncompressed_bytes':64*1024*1024,'member_bytes':32*1024*1024,'ratio':200},'inventory':inventory,'archive_metadata':archive_metadata,'archive_reread':after,'extracted_root':str(target),'triad_byte_identical':True,'excluded_metadata_fields':['st_atime','st_atime_ns'],'windows_ctime_comparison':'same API domain only; compatible identity fields across pathname/handle'}
(ROOT/'intake_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
(ROOT/'packet_root.txt').write_text(str(target),encoding='utf-8')
print(json.dumps({'status':receipt['status'],'root':str(target),'file_count':16,'manifest_sha256':EXPECTED}))
