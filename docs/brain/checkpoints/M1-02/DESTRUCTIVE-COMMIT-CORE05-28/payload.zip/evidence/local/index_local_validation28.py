from pathlib import Path
import hashlib
import json
import re
import subprocess

OUT=Path(__file__).resolve().parent
SOURCE=OUT.parent/'campaign28-source'
HEAD='78f3198c996cee96168423557a7072f405b0391e'
TREE='8856134ca636ab510fea554cf6508f9225b2f9c4'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).decode().strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=SOURCE)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
cases=['full-quality28-clean-recovered','unsigned-ios28-clean-recovered','unsigned-android28-clean',
       'postinstall-check28-clean','core05-original28-clean','core05-focused28-clean',
       'launch-contracts28-clean','launch-baseline-check28-clean','launch-baseline-smoke28-clean',
       'native-privacy28-clean','advisory-controls28-clean','native-readiness28-clean']
records=[]
for name in cases:
    p=OUT/(name+'.receipt.json');raw=p.read_bytes();record=json.loads(raw)
    assert record['sourceHead']==HEAD and record['sourceTree']==TREE and record['cleanTrackedBefore']
    assert record['headUnchanged'] and record['trackedDiffUnchanged']
    log=OUT/record['log'];body=log.read_bytes()
    assert len(body)==record['logBytes'] and sha(body)==record['logSHA256']
    assert record['exit']==(1 if name=='native-readiness28-clean' else 0)
    records.append(dict(case=name,exit=record['exit'],receipt=p.name,receiptBytes=len(raw),receiptSHA256=sha(raw),
                        log=log.name,logBytes=len(body),logSHA256=sha(body)))
log=(OUT/'full-quality28-clean-recovered.log').read_text(encoding='utf-8')
log=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',log)
assert re.search(r'Tests\s+6478 passed',log) and re.search(r'Tests\s+24 passed',log)
assert re.search(r'Cached:\s+0 cached, 8 total',log)
prior=json.loads((OUT.parent/'campaign27-run-taxf1ogb/photo15-97-27.json').read_bytes())
photo=[]
for row in prior['testResults']:
    name=Path(row['name']).name
    pattern=re.escape('src/features/photos/'+name)+r'\s+\((\d+) tests\)'
    match=re.search(pattern,log)
    assert match and int(match[1])==len(row['assertionResults'])
    path='apps/mobile/src/features/photos/'+name
    original=subprocess.check_output(['git','show','517b50413b136639413b783cf3e899a6bc6c19ed:'+path],cwd=SOURCE)
    assert original==(SOURCE/path).read_bytes()
    photo.append(dict(path=path,tests=int(match[1]),sourceUnchangedFromPR31=True))
assert sum(row['tests'] for row in photo)==112
exports={}
for platform,dir_name in [('ios','campaign28-export-clean-ios-recovered'),('android','campaign28-export-clean-android')]:
    root=OUT.parent/dir_name
    files={p.relative_to(root).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(root.rglob('*')) if p.is_file()}
    assert files and 'metadata.json' in files
    exports[platform]=dict(files=files,qualification='ACTUAL_CLEAR_CACHE_UNSIGNED_DEVELOPMENT_EXPORT_NOT_INSTALLED_NATIVE_OR_RELEASE_PROOF')
value=dict(schema=1,sourceHead=HEAD,sourceTree=TREE,records=records,
           forcedTasks=dict(mobile=6478,operator=24,tasks=8,cacheHits=0,qualification='ACTUAL_CLEAN_COMMITTED_SOURCE_EXPLICIT_FORCE'),
           photoRegression=dict(layout=15,focused=97,files=photo,qualification='IDENTIFIED_SUBSET_OF_ACTUAL_FULL_FORCED_RUN_NOT_AN_ADDITIONAL_EXECUTION'),
           core05=dict(currentOriginal=36,focusedFileTotal=69,newPositive=2,newRefusals=31,uniqueTotal=69,
                       combinedEarlierTotal105IncludesDuplicatedOriginal36=True,historicalOriginal35Pass1FailPreserved=True),
           exports=exports,browser='NOT_RUN_LOCAL_BROWSER_USE_DISABLED_IN_WORK_SETTINGS',
           localDatabase='NOT_RUN_DOCKER_DAEMON_UNAVAILABLE_AFTER_BOUNDED_START_ATTEMPT',
           nativeReadiness='ACTUAL_EXIT1_FIVE_UNCLEARED_NATIVE_PRODUCTION_WARNINGS_PRESERVED',
           qualification='ACTUAL_SUPPLIER_TECHNICAL_EXECUTION_NOT_BRAIN_OR_QUALIFIED_ACCEPTANCE',acceptanceGranted=False,release='NO_GO')
(OUT/'LOCAL_VALIDATION28.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='INDEXED_ACTUAL_EXECUTIONS',records=len(records),mobile=6478,operator=24,photoTests=112,exportFiles={k:len(v['files']) for k,v in exports.items()})))
