# Independent Campaign27 return orientation for Campaign28

This report authenticates/read-only reviews prior evidence. It grants no current source, native, Security, database or release acceptance. The complete 32,576-byte prior FINAL_REPORT.md was read, including its immutable checkpoint report. No integration source was edited.

## Authentication and extraction

The authenticated Campaign28 SOURCE_ANCHORS.json supplied prior ZIP size 2,160,274 and SHA256 `d44e701ef98d2c6879b21ce8d6958fa580bd4bcf51304e6c6713c279c78111bc`, manifest SHA256 `9c5d9cd0606763d66a62d651e0c3f4457e28608abcf7b6dfba611830508baf11`, and return verifier SHA256 `dece962df8b3b1eeac3d32ccda1665e87d4fc0faf8f0736adc7318ac22e561ce`. All matched independently before verifier execution.

Own stdlib inspection authenticated all 122 exact outer members and all 305 exact checkpoint payload members. Local/central metadata, consecutive offsets and complete record coverage, EOCD/end boundaries, regular modes, unsupported encryption/extras/comments, case/Unicode/implicit-parent collisions, traversal and expansion limits passed. Complete CRC-checked reads and repeated input hashes passed. Same-domain metadata retains every st_* field except st_atime/st_atime_ns; compatible Windows path/handle fields compare identity/size/mode/links/mtime while ctime remains checked within its API family.

Fresh extracted outer directory: `prior-return-authenticated-r0bf2irz`. Fresh extracted checkpoint payload directory: `prior-payload-authenticated-fpgp5ndh`. Both live beside this report. New-file exclusive writes and exact byte readback were used. Evidence: `prior_return_audit.json`, own `audit_prior_return.py`.

Authenticated original return verifier exited 0 / VERIFIED with 122 files and 305 payload files. It explicitly reports sourceChecks NOT_RUN and Git prerequisites/history/delta NOT_CHECKED_WITHOUT_GIT_ROOT. The initial observed successful command was repeated solely to persist actual stdout/stderr and argv; `prior_return_artifact_verifier_receipt.json` records this qualification. No full prior Git-source verification is claimed by this worker.

## Exact prior baseline evidence to preserve and rerun

Paths below are relative to the extracted payload.

- `evidence/app-evidence/detail-pending-retirement.test.ts`: original external three mounted cases. Same-owner health regrant passes; same-grant actual Query object replacement during held initial private read fails; modal unmount during held initial private read fails. Original assertions require the stored item to remain. They must be rerun unmodified against exact PR31 and then the changed source, rather than replacing assertions.
- `evidence/app-evidence/baseline-r2-results.json` plus `baseline-r2-receipt.json`: actual 54 pass / 2 fail across 53 original Campaign26 cases plus three external controls. This is overlapping assertion count, not 56 independent assurance properties. `baseline.config.mjs` contains prior absolute aliases and must be adapted in an external current config; preserve its original bytes.
- `evidence/app-evidence/commit-boundary.test.ts`: four actual privateKV/encryption/health/store probes. Updater-only admission misses retirement during the later conflict read; existing third-argument guard can refuse prewrite; that guard can also restore adapter-visible bytes already written while native promise is unsettled (two writes); later retirement after full operation completion does not reverse the operation. This is the concrete reason to introduce a distinct precommit-only callback rather than reusing the old third guard for UI retirement.
- `evidence/app-evidence/boundary-r4-results.json` and receipt: all four probes pass; they do not implement Remove/Discard or validate mirror-outbox correctness.
- `evidence/app-evidence/R27_02_EXECUTED_COVERAGE_SUPPLEMENT_PUBLIC.json`: precise executed versus NOT_RUN matrix. Pending Discard, queueing behind distinct transaction, pending Query ABA, pending A-B-A/expiry/withdrawal, delayed key/crypto, partial/ambiguous readback, failed compensation and direct native/mirror counts were NOT_RUN. They cannot inherit PASS from ordinary Remove or another stage.
- `evidence/archive-review/core05-pr28.receipt.json` and `core05-pr29.receipt.json`: immutable original Node source-contract 35 PASS / 1 FAIL. PR28 source `d0ccef65bcbe0c90483e6c0f691ed95f92228c6c`, tree `22f91455d651a81296ab8724f9db7cfead65af08`; PR29 `52a3d01ebb36a6845d0ac21935ad35520732633f`, tree `ef49a81ca814f3d82b8a868e0308b6dda09c9cca`. Failure is test 8 exact one-argument spelling, while authentic route supplies proposed times, undefined dependencies, assertLifecycle. Public diagnosis files preserve call-site/public Git identities without route source dumps.
- `evidence/archive-review/core05-notification-runtime-pr29.receipt.json`: original notification behavior 29 tests / 3 files, mocked platform qualification. SQL CORE05 passing is separate from the Node source test failure.

## Reusable external engineering tools

These are authenticated prior templates, not directly runnable Campaign28 tools. They hardcode Campaign27 authority, source heads, directories, expected schemas and/or checker hashes. Preserve prior originals; adapt copies outside integration before running and bind actual Campaign28 inputs.

| Tool | Reusable behavior and required adaptation |
| --- | --- |
| `evidence/local/build_verifier27.py` | Builds new verifier from prior verifier; imports compatible-reader functions from replay27. Must update authority, exact grants, pinned PR31/base tree, first-child plan identities, checkpoint path and Release28 checker hash. Do not perform broad substitutions in historical inherited logic. |
| `evidence/local/build_checkpoint27.py` | Deterministic regular-mode ZIP framing and authenticated witnesses; five-file checkpoint after sole worklist freeze. Update source schema and evidence allowlist; preserve no-admission fields. |
| `evidence/local/freeze_worklists27.py` | One-shot receipt written before producer invocation, refuses rerun, authenticates unchanged producer, runs producer exactly once, commits sole two-worklist child. Replace hardcoded run/runtime/base/node/plan anchors from observed current facts. Never execute this old script itself on Campaign28. |
| `evidence/local/commit_tail27.py` | Sole five-file checkpoint plus root handoff evidence tail. Update paths and pins; no source changes after freeze. |
| outer `evidence/final-verification/return-builder-used.py` | Adopted reviewed final builder binds exact evidence selection, logs, actual final CI and both clone receipts before one ZIP. Prefer this reviewed implementation over an earlier similarly named local builder. It imports sibling checkpoint helpers and has strict identities. |
| outer `evidence/final-verification/build_final_receipts27.py` and usage | Stages check-inputs/write-receipts/prepare-inventory/accept-inventory. Requires actual final workflow API heads, bound public artifacts, complete clones and reviewed inventory digest. Preserve failed/interim evidence; no invented artifact. |
| `evidence/app-evidence/final_clone27.py` | Fresh full remote clone, no shared objects/alternates/hardlinks, fsck, normal empty-cache npm ci and mandatory hooks, exact source/checkpoint/Phase4 verification. Same full command gives source 0/1/0 and artifact 0/1/0; actual bytes restored with original mtime/mode without claiming ctime rollback. Update verifier/schema/current checkpoint identity; protect sensitive source bytes from logging. |
| outer `evidence/final-verification/verify_postassembly_return27.py` | After actual ZIP assembly, full verification against two completed clones; separate supplied-download mode rehashes bytes but explicitly does not attest network freshness. Real network download must occur separately and be recorded truthfully. |
| `evidence/app-evidence/github_ci_reader27.py` / test | Strict bounded CI artifact parser accepts genuine GitHub data descriptors after local/central agreement, authenticates whole archive but exports public allowlist only. Adapt allowlist for new security28 files; no original private Security logs. |
| `evidence/history-review/execute_original_history.py` | Original151 and Release09–23 at authentic commits, separate remote objects, raw tracked inventories. Depends on historical pins/native source fixture pins from earlier artifact. Earlier09–23 use ten authenticated current-install native source fixtures, not full historical installations; preserve that explicit limitation. |

## Prior final-head qualifications that matter for new work

Prior actual source is PR31 `517b50413b136639413b783cf3e899a6bc6c19ed`, tree `497f248472f775cef2a9922475fa9f3f62b75060`; its substantive head is `97bb8341e979e5eb38034419fd0e5a106b794d90`, sole worklist child `82a8ffbeab2c740a75b96fabdd7ddf4016e122c9`, then final evidence tail. Release27 original checker/consumer must execute at exact PR31 in Campaign28. Prior Release24/25/26 replay must remain at PR28/29/30 respectively.

Campaign27 had actual Linux/Windows historical executions, current source governance, full mobile6370/operator24 zero-cache tests, clear-cache unsigned exports and hosted canonical DB/PG15/17. Those are prior-head observations. Campaign28 must produce fresh current execution. Linux runtime3.14.4 and explicit3.12.15; Windows3.12.10. Windows open-handle rename mutation was denied by OS and remains NOT_RUN. Original Security stays public-status failure without reading its private logs. Authentic scanner/custody findings kept candidateReady=false and real exit1.

Prior report's no-browser and unavailable-local-Docker claims describe Campaign27 environment only. Determine current availability independently. Prior mounted structure/fontScale2 tests are not rendered viewport, focus, scroll, VoiceOver or physical durability evidence.

Final Campaign28 disposition must remain SUBMITTED_REVIEW_REQUIRED / NO_GO. G97 FAIL/NO_GO and all qualified gates remain closed. None of this read-only orientation is independent Brain replay or acceptance.
