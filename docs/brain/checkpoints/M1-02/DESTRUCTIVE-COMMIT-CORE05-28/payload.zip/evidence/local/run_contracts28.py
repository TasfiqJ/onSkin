import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'campaign28-source'
PREFIX=HERE.parent/'campaign26-run-1b46eb3809914b21a97234dcffb185dc/security26-tools'
env=os.environ.copy(); env['PATH']=str(PREFIX)+os.pathsep+env['PATH']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE).strip()==b'78f3198c996cee96168423557a7072f405b0391e'
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=SOURCE)
cases=[
 ('postinstall-check28-clean',['node','scripts/postinstall.mjs','--check'],True),
 ('core05-original28-clean',['node','--test','scripts/core05/adherence-source-contract.test.mjs'],True),
 ('core05-focused28-clean',['node','--test','scripts/core05/adherence-source-contract28.test.mjs'],True),
 ('launch-contracts28-clean',['node',str(PREFIX/'node_modules/npm/bin/npm-cli.js'),'run','launch:contract:verify'],True),
 ('launch-baseline-check28-clean',['node','scripts/launch/validate-execution-baseline.mjs'],True),
 ('launch-baseline-smoke28-clean',['node','scripts/launch/execution-baseline-smoke.mjs'],True),
 ('native-privacy28-clean',['node','scripts/phase9/ios-privacy-source-audit.mjs','--check','--strict'],True),
 ('advisory-controls28-clean',['node','--test','scripts/security24/advisory-behavior.test.mjs','scripts/security24/patch-tooling.test.mjs'],True),
 ('native-readiness28-clean',['node','scripts/phase5/check-native-config.mjs','--strict'],False),
]
results=[]
for name,argv,required in cases:
    child=subprocess.run([sys.executable,'-B',str(HERE/'run_command28.py'),'--source',str(SOURCE),'--name',name,'--',*argv],cwd=SOURCE,env=env)
    results.append(dict(name=name,exit=child.returncode,requiredTechnicalControl=required))
    if required and child.returncode:
        (HERE/'contracts28-incomplete.json').write_text(json.dumps(results,indent=2));raise SystemExit(child.returncode)
assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=SOURCE)
(HERE/'contracts28-results.json').write_text(json.dumps(dict(sourceHead='78f3198c996cee96168423557a7072f405b0391e',results=results,release='NO_GO',acceptanceGranted=False),indent=2))
print(json.dumps(dict(status='CONTRACT_COMMANDS_EXECUTED',results=results)),flush=True)
