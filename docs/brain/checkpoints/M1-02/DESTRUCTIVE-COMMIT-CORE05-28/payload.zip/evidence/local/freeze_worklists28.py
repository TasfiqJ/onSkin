"""Sole original Phase4 producer invocation; never execute before reviewed gate."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

assert not sys.flags.optimize
RUN=Path(__file__).resolve().parent
ROOT=RUN.parent/'campaign28-source'
RUNTIME='78f3198c996cee96168423557a7072f405b0391e'
TREE='8856134ca636ab510fea554cf6508f9225b2f9c4'
BASE='517b50413b136639413b783cf3e899a6bc6c19ed'
PLAN_SHA='cd862ff6be2e30332f9e3810d565fd55402353fe016e4e684acaaa30b3a6222d'
VERIFIER=RUN.parent/'campaign28-packaging/reviewed-substantive-03/packaging/verify28.py'
VERIFIER_SHA='9769435d01d678fd6acfcd1bd484f493578d2c32e2ecc7d5c431f2925c8d33f7'
NODE=RUN.parent/'campaign26-run-1b46eb3809914b21a97234dcffb185dc/security26-tools/node.exe'
NODE_SHA='47cd67453da180a39cdf5daedb89862667b8e627e60c116607874633450cd30d'
PATHS=['docs/phase-4/generated/source-worklist.json','docs/phase-4/generated/source-worklist.md']
PRODUCER='scripts/phase4/build-source-worklist.mjs'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encoded=lambda obj:(json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()

def main():
    output=RUN/'WORKLIST_FREEZE_RECEIPT.json'
    assert not output.exists(), 'PRODUCER_ALREADY_RESERVED_NEVER_REPEAT'
    assert sha(VERIFIER.read_bytes())==VERIFIER_SHA
    spec=importlib.util.spec_from_file_location('freeze28_anchored_reader',VERIFIER)
    v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
    assert v.sha(v.read_regular(VERIFIER))==VERIFIER_SHA
    git=lambda *args:v.git(ROOT,*args).decode().strip()
    assert git('rev-parse','HEAD')==RUNTIME and git('rev-parse','HEAD^{tree}')==TREE
    assert not git('status','--porcelain=v1','--untracked-files=all')
    assert sha(v.read_regular(ROOT/'docs/brain/task-specs/M1X-28/SCOPE_PLAN.md'))==PLAN_SHA
    original=v.git(ROOT,'show',BASE+':'+PRODUCER)
    assert v.read_regular(ROOT/PRODUCER)==original
    gate_raw=v.read_regular(RUN/'PREFREEZE_GATE.json');gate=json.loads(gate_raw)
    assert gate['status']=='PREFREEZE_TECHNICAL_EXECUTION_READY_FOR_WORKLIST_ONLY'
    assert gate['sourceHead']==RUNTIME and gate['sourceTree']==TREE
    assert gate['readyForWorklistFreeze'] is True and gate['acceptanceGranted'] is False and gate['release']=='NO_GO'
    for name,witness in gate['requiredReceipts'].items():
        raw=v.read_regular(Path(witness['path']))
        assert len(raw)==witness['bytes'] and sha(raw)==witness['sha256'], name
    assert shutil.disk_usage(ROOT).free>=2*1024**3, 'CAPACITY_REQUIRED_BEFORE_RESERVING_PRODUCER'
    assert sha(v.read_regular(NODE))==NODE_SHA
    checked=v.hash_worktree(ROOT,v.git_tree(ROOT,'HEAD'))
    assert checked==23535 and not git('status','--porcelain=v1','--untracked-files=all')
    env={k:val for k,val in os.environ.items() if not k.upper().startswith(('GIT_','NPM_','PYTHON','GITHUB_','PHASE4_'))
         and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
    env['PATH']=str(NODE.parent)+os.pathsep+env['PATH']
    receipt=dict(status='STARTED',sourceHead=RUNTIME,sourceTree=TREE,producer=PRODUCER,
        producerSHA256=sha(original),nodeSHA256=NODE_SHA,invocation=[str(NODE),PRODUCER,'--strict'],
        producerInvocations=1,cleanBefore=True,rawTrackedBlobsChecked=checked,gateSHA256=sha(gate_raw),
        environmentQualification='TASK_OVERRIDES_AND_TOOL_INJECTION_VARIABLES_REMOVED',acceptanceGranted=False,release='NO_GO')
    with output.open('xb') as f:f.write(encoded(receipt))
    started=time.monotonic()
    try:
        child=subprocess.run(receipt['invocation'],cwd=ROOT,capture_output=True,timeout=300,env=env)
    except (OSError,subprocess.TimeoutExpired):
        receipt.update(status='FAILED_OR_INCOMPLETE',failureCategory='PRODUCER_EXECUTION_INCOMPLETE')
        output.write_bytes(encoded(receipt));raise
    (RUN/'phase4-producer28.stdout.log').write_bytes(child.stdout)
    (RUN/'phase4-producer28.stderr.log').write_bytes(child.stderr)
    receipt.update(producerExit=child.returncode,elapsedSeconds=time.monotonic()-started,
                   stdoutSHA256=sha(child.stdout),stderrSHA256=sha(child.stderr))
    output.write_bytes(encoded(receipt))
    assert child.returncode==0
    assert set(git('diff','--name-only').splitlines())==set(PATHS)
    assert not git('diff','--cached','--name-only') and not git('ls-files','--others','--exclude-standard')
    receipt['worklists']={p:dict(bytes=len(v.read_regular(ROOT/p)),sha256=sha(v.read_regular(ROOT/p))) for p in PATHS}
    subprocess.run(['git','-C',str(ROOT),'add','--',*PATHS],check=True,capture_output=True)
    assert set(git('diff','--cached','--name-only').splitlines())==set(PATHS)
    subprocess.run(['git','-C',str(ROOT),'commit','-m','docs(campaign28): freeze original Phase4 worklists'],check=True,capture_output=True)
    assert git('rev-parse','HEAD^')==RUNTIME and not git('status','--porcelain=v1','--untracked-files=all')
    assert set(git('diff','--name-only',RUNTIME,'HEAD').splitlines())==set(PATHS)
    for p in PATHS:
        raw=v.git(ROOT,'show','HEAD:'+p)
        assert raw==v.read_regular(ROOT/p) and sha(raw)==receipt['worklists'][p]['sha256']
        assert git('ls-tree','HEAD','--',p).startswith('100644 blob ')
    receipt.update(status='COMMITTED_SOLE_WORKLIST_CHILD',runtimeHead=RUNTIME,runtimeTree=TREE,
        sourceHead=git('rev-parse','HEAD'),sourceTree=git('rev-parse','HEAD^{tree}'),changedPaths=PATHS,cleanAfter=True)
    output.write_bytes(encoded(receipt));print(json.dumps(receipt,sort_keys=True))

if __name__=='__main__':
    try:main()
    except BaseException:
        p=RUN/'WORKLIST_FREEZE_RECEIPT.json'
        if p.exists():
            r=json.loads(p.read_bytes())
            if r.get('status')!='COMMITTED_SOLE_WORKLIST_CHILD':
                r.update(status='FAILED_OR_INCOMPLETE',failureCategory=r.get('failureCategory','FREEZE_INCOMPLETE'))
                p.write_bytes(encoded(r))
        raise
