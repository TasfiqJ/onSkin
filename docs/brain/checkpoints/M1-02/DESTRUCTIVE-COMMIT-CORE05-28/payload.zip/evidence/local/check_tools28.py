import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root / 'scripts/security22'))
from toolchain import identity
print(json.dumps(identity(root), sort_keys=True))
