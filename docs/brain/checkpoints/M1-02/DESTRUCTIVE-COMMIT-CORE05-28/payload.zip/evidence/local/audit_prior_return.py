"""Authenticate prior return and payload with independent framing; safe fresh extraction."""
import hashlib
import io
import json
import os
import pathlib
import stat
import struct
import tempfile
import unicodedata
import zipfile
from independent_archive_audit import demand, metadata, no_duplicates

ROOT = pathlib.Path(__file__).resolve().parent
PACKET = ROOT.parent / "campaign28-context-i5sa4mb8"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inspect(raw, expected_count=None):
    demand(len(raw) < 100_000_000 and raw[-22:-18] == b"PK\x05\x06", "archive size/EOCD/trailing")
    _, disk, cdisk, dcount, count, csize, coff, comment = struct.unpack_from("<4s4H2LH", raw, len(raw) - 22)
    demand((disk, cdisk, dcount, comment) == (0, 0, count, 0), "split/comment archive")
    demand(coff + csize == len(raw) - 22, "central bounds")
    demand(count <= 1000 and (expected_count is None or count == expected_count), "inventory count")
    cpos, lpos, total = coff, 0, 0
    aliases, implicit_dirs = set(), set()
    contents, inventory = {}, []
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        demand(len(entries) == count, "entry count")
        for entry in entries:
            v = struct.unpack_from("<4s6H3L5H2L", raw, cpos)
            signature, made, needed, flags, method, mt, md, crc, compressed, size, nlen, elen, clen, sdisk, iattr, eattr, offset = v
            demand(signature == b"PK\x01\x02" and flags == 0 and method in (0, 8) and sdisk == 0 and needed <= 20, "central mode/framing")
            name_raw = raw[cpos + 46:cpos + 46 + nlen]
            demand(elen == 0 and clen == 0, "unexpected extra/comment")
            cpos += 46 + nlen + elen + clen
            demand(offset == lpos and raw[offset:offset+4] == b"PK\x03\x04", "local gap/overlap/prefix")
            lv = struct.unpack_from("<4s5H3L2H", raw, offset)
            demand(lv[1:9] == (needed, flags, method, mt, md, crc, compressed, size), "local/central fields")
            demand(lv[9:] == (nlen, 0) and raw[offset+30:offset+30+nlen] == name_raw, "local/central name/extra")
            lpos = offset + 30 + nlen + compressed
            demand(lpos <= coff, "local data bounds")
            name = name_raw.decode("ascii")
            demand(name == entry.filename and entry.header_offset == offset, "manual/stdlib discrepancy")
            parts = name.split("/")
            demand(all(p not in ("", ".", "..") and p == p.rstrip(" .") for p in parts) and "\\" not in name and ":" not in name and "\x00" not in name, "unsafe name")
            alias = unicodedata.normalize("NFKC", name).casefold()
            demand(alias not in aliases and alias not in implicit_dirs and unicodedata.normalize("NFC", name) == name, "alias/collision")
            for index in range(1, len(parts)):
                parent_alias = "/".join(parts[:index]).casefold()
                demand(parent_alias not in aliases, "file/implicit-parent collision")
                implicit_dirs.add(parent_alias)
            aliases.add(alias)
            demand(stat.S_ISREG(eattr >> 16) and not (eattr & 0x10), "nonregular/link/directory")
            demand(size <= 20_000_000 and compressed > 0 and size / compressed <= 200, "entry expansion bounds")
            total += size
            demand(total <= 100_000_000, "total expansion bounds")
            with archive.open(entry) as stream:
                data = stream.read(size + 1)
                demand(len(data) == size and stream.read(1) == b"", "complete entry read")
            contents[name] = data
            inventory.append({"name": name, "bytes": size, "compressedBytes": compressed, "sha256": sha(data), "mode": oct(eattr >> 16)})
    demand(lpos == coff and cpos == coff + csize, "complete record coverage")
    return contents, inventory


def extract(contents, directory):
    demand(directory.is_dir() and not list(directory.iterdir()), "fresh directory not empty")
    for name, data in contents.items():
        target = directory.joinpath(*name.split("/"))
        demand(directory in target.parents, "target escaped")
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as output:
            demand(output.write(data) == len(data), "partial extraction write")
        before = target.lstat()
        demand(stat.S_ISREG(before.st_mode) and not (getattr(before, "st_file_attributes", 0) & 0x400), "extracted nonregular")
        with target.open("rb") as check:
            h0 = os.fstat(check.fileno())
            actual = check.read(len(data)+1)
            demand(actual == data and check.read(1) == b"", "extracted readback")
            demand(metadata(h0) == metadata(os.fstat(check.fileno())), "extraction handle metadata unstable")
        demand(metadata(before) == metadata(target.lstat()), "extraction path metadata unstable")


def main():
    anchors = json.loads((PACKET / "SOURCE_ANCHORS.json").read_text())
    a = anchors["priorArchive"]
    source = PACKET / a["path"]
    before = source.lstat()
    demand(stat.S_ISREG(before.st_mode) and not (getattr(before, "st_file_attributes", 0) & 0x400), "input nonregular/reparse")
    with source.open("rb") as handle:
        h0 = os.fstat(handle.fileno())
        for field in ("st_dev", "st_ino", "st_mode", "st_nlink", "st_size", "st_mtime_ns"):
            demand(getattr(before, field) == getattr(h0, field), "compatible path/handle mismatch")
        raw = handle.read(before.st_size+1)
        demand(len(raw) == before.st_size and handle.read(1) == b"", "input complete read")
        handle.seek(0)
        demand(sha(handle.read(before.st_size+1)) == sha(raw), "input repeat hash")
        demand(metadata(h0) == metadata(os.fstat(handle.fileno())), "input handle changed")
    demand(metadata(before) == metadata(source.lstat()), "input pathname changed")
    demand(len(raw) == a["bytes"] and sha(raw) == a["sha256"], "outer prior archive anchor")
    contents, inventory = inspect(raw, 122)
    demand(sha(contents["manifest.json"]) == a["manifestSHA256"], "outer manifest anchor")
    demand(sha(contents["verify_return27.py"]) == a["verifierSHA256"], "outer verifier anchor")
    manifest = json.loads(contents["manifest.json"].decode(), object_pairs_hook=no_duplicates)
    demand(set(manifest["files"]) | {"manifest.json"} == set(contents), "outer exact manifest inventory")
    for name, record in manifest["files"].items():
        demand(len(contents[name]) == record["bytes"] and sha(contents[name]) == record["sha256"], "outer file hash/size " + name)
    checkpoint = json.loads(contents["checkpoint/manifest.json"].decode(), object_pairs_hook=no_duplicates)
    for name, record in checkpoint["files"].items():
        data = contents["checkpoint/" + name]
        demand(len(data) == record["bytes"] and sha(data) == record["sha256"], "checkpoint file hash/size " + name)
    payload, payload_inventory = inspect(contents["checkpoint/payload.zip"])
    demand(set(payload) == set(checkpoint["payload"]["files"]), "payload exact manifest inventory")
    for name, record in checkpoint["payload"]["files"].items():
        demand(len(payload[name]) == record["bytes"] and sha(payload[name]) == record["sha256"], "payload file hash/size " + name)
    directory = pathlib.Path(tempfile.mkdtemp(prefix="prior-return-authenticated-", dir=ROOT))
    extract(contents, directory)
    payload_directory = pathlib.Path(tempfile.mkdtemp(prefix="prior-payload-authenticated-", dir=ROOT))
    extract(payload, payload_directory)
    report = {"result": "AUTHENTICATED_AND_SAFELY_EXTRACTED", "sourceArchive": str(source), "archiveSHA256": sha(raw), "manifestSHA256": a["manifestSHA256"], "verifierSHA256": a["verifierSHA256"], "outerFiles": len(contents), "payloadFiles": len(payload), "outerDirectory": str(directory), "payloadDirectory": str(payload_directory), "packetCodeExecuted": False, "inputPathMetadata": metadata(before), "inputHandleMetadata": metadata(h0), "excludedOnly": ["st_atime", "st_atime_ns"], "outerInventory": inventory, "payloadInventory": payload_inventory}
    (ROOT / "prior_return_audit.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("result", "outerFiles", "payloadFiles", "outerDirectory", "payloadDirectory")}))


if __name__ == "__main__":
    main()
