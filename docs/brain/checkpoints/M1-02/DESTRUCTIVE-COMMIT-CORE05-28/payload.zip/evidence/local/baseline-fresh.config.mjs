export default {
  "root": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/apps/mobile",
  "cacheDir": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/Campaign28_bootstrap/baseline-cache",
  "resolve": {
    "alias": {
      "@": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/apps/mobile/src",
      "react": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/node_modules/react",
      "react-test-renderer": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/node_modules/react-test-renderer",
      "@tanstack/react-query": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/node_modules/@tanstack/react-query",
      "vitest": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/node_modules/vitest/dist/index.js"
    }
  },
  "test": {
    "environment": "node",
    "include": [
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-review-app/historical-pending-retirement.test.ts",
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-review-app/discard-pending-retirement.test.ts",
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-review-app/historical-commit-boundary.test.ts",
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/apps/mobile/src/features/shelf/detailActionSheet.campaign26.test.ts",
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-source/apps/mobile/src/features/shelf/manualDraftRecovery.campaign26.test.ts"
    ]
  }
};
