"""External actual-execution receipt writer; contains no claimed test outcomes."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--source', required=True)
p.add_argument('--cwd')
p.add_argument('--name', required=True)
p.add_argument('argv', nargs=argparse.REMAINDER)
a = p.parse_args()
assert a.argv and a.argv[0] == '--'
argv = a.argv[1:]
root = Path(__file__).resolve().parent
source = Path(a.source).resolve()
cwd = Path(a.cwd).resolve() if a.cwd else source
assert a.name.replace('-', '').replace('_', '').isalnum()
log = root / (a.name + '.log')
receipt_path = root / (a.name + '.receipt.json')
assert not log.exists() and not receipt_path.exists(), 'preserve prior executions'
def git(*args):
    return subprocess.check_output(['git', '-C', str(source), *args])
head = git('rev-parse', 'HEAD').decode().strip()
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
diff = git('diff', '--binary', 'HEAD')
started = datetime.now(timezone.utc).isoformat()
t = time.monotonic()
with log.open('xb') as output:
    result = subprocess.run(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT)
raw = log.read_bytes()
receipt = dict(argv=argv, cwd=str(cwd), startedUTC=started,
               endedUTC=datetime.now(timezone.utc).isoformat(),
               elapsedSeconds=time.monotonic()-t, exit=result.returncode,
               sourceHead=head, sourceTree=tree,
               workingDiffSHA256=hashlib.sha256(diff).hexdigest(),
               cleanTrackedBefore=not diff, headUnchanged=git('rev-parse','HEAD').decode().strip()==head,
               trackedDiffUnchanged=git('diff','--binary','HEAD')==diff,
               log=log.name, logBytes=len(raw), logSHA256=hashlib.sha256(raw).hexdigest(),
               qualification='ACTUAL_SUPPLIER_EXECUTION_NOT_BRAIN_ACCEPTANCE', release='NO_GO', acceptanceGranted=False)
receipt_path.write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
