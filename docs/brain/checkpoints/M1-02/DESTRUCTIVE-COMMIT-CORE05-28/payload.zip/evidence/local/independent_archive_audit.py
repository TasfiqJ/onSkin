"""Independent read-only ZIP authentication; never executes or extracts packet code."""
import hashlib
import io
import json
import os
import pathlib
import re
import stat
import struct
import unicodedata
import zipfile

ARCHIVE = pathlib.Path(r"C:\Users\jasim\.codex\codex-remote-attachments\01a18a80-11b4-7fc2-8a54-b05c4fe670c4\D2B0EBA3-93B8-496E-A3D6-432953738024\1-onSkin_Campaign28_Destructive_Commit_CORE05_Context_2026-10-29.zip")
EXPECTED = "6bcd248c67f4db0eeb27691c34bcef5ebdc4bcaabf300e24f5e3dc7a3b941c81"
OUTPUT = pathlib.Path(__file__).with_suffix(".json")


def demand(condition, message):
    if not condition:
        raise ValueError(message)


def metadata(s):
    # Preserve every reported stat field except the two read-induced access fields.
    return {n: getattr(s, n) for n in dir(s) if n.startswith("st_") and n not in ("st_atime", "st_atime_ns")}


def no_duplicates(pairs):
    result = {}
    for k, v in pairs:
        demand(k not in result, "duplicate JSON key: " + k)
        result[k] = v
    return result


def main():
    p0 = ARCHIVE.lstat()
    demand(stat.S_ISREG(p0.st_mode), "archive must be regular file")
    demand(not (getattr(p0, "st_file_attributes", 0) & 0x400), "archive reparse point")
    for parent in ARCHIVE.parents:
        demand(not (getattr(parent.lstat(), "st_file_attributes", 0) & 0x400), "ancestor reparse point")
    demand(p0.st_size < 100_000_000, "compressed size limit")
    with ARCHIVE.open("rb") as stream:
        f0 = os.fstat(stream.fileno())
        # ctime intentionally remains checked within each stat family, but is not
        # compared across Windows pathname/handle APIs with incompatible semantics.
        compatible = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_size", "st_mtime_ns")
        for field in compatible:
            demand(getattr(p0, field) == getattr(f0, field), "pathname/handle mismatch " + field)
        raw = stream.read(p0.st_size + 1)
        demand(len(raw) == p0.st_size and stream.read(1) == b"", "incomplete read")
        stream.seek(0)
        reread = stream.read(p0.st_size + 1)
        demand(len(reread) == len(raw) and hashlib.sha256(raw).digest() == hashlib.sha256(reread).digest(), "repeat read mismatch")
        f1 = os.fstat(stream.fileno())
        demand(metadata(f0) == metadata(f1), "handle metadata changed")
    p1 = ARCHIVE.lstat()
    demand(metadata(p0) == metadata(p1), "pathname metadata changed")
    demand(len(raw) >= 22 and raw[-22:-18] == b"PK\x05\x06", "EOCD missing, comments, or trailing data")
    sig, disk, c_disk, disk_count, count, c_size, c_off, comment = struct.unpack_from("<4s4H2LH", raw, len(raw) - 22)
    demand((disk, c_disk, disk_count, count, comment) == (0, 0, 16, 16, 0), "EOCD inventory/disk/comment mismatch")
    demand(c_off + c_size == len(raw) - 22, "central directory boundary mismatch")
    inventory = []
    contents = {}
    aliases = set()
    central_at = c_off
    local_at = 0
    total = 0
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        entries = archive.infolist()
        demand(len(entries) == count, "parsed inventory mismatch")
        for entry in entries:
            demand(raw[central_at:central_at + 4] == b"PK\x01\x02", "central signature")
            values = struct.unpack_from("<4s6H3L5H2L", raw, central_at)
            _, made, needed, flags, method, mtime, mdate, crc, compressed, size, name_len, extra_len, comment_len, start_disk, internal, external, offset = values
            name_raw = raw[central_at + 46:central_at + 46 + name_len]
            extra = raw[central_at + 46 + name_len:central_at + 46 + name_len + extra_len]
            central_at += 46 + name_len + extra_len + comment_len
            demand(flags == 0 and method in (0, 8), "unsupported flags, encryption, or compression")
            demand(start_disk == 0 and offset == local_at and needed <= 20, "disk, record gap/overlap, or ZIP64")
            demand(extra == b"" and comment_len == 0, "unexpected extra fields or comments")
            demand(raw[offset:offset + 4] == b"PK\x03\x04", "local signature")
            local = struct.unpack_from("<4s5H3L2H", raw, offset)
            _, ln, lf, lm, lt, ld, lc, lcs, lus, lnl, lel = local
            local_name = raw[offset + 30:offset + 30 + lnl]
            demand((ln, lf, lm, lt, ld, lc, lcs, lus) == (needed, flags, method, mtime, mdate, crc, compressed, size), "local/central metadata mismatch")
            demand(lnl == name_len and lel == 0 and local_name == name_raw, "local/central names/extras mismatch")
            local_at = offset + 30 + lnl + lel + compressed
            demand(local_at <= c_off, "local record exceeds central boundary")
            name = name_raw.decode("ascii")
            demand(name == entry.filename and entry.header_offset == offset, "zipfile/manual parser mismatch")
            demand(not name.startswith(("/", "\\")) and "\\" not in name and ":" not in name and "\x00" not in name, "unsafe pathname")
            parts = name.split("/")
            demand(all(x not in ("", ".", "..") and x == x.rstrip(" .") for x in parts), "unsafe pathname component")
            demand(all(not re.match(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", x, re.I) for x in parts), "Windows reserved component")
            alias = unicodedata.normalize("NFKC", name).casefold()
            demand(alias not in aliases and unicodedata.normalize("NFC", name) == name, "case/Unicode alias")
            aliases.add(alias)
            mode = external >> 16
            demand(stat.S_ISREG(mode) and not stat.S_ISLNK(mode) and not (external & 0x10), "nonregular/link/directory entry")
            demand(size <= 20_000_000 and compressed > 0 and size / compressed <= 100, "entry compression limit")
            total += size
            demand(total <= 50_000_000, "total uncompressed limit")
            with archive.open(entry) as member:
                data = member.read(size + 1)
                demand(len(data) == size and member.read(1) == b"", "entry complete-read failure")
            contents[name] = data
            inventory.append({"name": name, "bytes": size, "compressed_bytes": compressed, "sha256": hashlib.sha256(data).hexdigest(), "crc32": "%08x" % crc, "mode": oct(mode), "local_offset": offset})
    demand(local_at == c_off and central_at == c_off + c_size, "record coverage mismatch")
    demand(hashlib.sha256(contents["manifest.json"]).hexdigest() == EXPECTED, "EXTERNAL manifest hash mismatch")
    manifest = json.loads(contents["manifest.json"].decode("utf-8"), object_pairs_hook=no_duplicates)
    demand(set(manifest["files"]) | {"manifest.json"} == set(contents), "manifest exact inventory mismatch")
    demand(len(manifest["files"]) == 15 and len(contents) == 16, "exact 16 file requirement")
    for name, declared in manifest["files"].items():
        data = contents[name]
        demand(len(data) == declared["bytes"] and hashlib.sha256(data).hexdigest() == declared["sha256"], "declared hash/size mismatch " + name)
    triad = [contents[n] for n in ("TASK_DIRECTIVE.md", "PROMPT_TEMPLATE.md", "EXACT_PROMPT.md")]
    demand(triad[0] == triad[1] == triad[2], "triad byte mismatch")
    report = {"result": "INDEPENDENT_READ_ONLY_AUTHENTICATED", "archive": str(ARCHIVE), "archive_bytes": len(raw), "archive_sha256": hashlib.sha256(raw).hexdigest(), "manifest_sha256": EXPECTED, "files": 16, "triad_identical": True, "all_manifest_files_authenticated_including_verifier": True, "packet_code_executed": False, "extracted": False, "compression_limits": {"archive_max_bytes": 100000000, "entry_max_bytes": 20000000, "uncompressed_total_max_bytes": 50000000, "ratio_max": 100}, "uncompressed_total_bytes": total, "pathname_metadata_before": metadata(p0), "pathname_metadata_after": metadata(p1), "handle_metadata_before": metadata(f0), "handle_metadata_after": metadata(f1), "cross_api_compatible_fields": compatible, "excluded_only_read_induced_fields": ["st_atime", "st_atime_ns"], "ctime_policy": "ctime preserved within pathname and handle families; incompatible Windows ctime meanings not equated across APIs", "inventory": inventory}
    OUTPUT.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("result", "archive_sha256", "manifest_sha256", "files", "triad_identical", "uncompressed_total_bytes")}))


if __name__ == "__main__":
    main()
