# Campaign28 pre-seal engineering report draft

Authority: **BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01**.
Intended submission status: **SUBMITTED_REVIEW_REQUIRED / NO_GO**.
This is a pre-seal draft for root review, not an acceptance decision or a claim
that the final return has already been delivered. The independent Brain
retains source acceptance; qualified owners retain all other gates. USD0.
NO MERGES. No auto-merge, rebase, force push or prior-PR modification.

## Authenticated authority and exact source

The single supplied context ZIP passed independent framing, inventory,
compression, regular-file/link/reparse, path/alias, stable complete-read and
hash checks before extraction or packet execution. External manifest SHA256:
`6bcd248c67f4db0eeb27691c34bcef5ebdc4bcaabf300e24f5e3dc7a3b941c81`.
All declared members, including verify_packet.py, were authenticated. The
original command with two ASCII hyphens returned exit0 / VERIFIED, exactly16
files and byte-identical directive/template/prompt. Only legitimate access-time
changes were excluded; applicable identity, size, mtime, mode, link, reparse,
complete-read and hash checks remained. Windows ctime comparisons stayed
within compatible metadata domains.

The complete directive, 00–06, anchors and authenticated Brain audit/receipt
were read. The actual prior Campaign27 return was separately authenticated:
ZIP SHA256 `d44e701ef98d2c6879b21ce8d6958fa580bd4bcf51304e6c6713c279c78111bc`,
122 outer files and305 checkpoint-payload files, original artifact verifier
exit0 / VERIFIED. Prior supplier execution is not independent Brain Git replay.

PR31 was independently confirmed open/draft/unmerged at HEAD
`517b50413b136639413b783cf3e899a6bc6c19ed`, tree
`497f248472f775cef2a9922475fa9f3f62b75060`. The sole first-child scope plan is
`fda89d90e92b05a094018f07d83077659f847509`, SHA256
`cd862ff6be2e30332f9e3810d565fd55402353fe016e4e684acaaa30b3a6222d`.
Its controlling explicit array contains27 finite paths. The prose count29 is
an acknowledged immutable typo; it does not authorize two additional paths.

Clean substantive source is HEAD
`78f3198c996cee96168423557a7072f405b0391e`, tree
`8856134ca636ab510fea554cf6508f9225b2f9c4`, branch
`stage/m1-destructive-commit-core05-28`. One new draft PR32 stacks on unchanged
PR31. Raw PR metadata confirms open/draft/unmerged, auto_merge=null and
maintainer_can_modify=false. The GitHub test-merge object
`09274408582031036d5697ee98993aab64adab79` has the same tree and exact ordered
parents PR31 then substantive HEAD. It is not an actual merged PR.

At this SOURCE stage,19 finite paths changed and23,535 tracked blobs were
reconciled. Current controls pass29 positives/216 refusals and preserve202
inherited function ASTs. Original Security, health/consent/account authority,
onboarding notifications production route, photo/F09 and SQL sources remain
outside the modification scope. A finite delta summary and exact fact-input
hashes accompany this draft, without a large protected per-file catalog.

## R28-A: confirmed destructive operations

**FIXED_AND_PROVED within the explicit source/adapter pre-native boundary.**
The original two stronger mounted cases are preserved byte-identically. Both
are Remove cases: a current user confirms, then exact Query replacement or
unmount overtakes the first pending private read and the original code still
removes the item. Separate Discard equivalents fail in the same interval.
Pinned-PR31 before result is63 total,59 pass/4 fail. Root repeated it after
normal fresh npm-ci with the same four failures. Ordinary valid confirmation,
duplicate/cancel/stale callback and grant-denial controls remain positive.

The state machine is accepted UI/query/owner lease → serialized queue → raw
private read/failed-read guard → key/decrypt → synchronous product/outbox
transform → conflict reread → key/encryption preparation → final synchronous
admission → native API invocation → fulfillment/ambiguous failure → canonical
readback → permitted current-screen publication.

A backward-compatible optional fourth privateKV callback checks the current
UI/source predicate during preparation and at the last synchronous point
before AsyncStorage invocation, without an intervening await. Only Shelf
Remove/Discard threads the predicate through store and mutation APIs. It is
separate from the original postwrite health/additional guard. Old callers,
encrypted contents/key behavior, serialization, conflict protection, original
account/health and ambiguous-write compensation remain preserved.

Precommit retirement produces zero native Shelf writes, exact prior encrypted
product/outbox bytes and no outbox notification. After native invocation,
volatile UI retirement does not add compensation or promise cancellation.
Tests hold the adapter both before it stores bytes and after bytes are visible;
the admitted write settles with its item/outbox transaction intact while stale
publication is refused. Original health/regrant compensation remains distinct
and is exercised after adapter-visible writes.

Canonical success is independently fenced: the same Query object must complete
its ordered invalidate→fetch→one nonmanual success sequence, exactly one data
counter increment, unchanged error counter and current authority. Actual
replacement, reset/ABA, manual data, canceled/restarted readback, unmount,
errors and health retirement revoke publication. An idempotent reinvalidation
of an already-invalidated Query produces no state/event transition; it is
explicitly measured as a no-op, not mislabeled as source retirement.

Independent new boundary suite:108/108. Untouched original regression lane:
192/192. Tests cover queue/read/conflict/key/final serialization, native
invoked/unsettled/fulfilled, canonical refetch, exact outbox, duplicate taps,
same-owner regrant, owner ABA, actual account-generation transition, expiry,
withdrawal, malformed/decrypt/key/encryption failures, conflict and ambiguous
native/readback failures. Dedicated Remove/Discard restart controls confirm
that a retired pending operation leaves bytes unchanged, its old callback
stays inert after Close/reopen, and a new explicit confirmation commits once.

The broader native guarantee is **OPEN_REQUIRED / UNAPPLIED**. JavaScript API
invocation is the observed boundary; adapters do not prove physical iOS/Android
durability, native atomic transactions, termination/relaunch behavior or safe
cancellation after invocation. Previously existing compensation is not recast
as physical rollback. No native acceptance is inferred.

## R28-B: CORE-05 structural correction

**FIXED_AND_PROVED as a current source-contract correction.** Original PR31
execution remains35 pass/1 fail at the brittle line595 one-argument spelling;
historical PR28/29 red evidence also remains. The production route actually
awaits the three ordered arguments PROPOSED_ROUTINE_REMINDER_TIMES, undefined,
assertLifecycle. The production route itself is unchanged.

Only the brittle original assertion is replaced. Its TypeScript/TSX AST helper
binds the actual component/handler/enable branch, awaited callee/imports,
ordered arguments, const accepted lease, synchronous meaningful lifecycle
callback, direct ordered focus/current-health/captured-health assertions and
anti-shadow/no-op/dead-branch structure. Unrelated original assertions remain.
Thirty-one actual mutations are refused; two authentic/formatting positives
pass. Current original suite36/36 and focused file69/69 (original36 plus33 new)
pass. Earlier combined105 contains duplicated original36 registration and is
not105 unique cases. Runtime reminder/lifecycle suites execute in the full
mobile corpus. This does not prove OS consent, permission or reminder delivery;
canonical SQL CORE-05 remains separate evidence.

## Actual clean local regression and export evidence

At exact clean substantive HEAD/tree, root executed
`turbo run test typecheck lint --force --concurrency=1`:6478 mobile tests across
499 files,24 operator tests across7 files,8 successful tasks and0 cached.
The receipt proves unchanged HEAD/tracked diff throughout. The identified
original photo subset is112 tests: layout15 plus focused97, included in this
actual full forced run; it is not counted as an additional execution.

Both separate clear-cache unsigned Expo development exports returned exit0
from clean exact source, with unchanged tracked state. Their actual Hermes
bundles and asset/type metadata are hashed in LOCAL_VALIDATION28.json. This
does not establish signed builds, installed-native behavior or Apple approval.

Eight required technical commands return0: postinstall patch check, corrected
original CORE-05, focused CORE-05, launch contracts, launch baseline check and
smoke, native privacy source snapshot and advisory/patch behavior controls.
The separate strict native-readiness command returns1 on five retained
warnings: development/production OCR disabled, final native identity/brand
clearance, signed Phase3 release clearance and reviewed export declaration.
Its source readiness failure is not waived or presented as a technical pass.

An earlier clean forced run failed immediately with ENOSPC; its receipt and
log remain. C: capacity was recovered through verified lossless NTFS compression,
without deletion or moving protected material.55,170 dependency files retained
raw bytes, identities, modes, links and mtimes; compressed attributes changed
intentionally, with no ctime-restoration claim. Subsequent full clean tests,
exports, hooks and source checks passed. Failed earlier attempts are not
relabeled; incomplete zero-byte artifacts are excluded from this proof index.

## Historical and public CI execution

The local historical worker has actual completed original151 semantic-negative
controls and Release09–18 receipts at this fixed draft snapshot. Each retains
its authentic source/script/checker identities, clean before/after state and
original synthetic/native-input qualifications. Ten authenticated source pins
from the current real install are fixture inputs for those historical lanes;
they are not a claim of historical full npm installations. Release19–23
completion is not asserted in this draft; root must incorporate the remaining
actual receipts before sealing its final historical conclusion.

Prefreeze candidate run40992328036 on Linux and Windows independently completes
actual original Release24/25/26/27 full fresh-clone, normal-npm-ci/mandatory-hook,
consumer and source checks at their own exact heads. Counts are23/127,16/122,
26/198 and26/198 respectively. Original27 executes at pinned PR31, not current28.
Current28 passes29/216/202 and CORE-05 passes69/69 on both platforms. New28
filesystem controls are Linux32 positive/12 refusals/0 NOT_RUN and Windows
34/11/1 NOT_RUN; untouched27 Windows hosted/Python3.12 results retain32/11/1.

Both real public readiness runners subsequently exit1 with candidateReady=false,
executionComplete=true and authentic unresolved public findings/custody.
Actual downloaded Linux/Windows artifacts match GitHub digests, each pass56
member safety/authentication and export12 allowlisted public receipts. No
original private Security log/finding/artifact was read. Original Security
run40992328038 completes FAILURE, observed through metadata only.

Prefreeze iOS launch run40992328194 succeeds at the actual test-merge, with6478
mobile/24 operator and0 task-cache hits. Hosted commands are plain Turbo with
cache misses; unlike the local lane they are not mislabeled --force. Prefreeze
Quality run40992327995 remains FAILURE because the unchanged strict Phase4
check correctly rejects both stale prefreeze worklists; its export matrix is
skipped. This red run remains historical evidence for the later freeze.

The canonical credential-free DB job123857872354 actually succeeds: two resets,
97 migrations through20261010000081, focused SQL CORE-05, structural pgTAP/RLS,
schema lint, empty drift, CAT08 two-connection rehearsal and7381-line generated
type parity (SHA2562b475803f0ea143681de2912637e61b1cf26e271043a84a1692e7d1d6b87a795).
Optional failure-only type retention is skipped. PG15/PG17 jobs each complete15
isolated rehearsals. These are hosted mechanics only: DB06/DB08/R2B remain
NOT_ACCEPTED. Local canonical DB execution is NOT_RUN because Docker server
availability timed out; hosted execution is reported separately.

## Explicit limits and work after this seal

Current browser viewport/manual-draft/scroll/confirmation, measured200% text,
focus and keyboard execution is NOT_RUN: the actual browser tool reported
local browser use disabled. Historical screenshots and mounted geometry do
not become current browser, physical iPhone or VoiceOver proof.

Final freeze/worklist child, sole checkpoint/handoff tail, final sealed HEAD/tree
and final-head CI, two complete independent final-head Git clones, actual
source/artifact corruption/refusal/restoration0/1/0, minimal PR31-dependent
bundle, complete outer FINAL_REPORT, one actual return ZIP, external anchors
and fresh authenticated download are **NOT_RUN_AT_SEAL** placeholders here.
They must be performed and reported externally after the immutable seal; they
are not fabricated as already complete. This pre-seal source report does not
claim delivery or become a second source/evidence commit after freeze.

G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03
BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED; J01 optical
G1/G2/G3/G5 and longitudinal G4 NOT_ACCEPTED. Native/VoiceOver, provider, paid,
professional, clinical/legal/licensing, Apple and public release remain CLOSED.
Retain required non-Korean F01–F17/F19–F20, C01–C12, P01–P06, private F09 diary/
manual comparison and only independently qualified Korean J01 Visible Pores;
F18 and J02–J27 including J05 remain deferred.
