import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parent
HEAD='78f3198c996cee96168423557a7072f405b0391e'
TREE='8856134ca636ab510fea554cf6508f9225b2f9c4'
BASE='517b50413b136639413b783cf3e899a6bc6c19ed'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def meta(value):return {k:getattr(value,k) for k in dir(value) if k.startswith('st_') and k not in ('st_atime','st_atime_ns')}
def read(path):
 before=path.lstat();assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and not getattr(before,'st_file_attributes',0)&1024
 with path.open('rb') as stream:
  opened=os.fstat(stream.fileno());raw=stream.read();finished=os.fstat(stream.fileno())
 after=path.lstat();assert meta(before)==meta(after) and meta(opened)==meta(finished) and len(raw)==before.st_size
 for key in ['st_dev','st_ino','st_nlink','st_size','st_mode','st_mtime_ns','st_uid','st_gid']:
  assert getattr(before,key)==getattr(opened,key)
 for key in ['st_file_attributes','st_reparse_tag','st_birthtime_ns']:
  if hasattr(before,key) and hasattr(opened,key):assert getattr(before,key)==getattr(opened,key)
 return raw
inputs={}
def add(path,role,qualification):
 path=Path(path);absolute=WORKSPACE/path;raw=read(absolute);assert raw,('INCOMPLETE_ZERO_BYTE_INPUT',str(path))
 row=inputs.setdefault(path.as_posix(),{'path':path.as_posix(),'bytes':len(raw),'sha256':sha(raw),'roles':[],'qualification':qualification})
 assert row['sha256']==sha(raw)
 if role not in row['roles']:row['roles'].append(role)

boot=WORKSPACE/'Campaign28_bootstrap'
local=json.loads(read(boot/'LOCAL_VALIDATION28.json'))
assert local['sourceHead']==HEAD and local['sourceTree']==TREE
for record in local['records']:
 for name,digest in [(record['log'],record['logSHA256']),(record['receipt'],record['receiptSHA256'])]:
  assert sha(read(boot/name))==digest
  add('Campaign28_bootstrap/'+name,'clean-source-local-validation:'+record['case'],'ACTUAL_CLEAN_SUBSTANTIVE_EXECUTION_NOT_ACCEPTANCE; exit retained including native strict1')
add('Campaign28_bootstrap/LOCAL_VALIDATION28.json','clean-source-validation-index','Twelve actual executions; full6478+24/8tasks0cache; photo112 is included subset, not additional execution')
for name in ['intake_receipt.json','independent_archive_audit.json','verification.json','prior_return_artifact_verifier_receipt.json','PRIOR_RETURN_REVIEW.md','baseline-fresh-receipt.json','baseline-fresh-results.json','after-original-results.json','npm-ci28-authenticated.receipt.json','npm-ci28-authenticated.log','pinned-toolchain28-corrected.receipt.json','pinned-toolchain28-corrected.log','full-quality28-clean.receipt.json','full-quality28-clean.log','full-test28-precommit.receipt.json','full-test28-precommit.log','browser28-availability.json','docker28-availability.json','contracts28-results.json']:
 add('Campaign28_bootstrap/'+name,'context/baseline/install/retained-failure/availability','Original file qualification controls; precommit/failed/NOT_RUN identities are not relabeled as clean final proof')
for name in ['baseline-receipt.json','baseline-results.json','historical-pending-retirement.test.ts','discard-pending-retirement.test.ts','historical-commit-boundary.test.ts','proposed-baseline-receipt.json','proposed-baseline-results.json','proposed-after-results.json','restart-complete-results.json','final-original-regression-results.json','independent-app-review.json','INDEPENDENT_APP_REVIEW.md']:
 add('campaign28-review-app/'+name,'application-independent-review','Supplier separate-object exact-PR31 clone plus root-written candidate bytes; reused installed dependencies, not fresh install/native proof')
for name in ['core05-baseline-identity.json','core05-baseline-original.tap','REVIEW.md']:
 add('campaign28-review-governance/'+name,'core05-original-red-and-governance-review','Original35/1 retained; review/proposals and synthetic controls are not final source acceptance')
for name in ['BOUND_SUBSTANTIVE_REVIEW_RECEIPT.json','CI_MEMORY_CONTROLS_RECEIPT.json']:
 add('campaign28-packaging/'+name,'packaging-source-binding-and-controls','External supplier review/control evidence, not completed final clone or delivery proof')

ci='campaign28-review-app/ci-observer28/'
for name in ['prefreeze-pr32-raw.json','prefreeze-test-merge-identity.json','prefreeze-candidate-run-complete.json','prefreeze-candidate-jobs-complete.json','prefreeze-candidate-artifacts-complete.json','prefreeze-linux-receipts-inspection.json','prefreeze-windows-receipts-inspection.json','prefreeze-linux-public.download.json','prefreeze-windows-public.download.json','prefreeze-quality-run-report-seal-snapshot.json','prefreeze-quality-jobs-report-seal-snapshot.json','prefreeze-ios-launch-public.log','prefreeze-postgres15-public.log','prefreeze-postgres17-public.log','prefreeze-quality-public.log','prefreeze-canonical-db-public.log','prefreeze-original-security-run-cached-2.json','prefreeze-original-security-jobs-cached-2.json','prefreeze-observation-correction.json']:
 add(ci+name,'actual-prefreeze-live-ci','Actual connected GitHub metadata/public technical execution; original Security metadata only; prefreeze Quality failure preserved')
for directory in ['public-ci-verified-b1jmh523','public-ci-verified-wtcn0dws']:
 root=WORKSPACE/ci/directory
 for path in sorted(root.iterdir()):
  assert path.is_file()
  add(path.relative_to(WORKSPACE),'authenticated-allowlisted-public-ci-receipt','All56 archive members framing/CRC/hash verified; exact12 public files plus extraction metadata; no original private Security logs')

history='campaign28-history/substantive-78f3198c-recovered/'
completed=[]
for release in ['08-original151']+[f'{n:02}' for n in range(9,19)]:
 name='release'+release;receipt=json.loads(read(WORKSPACE/history/(name+'.receipt.json')))
 assert receipt['campaign28ContextHead']==HEAD and receipt['campaign28ContextTree']==TREE and receipt['exit']==0 and not receipt['timeout'] and receipt['cleanAfter'] and receipt['before']==receipt['after']
 assert sha(read(WORKSPACE/history/(name+'.stdout.log')))==receipt['stdoutSHA256']
 completed.append({'release':release,'historicalSource':receipt['source'],'tree':receipt['tree'],'terminalResult':receipt['terminalResult'],'qualification':receipt['qualification'],'nativeInputs':receipt['nativeInputs']})
 for suffix in ['.receipt.json','.stdout.log']:add(history+name+suffix,'completed-original-historical-consumer','Exact original unchanged script at authenticated historical full checkout; internal synthetic/native-pin fixture qualification retained; not historical full npm install')
for name in ['early-provenance.json','late-provenance.json']:
 add(history+name,'historical-checkout-provenance','Separate complete Git objects; authenticated fixture-only native source inputs, not historical npm installation')

compression=json.loads(read(boot/'compression28-files-receipt.json'))
resource={k:compression[k] for k in ['status','qualification','attributesChange','files','elapsedSeconds','freeBefore','freeAfter','release']}
resource.update(sourceReceiptSHA256=sha(read(boot/'compression28-files-receipt.json')),sourceReceiptNotPackaged='Large command/per-file catalogs omitted; source digest retained for custody',skippedPathCount=len(compression['skippedReparsePaths']),acceptanceGranted=False)
(ROOT/'RESOURCE_RECOVERY_SUMMARY.json').write_text(json.dumps(resource,indent=2),encoding='utf-8')
add('campaign28-report/RESOURCE_RECOVERY_SUMMARY.json','resource-recovery','Verified lossless storage representation change only; no deletion/move or ctime restoration claim')

git=lambda *args:subprocess.check_output(['git','-C',str(WORKSPACE/'campaign28-source'),*args])
changes=[]
for line in git('diff','--raw','--full-index','--abbrev=40','--no-renames',BASE,HEAD).decode().splitlines():
 fields,path=line.split('\t',1);oldmode,newmode,oldblob,newblob,status=fields.lstrip(':').split()
 assert len(oldblob)==len(newblob)==40
 blob=git('show',HEAD+':'+path)
 changes.append({'path':path,'oldMode':oldmode,'mode':newmode,'oldBlob':oldblob,'blob':newblob,'change':status,'bytes':len(blob),'sha256':sha(blob)})
assert len(changes)==19
delta={'base':BASE,'head':HEAD,'tree':TREE,'stage':'SOURCE','changedPaths':changes,'qualification':'Finite19-path substantive delta only; not the final27-path freeze/tail delta','acceptanceGranted':False,'release':'NO_GO'}
(ROOT/'PREFREEZE_SOURCE_DELTA.json').write_text(json.dumps(delta,indent=2),encoding='utf-8')
add('campaign28-report/PREFREEZE_SOURCE_DELTA.json','finite-substantive-source-delta','Exact Git object modes/blobs/SHA256s for only19 changed paths; no protected full-tree catalog')
add('campaign28-source/docs/brain/task-specs/M1X-28/SCOPE_PLAN.md','immutable-first-child-scope','Controlling27-path array; prose29 typo immutable and not scope expansion')

index={'schema':1,'recordedUTC':datetime.now(timezone.utc).isoformat(),'status':'PREFREEZE_SOURCE_PROOF_INDEX_NOT_FINAL_DELIVERY','authority':'BRAIN-M1X-DESTRUCTIVE-COMMIT-CORE05-28-CANDIDATE-01','source':{'base':BASE,'baseTree':'497f248472f775cef2a9922475fa9f3f62b75060','head':HEAD,'tree':TREE,'phase':'SOURCE','plan':'fda89d90e92b05a094018f07d83077659f847509','controllingScopePaths':27,'proseCountTypo':29,'currentChangedPaths':19,'rawTrackedBlobs':23535,'currentControls':{'positive':29,'refused':216,'inheritedFunctions':202}},'localValidation':{'executions':len(local['records']),'mobile':6478,'operator':24,'successfulForcedTasks':8,'cachedTasks':0,'photoIncludedSubset':{'layout':15,'focused':97,'total':112,'additionalExecution':False},'core05':local['core05'],'nativeStrictExit':1,'nativeWarnings':5},'historical':{'completedInThisFixedSnapshot':completed,'remainingCompletionNotClaimed':['19','20','21','22','23'],'full09Through23CompletionClaimed':False},'notRunAtSeal':['freeze/worklist child','checkpoint/handoff tail and final head/tree','final-head CI','two complete independent final-head clones','real final source/artifact0/1/0 controls','minimal PR31-dependent final bundle','complete final outer report/ZIP/external hashes','fresh final authenticated network download'],'inputs':sorted(inputs.values(),key=lambda item:item['path']),'inputBytes':sum(row['bytes'] for row in inputs.values()),'explicitExclusions':['mutable STATE.json as sole proof','all incomplete zero-byte files','large dependency compression per-file catalogs','full protected tracked-file catalogs','all original private Security logs/findings/annotations/artifacts','temporary signed download URLs','whole historical/full-source Git checkouts','raw public CI ZIPs are custody references, not additional return ZIPs'],'metadataQualification':'Stable complete reads with same-domain stat/fstat checks excluding only atime; compatible Windows cross-domain identities; no cross-domain ctime equality assumption','sourceAcceptance':False,'acceptanceGranted':False,'release':'NO_GO'}
(ROOT/'PREFREEZE_SOURCE_PROOF_INDEX.json').write_text(json.dumps(index,indent=2),encoding='utf-8')
print(json.dumps({'status':index['status'],'inputFiles':len(inputs),'inputBytes':index['inputBytes'],'localExecutions':len(local['records']),'historicalCompleted':len(completed),'remainingHistorical':['19','20','21','22','23'],'indexSHA256':sha(read(ROOT/'PREFREEZE_SOURCE_PROOF_INDEX.json'))}))
