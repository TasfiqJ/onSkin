"""Authenticate actual completed prefreeze receipts; no producer/source writes."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

RUN = Path(__file__).resolve().parent
WORK = RUN.parent
ROOT = WORK / 'campaign28-source'
HEAD = '78f3198c996cee96168423557a7072f405b0391e'
TREE = '8856134ca636ab510fea554cf6508f9225b2f9c4'
VERIFIER = WORK / 'campaign28-packaging/reviewed-substantive-03/packaging/verify28.py'
ANCHOR = '9769435d01d678fd6acfcd1bd484f493578d2c32e2ecc7d5c431f2925c8d33f7'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def main():
    assert not (RUN/'WORKLIST_FREEZE_RECEIPT.json').exists(), 'PRODUCER_ALREADY_RESERVED'
    assert sha(VERIFIER.read_bytes()) == ANCHOR
    spec = importlib.util.spec_from_file_location('gate28_reader', VERIFIER)
    v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
    required = {}
    def add(path, expected=None):
        path = path.resolve(); raw = v.read_regular(path)
        actual = dict(path=str(path), bytes=len(raw), sha256=sha(raw))
        if expected:
            assert actual['bytes'] == expected['bytes'] and actual['sha256'] == expected['sha256']
        required[str(path.relative_to(WORK)).replace('\\','/')] = actual
        return raw
    index_path = WORK/'campaign28-report/PREFREEZE_SOURCE_PROOF_INDEX.json'
    index = json.loads(add(index_path))
    assert index['source']['head'] == HEAD and index['source']['tree'] == TREE
    assert index['acceptanceGranted'] is False and index['release'] == 'NO_GO'
    assert index['localValidation']['mobile'] == 6478 and index['localValidation']['operator'] == 24
    assert index['localValidation']['cachedTasks'] == 0
    for entry in index['inputs']:
        add(WORK/entry['path'], entry)
    history = []
    for label in ['08-original151'] + [str(n).zfill(2) for n in range(9,24)]:
        folder = WORK/'campaign28-history/substantive-78f3198c-recovered'
        receipt = json.loads(add(folder/('release'+label+'.receipt.json')))
        assert receipt['campaign28ContextHead'] == HEAD and receipt['campaign28ContextTree'] == TREE
        assert receipt['exit'] == 0 and receipt['timeout'] is False and receipt['cleanAfter'] is True
        assert receipt['before'] == receipt['after']
        for stream in ('stdout','stderr'):
            raw = add(folder/('release'+label+'.'+stream+'.log'))
            assert sha(raw) == receipt[stream+'SHA256']
        history.append(dict(release=label, source=receipt['source'], tree=receipt['tree'],
            result=receipt['terminalResult'], qualification=receipt['qualification'], nativeInputs=receipt['nativeInputs']))
    for number, expected in [(31,'517b50413b136639413b783cf3e899a6bc6c19ed'),(32,HEAD)]:
        pr = json.loads(add(WORK/('campaign28-report/PRESEAL_PR'+str(number)+'_LIVE.json')))
        assert pr['head']['sha'] == expected and pr['state'] == 'open' and pr['draft'] is True
        assert pr['merged'] is False and pr['auto_merge'] is None and pr['maintainer_can_modify'] is False
    assert v.git(ROOT,'rev-parse','HEAD').decode().strip() == HEAD
    assert v.git(ROOT,'rev-parse','HEAD^{tree}').decode().strip() == TREE
    assert not v.git(ROOT,'status','--porcelain=v1','--untracked-files=all').strip()
    gate = dict(status='PREFREEZE_TECHNICAL_EXECUTION_READY_FOR_WORKLIST_ONLY',
        sourceHead=HEAD,sourceTree=TREE,readyForWorklistFreeze=True,
        requiredReceipts=required,historicalOriginal151And09Through23=history,
        technicalQualification='ACTUAL_SOURCE_AND_ADAPTER_MECHANICS_ONLY_NOT_NATIVE_OR_QUALIFIED_ACCEPTANCE',
        unresolved=['G97_FAIL','GENUINE_PUBLIC_READINESS_NONREADY','PREFREEZE_PHASE4_STALE_EXPECTED',
          'NATIVE_STRICT_FIVE_WARNINGS','BROWSER_NOT_RUN_DISABLED','LOCAL_CANONICAL_DB_NOT_RUN',
          'PHYSICAL_NATIVE_DURABILITY_OPEN_REQUIRED_UNAPPLIED','ALL_QUALIFIED_GATES_CLOSED'],
        acceptanceGranted=False,release='NO_GO')
    out=RUN/'PREFREEZE_GATE.json'
    with out.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(gate,stream,sort_keys=True,indent=2);stream.write('\n')
    print(json.dumps(dict(status=gate['status'],authenticatedInputs=len(required),historicalLanes=len(history),
        sha256=sha(v.read_regular(out)),sourceHead=HEAD,sourceTree=TREE,acceptanceGranted=False,release='NO_GO'),sort_keys=True))

if __name__ == '__main__': main()
