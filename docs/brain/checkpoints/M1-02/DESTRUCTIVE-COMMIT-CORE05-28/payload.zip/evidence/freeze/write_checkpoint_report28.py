"""Write factual pre-tail report from immutable source proof and actual history."""
import json
from pathlib import Path

WORK=Path(__file__).resolve().parent.parent
REPORT=WORK/'campaign28-report'

def main():
    freeze=json.loads((WORK/'Campaign28_bootstrap/WORKLIST_FREEZE_RECEIPT.json').read_bytes())
    assert freeze['status']=='COMMITTED_SOLE_WORKLIST_CHILD' and freeze['producerInvocations']==1
    gate=json.loads((WORK/'Campaign28_bootstrap/PREFREEZE_GATE.json').read_bytes())
    history=json.loads((WORK/'campaign28-history/substantive-78f3198c-recovered/SUMMARY.json').read_bytes())
    assert history['status']=='PASS_ORIGINAL151_AND_AUTHENTIC_ORIGINAL09_TO23' and len(history['runs'])==16
    body=(REPORT/'PRESEAL_REPORT_DRAFT.md').read_text(encoding='utf8')
    body=body.replace('# Campaign28 pre-seal engineering report draft','# Campaign28 immutable checkpoint engineering report',1)
    body=body.replace('Intended submission status:', 'Submission status:',1)
    body=body.replace('This is a pre-seal draft for root review, not an acceptance decision or a claim\nthat the final return has already been delivered.',
      'This is the immutable pre-tail checkpoint, not an acceptance decision or a claim\nthat the later final return has already been delivered.',1)
    start=body.index('The local historical worker has actual completed original151')
    end=body.index('\nPrefreeze candidate run',start)
    paragraph=('The local historical worker completed all16 original lanes: original151 semantic-negative controls and Release09–23, all actual exit0, with exact historical source/tree/script/checker identities, full raw tracked-byte reconciliation before and after, and clean final state. Original internal bundle/fixture/synthetic-segment qualifications remain in every receipt. Ten authenticated public source pins from the current real install are inputs to those historical lanes; they are not historical full npm installations and do not prove installed-native behavior. The actual unmodified24–27 normal fresh-clone/install replay is separately executed on both current hosted platforms below.\n\n')
    paragraph+='| Original lane | Exact historical source | Actual terminal result |\n| --- | --- | --- |\n'
    for row in history['runs']:
        result=json.dumps(row['terminalResult'],sort_keys=True,separators=(',',':'))
        paragraph+='| '+row['release']+' | `'+row['source']+'` | `'+result+'` |\n'
    body=body[:start]+paragraph+body[end:]
    start=body.index('Final freeze/worklist child, sole checkpoint/handoff tail, final sealed HEAD/tree')
    end=body.index('\nG97 FAIL/NO_GO;',start)
    body=body[:start]+('The unchanged original Phase4 producer was invoked exactly once from clean committed substantive source, returned0, and created only the two original generated worklists. Its sole child is `'+freeze['sourceHead']+'`, tree `'+freeze['sourceTree']+'`. The complete authenticated prefreeze gate references '+str(len(gate['requiredReceipts']))+' actual inputs; its readiness is for this worklist operation only and grants no acceptance.\n\n'
      'The subsequent sole checkpoint/handoff tail, final sealed HEAD/tree, final-head CI, two complete independent final-head Git clones, actual source/artifact corruption-refusal-restoration0/1/0, minimal PR31-dependent bundle, complete outer FINAL_REPORT, one actual return ZIP, external anchors and fresh authenticated download are **NOT_RUN_AT_SEAL**. They are required subsequent executions and must be reported externally after this immutable seal. No final-head result or delivery is asserted by this checkpoint, and no second source/evidence tail is authorized.\n')+body[end:]
    assert 'Release19–23\ncompletion is not asserted' not in body
    assert body.count('NOT_RUN_AT_SEAL')>=1
    out=REPORT/'PRESEAL_REPORT.md'
    with out.open('x',encoding='utf8',newline='\n') as stream:stream.write(body)
    print(json.dumps(dict(report=str(out),bytes=len(out.read_bytes()),freeze=freeze['sourceHead'],historicalLanes=16,acceptanceGranted=False,release='NO_GO')))

if __name__=='__main__': main()
