# Campaign28 prefreeze live CI observation

ACTUAL_PREFREEZE_SOURCE_EXECUTION_NOT_FINAL_HEAD_OR_ACCEPTANCE.
SUBMITTED_REVIEW_REQUIRED / NO_GO. Original Security logs/findings were not
opened; only its run/job metadata was read. No CI rerun, comment, upload, source
write, merge or approval was performed by this observer.

## Source and event identities

Observed PR32 is open, draft and unmerged. `auto_merge=null` and
`maintainer_can_modify=false`. Source HEAD
`78f3198c996cee96168423557a7072f405b0391e`, tree
`8856134ca636ab510fea554cf6508f9225b2f9c4`, base exact PR31
`517b50413b136639413b783cf3e899a6bc6c19ed`.

The actual GitHub `refs/pull/32/merge` object was independently fetched from
the GitHub remote: `09274408582031036d5697ee98993aab64adab79`, same tree
`8856134ca636ab510fea554cf6508f9225b2f9c4`, exact ordered parents PR31 and
`78f3198c996cee96168423557a7072f405b0391e`. Raw API responses corroborate it.
It is a GitHub-generated test-merge object, not an actual PR merge.

## Candidate Linux and Windows — completed

Run40992328036 (`security-candidate22.yml`) executes exact source HEAD78f3198c.
Both job123857425886 (Linux) and123857426248 (Windows) completed with the
expected actual failure solely at the current public readiness runner. The
historical and current source-control steps actually completed successfully.

Both platforms independently cloned, normally installed with mandatory hooks,
and ran original Release24/25/26/27 consumers and source checkers at their
actual immutable heads. Counts retain original qualifications:

| Release | Exact historical HEAD | Positives/refusals |
| --- | --- | --- |
|24|d0ccef65bcbe0c90483e6c0f691ed95f92228c6c|23/127|
|25|52a3d01ebb36a6845d0ac21935ad35520732633f|16/122|
|26|8c02a02afd7f2e9775dcc512c800d4f71f733234|26/198|
|27|517b50413b136639413b783cf3e899a6bc6c19ed|26/198|

All four machine receipts and strict parser pins authenticate the full
identities above. All four records prove
npm-ci/postinstall exit0, mandatory hooks, fresh empty install cache, unchanged
checkout/tool identities and nativeDeviceOrSignedBuild=NOT_RUN.

Current28 controls pass29 positives/216 refusals with202 inherited function
ASTs. Source28 is valid at exact HEAD/tree, SOURCE phase,19 changed paths and
23,535 tracked working blobs hashed, with all admission fields false. Its
working qualification is FINITE_PENDING_ALLOWED because this is prefreeze;
it is not final strict Phase4/frozen-source evidence.

Hosted current CORE-05 runs69 unique cases: original36 plus33 focused controls,
all pass, zero skips/todos. Current28 filesystem controls: Linux32 positive /
12 refusals /0 NOT_RUN; Windows34 positive /11 refusals /1 NOT_RUN. Untouched27
Windows controls on both hosted and explicit Python3.12 lanes are32/11/1
NOT_RUN. These filesystem controls are distinct from actual historical source
execution and do not prove installed-native storage.

The real public runner subsequently exits1 on both platforms, with
candidateReady=false, executionComplete=true, acceptanceGranted=false and
NO_GO. Authentic unresolved categories remain archive coverage, dependencies,
original source contract, protected secret-history custody, protected static
analysis custody, qualified custody and working-byte coverage. Nothing was
deleted or relabeled to make Security green.

Actual downloaded public artifact bytes match GitHub's independent metadata
digests, and the external strict reader authenticates all56 regular members
and exports only12 explicitly allowlisted public receipts per platform:

| Platform | Artifact ID | Bytes | ZIP SHA256 |
| --- | --- | --- | --- |
|Linux|12950337425|325425|09974977226b6b6f18c7a57ea9aa7ef8e1df45ddf81b40a33611e785e6aa359b|
|Windows|12950827956|327630|c2ac0b47a1154056dc107dffd79ef1100a6aa3df093e4cf7dbf9658184aad043|

Local/central/signed-descriptor framing, platform modes, paths/aliases,
bounded full decompression, CRC, complete stable reads and hashes passed.
`prefreeze-linux-receipts-inspection.json` and its Windows counterpart strictly
verify exact historical script identities, counts, fresh-install/hook outcomes,
stable checkouts/tools, current source/event/context, CORE-05 counts and public
nonadmission. The reader's own44 rejection/allowlist controls are separately
recorded and are not substituted for the actual CI artifacts.

## Quality, launch and database qualifications

Prefreeze Quality run40992327995 is incomplete overall at this report. Its
repository job123857872487 actually fails unchanged Phase4 strict check because
both generated worklists are stale. The failed command/exit1 and both explicit
stale-file errors are preserved in the permitted public log. The export matrix
is skipped after this failure. No current prefreeze unsigned export success or
six-job Quality success is claimed.

Independent iOS launch run40992328194/job123857426229 succeeds at the exact
test-merge above. Its actual public log shows6478 mobile tests across499 files,
24 operator tests across7 files, successful typecheck/lint/test task counts3/3/2
and zero cache hits on all three. The actual hosted commands are plain
`turbo run typecheck/lint/test`, with cache misses; they are not labeled as
explicitly forced. Root's separate local --force run is different evidence.
This is source/synthetic runtime
execution, not a physical iPhone or OS-delivery result.

Quality PG15 job123857872410 and PG17 job123857872129 each succeed. Their actual
public logs identify15 isolated PostgreSQL rehearsal invocations each and the
same checkout test-merge. Database mechanical success does not qualify
DB06/DB08/R2B.

Canonical DB job123857872354 is still executing “Reset twice, test, lint, and
prove zero drift” at the actual03:12:33 UTC metadata observation. Two-reset /
97-migration /SQL /pgTAP /RLS /lint /empty-drift /generated-type completion is
PENDING, not inferred from earlier campaigns or PG15/17 success. A later
completed or canceled result must be appended as a separate actual observation.

## Original Security and remaining work

Original Security run40992328038 completes FAILURE. Four security jobs fail;
live adversarial evidence is skipped. These are metadata-only observations.
No original Security log, annotation, finding or artifact was opened.

The C: filesystem temporarily reached zero free bytes while persisting public
metadata. Raw API/public logs were cached in memory, then written after
lossless compression recovered capacity. No delete/move bypass followed the
automatic cleanup rejection. Complete cached captures and hashes are retained;
the0-byte failed-write `prefreeze-quality-run-initial.json` is not a valid raw
metadata snapshot and should be excluded from the packaged evidence inventory.

Final frozen HEAD/tree, final test-merge, final CI, unsigned exports, strict
Phase4, two independent final-head checkouts and real artifact/source0/1/0 are
outside this prefreeze report and remain root's later validation. All qualified
gates stay closed. G97 FAIL/NO_GO; source acceptance remains with the Brain.
