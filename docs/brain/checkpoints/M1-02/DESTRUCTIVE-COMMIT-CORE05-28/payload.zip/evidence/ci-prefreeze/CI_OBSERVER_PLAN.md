# Campaign28 public CI observer plan

PREPARED_NOT_LIVE_CI_EVIDENCE. Read-only; no source changes, workflow reruns,
comments, uploads, merges or approvals. Original Security is metadata-only.

## Required future source inputs

Root supplies a committed, pushed candidate HEAD and tree after substantive
source checks, and later repeats with the sealed final HEAD/tree. PR32 must be
open/draft/unmerged, head branch `stage/m1-destructive-commit-core05-28`, base
`stage/m1-first-value-safety-ci27` at pinned PR31
`517b50413b136639413b783cf3e899a6bc6c19ed`. Its tree is
`497f248472f775cef2a9922475fa9f3f62b75060`.

Fresh GitHub run IDs are discovered from the supplied candidate HEAD. Supply
the PR test-merge SHA, tree and both parent identities once GitHub generates
that object. Quality normally checks that test-merge rather than the candidate
HEAD; those are distinct identities even when their trees match. Observing a
GitHub-generated test-merge is not an actual PR merge. Do not infer event
identity from a workflow title or a successful job.

`observe_metadata28.js` is a functions.exec template. Before executing it,
set `store('ci28_expected', {repository:'TasfiqJ/onSkin', pr:32, head:<actual>,
tree:<actual>, baseHead:'517b50413b136639413b783cf3e899a6bc6c19ed'})`.
It fetches PR metadata, commit-associated PR-triggered workflow runs and
combined status in parallel, then persists the complete connector responses
outside source. It saves immutable timestamped snapshots and prints only
small retrieval metadata. These are actual connector JSON responses, not
claimed raw HTTP bytes. The wrapper returns the first page; pagination gaps
must be disclosed rather than claiming a complete run inventory.

## Metadata and log allowlist

Resolve exact workflow paths from current run metadata:

| Workflow path | Permitted observations |
| --- | --- |
| `.github/workflows/security-candidate22.yml` | Both Linux/Windows job metadata, public candidate logs and the exact named public component artifact archives |
| `.github/workflows/quality.yml` | Six job metadata records and public technical logs for repository checks, canonical DB, PG15/17 and unsigned iOS/Android exports |
| `.github/workflows/ios-launch-contract.yml` | Run/job metadata and public technical launch-contract log |
| `.github/workflows/security.yml` | Run/job/status/conclusion metadata ONLY; no log, annotation, finding or artifact contents |

Use `github_fetch_workflow_run_jobs` for each verified run ID. Bind the returned
job IDs and attempt to those runs and the expected candidate HEAD. For logs,
call `github_fetch_workflow_job_logs` only after matching an exact allowed
workflow path, run ID and public job identity. No original Security log call
is permitted. First-page truncation or missing metadata remains incomplete.

Store raw public connector logs locally for audit where appropriate; publish
only exact technical summaries and hashed log identities in the return. A
passed workflow summary alone does not establish test counts, zero cache,
database SQL execution, platform replay or native admission.

## Candidate artifacts and boundary controls

Fetch candidate artifacts with `github_fetch_workflow_run_artifacts` only for
the verified candidate run. Accept exactly the named artifacts
`security23-public-components-ubuntu-latest-<runId>` and
`security23-public-components-windows-latest-<runId>` at matching workflow/head.
Require nonexpired metadata and its repository `digest` SHA256. Retrieve bytes
through `github_download_workflow_artifact`; its authorized file reference has
a short-lived content download URL. Feed that URL directly to
`download_artifact28.py` over stdin, with artifact ID, filename, expected
digest and qualification. Do not retain signed query strings in public
evidence or obtain service credentials. This helper downloads bounded bytes,
checks content length when provided, matches repository digest, exclusively
creates the local file and rereads exact bytes.

Before extraction, run `github_ci_reader28.py` with the expected digest and
platform. It derives from the authenticated Campaign27 helper
SHA256 `540f06fa7a2a35a666d2addf3fe5cde051822e5a65be9e2f54360bad67d13875`, with
authenticated checkpoint reader dependency
`1c0def8c666010b0ff09fd23a1385739a9b162b3304413fbbb9c88b937a05434`.
Only the dependency location/module label and explicit28 allowlist were
extended. Contiguous local/central/data-descriptor framing, exact platform
regular modes (Linux100644/Windows100666), paths/aliases, bounds, complete
inflate, CRC, stable reads and hashes remain checked. Every archive member is
authenticated; only exact public allowlisted files are written to a new empty
directory. Raw original Security logs are never exported. All44 synthetic
reader controls passed; that is reader testing, not fresh CI execution.

Require fresh current28 receipt files, not merely an older27 file accepted by
the compatibility allowlist:

- `security28-reader.jsonl`
- `security28-historical-receipt.json`
- `security28-historical-controls.jsonl`
- `security28-source-controls.jsonl`
- `security28-current-source.json`
- `security28-core05.tap`
- `security22-public.json`

The inherited27 hosted/Python3.12 reader receipts and toolchain/native/advisory
public controls remain separately observed. Validate every reported historic
HEAD/tree/checker/consumer identity, normal install/hook outcome and qualified
count: original24 at exact PR28,25 at PR29,26 at PR30,27 at pinned PR31. Current28
must run at the supplied source HEAD, not masquerade as original27. Each
platform's receipt is separately bound to its archive, run, job and attempt.

The actual public component summary must retain `candidateReady=false` and
the authentic nonzero readiness result for outstanding findings/custody.
Execution completeness and passing source controls do not make Security green.
Never infer scanner or custody success from an allowlisted artifact's integrity.

## Quality, DB and launch observations

Read actual public logs and record only substantiated markers:

- Repository quality: current mobile count should be6478 only if the actual
  completed log says so; operator24, file counts, forced typecheck/lint/tests
  and0 cache hits. Bind actual checkout/test-merge identity. Earlier6476
  precommit execution remains separate and cannot be relabeled.
- Canonical DB: two actual resets,97 migration traversal, focused SQL, full
  pgTAP/RLS/structural checks, lint, empty drift and generated-type parity.
  Preserve skipped diagnostic-retention and any failed/not-run details.
- PG15 and PG17: actual separately identified jobs/rehearsal results; no
  database qualification inferred merely from mechanical success.
- Clear-cache unsigned iOS and Android exports: distinct jobs/platform logs;
  unsigned exports are not installed native or signed Apple evidence.
- iOS all-features launch contract: exact run/job and technical source result;
  no physical device or public release implication.
- Original Security: record failure/nonadmitting status or other actual
  metadata, without opening its findings/logs. G97 remains FAIL/NO_GO.

A first unchanged in-progress snapshot is followed by independent work. Check
again only after meaningful elapsed time or an indicated state change; do not
busy-poll unchanged jobs. Completed unsuccessful/skipped jobs remain actual
failures/skips; diagnose ordinary public implementation failures within the
grant and preserve earlier red runs. There is no automatic retry or rerun.

## Preparation probe and current status

The connector download path was actually exercised against historical27 Linux
public artifact12926848938:320566 bytes, repository SHA256
`485c119e169714ebc2123d6f1b0d1685c68149cf55b0dcd26988df563fc266a9`.
The copied bytes matched its digest; the reader verified54 members and wrote
10 allowlisted files in a new directory. This is explicitly
HISTORICAL_C27_CONNECTOR_DOWNLOAD_PATH_PREPARATION_ONLY_NOT_CURRENT28.
No current28 run, CI result, fresh artifact or final-source acceptance is
claimed before root supplies the actual committed/pushed source identity.

All resulting observation records carry acceptanceGranted=false and NO_GO.
