"""Read-only strict inspection of already authenticated public CI receipts."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
import github_ci_reader28 as reader

PINS=[
 (24,'d0ccef65bcbe0c90483e6c0f691ed95f92228c6c','22f91455d651a81296ab8724f9db7cfead65af08',23,127,'855977dc4fc5ecc57f13b810cac6c63654b72b04bf867412d8c4510efe221145','715920a4dff3757adef2916015a244babef9babf92fea5725b1d2e96abf1c7d1'),
 (25,'52a3d01ebb36a6845d0ac21935ad35520732633f','ef49a81ca814f3d82b8a868e0308b6dda09c9cca',16,122,'bcb0235eb05d653b27b0871c52f72f6300513c68f2de46a3e959194fb5cbc838','cfe4ff3959d8cfba1939711a86cc9ee961c8c66a762425684ac7cd002dacb28d'),
 (26,'8c02a02afd7f2e9775dcc512c800d4f71f733234','ff0f76d11fa7775e27732f54ce7fdfbd51c8c676',26,198,'23b5e760944ee7c8163aee79a5132c1b329ec126b3e20f3c8e1fd96dab6807a3','8429fbd1f200b6d63064d524675c81d021f77228cfb232e8168df49ea88ff678'),
 (27,'517b50413b136639413b783cf3e899a6bc6c19ed','497f248472f775cef2a9922475fa9f3f62b75060',26,198,'2f2c7e97d133c2f693505f37d756a7d688ae1209c660d3b2730851c90ea72bb0','305f56b9a1bc2a3d29c8ccedd013024cb82cacc7fda823b8083f6a54eee7daec'),
]
def require(value,label):
 if not value:raise ValueError(label)
def pairs(values):
 result={}
 for key,value in values:
  require(key not in result,'DUPLICATE_JSON_KEY');result[key]=value
 return result
def load(raw):return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:require(False,'NONFINITE_JSON'))
def main():
 p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,required=True)
 for name in ['head','tree','run-id','test-merge','archive-sha256']:p.add_argument('--'+name,required=True)
 p.add_argument('--platform',choices=['linux','windows'],required=True);p.add_argument('--phase',choices=['SOURCE','FROZEN','TAIL'],required=True)
 args=p.parse_args();root=args.directory.resolve(strict=True)
 for value in [args.head,args.tree,args.test_merge]:require(re.fullmatch('[a-f0-9]{40}',value),'IDENTITY_SCHEMA')
 require(re.fullmatch('[a-f0-9]{64}',args.archive_sha256),'DIGEST_SCHEMA')
 read=lambda name:reader.v.read_regular(root/name,32*1024*1024)
 meta=load(read('ci-artifact-metadata.json'))
 require(meta['status']=='VERIFIED_PUBLIC_ARTIFACT_BYTES_ONLY' and meta['archive']['sha256']==args.archive_sha256 and meta['archive']['expectedPlatform']==args.platform,'ARCHIVE_IDENTITY')
 files={item['name']:read(item['name']) for item in meta['exported']}
 for item in meta['exported']:require(len(files[item['name']])==item['bytes'] and hashlib.sha256(files[item['name']]).hexdigest()==item['sha256'],'EXPORTED_BYTES')
 value=lambda name:load(files[name])
 terminal=lambda name:[load(line) for line in files[name].splitlines() if line.strip()][-1]
 hist=value('security28-historical-receipt.json');context=hist['context']
 require(hist['status']=='PASS' and hist['qualification']=='AUTHENTIC_PINNED_HISTORICAL_SOURCE_REPLAY_NOT_SECURITY_ACCEPTANCE' and hist['acceptanceGranted'] is False and hist['release']=='NO_GO','HISTORICAL_TERMINAL')
 require(context['head']==args.head and context['tree']==args.tree and context['runId']==args.run_id and context['runAttempt']=='1' and context['sourcePhase']==args.phase and context['platform']=={'linux':'linux','windows':'win32'}[args.platform],'HISTORICAL_CONTEXT')
 require(len(hist['records'])==4,'HISTORICAL_COUNT');history=[]
 for record,pin in zip(hist['records'],PINS):
  release,head,tree,positives,refusals,checker,consumer=pin
  require((record['release'],record['head'],record['tree'])==(release,head,tree),'HISTORICAL_PIN')
  require(record['checker']['sha256']==checker and record['consumer']['sha256']==consumer and record['checker']['mode']==record['consumer']['mode']=='100644','HISTORICAL_SCRIPT_IDENTITIES')
  require(record['checkoutBefore']==record['checkoutAfter'] and record['checkoutBefore']['head']==head and record['checkoutBefore']['tree']==tree and record['toolIdentityBefore']==record['toolIdentityAfter']==hist['tools'],'HISTORICAL_STABILITY')
  controls=record['consumerResult'];installation=record['installation'];source=record['sourceResult']
  require(controls['status']=='PASS' and controls['exit']==0 and controls['positiveControls']==positives and controls['refusals']==refusals and controls['acceptanceGranted'] is False and controls['release']=='NO_GO','HISTORICAL_CONTROLS')
  require(installation['npmCiExit']==installation['postinstallCheckExit']==0 and installation['mandatoryHooks'] is True and installation['cacheMode']=='FRESH_EMPTY_EXTERNAL_NPM_CACHE' and installation['nativeDeviceOrSignedBuild']=='NOT_RUN' and installation['nativePinsCount']==10,'HISTORICAL_INSTALL')
  require(source['exit']==0 and source['valid'] is True and source['governance']=='RELEASE'+str(release)+'_FINITE_SCOPE_ONLY' and source['acceptanceGranted'] is False and source['release']=='NO_GO','HISTORICAL_SOURCE')
  history.append({'release':release,'head':head,'tree':tree,'positiveControls':positives,'refusals':refusals,'qualification':controls['qualification'],'normalFreshNpmCiAndHooks':True,'nativeDeviceOrSignedBuild':'NOT_RUN'})
 current=terminal('security28-source-controls.jsonl');source=value('security28-current-source.json');public=value('security22-public.json');filesystem=terminal('security28-reader.jsonl')
 require(current['status']=='PASS' and current['positiveControls']==29 and current['refusals']==216 and current['inheritedFunctions']==202 and current['acceptanceGranted'] is False and current['release']=='NO_GO','CURRENT_CONTROLS')
 require(source['valid'] is True and source['current_source_governance']=='RELEASE28_FINITE_SCOPE_ONLY' and source['source_acceptance']=='SUBMITTED_REVIEW_REQUIRED' and source['acceptanceGranted'] is False and source['release']=='NO_GO' and all(v is False for v in source['admissions'].values()),'CURRENT_SOURCE')
 require(source['source28']['endpoint']==source['source28']['checkoutHead']==args.head and source['source28']['tree']==source['source28']['checkoutTree']==args.tree and source['source28']['ciEventCommit']==args.test_merge and source['source28']['phase']==args.phase,'CURRENT_SOURCE_CONTEXT')
 require(args.phase!='TAIL' or source['source28']['workingQualification']=='RAW_TRACKED_BLOBS_EXACT','FINAL_RAW_SOURCE_REQUIRED')
 require(public['candidateReady'] is False and public['executionComplete'] is True and public['acceptanceGranted'] is False and public['release']=='NO_GO' and public['source']['head']==args.head and public['source']['tree']==args.tree,'PUBLIC_NONADMISSION')
 require(filesystem['status']=='PASS' and filesystem['acceptanceGranted'] is False and filesystem['release']=='NO_GO','FILESYSTEM_READER_RESULT')
 tap=files['security28-core05.tap'].decode();counts={key:int(re.search(r'^# '+key+r' (\d+)$',tap,re.M)[1]) for key in ['tests','pass','fail','skipped','todo']}
 require(counts=={'tests':69,'pass':69,'fail':0,'skipped':0,'todo':0},'CORE05_COUNTS')
 report={'schema':1,'status':'VERIFIED_ACTUAL_PUBLIC_RECEIPTS_NOT_ACCEPTANCE','head':args.head,'tree':args.tree,'testMerge':args.test_merge,'run':int(args.run_id),'platform':args.platform,'phase':args.phase,'archiveSHA256':args.archive_sha256,'archiveMembers':meta['archive']['members'],'exported':len(files),'history':history,'currentControls':current,'currentSource':source['source28'],'core05':counts,'filesystem':filesystem,'public':{'executionComplete':True,'candidateReady':False,'unresolvedRequired':public['unresolvedRequired']},'sourceAcceptance':False,'release':'NO_GO'}
 print(json.dumps(report,sort_keys=True))
if __name__=='__main__':
 try:main()
 except Exception as error:
  print(json.dumps({'status':'REFUSED','category':str(error) if type(error) is ValueError else type(error).__name__,'sourceAcceptance':False,'release':'NO_GO'}));raise SystemExit(1)
