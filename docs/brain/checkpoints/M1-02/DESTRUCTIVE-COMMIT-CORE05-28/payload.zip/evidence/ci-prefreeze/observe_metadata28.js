// Run only inside functions.exec after store('ci28_expected', {...}).
// This is an external read-only connector observer; it does not publish.
const expected = load('ci28_expected');
if (!expected || expected.repository !== 'TasfiqJ/onSkin' || expected.pr !== 32 ||
    !/^[0-9a-f]{40}$/.test(expected.head) || !/^[0-9a-f]{40}$/.test(expected.tree) ||
    expected.baseHead !== '517b50413b136639413b783cf3e899a6bc6c19ed') {
  throw new Error('EXPLICIT_PUSHED_SOURCE_IDENTITY_REQUIRED');
}
const requested = [
  ['pr', () => tools.mcp__codex_apps__github_get_pr_info({repository_full_name: expected.repository, pr_number: expected.pr})],
  ['workflowRuns', () => tools.mcp__codex_apps__github_fetch_commit_workflow_runs({repo_full_name: expected.repository, commit_sha: expected.head})],
  ['combinedStatus', () => tools.mcp__codex_apps__github_get_commit_combined_status({repo_full_name: expected.repository, commit_sha: expected.head})],
];
const replies = await Promise.allSettled(requested.map(async ([label, invoke]) => ({label, response: await invoke()})));
const snapshot = {
  schema: 1, observedUTC: new Date().toISOString(), expected,
  qualification: 'ACTUAL_CONNECTOR_METADATA_SNAPSHOT_NOT_HTTP_RAW_BYTES_NOT_SOURCE_ACCEPTANCE',
  paginationQualification: 'Workflow-runs wrapper returns PR-triggered first page only; incomplete listing must be disclosed.',
  observations: replies, acceptanceGranted: false, release: 'NO_GO',
};
const file = 'C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign28-review-app/ci-observer28/metadata-' + Date.now() + '.json';
const serialized = JSON.stringify(snapshot, null, 2) + '\n';
await tools.apply_patch('*** Begin Patch\n*** Add File: ' + file + '\n' + serialized.split('\n').filter((_, i, a) => i < a.length - 1).map(line => '+' + line).join('\n') + '\n*** End Patch');
store('ci28_latest_metadata', snapshot);
text({file, expectedHead: expected.head, replies: replies.map((item, index) => ({label: requested[index][0], status: item.status})), sourceAcceptance: false, release: 'NO_GO'});
