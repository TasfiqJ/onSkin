"""Download connector-provided public candidate artifact bytes, not credentials."""
import hashlib
import json
from pathlib import Path
import re
import sys
import urllib.parse
import urllib.request

request=json.load(sys.stdin)
assert set(request)=={'download_url','artifact_id','file_name','expected_sha256','qualification'}
assert type(request['artifact_id']) is int and request['artifact_id']>0
assert re.fullmatch(r'[a-z0-9-]+\.zip',request['file_name'])
assert re.fullmatch(r'[0-9a-f]{64}',request['expected_sha256'])
url=urllib.parse.urlparse(request['download_url'])
assert url.scheme=='https' and url.hostname.endswith('.oaiusercontent.com')
assert not url.username and not url.password
target=Path(__file__).resolve().parent/request['file_name']
assert not target.exists()
with urllib.request.urlopen(request['download_url'],timeout=30) as response:
    data=response.read(32*1024*1024+1)
    expected_length=response.headers.get('Content-Length')
assert 0<len(data)<=32*1024*1024
assert expected_length is None or len(data)==int(expected_length)
digest=hashlib.sha256(data).hexdigest()
assert digest==request['expected_sha256']
with target.open('xb') as stream:assert stream.write(data)==len(data)
assert target.read_bytes()==data
receipt={'artifactId':request['artifact_id'],'file':target.name,'bytes':len(data),'sha256':digest,'repositoryArtifactDigestMatched':True,'downloadHost':url.hostname,'qualification':request['qualification'],'sourceAcceptance':False,'release':'NO_GO'}
(target.with_suffix('.download.json')).write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
