"""External Campaign27 witness: unchanged original consumers at their own commits."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

import argparse
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', required=True)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--expected-tree', required=True)
parser.add_argument('--node-prefix', required=True)
parser.add_argument('--output-name', required=True)
parser.add_argument('--reuse-checkout-root')
parser.add_argument('--workers', type=int, choices=(1,2), default=1)
args = parser.parse_args()
assert __import__('re').fullmatch('[a-z0-9-]{1,80}', args.output_name)
assert all(__import__('re').fullmatch('[0-9a-f]{40}', value) for value in (args.expected_head,args.expected_tree))
RUN = Path(__file__).resolve().parent.parent
OUT = RUN/args.output_name
SOURCE_ROOT = Path(args.source_root).resolve()
PAYLOAD = RUN.parent/'Campaign28_bootstrap/prior-payload-authenticated-fpgp5ndh'
CHECKPOINT = RUN.parent/'Campaign28_bootstrap/prior-return-authenticated-r0bf2irz/checkpoint/manifest.json'
def authenticated_prior(name):
    body=(PAYLOAD/name).read_bytes()
    checkpoint_raw=CHECKPOINT.read_bytes()
    assert hashlib.sha256(checkpoint_raw).hexdigest()=='1a8fc2026c557c4e41192f5dc755627f8ce6e392cc791141fbe1444bc7929907'
    record=json.loads(checkpoint_raw)['payload']['files'][name]
    assert len(body)==record['bytes'] and hashlib.sha256(body).hexdigest()==record['sha256']
    return json.loads(body)
prior=authenticated_prior('evidence/history-execution/SUMMARY.json')
PINS=[]
for row in prior['runs']:
    PINS.append(dict(release=row['release'],source=row['source'],tree=row['tree'],script=row['argv'][-1],
        scriptIdentity=row['scriptIdentity'],checkerIdentity=row['checkerIdentity'],expectedTerminal=row['terminalResult']))
assert [row['release'] for row in PINS]==['08-original151']+[str(i).zfill(2) for i in range(9,24)]
NATIVE=authenticated_prior('evidence/history-execution/early-provenance.json')['nativeInputs']
assert len(NATIVE)==10
PYTHON=sys.executable
ENV={key:value for key,value in os.environ.items() if not key.upper().startswith(('GIT_','GITHUB_','PYTHON','NPM_')) and key.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
ENV['GIT_TERMINAL_PROMPT']='0'
ENV['PATH']=str(Path(args.node_prefix).resolve())+os.pathsep+ENV['PATH']


def sha(raw): return hashlib.sha256(raw).hexdigest()

def git(root, *args):
    child = subprocess.run(['git','--no-replace-objects','-c','core.hooksPath=','-c','core.autocrlf=false','-c','core.longpaths=true',*args],cwd=root,env=ENV,capture_output=True,timeout=600)
    if child.returncode: raise RuntimeError('CAMPAIGN28_HISTORY_GIT_FAILED')
    return child.stdout

"""Compatible metadata helpers for the NEW external historical executor only."""
import os
from pathlib import Path
import stat
import hashlib


def stable(a, b):
    fields = [n for n in dir(a) if n.startswith('st_') and n not in ('st_atime', 'st_atime_ns')]
    return fields == [n for n in dir(b) if n.startswith('st_') and n not in ('st_atime', 'st_atime_ns')] and all(
        getattr(a, n) == getattr(b, n) for n in fields)


def compatible28(path, named, opened):
    fields = ('st_dev', 'st_ino', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_uid', 'st_gid')
    if not all(getattr(named, field) == getattr(opened, field) for field in fields):
        return False
    if os.name != 'nt':
        return named.st_mode == opened.st_mode and named.st_ctime_ns == opened.st_ctime_ns
    execute = 0o111 if Path(path).suffix.lower() in ('.exe', '.com', '.bat', '.cmd') else 0
    if opened.st_mode & 0o111 or named.st_mode != opened.st_mode | execute:
        return False
    for field in ('st_file_attributes', 'st_reparse_tag'):
        if hasattr(named, field) != hasattr(opened, field):
            return False
        if hasattr(named, field) and getattr(named, field) != getattr(opened, field):
            return False
    if hasattr(named, 'st_birthtime_ns') and hasattr(opened, 'st_birthtime_ns'):
        return named.st_birthtime_ns == opened.st_birthtime_ns
    return True


def regular28(info):
    return stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0) & 1024 and not (
        info.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX)) and 0 <= info.st_size <= 128*1024*1024


def inventory(root, commit):
    assert git(root, 'rev-parse', 'HEAD').decode().strip() == commit
    assert not git(root, 'status', '--porcelain=v1', '--untracked-files=all', '-z')
    tree = git(root, 'ls-tree', '-r', '-z', commit)
    records = []
    parents = set(root.parents) | {root}
    for row in tree.split(b'\0'):
        if not row:
            continue
        meta, name = row.split(b'\t', 1)
        mode, kind, oid = meta.split()
        assert kind == b'blob' and mode in (b'100644', b'100755')
        target = root/name.decode('utf-8')
        records.append((target, mode, oid))
        parent = target.parent
        while parent not in parents:
            parents.add(parent)
            parent = parent.parent
    identities = {}
    for parent in parents:
        info = parent.lstat()
        assert stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024
        identities[parent] = (info.st_dev, info.st_ino, info.st_mode,
                              getattr(info, 'st_file_attributes', None), getattr(info, 'st_reparse_tag', None))
    count = total = 0
    for target, mode, oid in records:
        before = target.lstat()
        assert regular28(before)
        if os.name != 'nt':
            assert bool(before.st_mode & 0o111) == (mode == b'100755')
        digest = hashlib.sha1(b'blob '+str(before.st_size).encode()+b'\0')
        size = 0
        with target.open('rb') as stream:
            opened = os.fstat(stream.fileno())
            assert regular28(opened) and compatible28(target, before, opened)
            while True:
                block = stream.read(min(1024*1024, before.st_size-size+1))
                if not block:
                    break
                size += len(block)
                assert size <= before.st_size
                digest.update(block)
            finished = os.fstat(stream.fileno())
        after = target.lstat()
        assert regular28(finished) and regular28(after) and stable(opened, finished) and stable(before, after) and (
            compatible28(target, after, finished)) and size == before.st_size and digest.hexdigest() == oid.decode()
        count += 1
        total += size
    for parent, identity in identities.items():
        info = parent.lstat()
        assert stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024 and (
            info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_file_attributes', None),
            getattr(info, 'st_reparse_tag', None)) == identity
    assert not git(root, 'status', '--porcelain=v1', '--untracked-files=all', '-z')
    return {'trackedFiles': count, 'trackedBytes': total, 'treeMetadataSHA256': sha(tree),
            'tree': git(root, 'rev-parse', 'HEAD^{tree}').decode().strip()}


def run_case(root, pin):
    release=pin['release'];start=time.monotonic()
    print(json.dumps({'release':release,'status':'STARTED'}),flush=True)
    git(root,'checkout','--detach',pin['source'])
    assert git(root,'rev-parse','HEAD^{tree}').decode().strip()==pin['tree']
    for label,path in [('scriptIdentity',pin['script']),('checkerIdentity','scripts/release/full-app-j01/check.py')]:
        raw=(root/path).read_bytes();expected=pin[label]
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
        assert raw==git(root,'show',pin['source']+':'+path)
        assert git(root,'ls-tree',pin['source'],'--',path).decode().strip()==expected['mode']+' blob '+expected['blob']+'\t'+path
    before=inventory(root,pin['source'])
    command=[PYTHON,'-B',pin['script']]
    stdout=OUT/('release'+release+'.stdout.log');stderr=OUT/('release'+release+'.stderr.log')
    timeout=False
    with stdout.open('xb') as out,stderr.open('xb') as err:
        try:
            child=subprocess.run(command,cwd=root,env=ENV,stdout=out,stderr=err,timeout=1800)
            exit_code=child.returncode
        except subprocess.TimeoutExpired:
            timeout=True;exit_code=None
    after=inventory(root,pin['source'])
    assert before==after
    raw=stdout.read_bytes();errors=stderr.read_bytes();terminal=None
    for line in reversed(raw.decode('utf-8',errors='replace').splitlines()):
        try:terminal=json.loads(line);break
        except json.JSONDecodeError:continue
    receipt={'campaign28ContextHead':args.expected_head,'campaign28ContextTree':args.expected_tree,'release':release,'source':pin['source'],'tree':pin['tree'],'scriptIdentity':pin['scriptIdentity'],
        'checkerIdentity':pin['checkerIdentity'],'argv':command,'exit':exit_code,'timeout':timeout,'elapsedSeconds':time.monotonic()-start,
        'before':before,'after':after,'cleanAfter':True,'stdoutSHA256':sha(raw),'stderrSHA256':sha(errors),'terminalResult':terminal,
        'qualification':'ORIGINAL_UNCHANGED_CONSUMER_AT_AUTHENTIC_FULL_CHECKOUT;INTERNAL_SYNTHETIC_AND_NATIVE_PIN_FIXTURE_QUALIFICATIONS_PRESERVED;NOT_CURRENT_ACCEPTANCE',
        'nativeInputs':'TEN_AUTHENTICATED_PUBLIC_SOURCE_PINS_FROM_CURRENT_REAL_INSTALL;NOT_A_HISTORICAL_NPM_INSTALL',
        'acceptanceGranted':False,'releaseStatus':'NO_GO'}
    (OUT/('release'+release+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'release':release,'exit':exit_code,'timeout':timeout,'cleanAfter':True,'terminalResult':terminal}),flush=True)
    assert exit_code==0 and timeout is False and terminal==pin['expectedTerminal']
    return receipt

def worker(label,pins):
    reused=args.reuse_checkout_root is not None
    if reused:
        reuse=Path(args.reuse_checkout_root).resolve(strict=True)
        assert reuse==(RUN/'substantive-78f3198c').resolve() and reuse.parent==RUN
        root=(reuse/label).resolve(strict=True)
        assert root.parent==reuse and root.name in ('early','late')
        assert git(root,'remote','get-url','origin').decode().strip()=='https://github.com/TasfiqJ/onSkin.git'
        head=git(root,'rev-parse','HEAD').decode().strip()
        assert head in {row['source'] for row in PINS}
        inventory(root,head)
    else:
        root=OUT/label
        assert not root.exists()
        git(OUT,'clone','--no-checkout','--single-branch','--branch','stage/m1-first-value-safety-ci27','--no-hardlinks','https://github.com/TasfiqJ/onSkin.git',str(root))
    assert git(root,'rev-parse','--is-shallow-repository').strip()==b'false'
    assert (root/'.git').is_dir() and not (root/'.git/objects/info/alternates').exists()
    for path in (root/'.git/objects').rglob('*'):
        info=path.lstat()
        assert not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024
        if stat.S_ISREG(info.st_mode):assert info.st_nlink==1
    git(root,'fsck','--full','--strict','--no-reflogs','--no-dangling')
    materialized=[]
    for row in NATIVE:
        body=(SOURCE_ROOT/row['path']).read_bytes()
        assert len(body)==row['bytes'] and sha(body)==row['sha256']
        target=root/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            assert reused and target.read_bytes()==body
        else:
            with target.open('xb') as stream:stream.write(body)
        materialized.append({'path':row['path'],'bytes':len(body),'sha256':sha(body)})
    provenance={'group':label,'complete':True,'separateObjectStore':True,'noAlternates':True,'fullFsckExit':0,
        'source':'FRESH_GITHUB_CLONE_REAUTHENTICATED_AFTER_ENVIRONMENT_FAILURE' if reused else 'FRESH_GITHUB_CLONE',
        'checkoutRoot':str(root),'reusedAfterENOSPCBeforeAnyConsumerStarted':reused,
        'nativeInputQualification':'AUTHENTICATED_NATIVE_SOURCE_PIN_FIXTURES_ONLY;NOT_FULL_NPM_INSTALL',
        'nativeInputs':materialized,'python':subprocess.check_output([PYTHON,'--version']).decode().strip(),
        'pythonSHA256':sha(Path(PYTHON).read_bytes())}
    (OUT/(label+'-provenance.json')).write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
    return [run_case(root,pin) for pin in pins]

def main():
    assert sys.flags.optimize==0 and sys.version_info[:2]==(3,9)
    assert git(SOURCE_ROOT,'rev-parse','HEAD').decode().strip()==args.expected_head
    assert git(SOURCE_ROOT,'rev-parse','HEAD^{tree}').decode().strip()==args.expected_tree
    assert not git(SOURCE_ROOT,'status','--porcelain=v1','--untracked-files=all')
    assert hashlib.sha256((SOURCE_ROOT/'package-lock.json').read_bytes()).hexdigest()=='1485297ffa6cc20367a5f2fda35bc33e12dc11ef422c813f5f28a4e339cb3b95'
    loader="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
    tools_raw=subprocess.check_output([PYTHON,'-I','-B','-c',loader],cwd=SOURCE_ROOT,env=ENV,timeout=180)
    tools=json.loads(tools_raw)
    assert tools['tools']['npm']['version']=='11.20.0' and tools['tools']['npm']['installationModelSHA256']=='c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9'
    OUT.mkdir(exist_ok=False)
    (OUT/'current-toolchain.json').write_bytes(tools_raw)
    pins=PINS[1:]
    semantic=PINS[0]
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(worker,'early',[semantic]+pins[:7]),pool.submit(worker,'late',pins[7:])]
        for future in concurrent.futures.as_completed(futures):results.extend(future.result())
    endpoints=[]
    for label in ('early','late'):
        root=(Path(args.reuse_checkout_root).resolve()/label) if args.reuse_checkout_root else OUT/label
        assert not git(root,'status','--porcelain=v1','--untracked-files=all')
        info=(root/'.git/objects').lstat()
        endpoints.append(dict(group=label,head=git(root,'rev-parse','HEAD').decode().strip(),clean=True,objectDirectoryDevice=info.st_dev,objectDirectoryInode=info.st_ino))
    assert len({(row['objectDirectoryDevice'],row['objectDirectoryInode']) for row in endpoints})==2
    summary={'status':'PASS_ORIGINAL151_AND_AUTHENTIC_ORIGINAL09_TO23','runs':sorted(results,key=lambda p:p['release']),
        'contextHead':args.expected_head,'contextTree':args.expected_tree,'endpoints':endpoints,'workers':args.workers,
        'scriptSHA256':sha(Path(__file__).read_bytes()),'priorPinFileSHA256':sha((PAYLOAD/'evidence/history-execution/SUMMARY.json').read_bytes()),
        'nativePins':NATIVE,'nativeInputs':'TEN_AUTHENTICATED_PUBLIC_SOURCE_PINS_FROM_CURRENT_REAL_INSTALL;NOT_A_HISTORICAL_NPM_INSTALL',
        'qualification':'ACTUAL_UNCHANGED_ORIGINAL_EXECUTION_AT_AUTHENTIC_FULL_REMOTE_CHECKOUTS;ORIGINAL_TEST_QUALIFICATIONS_RETAINED;NOT_CURRENT_ACCEPTANCE',
        'acceptanceGranted':False,'release':'NO_GO'}
    (OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':summary['status'],'completed':len(results),'failed':sum(r['exit']!=0 for r in results),'release':'NO_GO'}),flush=True)

if __name__=='__main__':main()
