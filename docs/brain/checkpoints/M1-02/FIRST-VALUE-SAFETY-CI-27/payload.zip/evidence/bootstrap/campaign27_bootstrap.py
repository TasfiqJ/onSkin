"""Independent external bootstrap. No packet imports or execution."""
from pathlib import Path
import hashlib
import json
import os
import re
import stat
import struct
import tempfile
import unicodedata
import zlib

ZIP = Path(r'C:\Users\jasim\.codex\codex-remote-attachments\01a188be-80fe-7821-84dc-7a7475daaf16\9DD91D08-6514-44E0-A745-E92CAC37DEE8\1-onSkin_Campaign27_Postdispatch_Safety_Windows_CI_Context_2026-10-29.zip')
ANCHOR = 'cb1e3106f40b2a81872bdfc0c4f2642a0700d113bbb0a43fd33e8da09fe0d2b0'
ZIP_SHA256 = '2c5443fb399830bf2f971c4f7457258134e3df2669cff8930759ed065d830338'
ZIP_SIZE = 42150
WORK = Path(__file__).resolve().parent

def require(value, label):
    if not value:
        raise ValueError('CONTEXT_INVALID: ' + label)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def plain_file(path):
    s = path.lstat()
    require(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and not getattr(s, 'st_file_attributes', 0) & 0x400, 'nonregular file')
    return s

def stable_metadata(left, right):
    # Access time can change as a consequence of this read. Only atime is excluded.
    fields = sorted(name for name in dir(left) if name.startswith('st_') and name not in ('st_atime', 'st_atime_ns'))
    require(fields == sorted(name for name in dir(right) if name.startswith('st_') and name not in ('st_atime', 'st_atime_ns')), 'metadata field availability')
    return all(getattr(left, name) == getattr(right, name) for name in fields)

def unique_object(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, 'duplicate JSON key')
        out[key] = value
    return out

def inspect(data):
    require(22 <= len(data) <= 16*1024*1024, 'archive bounds')
    e = struct.unpack('<4s4H2IH', data[-22:])
    require(e[0] == b'PK\x05\x06' and e[1:3] == (0, 0) and e[3] == e[4] == 14 and e[7] == 0, 'EOCD framing/count')
    cd_size, cd_offset = e[5:7]
    require(cd_offset + cd_size == len(data)-22, 'central bounds/trailing bytes')
    cursor = cd_offset
    local_end = 0
    records = []
    aliases = {}
    files = set()
    total = 0
    for _ in range(14):
        require(cursor + 46 <= len(data)-22, 'central header bounds')
        c = struct.unpack_from('<4s6H3I5H2I', data, cursor)
        sig, made, need, flags, method, tm, dt, crc, packed, size, nl, xl, cl, disk, internal, external, offset = c
        require(sig == b'PK\x01\x02' and made >> 8 == 3 and need <= 20, 'central signature/version')
        require(flags in (0, 0x800) and method in (0, 8) and xl == cl == disk == internal == 0, 'unsupported ZIP feature')
        require(external == (stat.S_IFREG | 0o644) << 16, 'mode/reparse/special')
        require(0 < nl <= 1024 and cursor+46+nl <= len(data)-22, 'name bounds')
        raw_name = data[cursor+46:cursor+46+nl]
        name = raw_name.decode('utf-8' if flags & 0x800 else 'ascii', errors='strict')
        require(unicodedata.normalize('NFKC', name) == name and '\\' not in name and not name.startswith('/') and not name.endswith('/'), 'normalization/absolute/directory')
        parts = name.split('/')
        for i, component in enumerate(parts):
            require(component not in ('', '.', '..') and component[-1:] not in ('.', ' ') and not re.search(r'[<>:"|?*\x00-\x1f\x7f]', component), 'unsafe component')
            require(not re.fullmatch(r'(?i)(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\..*)?', component), 'device alias')
            parent = '/'.join(parts[:i+1])
            key = unicodedata.normalize('NFKC', parent).casefold()
            require(key not in aliases or aliases[key] == parent, 'implicit parent alias')
            require(i == len(parts)-1 or parent not in files, 'parent file collision')
            if i == len(parts)-1:
                require(key not in aliases, 'duplicate/parent overwrite')
            aliases[key] = parent
        files.add(name)
        require(0 <= size <= 1024*1024 and 0 < packed <= 1024*1024 and size <= packed*100, 'entry expansion')
        total += size
        require(total <= 8*1024*1024, 'total expansion')
        require(offset == local_end and offset+30 <= cd_offset, 'local overlap/gap')
        l = struct.unpack_from('<4s5H3I2H', data, offset)
        require(l == (b'PK\x03\x04', need, flags, method, tm, dt, crc, packed, size, nl, 0), 'local/central mismatch')
        require(data[offset+30:offset+30+nl] == raw_name, 'local name mismatch')
        start = offset+30+nl
        local_end = start+packed
        require(local_end <= cd_offset, 'data overlap')
        records.append((name, start, packed, size, crc, method))
        cursor += 46+nl
    require(cursor == cd_offset+cd_size and local_end == cd_offset, 'unaccounted records/bytes')
    # Every record has now passed framing, identity and bounded expansion checks.
    contents = {}
    for name, start, packed, size, crc, method in records:
        compressed = data[start:start+packed]
        if method == 8:
            inflater = zlib.decompressobj(-15)
            content = inflater.decompress(compressed, size+1)
            require(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail, 'incomplete/trailing deflate')
        else:
            content = compressed
        require(len(content) == size and zlib.crc32(content) == crc, 'size/CRC')
        contents[name] = content
    require('manifest.json' in contents and sha(contents['manifest.json']) == ANCHOR, 'external manifest anchor')
    manifest = json.loads(contents['manifest.json'], object_pairs_hook=unique_object)
    declared = manifest['files']
    require(type(declared) is dict and set(contents) == set(declared) | {'manifest.json'} and len(contents) == 14, 'declared files')
    for name, desc in declared.items():
        require(type(desc['bytes']) is int and len(contents[name]) == desc['bytes'] and sha(contents[name]) == desc['sha256'], 'declared bytes/hash')
    require('verify_packet.py' in declared, 'verifier declaration')
    require(contents['TASK_DIRECTIVE.md'] == contents['PROMPT_TEMPLATE.md'] == contents['EXACT_PROMPT.md'], 'triad bytes')
    return contents

def main():
    before = plain_file(ZIP)
    require(before.st_size == ZIP_SIZE, 'external archive size')
    with ZIP.open('rb') as handle:
        initial = os.fstat(handle.fileno())
        data = handle.read(ZIP_SIZE+1)
        after_handle = os.fstat(handle.fileno())
    after = plain_file(ZIP)
    for entry in (initial, after_handle):
        require(stat.S_ISREG(entry.st_mode) and entry.st_nlink == 1 and not getattr(entry, 'st_file_attributes', 0) & 0x400, 'nonregular archive handle')
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns')
    require(all(getattr(before, f) == getattr(initial, f) == getattr(after_handle, f) == getattr(after, f) for f in fields), 'archive changed')
    require(stable_metadata(initial, after_handle) and stable_metadata(before, after), 'archive metadata changed')
    # This Python 3.9 Windows runtime presents compatible ctime in both domains;
    # preserve every previously passing comparison instead of normalizing it away.
    require(stable_metadata(before, initial) and stable_metadata(after, after_handle), 'archive cross-domain metadata changed')
    require(len(data) == ZIP_SIZE and all(s.st_size == ZIP_SIZE for s in (before, initial, after_handle, after)), 'archive incomplete/changed')
    require(sha(data) == ZIP_SHA256, 'external archive hash')
    contents = inspect(data)
    run = Path(tempfile.mkdtemp(prefix='campaign27-run-', dir=WORK))
    root = run / 'context'
    root.mkdir()
    require(not list(root.iterdir()), 'nonempty extraction root')
    for name, content in contents.items():
        target = root.joinpath(*name.split('/'))
        target.parent.mkdir(parents=True, exist_ok=True)
        require(target.resolve().is_relative_to(root.resolve()), 'extraction escape')
        with target.open('xb') as handle:
            handle.write(content)
        plain_file(target)
        require(sha(target.read_bytes()) == sha(content), 'extracted file hash')
    require(len([p for p in root.rglob('*') if p.is_file()]) == 14, 'extracted file count')
    receipt = {'qualification': 'CONTEXT_ONLY_NO_ACCEPTANCE', 'zip_sha256': sha(data), 'manifest_sha256': ANCHOR, 'verifier_sha256': sha(contents['verify_packet.py']), 'files': {name: {'bytes': len(b), 'sha256': sha(b)} for name, b in contents.items()}, 'root': str(root), 'result': 'INDEPENDENT_BOOTSTRAP_AUTHENTICATED'}
    (run/'bootstrap_receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__':
    main()
