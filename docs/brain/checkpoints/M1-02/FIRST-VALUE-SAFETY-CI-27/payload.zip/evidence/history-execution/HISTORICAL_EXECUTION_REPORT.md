All 16 original execution commands completed with exit 0: the unchanged original 151-negative suite at its immutable Release08 fixture source, and the unchanged original Release09–23 consumers at their individual authenticated commits. No run timed out. Every stderr log is empty. Before and after each execution, every tracked file matched its pinned Git blob and the complete tracked inventory remained identical; Git status remained clean.

These were local Windows executions using Python 3.9.13 (`python.exe` SHA256 `07c96337729e3c4c986e8f5660a97cb475c4c04842606be2654b37892af57de9`). Each command was `python -B scripts/release/full-app-j01/source_consumerNN.test.py`, except the original151 command, which used `test_contract.py`. The exact interpreter path, source commit, tree, script/checker byte counts, modes, blob IDs and SHA256 hashes are recorded in each `releaseNN.receipt.json`.

The original151 source was commit `d08347f0011672cd309d835628c094b5e9f4725d`, tree `0998881bc543840395dca375769ea1b7c9a8d4c7`. Its 153 case records comprise the authentic positive control, all 151 negative cases, and the restored positive control. The observed sequence is 0 / all 151 exits 1 / 0. Its original `BUNDLE_FIXTURES_ONLY_NOT_INDEPENDENT_CHECKOUT` qualification remains unchanged.

| Original release | Command exit | Original terminal refusal count | Original reported positive controls |
| --- | ---: | ---: | ---: |
| 08 original151 | 0 | 151 | 2 observed |
| 09 | 0 | 23 | Not reported |
| 10 | 0 | 44 | Not reported |
| 11 | 0 | 58 | Not reported |
| 12 | 0 | 55 | Not reported |
| 13 | 0 | 68 | Not reported |
| 14 | 0 | 89 | 8 |
| 15 | 0 | 115 | 6 |
| 16 | 0 | 153 | 6 |
| 17 | 0 | 161 | 6 |
| 18 | 0 | 175 | 6 |
| 19 | 0 | 163 | 6 |
| 20 | 0 | 197 | 6 |
| 21 | 0 | 234 | 10 |
| 22 | 0 | 108 | 16 |
| 23 | 0 | 156 | 33 |

The table preserves each original program's counter, rather than redefining its reporting. The separate audit also records actual JSON case-row and explicit exit-row counts. Release09 records ten direct `rejected: true` path cases in addition to thirteen exit-1 rows. Release12 and13 each emit one more exit-1 row than their original terminal counter reports. No original assertion, counter, checker, or consumer was changed.

The two execution tracks used fresh GitHub clones with complete ancestry, no alternates, no shallow history, no shared or hard-linked Git object files, and successful full strict Git fsck. Final detached endpoints are:

- `early`: `b79e6d1e21a367be5cea5d0b333de9f2a144d41f` (Release15), clean.
- `late`: `5976394fd39f41550bde8107b9cc27c758b7ce14` (Release23), clean.

The original consumers' internal disposable Git, synthetic Git, bounded index/history, materialized native-source and current-segment qualifications are retained verbatim in their logs and receipts. For the consumers that need native source inputs, the two clones contain only ten separately authenticated public source files from the current real npm installation. Those files match the authenticated historical native pin hashes and sizes. This is not a historical npm installation, a native build, a device execution, or a privacy/security acceptance result. Original24–26 and current27 are outside this execution witness and are being handled separately by the integration owner.

[SUMMARY.json](SUMMARY.json) contains the 16 complete receipts. Its SHA256 is `3b1cd71d7ff3d1fceb76b08fba629385b22e23f454b134e9309368233d0606cc`.

[INDEPENDENT_RECEIPT_AUDIT.json](INDEPENDENT_RECEIPT_AUDIT.json) rehashes every receipt and log, checks recorded case exits against expected exits, verifies the original151 sequence, compares each Release09–23 terminal result and checker/script identity with its authenticated prior anchor, and independently confirms the two clean final clone identities. It completed exit 0. Its SHA256 is `3b4d7dfaf016d851ccfa79f17815c931dd4425483dba3e9fd6464d072db81f97`.

No application/workflow source, historical commit, branch, PR, or acceptance gate was modified by this work. Source acceptance remains with the independent Brain; qualified-owner gates remain unchanged. SUBMITTED_REVIEW_REQUIRED / NO_GO. G97 remains FAIL/NO_GO.
