# Public database prefreeze evidence

Public jobs 123642803055 (canonical), 123642803601 (PostgreSQL 15), and 123642803574 (PostgreSQL 17) completed successfully. Their logs identify the checkout as GitHub's generated PR31 test merge `f36f8a0fbbe2eddba44c3c1c40f5c722869a7df6`, combining candidate `f20a58c09fefb9b9b15d10bc59119462ecdec386` with base `8c02a02afd7f2e9775dcc512c800d4f71f733234`. This is CI test-merge execution, not an actual merge or an exact-candidate-head checkout. This review did not independently compare the merge object's tree.

The canonical job reports two complete resets with PASS, verified history containing 97 migrations through `20261010000081`, focused CORE-05 structural regressions PASS, the complete structural pgTAP command PASS, migrated public schema lint PASS, empty migration/schema drift PASS, and CAT-08 two-connection revocation rehearsal PASS. Generated types and repository parity both pass at 7,381 lines and SHA256 `2b475803f0ea143681de2912637e61b1cf26e271043a84a1692e7d1d6b87a795`. Its observed database binding reports PostgreSQL major 15; no binding identifiers, ports, temporary paths, or credentials are copied into the receipt.

The protected canonical runner invokes the five focused SQL files, then `supabase test db --local supabase/tests/database`. Read-only candidate source inventory contains 20 SQL files in that directory, including RLS enablement, policy, and role assertions in schema, consent, catalog, and other lifecycle suites. This is source coverage evidence combined with the logged suite PASS; the sanitized runner does not emit a runtime SQL assertion count. The separate RLS smoke command was not observed. The 171 passing Node tests in the DB-contract step must not be described as 171 SQL assertions.

Each PostgreSQL matrix job starts 15 real isolated SQL rehearsals and emits 16 PASS markers. The additional marker is the nested 0064 result emitted during the 0075 upgrade rehearsal. These are PostgreSQL 15-alpine and 17-alpine rehearsal executions, not two independent canonical reset/lint/drift/type-parity runs.

The bounded extracted values and outcome markers are in `public-db-prefreeze-sanitized.json`. No raw database status output, credentials, or original Security API logs were saved by this review. SQL assertion counts not exposed by the sanitized runner remain NOT_REPORTED. No synthetic positive substitute was used.

DB06/DB08/R2B remain NOT_ACCEPTED. SUBMITTED_REVIEW_REQUIRED / NO_GO; acceptanceGranted=false.
