const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(process.argv[2]);
const ts = require(path.join(root, 'node_modules/typescript'));
const sourcePath = 'apps/mobile/src/app/onboarding/notifications.tsx';
const testPath = 'scripts/core05/adherence-source-contract.test.mjs';
const source = fs.readFileSync(path.join(root, sourcePath), 'utf8');
const test = fs.readFileSync(path.join(root, testPath), 'utf8');
const ast = ts.createSourceFile(sourcePath, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const calls = [];
function visit(node) {
  if (ts.isCallExpression(node) && ts.isIdentifier(node.expression) && node.expression.text === 'acceptRoutineReminderSoftAsk') {
    calls.push({
      line: ast.getLineAndCharacterOfPosition(node.getStart(ast)).line + 1,
      argumentCount: node.arguments.length,
      proposedTimesFirst: node.arguments[0]?.getText(ast) === 'PROPOSED_ROUTINE_REMINDER_TIMES',
      defaultDependenciesSecond: node.arguments[1]?.getText(ast) === 'undefined',
      lifecycleFenceThird: node.arguments[2]?.getText(ast) === 'assertLifecycle',
    });
  }
  ts.forEachChild(node, visit);
}
visit(ast);
console.log(JSON.stringify({
  qualification: 'READ_ONLY_AST_DIAGNOSIS_NOT_ORIGINAL_TEST_OR_ACCEPTANCE',
  sourcePath, testPath,
  sourceSHA256: crypto.createHash('sha256').update(source).digest('hex'),
  testSHA256: crypto.createHash('sha256').update(test).digest('hex'),
  originalExactCallRegexMatches: /acceptRoutineReminderSoftAsk\(PROPOSED_ROUTINE_REMINDER_TIMES\)/u.test(source),
  calls,
  release: 'NO_GO', acceptanceGranted: false,
}, null, 2));
