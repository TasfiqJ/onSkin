"""Task-owned invocation receipt; does not modify application/replay source."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent/'source'
PREFIX = Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code\campaign26-run-1b46eb3809914b21a97234dcffb185dc\security26-tools')
PYTHON = Path(r'C:\Users\jasim\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=SOURCE).decode().strip()

def main():
    environment = {key:value for key,value in os.environ.items() if not key.upper().startswith(('GIT_', 'NPM_', 'PYTHON', 'GITHUB_')) and key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
    environment['PATH'] = str(PREFIX)+os.pathsep+environment['PATH']
    environment['GIT_TERMINAL_PROMPT'] = '0'
    endpoint = git('rev-parse', 'HEAD'); tree = git('rev-parse', 'HEAD^{tree}')
    assert endpoint == 'f20a58c09fefb9b9b15d10bc59119462ecdec386'
    assert not git('status', '--porcelain=v1', '--untracked-files=all')
    output = HERE/'local-replay27-authenticated.stdout.jsonl'
    error = HERE/'local-replay27-authenticated.stderr.log'
    result = HERE/'local-replay27-authenticated.runner-receipt.json'
    record_path = HERE/'local-replay27-authenticated.invocation.json'
    assert not any(path.exists() for path in (output,error,result,record_path))
    loader = "import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
    tools = subprocess.run([str(PYTHON),'-I','-B','-c',loader],cwd=SOURCE,env=environment,capture_output=True,timeout=180)
    assert tools.returncode == 0 and not tools.stderr
    identity = json.loads(tools.stdout)
    assert identity['tools']['npm']['installationModelSHA256']=='c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9'
    (HERE/'local-replay27-authenticated.toolchain.json').write_bytes(tools.stdout)
    arguments = [str(PYTHON),'-I','-B','scripts/release/full-app-j01/replay27.py','--receipt',str(result)]
    record = dict(argv=arguments,head=endpoint,tree=tree,sourceHashes={name:sha(SOURCE/name) for name in ('scripts/release/full-app-j01/replay27.py','scripts/release/full-app-j01/check.py')},toolIdentitySHA256=identity['identitySHA256'],toolchainReceipt='local-replay27-authenticated.toolchain.json',qualification='ACTUAL_LOCAL_REPLAY_WITH_AUTHENTICATED_TOOLCHAIN_NOT_ACCEPTANCE',release='NO_GO',acceptanceGranted=False)
    started=time.time()
    try:
        with output.open('xb') as stdout,error.open('xb') as stderr:
            completed=subprocess.run(arguments,cwd=SOURCE,env=environment,stdout=stdout,stderr=stderr,timeout=7200)
        record['exit']=completed.returncode
    except subprocess.TimeoutExpired:
        record['exit']=None;record['category']='LOCAL_REPLAY_TIMEOUT'
    record['elapsedSeconds']=time.time()-started
    record['stdoutSHA256']=sha(output);record['stderrSHA256']=sha(error)
    record['stdoutBytes']=output.stat().st_size;record['stderrBytes']=error.stat().st_size
    record['sourceHeadAfter']=git('rev-parse','HEAD');record['sourceTreeAfter']=git('rev-parse','HEAD^{tree}')
    record['cleanAfter']=not git('status','--porcelain=v1','--untracked-files=all')
    record['sourceUnchanged']=record['sourceHeadAfter']==endpoint and record['sourceTreeAfter']==tree and all(sha(SOURCE/name)==digest for name,digest in record['sourceHashes'].items())
    record['runnerReceiptExists']=result.exists()
    if result.exists(): record['runnerReceiptSHA256']=sha(result)
    record_path.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,sort_keys=True))

if __name__=='__main__': main()
