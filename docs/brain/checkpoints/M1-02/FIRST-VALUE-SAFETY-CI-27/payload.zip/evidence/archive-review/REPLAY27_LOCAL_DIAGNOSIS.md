# Local Replay27 toolchain diagnosis

The original `historical27-local.log` records `R27_REPLAY_CHILD_FAILURE` without the failing child's category. It remains unchanged.

Read-only probes of source `f20a58c09fefb9b9b15d10bc59119462ecdec386`, using explicit bundled Python 3.12, reproduced a launch-environment distinction:

| Environment | Original toolchain identity | Replay27 tools27 |
|---|---|---|
| Default PATH | REFUSED: `NPM_TOOL_CHANGED` | REFUSED: `R27_REPLAY_CHILD_FAILURE` |
| Validated `security26-tools` prefix first on PATH | PASS, pinned npm 11.20.0 model matches | PASS, assertions enabled |

Only fixed diagnostic labels/booleans were emitted by these probes; arbitrary child exception text was not forwarded. Receipts are the four `replay27-*-diagnostic.json` files. No source or tool checks were modified or bypassed.

This reproduces the same wrapper failure under the default launch path and proves the untouched function works with the authenticated prefix. The original failed invocation did not record its child stderr/environment, so this is not a claim that its original internal field was independently captured retroactively.

The actual full replay completed with exit 0/PASS in 3,081.165 seconds from clean f20/tree `4fdd7eca278a8e9cd963b74ed2b066b848eb6dd3`, using authenticated Python 3.12.14, Node 22.21.0, and npm 11.20.0. The source head/tree and checker/runner bytes remained unchanged, the final checkout was clean, and stderr was empty. Original Release24, Release25, and Release26 consumers returned respectively 23/127, 16/122, and 26/198 positive/refusal controls. Their unchanged original checkers all returned exit 0, valid=true, acceptanceGranted=false, and NO_GO. Each fresh isolated complete checkout passed actual normal npm ci, mandatory hooks, postinstall verification, and before/after source/tool identity checks.

The actual result is recorded in `local-replay27-authenticated.invocation.json` and `local-replay27-authenticated.runner-receipt.json`; the latter's SHA256 is `eb3b8ebba65bc34953bc37100869e97733c5ac1591944663b6886b893405cdaf`. The original failed launch remains preserved. This successful corrected launch does not convert that old observation into a pass or establish the first launch's uncaptured internal cause retroactively.

Candidate run 40929022866 completed on both platforms: authenticated historical replay and current Release27 source steps succeeded, while public components remained nonready and the jobs failed. Completed Windows public job 123642181492 logs independently record both reader-control runs at 31 positives/11 refusals, original historical counts matching the local run, current Release27 controls at 23 positives/190 refusals, current checker valid=true with all admissions false, and public executionComplete=true/candidateReady=false. The hosted historical toolchain was Python 3.12.10, Node 22.23.4, and npm 11.20.0. Public advisory/custody and inherited inventory findings remained unresolved. Bounded selected evidence is in `public-windows-prefreeze-sanitized.json`; an earlier active-job log request returned unavailable/404 and was not treated as a failure. No original Security API logs were requested.

Scope note: one overbroad local filename/content search returned command-line excerpts from tracked historical CI logs under `history-execution`; that search was stopped. No scanner finding values were used. Subsequent investigation was restricted to current replay/toolchain files and the specifically authorized public candidate/Quality jobs.

SUBMITTED_REVIEW_REQUIRED / NO_GO. No source acceptance is granted.
