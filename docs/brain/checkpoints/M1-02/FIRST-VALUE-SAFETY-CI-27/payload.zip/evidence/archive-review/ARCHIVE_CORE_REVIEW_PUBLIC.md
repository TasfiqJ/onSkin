# Public derivative notice

This labelled publication derivative changes only the diagnosis-document reference to the public derivative. The original review remains unchanged. Original raw CORE05 assertion logs and direct new notification/test SHA256 values are omitted from public delivery; see core05-pr28-PUBLIC.json and core05-pr29-PUBLIC.json for preserved bounded failed-run outcomes. Historical evidence indexes may name retained private originals; the sealed payload catalog defines actual included files.

# Campaign27 independent Campaign26 archive and legacy CORE-05 review

Completed historical artifact/source verification and R27-03 diagnosis. No repository application/workflow source, original assertion, prior branch or PR was modified. All local review checkouts are isolated, detached and have separate Git object stores. This is evidence for independent Brain review, not ordinary source acceptance or release acceptance.

## Historical archive: independently VERIFIED

The actual binary was freshly downloaded from the exact supplier URL in the authenticated Campaign27 `SOURCE_ANCHORS.json`:

https://raw.githubusercontent.com/TasfiqJ/onSkin/91e641cbf5d6ec73015445905e4027480ae4caf7/onSkin_Campaign26_First_Value_Recovery_And_CI_Return_2026-10-29.zip

The original downloaded archive remains `original-campaign26.zip`:

- Exact size: 11,324,492 bytes.
- ZIP SHA256: `9f6c775c24ee4f6f5ac6da5a9422bd629ec624fa05ccbcf93e84b7cf644d9c7a`.
- External manifest SHA256: `b7a6c2ffb8f4aad827dc147ee16388b3a60760bdfb79a16077f32ffa733e5004`.
- External verifier SHA256: `2b24bf81d7d3dac652cc3cdee3ebed74f5ef9fcf3830ff1240c1da50cab17fc1`.
- Independent framing/alias/mode/CRC/bounded-expansion inspection: 145 regular outer members and 269 regular checkpoint members; 414 total recursively inspected, 16,715,430 expanded bytes.
- Every outer declared file and every nested payload file was size/hash authenticated before execution or viewing. Extraction used new empty directories and exclusive file creation; no links/reparse points or special modes were accepted.

The unchanged authenticated `verify_return26.py` was executed with the external manifest/verifier anchors, the original ZIP, a new complete remote clone at exact PR30 HEAD `8c02a02afd7f2e9775dcc512c800d4f71f733234`, tree `ff0f76d11fa7775e27732f54ce7fdfbd51c8c676`, and `--execute-source-checks`.

Final result: **exit 0 / VERIFIED**, after an authenticated npm 11.20.0 installation with all mandatory root hooks, a new empty npm cache, and passing original `postinstall --check`. The standalone npm installation reconciles to the original protected model SHA256 `c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9` (1,970 files, 12,246,399 bytes). Node is 22.21.0, Python is 3.9.13, Git is 2.50.1.windows.1.

The final full verifier independently checked:

- All 23,513 tracked working blobs against raw Git identities, complete history and actual object hashes; no shallow clone, worktree sharing or checkout alternates.
- Exact first plan, source chronology, source/worklist/evidence-tail boundaries and changed path/mode/blob identities.
- Exact five-file checkpoint copy and 269 payload files.
- Minimal Git bundle prerequisite and delta semantics: 70 original delta objects; 24 temporary delta bases in the original verifier's documented temporary parser, not in the independent checkout.
- Original Release26 current-source checker: `PASS_FINITE_SOURCE_GOVERNANCE_ONLY`.
- Original unchanged Phase4 producer in strict check mode: `PASS_UNCHANGED_PRODUCER_STRICT_CHECK`; producer SHA256 `b3882f954498008cd80fe57d50f75c358504bca99f5f97b7481239977af26d1e`.
- Exact final PR30 source/head/tree and clean status after verification. This was an exact source checkout, not a GitHub generated PR merge commit.

Final receipts: `full-return-verifier-authenticated.receipt.json`, `.stdout.json`, `.stderr.log`; elapsed 440.726 seconds. Output SHA256 `cef08da2244f3f9bda75ebb20b31a5b5038e5bad481af2bc7ddffdefbacc7a8a`. Installation and tool identity: `npm-ci-pr30-authenticated.*`, `postinstall-check-authenticated.*`, `pinned-toolchain.stdout.json`.

This closes the Campaign27 prerequisite `ARCHIVE_BINARY_NOT_INDEPENDENTLY_VERIFIED` for this actual supplier artifact. It does not retroactively change the sealed Campaign26 Windows historical launcher failure, prove an original consumer was run if it was not, or grant Security/DB/native/source/release acceptance.

## Earlier attempts remain qualified

The initial direct system npm CLI installation was actually npm 10.9.4, despite the wrapper's 11.20.0 version output. Its normal install succeeded but is not pinned-tool proof (`npm-ci-pr30.*`). A second install used the real global npm 11.20.0 CLI, but later full installation-model reconciliation refused it with `NPM_EXPECTED_CONTENT` (`used-npm-installation-model.json`). The first full return verifier naturally finished exit 0 in 563.106 seconds before an attempted cancellation check; no process was killed and no cancellation is claimed. That result remains qualified by the installation mismatch (`full-return-verifier.*`).

The final install was independently authenticated against the original protected model, performed through the validated standalone prefix, and followed by a complete repeat of the unchanged full verifier. No tool rule, assertion or source check was relaxed.

## R27-03: reproduced and diagnosed; remediation UNAPPLIED

Original core05 source contract at exact PR28 and PR29: **exit 1; 35 PASS / 1 FAIL** at both. The failing test expects a one-argument, whitespace-free call at `scripts/core05/adherence-source-contract.test.mjs:595`. The authentic route at `apps/mobile/src/app/onboarding/notifications.tsx:145` passes the same proposed reminder times, then `undefined` for default dependencies and `assertLifecycle` for the focus/health fence in a multiline call. Both original source blobs are identical across PR28 and PR29.

Original notification onboarding/recovery/boundary runtime tests at exact PR29: **29 PASS in 3 files**. These preserve mocked OS/delivery/private-storage qualifications and are not native proof or a replacement positive for the failing source assertion.

`CORE05_DIAGNOSIS_UNAPPLIED_PUBLIC.md` contains exact identities, first-failure limits, user consequence and a specific future AST/behavioral contract proposal. The protected test and notification paths are outside Campaign27's finite grant. No assertion was rewritten, deleted or skipped; no lifecycle guard was removed; the original 35/1 result remains open.

## Historical screenshot inspected

The authenticated payload includes 23 PNGs. The 360x640 `final-source26-360x640-doubletext-remove.png` was actually viewed: the scrollable management sheet visibly contains Mark discarded and a fully visible outlined Remove completely action. SHA256 `8bcaa7084cb551778e1555f852de9011530cd9169a9d8aadb04472fa93b8f420`.

This is an authenticated historical screenshot observation only. It does not claim a new browser interaction, new font-scale/scroll measurement, or device VoiceOver. See `historical-screenshot-review.json`.

## Preserved gates

SUBMITTED_REVIEW_REQUIRED / NO_GO. G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED; J01 gates NOT_ACCEPTED; native/VoiceOver/provider/paid/professional/clinical/legal/licensing/Apple/public release CLOSED. USD0. NO MERGES.
