"""Read-only independent receipt checks and external evidence index."""
from pathlib import Path
import hashlib, json, stat

ROOT = Path(__file__).resolve().parent
def digest(path):
    meta = path.lstat()
    assert stat.S_ISREG(meta.st_mode) and meta.st_nlink == 1
    assert not getattr(meta, 'st_file_attributes', 0) & 1024
    return hashlib.sha256(path.read_bytes()).hexdigest()

invocation = json.loads((ROOT/'local-replay27-authenticated.invocation.json').read_bytes())
raw = (ROOT/'local-replay27-authenticated.runner-receipt.json').read_bytes()
runner = json.loads(raw)
assert invocation['exit'] == 0 and type(invocation['exit']) is int
assert invocation['sourceUnchanged'] is True and invocation['cleanAfter'] is True
assert invocation['stderrBytes'] == 0 and invocation['runnerReceiptExists'] is True
assert digest(ROOT/'local-replay27-authenticated.runner-receipt.json') == invocation['runnerReceiptSHA256']
assert digest(ROOT/'local-replay27-authenticated.stdout.jsonl') == invocation['stdoutSHA256']
assert digest(ROOT/'local-replay27-authenticated.stderr.log') == invocation['stderrSHA256']
assert json.loads((ROOT/'local-replay27-authenticated.stdout.jsonl').read_bytes()) == runner
assert runner['status'] == 'PASS' and runner['acceptanceGranted'] is False and runner['release'] == 'NO_GO'
assert runner['context']['head'] == invocation['head'] == 'f20a58c09fefb9b9b15d10bc59119462ecdec386'
assert runner['context']['tree'] == invocation['tree'] == '4fdd7eca278a8e9cd963b74ed2b066b848eb6dd3'
pins = [
    (24, 'd0ccef65bcbe0c90483e6c0f691ed95f92228c6c', '22f91455d651a81296ab8724f9db7cfead65af08', 23, 127, 23489),
    (25, '52a3d01ebb36a6845d0ac21935ad35520732633f', 'ef49a81ca814f3d82b8a868e0308b6dda09c9cca', 16, 122, 23501),
    (26, '8c02a02afd7f2e9775dcc512c800d4f71f733234', 'ff0f76d11fa7775e27732f54ce7fdfbd51c8c676', 26, 198, 23513),
]
assert len(runner['records']) == 3
for row, (release, head, tree, positive, refusal, count) in zip(runner['records'], pins):
    assert (row['release'], row['head'], row['tree']) == (release, head, tree)
    assert row['checkoutBefore'] == row['checkoutAfter']
    assert row['checkoutBefore']['trackedBlobs'] == count
    assert row['toolIdentityBefore'] == runner['tools'] == row['toolIdentityAfter']
    result = row['consumerResult']
    assert (result['exit'], result['positiveControls'], result['refusals']) == (0, positive, refusal)
    assert result['acceptanceGranted'] is False and result['release'] == 'NO_GO'
    assert row['sourceResult']['exit'] == 0 and row['sourceResult']['valid'] is True
    assert row['sourceResult']['acceptanceGranted'] is False
    assert row['installation']['npmCiExit'] == row['installation']['postinstallCheckExit'] == 0
    assert row['installation']['mandatoryHooks'] is True
    assert row['installation']['cacheMode'] == 'FRESH_EMPTY_EXTERNAL_NPM_CACHE'

review = dict(status='PASS', qualification='INDEPENDENT_RECEIPT_BYTE_AND_IDENTITY_REVIEW_NOT_ACCEPTANCE',
    acceptanceGranted=False, release='NO_GO', sourceHead=invocation['head'], sourceTree=invocation['tree'],
    elapsedSeconds=invocation['elapsedSeconds'], runnerReceiptSHA256=invocation['runnerReceiptSHA256'],
    historicalReleases=[pin[0] for pin in pins], cleanAfter=True, sourceUnchanged=True)
(ROOT/'local-replay27-independent-receipt-review.json').write_text(json.dumps(review, indent=2)+'\n', encoding='utf-8')
names = [
    'run_local_replay27.py', 'finalize_followup_review.py', 'REPLAY27_LOCAL_DIAGNOSIS.md',
    'replay27-local-toolchain-diagnostic.json', 'replay27-local-tools27-diagnostic.json',
    'replay27-default-path-diagnostic.json', 'replay27-default-tools27-diagnostic.json',
    'local-replay27-authenticated.toolchain.json', 'local-replay27-authenticated.invocation.json',
    'local-replay27-authenticated.runner-receipt.json', 'local-replay27-authenticated.stdout.jsonl',
    'local-replay27-authenticated.stderr.log', 'local-replay27-independent-receipt-review.json',
    'QUALITY_FAILURE_DIAGNOSIS.md', 'quality-job123642803542-relevant.log', 'quality-job123642803542-checkout.log',
    'PUBLIC_DB_PREFREEZE_REVIEW.md', 'public-db-prefreeze-sanitized.json', 'public-windows-prefreeze-sanitized.json',
]
index = dict(schema=1, acceptanceGranted=False, release='NO_GO', files=[dict(path=name, bytes=(ROOT/name).stat().st_size,
    sha256=digest(ROOT/name)) for name in names])
(ROOT/'archive-followup-evidence-index.json').write_text(json.dumps(index, indent=2)+'\n', encoding='utf-8')
print(json.dumps(dict(status='PASS', indexedFiles=len(names), runnerReceiptSHA256=invocation['runnerReceiptSHA256'])))
