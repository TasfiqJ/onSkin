from pathlib import Path
import hashlib, json, os, re, stat, struct, unicodedata, zlib

ROOT=Path(__file__).resolve().parent
ZIP_SHA='9f6c775c24ee4f6f5ac6da5a9422bd629ec624fa05ccbcf93e84b7cf644d9c7a'
MANIFEST_SHA='b7a6c2ffb8f4aad827dc147ee16388b3a60760bdfb79a16077f32ffa733e5004'
VERIFIER_SHA='2b24bf81d7d3dac652cc3cdee3ebed74f5ef9fcf3830ff1240c1da50cab17fc1'

def need(ok,label):
    if not ok: raise ValueError(label)

def sha(raw):return hashlib.sha256(raw).hexdigest()

def pairs(items):
    result={}
    for k,v in items:
        need(k not in result,'DUPLICATE_JSON_KEY');result[k]=v
    return result

def inspect(raw,expected_count=None,depth=0,budget=None):
    need(depth<=5 and 22<=len(raw)<=128*1024*1024,'ZIP_BOUND')
    budget=budget if budget is not None else {'members':0,'expanded':0}
    e=struct.unpack('<4s4H2IH',raw[-22:])
    need(e[0]==b'PK\x05\x06' and e[1:3]==(0,0) and e[3]==e[4] and e[7]==0,'EOCD')
    count,cdsize,cdoff=e[4:7]
    need(0<count<=20000 and (expected_count is None or count==expected_count) and cdoff+cdsize==len(raw)-22,'CENTRAL_BOUND')
    cursor=cdoff;end=0;records=[];aliases={};explicit=set()
    for _ in range(count):
        need(cursor+46<=len(raw)-22,'CENTRAL_HEADER')
        c=struct.unpack_from('<4s6H3I5H2I',raw,cursor)
        sig,made,needver,flags,method,tm,dt,crc,packed,size,nl,xl,cl,disk,internal,external,offset=c
        need(sig==b'PK\x01\x02' and made>>8==3 and needver<=20 and flags in (0,0x800) and method in (0,8),'CENTRAL_FEATURE')
        need(xl==cl==disk==internal==0 and external==0x81a40000,'MODE_EXTRA')
        need(0<nl<=4096 and cursor+46+nl<=len(raw)-22,'NAME_BOUND')
        nb=raw[cursor+46:cursor+46+nl];name=nb.decode('utf-8' if flags&0x800 else 'ascii')
        need(name==unicodedata.normalize('NFKC',name) and '\\' not in name and not name.startswith('/') and not name.endswith('/'),'PATH_FORM')
        parts=name.split('/');need(len(parts)<=64,'PATH_DEPTH')
        for i,part in enumerate(parts):
            need(part not in ('','.','..') and part[-1:] not in ('.',' ') and not re.search(r'[<>:"|?*\x00-\x1f\x7f-\x9f]',part),'PATH_COMPONENT')
            need(not re.fullmatch(r'(?i)(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\..*)?',part),'PATH_DEVICE')
            prefix='/'.join(parts[:i+1]);key=unicodedata.normalize('NFKC',prefix).casefold();kind='file' if i==len(parts)-1 else 'directory'
            need(key not in aliases or aliases[key]==(prefix,kind),'PATH_ALIAS')
            aliases[key]=(prefix,kind)
        need(name not in explicit,'DUPLICATE');explicit.add(name)
        budget['members']+=1;budget['expanded']+=size
        need(budget['members']<=20000 and budget['expanded']<=512*1024*1024 and size<=128*1024*1024 and size<=max(1024*1024,packed*500),'EXPANSION')
        need(offset==end and offset+30<=cdoff,'LOCAL_OVERLAP')
        local=struct.unpack_from('<4s5H3I2H',raw,offset)
        need(local==(b'PK\x03\x04',needver,flags,method,tm,dt,crc,packed,size,nl,0),'LOCAL_METADATA')
        need(raw[offset+30:offset+30+nl]==nb,'LOCAL_NAME')
        start=offset+30+nl;end=start+packed;need(end<=cdoff,'LOCAL_BOUND')
        records.append((name,start,packed,size,crc,method));cursor+=46+nl
    need(cursor==cdoff+cdsize and end==cdoff,'ZIP_GAP')
    contents={}
    for name,start,packed,size,crc,method in records:
        compressed=raw[start:start+packed]
        if method==8:
            d=zlib.decompressobj(-15);b=d.decompress(compressed,size+1)
            need(d.eof and not d.unused_data and not d.unconsumed_tail,'DEFLATE')
        else:b=compressed
        need(len(b)==size and zlib.crc32(b)==crc,'CRC_SIZE')
        contents[name]=b
        if name.endswith('.zip'):inspect(b,depth=depth+1,budget=budget)
    return contents,budget

def main():
    p=ROOT/'original-campaign26.zip';a=p.lstat()
    need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and not getattr(a,'st_file_attributes',0)&0x400,'SOURCE_MODE')
    with p.open('rb') as f:
        h0=os.fstat(f.fileno());raw=f.read(11324493);h1=os.fstat(f.fileno())
    b=p.lstat()
    for x,y in ((a,b),(h0,h1),(a,h0),(b,h1)):
        need(all(getattr(x,k)==getattr(y,k) for k in dir(x) if k.startswith('st_') and k not in ('st_atime','st_atime_ns')),'SOURCE_CHANGED')
    need(len(raw)==a.st_size==11324492 and sha(raw)==ZIP_SHA,'EXTERNAL_ZIP_HASH')
    files,budget=inspect(raw,145)
    need(sha(files['manifest.json'])==MANIFEST_SHA and sha(files['verify_return26.py'])==VERIFIER_SHA,'EXTERNAL_ANCHORS')
    manifest=json.loads(files['manifest.json'],object_pairs_hook=pairs)
    need(set(files)==set(manifest['files'])|{'manifest.json'},'INVENTORY')
    for name,item in manifest['files'].items():
        need(type(item['bytes']) is int and len(files[name])==item['bytes'] and sha(files[name])==item['sha256'],'DECLARED_HASH')
    out=ROOT/'extracted';out.mkdir(exist_ok=False)
    for name,content in files.items():
        dest=out.joinpath(*name.split('/'));dest.parent.mkdir(parents=True,exist_ok=True)
        for parent in (dest.parent,*dest.parent.parents):
            s=parent.lstat();need(stat.S_ISDIR(s.st_mode) and not getattr(s,'st_file_attributes',0)&0x400,'PARENT_REPARSE')
        with dest.open('xb') as f:f.write(content)
        s=dest.lstat();need(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not getattr(s,'st_file_attributes',0)&0x400 and sha(dest.read_bytes())==sha(content),'EXTRACTED_HASH')
    receipt={'status':'INDEPENDENT_ARCHIVE_PREFLIGHT_PASS','zip_sha256':sha(raw),'zip_bytes':len(raw),'manifest_sha256':MANIFEST_SHA,'verifier_sha256':VERIFIER_SHA,'outer_members':len(files),'recursive_budget':budget,'qualified':'SUPPLIER_ANCHORED_HISTORICAL_ARTIFACT_NO_ACCEPTANCE'}
    (ROOT/'preflight-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))

if __name__=='__main__':main()
