# Public Quality job 123642803542 diagnosis

The actual Quality checkout is GitHub's generated PR31 test merge `f36f8a0fbbe2eddba44c3c1c40f5c722869a7df6`, recorded as merging source `f20a58c09fefb9b9b15d10bc59119462ecdec386` into pinned PR30 `8c02a02afd7f2e9775dcc512c800d4f71f733234`. It is not an exact-head checkout or a real branch merge. This log inspection did not independently compare its tree to the source tree.

The first observed failure in the catalog-contract step is `npm run phase4:source-worklist:check`, which invokes the original `node scripts/phase4/build-source-worklist.mjs --strict --check`.

Both generated files were reported stale:

- `docs/phase-4/generated/source-worklist.json`
- `docs/phase-4/generated/source-worklist.md`

The shell then exited 1. Source-policy checks and the preceding beta-coverage contract completed before this failure (the latter reported 12 tests / 12 pass / 0 fail). The subsequent promotion, curation, catalog-serving and catalog-report-privacy commands were listed in the step script but were not reached after the strict worklist failure. Their success is not inferred.

This is a generated-worklist freshness failure at the observed pre-freeze candidate. It does not identify a failure of catalog-serving application behavior. Preserve this failed run. The authorized correction is the planned unchanged Phase4 producer from clean committed frozen source, followed by the single worklist-only child; do not hand-edit worklists or weaken the check.

Evidence: `quality-job123642803542-relevant.log`, bounded excerpts from the public Quality job logs returned by the GitHub connector. No original Security API logs were requested for this diagnosis. No source files were modified. All source/release acceptance remains withheld.
