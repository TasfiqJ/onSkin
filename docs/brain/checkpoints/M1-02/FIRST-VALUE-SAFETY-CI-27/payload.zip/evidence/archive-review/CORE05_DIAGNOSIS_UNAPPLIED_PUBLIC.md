# Public derivative notice

This labelled publication derivative preserves the original diagnosis, Git blob identities, results and qualifications. Direct new SHA256 values of the unchanged notification source and original test are omitted. The original review remains private and unchanged. See core05-pr28-PUBLIC.json and core05-pr29-PUBLIC.json for bounded actual failed-run evidence; their expanded raw assertion logs remain private.

# Campaign27 independent legacy CORE-05 diagnosis

Status: PARTIAL (diagnosed and reproduced); remediation UNAPPLIED. The original assertion remains FAIL. No source acceptance or database acceptance is granted. G97 FAIL/NO_GO and all qualified gates remain closed.

## Original results reproduced

The unchanged command `node --test scripts/core05/adherence-source-contract.test.mjs` was executed in a new complete remote clone at each authentic historical head:

| Source | Exact head | Exact tree | Result |
|---|---|---|---|
| PR28 | d0ccef65bcbe0c90483e6c0f691ed95f92228c6c | 22f91455d651a81296ab8724f9db7cfead65af08 | exit 1; 35 PASS / 1 FAIL |
| PR29 | 52a3d01ebb36a6845d0ac21935ad35520732633f | ef49a81ca814f3d82b8a868e0308b6dda09c9cca | exit 1; 35 PASS / 1 FAIL |

The failure is test 8, `notification opt-in is exact-time, authorization-aware, local-only, and cap-safe`. Both executions preserve all original assertions and finish with a clean tracked/untracked source status. The isolated checkout is restored to exact PR29. See `core05-pr28.receipt.json`, `core05-pr29.receipt.json` and their stdout/stderr logs.

The environment used actual normal npm 11.20.0 `ci --ignore-scripts=false` with a new empty cache and mandatory postinstall hooks, at PR29. The same installed environment was used at PR28 after independently checking identical package lock, package manifests and relevant postinstall source inputs. This was not a substitute fixture or an execution of the old consumer at a new head. Toolchain identity is pinned separately in `pinned-toolchain.stdout.json`; the normal historical install receipt is `npm-ci-core.receipt.json`.

## Exact discrepancy

At both source heads, `scripts/core05/adherence-source-contract.test.mjs:595` requires this exact source spelling:

```js
/acceptRoutineReminderSoftAsk\(PROPOSED_ROUTINE_REMINDER_TIMES\)/u
```

At both heads, `apps/mobile/src/app/onboarding/notifications.tsx:145` contains:

```ts
const outcome = await acceptRoutineReminderSoftAsk(
  PROPOSED_ROUTINE_REMINDER_TIMES,
  undefined,
  assertLifecycle,
);
```

The source uses multiline whitespace and three arguments; the regex requires adjacent parentheses with exactly one argument. The first argument remains the exact proposed times. `undefined` selects the helper's default dependencies, and the third argument carries the current focus/health lifecycle guard. A read-only TypeScript AST inspection independently found one such call with those exact three arguments (`core05-call-diagnosis-PUBLIC.json`). This diagnostic does not count as a passing original test.

The original test Git blob is `880be16d287890c24e3d4e5b3d8de04ccaf7142f` at both PR28 and PR29; SHA256 `OMITTED_DIRECT_SOURCE_OR_TEST_SHA256`. The route Git blob is `5b1678c414c463575f38a959d501447bcbd21ef5` at both; SHA256 `OMITTED_DIRECT_SOURCE_OR_TEST_SHA256`. The route's last introducing change is Campaign17 commit `2fa87c7fa1a9fa434468c16d96aaa9c027be8d04`.

The failing assertion precedes the remainder of that single test body; statements after line 595 are not claimed to have run successfully in that test. The other 35 original test cases passed.

## User consequence and supporting source tests

The discrepancy blocks the legacy source contract and therefore remains a real verification failure. It does not show that a different reminder time is passed or that notification permission has been obtained. The actual helper in `apps/mobile/src/features/notifications/onboarding.ts:40` defaults its second parameter to `defaultDeps`, composes its third parameter with the captured health lease, and checks currentness around permission and preference save/scheduling. The route's `assertLifecycle` captures the exact accepted focus/health window. Removing that argument to satisfy the regex would weaken existing stale-callback protection.

The original `onboarding.test.ts`, `reminderBoundary17.test.ts` and `reminderRecovery16.test.ts` were also executed at exact PR29: 3 files / 29 cases PASS, exit 0 (`core05-notification-runtime-pr29.receipt.json`). These tests include mocked React Native, notification delivery and private storage boundaries; they are useful source/runtime controls, not real OS permission, native notification delivery, physical iPhone, or VoiceOver proof.

The failure is unrelated to the canonical PostgreSQL CORE-05 structural SQL contract. This review does not rerun canonical SQL or grant DB06/DB08/R2B acceptance.

## Specific unapplied proposal

No remediation fits Campaign27's allowed source paths: the failing test and notification route/helper are protected outside the finite grant. Do not change the route's call to remove lifecycle protection; do not add a comment or dead one-argument call merely to make the regex match.

A separately authorized successor change would target `scripts/core05/adherence-source-contract.test.mjs` and require an AST/behavioral call contract that verifies the actual callee, the exact proposed-times first argument, the default-dependency second argument, and the lifecycle fence third argument. It would retain the full original frozen test and historical 35/1 observations, and add refusal controls for wrong times, missing lifecycle guard, wrong callee, and a comment/dead-code decoy. Whether and how to replace the active legacy exact-spelling assertion requires a new finite Brain grant; no replacement, skip, weakening, or history rewrite is applied here.

Acceptance remains SUBMITTED_REVIEW_REQUIRED / NO_GO, USD0, NO MERGES.
