# Source, product, protected permissions and custody

## Exact immutable source

- PR30 open/draft/unmerged at `8c02a02afd7f2e9775dcc512c800d4f71f733234`; tree `ff0f76d11fa7775e27732f54ce7fdfbd51c8c676`.
- PR29 remains exact `52a3d01ebb36a6845d0ac21935ad35520732633f`; tree `ef49a81ca814f3d82b8a868e0308b6dda09c9cca`.
- Campaign26 historical runner is `scripts/release/full-app-j01/source_consumer26.test.py` **at exact PR30**. Its original historical behavior must not be rewritten or retrospectively reported PASS when the original Windows run failed. Campaign26 terminal source HEAD/tree includes one evidence-only tail; do not amend/rebase.
- New proposed branch `stage/m1-first-value-safety-ci27` from the **exact** PR30 HEAD, one new stacked DRAFT PR, maintainer modification and auto-merge OFF. Discover PR number after creation; do not guess.

## Actual app behavior

The first iPhone release remains **all genuinely working non-Korean F01–F17/F19–F20, C01–C12 and P01–P06**, private F09 manual diary/comparison, plus **one independently qualified Korean/JANUS J01 Visible Pores**. F18 automated Trend and J02–J27, including J05 Spots, are deferred. The primary product value path is truthful consent/owned Shelf → reviewed insight/pending → routine/Today with durable confirmation and recovery. No scan, clinician, paid entitlement, J01 or diagnosis may be faked as fulfilled.

## Protected boundaries

- **READ-ONLY:** `.github/workflows/security.yml`, all original Security findings/acceptance/exception/fixture files, `scripts/phase9/security_acceptance/`, `apps/mobile/src/lib/storage/privateKV.ts`, core healthConsent/healthDataWriteAdmission/auth/account/session, private F09 photo store/image/sensitive caches, Supabase migrations/config/SQL, Phase2 DB acquisition, native settings/signing/entitlements, subscriptions/billing/provider, original Release08–26 checker definitions/tests (existing inherited script bodies), historical checkpoints and earlier branch heads.
- **No original reviewer signatures, private scanner logs/artifacts, credentials, protected secret-revocation workspaces, production mutations, paid vendor/provider access, auto-merge, main promotion, force push, rebase or spending.**
- Additive source-only remediation may guard an optional caller operation **only** within the granted Shelf UI/mutation/store paths, before the synchronous prepared encrypted write boundary. If correct cancellation requires modifying protected privateKV or health authority, return a precise **UNAPPLIED** proposal and preserve the failing control instead of weakening existing protection.
- Browser/web simulations are source-level evidence, not installed iPhone, VoiceOver, clinical/professional, Apple or public release acceptance. Credentials/health photos stay out of tests.
- Closed gates: **G97 FAIL/NO_GO**, DB06/DB08/R2B NOT_ACCEPTED despite real CI pass, M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED, M2 NOT_AUTHORIZED, J01 optical G1/G2/G3/G5 and longitudinal G4 NOT_ACCEPTED, native/provider/paid/professional/clinical/legal/licensing/Apple/public release CLOSED.
