# Finite implementation grant; first-child immutable SCOPE_PLAN required

After authenticating exact pinned PR30 and before first source edit, commit **only** `docs/brain/task-specs/M1X-27/SCOPE_PLAN.md` as the sole first-child. List an exact finite subset of allowed paths, reason, baseline reproduction, owners, tests. No wildcard or additions after the plan is committed. Choose design autonomously within grant. Scope is not permission to alter unrelated contracts.

## Allowed existing files (only where absolutely necessary)

```
.github/workflows/security-candidate22.yml
apps/mobile/src/app/shelf/[id].tsx
apps/mobile/src/features/shelf/mutations.ts
apps/mobile/src/features/shelf/store.ts
docs/USER_FLOW_TREE.md
scripts/release/full-app-j01/check.py
ONSKIN_BRAIN_HANDOFF.txt
docs/phase-4/generated/source-worklist.json
docs/phase-4/generated/source-worklist.md
```

Use original `source_consumer26.test.py`, original Campaign26 app tests, core05 original tests, old receipts, and Security original workflows as **READ ONLY**. If a regression requires changing a protected path, do not silently broaden; keep proposal unapplied.

## Allowed new files (the subset chosen must be exact)

```
apps/mobile/src/features/shelf/postDispatchCancellation.campaign27.test.ts
apps/mobile/src/features/shelf/confirmedDestructiveLease.campaign27.test.ts
apps/mobile/src/features/shelf/destructive27TestPorts.ts
scripts/release/full-app-j01/source_consumer27.test.py
scripts/release/full-app-j01/replay27.py
scripts/release/full-app-j01/replay27.test.py
docs/brain/contracts/M1X-27/source27.v1.json
docs/brain/task-specs/M1X-27/TASK.md
docs/brain/task-specs/M1X-27/SCOPE_PLAN.md
docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27/README.md
docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27/REPORT.md
docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27/manifest.json
docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27/payload.zip
docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27/verify27.py
```

This is a hard **9 existing +14 new** maximum, of which five checkpoint/plan paths are evidence/governance only. No renames/deletions/mode changes/symlinks of protected/tracked source. The new finite Release27 checker must bind the committed plan, entire history/modes/blobs, original checker function ASTs and prior prefix, false admission flags, hidden source/index states, and exactly one worklist-only child followed by one evidence-only tail. The unchanged Phase4 producer is used verbatim. Generated worklist files are **only** changed by that producer from clean frozen source, not handwritten. If tooling compatibility demands an unlisted path, submit a specific UNAPPLIED proposal; do not alter repository security22 identity configs or safety originals to make a run green.
