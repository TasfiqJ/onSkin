# Live evidence links, exact externally sourced identities, and limits

## Pinned work

- PR30: https://github.com/TasfiqJ/onSkin/pull/30, branch `stage/m1-first-value-recovery26`, exact head `8c02a02afd7f2e9775dcc512c800d4f71f733234`, tree `ff0f76d11fa7775e27732f54ce7fdfbd51c8c676`, DRAFT OPEN UNMERGED at Brain review.
- PR29: https://github.com/TasfiqJ/onSkin/pull/29, head `52a3d01ebb36a6845d0ac21935ad35520732633f`, tree `ef49a81ca814f3d82b8a868e0308b6dda09c9cca`. No merge.
- CI candidate: https://github.com/TasfiqJ/onSkin/actions/runs/40909340285, Windows job 123581174704, Linux job 123581177029. Windows historical replay traceback at `source_consumer26.test.py`, `bytes26()` `R26_REPLAY_CHANGED`; Linux historical and current source evidence passed while public security readiness stayed red.
- Quality: https://github.com/TasfiqJ/onSkin/actions/runs/40909340070, all six jobs success. iOS launch: https://github.com/TasfiqJ/onSkin/actions/runs/40909339965, success. Original Security: https://github.com/TasfiqJ/onSkin/actions/runs/40909340029, failure. Original protected scanner logs are intentionally not inspected by Brain.

## Supplier Campaign26 return, separately authenticated if accessible

- ZIP https://raw.githubusercontent.com/TasfiqJ/onSkin/91e641cbf5d6ec73015445905e4027480ae4caf7/onSkin_Campaign26_First_Value_Recovery_And_CI_Return_2026-10-29.zip
- Report https://github.com/TasfiqJ/onSkin/blob/3c8d855ef23060d0a5dcc96ac039509b4eff434e/FINAL_REPORT_EXTERNAL26.md
- Published anchors https://raw.githubusercontent.com/TasfiqJ/onSkin/3c8d855ef23060d0a5dcc96ac039509b4eff434e/EXTERNAL_ANCHORS26.json
- Supplier ZIP SHA256 `9f6c775c24ee4f6f5ac6da5a9422bd629ec624fa05ccbcf93e84b7cf644d9c7a`, size 11,324,492 bytes; manifest SHA256 `b7a6c2ffb8f4aad827dc147ee16388b3a60760bdfb79a16077f32ffa733e5004`; verifier SHA256 `2b24bf81d7d3dac652cc3cdee3ebed74f5ef9fcf3830ff1240c1da50cab17fc1`.
- Supplier states 145 archive members +269 nested checkpoint members, two independent full clean clones and source/artifact 0/1/0. **Brain has not independently reverified those archive bytes or replayed full clone**; actual GitHub source and CI independently support only the scope described in `01_CAMPAIGN26_INDEPENDENT_AUDIT.md`.
- The user's screenshot was a Windows-local `C:/Users/...` file and not accessible in this environment. If the return contains it, authenticate its archive bytes before saying it was visually inspected.

## Technical source observations

- PR30 changed 22 paths in six commits within a first-child finite grant. `apps/mobile/src/features/shelf/mutations.ts` and `store.ts` were not edited. Existing mutation hook `useShelfMutations` wraps `removeProduct` and `updateProduct` with a health lease; private store uses serialized `updatePrivateItem` and checks health lease at callback. A current UI/source fence **is not presently supplied** across that boundary for post-dispatch UI retirement.
- `source_consumer26.test.py` function `bytes26()` checks `st_ctime_ns` equality across path and opened file handle in a single stamp. The suspected Windows mismatch must be **measured and reproduced**, not declared proved solely from source.
- Original core05 source exact-string assertion 35/1 on PR28 and PR29 is **not** the canonical SQL CORE-05 structural PASS.

## No unsupported claims

This packet offers orientation, explicit finite engineering grant and supplier evidence hashes, not an independently cloned/verified protected release candidate. A future result may not claim original Security/custody/credential/clinical/Apple acceptance or pretend a prior historical failure was resolved retroactively. All code decisions within grant belong to Codex; every qualified gate remains independently held.
