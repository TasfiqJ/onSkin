"""Read-only source audit of externally recorded original historical executions."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess

RUN = Path(__file__).resolve().parent.parent
OUT = RUN / 'history-execution'
HIST = RUN / 'archive-review/authenticated-payload/evidence/historical26'
ENV = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_'))}
ENV['GIT_TERMINAL_PROMPT'] = '0'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def main():
    summary = json.loads((OUT/'SUMMARY.json').read_text(encoding='utf-8'))
    prior = json.loads((HIST/'HISTORICAL26_FRESH_SUMMARY.json').read_text(encoding='utf-8'))
    expected = {row['release']: row for row in prior['runs']}
    runs = summary['runs']
    assert [r['release'] for r in runs] == ['08-original151'] + [str(i).zfill(2) for i in range(9, 24)]
    witnessed = []
    for row in runs:
        release = row['release']
        receipt_raw = (OUT/('release'+release+'.receipt.json')).read_bytes()
        assert json.loads(receipt_raw) == row
        assert type(row['exit']) is int and row['exit'] == 0
        assert row['timeout'] is False and row['cleanAfter'] is True
        assert row['acceptanceGranted'] is False and row['releaseStatus'] == 'NO_GO'
        assert row['before'] == row['after']
        stdout = (OUT/('release'+release+'.stdout.log')).read_bytes()
        stderr = (OUT/('release'+release+'.stderr.log')).read_bytes()
        assert sha(stdout) == row['stdoutSHA256'] and sha(stderr) == row['stderrSHA256']
        assert stderr == b''
        events = [json.loads(line) for line in stdout.decode('utf-8').splitlines()]
        assert events[-1] == row['terminalResult']
        cases = [event for event in events if 'case' in event]
        for case in cases:
            if 'expected_exit' in case:
                assert type(case['exit']) is int and case['exit'] == case['expected_exit']
        if release == '08-original151':
            assert row['source'] == 'd08347f0011672cd309d835628c094b5e9f4725d'
            assert row['tree'] == '0998881bc543840395dca375769ea1b7c9a8d4c7'
            assert row['scriptIdentity']['sha256'] == '191f74631da86413c687801c7a620bbe01c0bd7d98c83f6bdd72947faf2ec455'
            assert row['checkerIdentity']['sha256'] == '7118308899a2b6b89e98680697d486b85dacd9b9fad8702cdf39a54751f6b822'
            assert events[-1] == {'passed': True, 'negative_cases': 151, 'current_exit': 0, 'tampered_exits': 1, 'restored_exit': 0,
                                  'qualification': 'BUNDLE_FIXTURES_ONLY_NOT_INDEPENDENT_CHECKOUT'}
            assert len(cases) == 153
            assert cases[0]['case'] == 'authentic-current' and cases[0]['exit'] == 0
            assert cases[-1]['case'] == 'authentic-restored' and cases[-1]['exit'] == 0
            assert all(case['exit'] == 1 for case in cases[1:-1])
        else:
            old = expected[release]
            assert row['source'] == old['head'] and row['tree'] == old['tree']
            assert row['scriptIdentity'] == old['scriptIdentity'] and row['checkerIdentity'] == old['checkerIdentity']
            assert events[-1] == old['originalTerminalResult']
        witnessed.append({'release': release, 'exit': 0, 'receiptSHA256': sha(receipt_raw),
                          'stdoutSHA256': sha(stdout), 'stderrSHA256': sha(stderr), 'eventCount': len(events),
                          'caseCount': len(cases),
                          'explicitExit1CaseCount': sum(case.get('exit') == 1 for case in cases),
                          'explicitExit0CaseCount': sum(case.get('exit') == 0 for case in cases),
                          'terminalResult': events[-1]})
    endpoints = []
    for group, head in [('early', 'b79e6d1e21a367be5cea5d0b333de9f2a144d41f'),
                        ('late', '5976394fd39f41550bde8107b9cc27c758b7ce14')]:
        root = OUT/group
        def git(*args):
            return subprocess.check_output(['git', '--no-replace-objects', '-c', 'core.hooksPath=', '-c', 'core.autocrlf=false', '-c', 'core.longpaths=true', *args], cwd=root, env=ENV)
        assert git('rev-parse', 'HEAD').decode().strip() == head
        assert not git('status', '--porcelain=v1', '--untracked-files=all', '-z')
        assert git('rev-parse', '--is-shallow-repository').strip() == b'false'
        assert not (root/'.git/objects/info/alternates').exists()
        folder = (root/'.git/objects').lstat()
        assert stat.S_ISDIR(folder.st_mode) and not getattr(folder, 'st_file_attributes', 0)&1024
        endpoints.append({'group': group, 'head': head, 'clean': True, 'shallow': False, 'alternates': False,
                          'objectDirectoryDevice': folder.st_dev, 'objectDirectoryInode': folder.st_ino})
    assert len({(r['objectDirectoryDevice'], r['objectDirectoryInode']) for r in endpoints}) == 2
    result = {'status': 'PASS_ORIGINAL151_AND_AUTHENTIC_ORIGINAL09_TO23', 'runs': witnessed, 'endpoints': endpoints,
              'executionHarnessSHA256': sha((RUN/'history-review/execute_original_history.py').read_bytes()),
              'receiptAuditSHA256': sha(Path(__file__).read_bytes()), 'summarySHA256': sha((OUT/'SUMMARY.json').read_bytes()),
              'nativeInputs': 'TEN_AUTHENTICATED_PUBLIC_NATIVE_SOURCE_PIN_FIXTURES;NOT_HISTORICAL_NPM_INSTALL',
              'qualification': 'ORIGINAL_TEST_QUALIFICATIONS_PRESERVED;NOT_CURRENT_SOURCE_SECURITY_NATIVE_OR_RELEASE_ACCEPTANCE',
              'acceptanceGranted': False, 'release': 'NO_GO'}
    with (OUT/'INDEPENDENT_RECEIPT_AUDIT.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'completed': len(witnessed), 'allExits0': True, 'acceptanceGranted': False, 'release': 'NO_GO'}))

if __name__ == '__main__':
    main()
