from pathlib import Path
import hashlib,json,os,stat,runpy,sys
source=Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code\c26-final-a-8c02r2')
script=source/'scripts/release/full-app-j01/source_consumer26.test.py'
target=source/'scripts/release/full-app-j01/check.py'
output={}
try:
 raw=script.read_bytes()
 output['original_consumer_sha256_equal']=hashlib.sha256(raw).hexdigest()=='8429fbd1f200b6d63064d524675c81d021f77228cfb232e8168df49ea88ff678'
 if not output['original_consumer_sha256_equal']: raise ValueError('UNAUTHENTICATED')
 namespace=runpy.run_path(str(script),run_name='read_only_diagnostic')
 a=target.lstat()
 with target.open('rb') as stream:
  b=os.fstat(stream.fileno());body=stream.read(128*1024*1024+1);c=os.fstat(stream.fileno())
 d=target.lstat()
 for label,x,y in (('path_before_after',a,d),('handle_before_after',b,c),('path_handle_before',a,b),('path_handle_after',d,c)):
  for field in ('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_atime_ns','st_birthtime_ns'):
   output[label+'_'+field+'_available']=hasattr(x,field) and hasattr(y,field)
   if hasattr(x,field) and hasattr(y,field):output[label+'_'+field+'_equal']=getattr(x,field)==getattr(y,field)
  output[label+'_execute_bits_equal']=(x.st_mode&0o111)==(y.st_mode&0o111)
  output[label+'_nonexecute_mode_equal']=(x.st_mode&~0o111)==(y.st_mode&~0o111)
 output['all_regular_single_link_nonreparse']=all(stat.S_ISREG(s.st_mode) and s.st_nlink==1 and not getattr(s,'st_file_attributes',0)&1024 for s in (a,b,c,d))
 output['all_read_sizes_equal']=a.st_size==b.st_size==c.st_size==d.st_size==len(body)
 try:
  result=namespace['bytes26'](target)
  output['original_bytes26_pass']=result==body
  output['original_bytes26_R26_REPLAY_CHANGED']=False
 except ValueError as e:
  output['original_bytes26_pass']=False
  output['original_bytes26_R26_REPLAY_CHANGED']=e.args==('R26_REPLAY_CHANGED',)
 except Exception:
  output['original_bytes26_unexpected_exception']=True
 print(json.dumps(output,sort_keys=True,indent=2))
except Exception:
 print(json.dumps({'diagnostic_exception':True}))
 raise SystemExit(1)
