# Campaign27 historical replay review

Read-only review against exact PR30 `8c02a02afd7f2e9775dcc512c800d4f71f733234`, tree `ff0f76d11fa7775e27732f54ce7fdfbd51c8c676`. Working checker, consumer26, workflow, AGENTS.md and CLAUDE.md bytes independently matched `git show` at that commit. No source was edited or committed.

## Reproduced defect

The bundled local Windows runtime is Python 3.12.14. The original consumer26 SHA256 was authenticated before `runpy` loaded its definitions with a non-main name. Calling its unchanged `bytes26()` on the exact PR30 checker raised `R26_REPLAY_CHANGED`. Python 3.9 and 3.11 controls passed. Fixed-field receipts are `windows-python312-reader.json`, `windows-python311-reader.json`, and `windows-python39-reader.json`.

The 3.12 assay shows stable device/inode/mode/link-count/size/mtime/ctime within each metadata domain. Cross-domain ctime differs; cross-domain birthtime agrees. Access time changes as a consequence of reading but is absent from the original bytes26 stamp. Executable bits matched for the `.py` fixture.

A separate read-only Win32 `GetFileInformationByHandleEx(FileBasicInfo)` comparison on the same file showed pathname ctime equals CreationTime and opened-handle ctime equals ChangeTime. Both birthtime fields equal CreationTime; both mtimes equal LastWriteTime. This establishes the actual representation discrepancy on local Python 3.12.14 rather than assuming it from documentation.

Live public candidate job 123581174704 was independently fetched via the connected GitHub tool. Its disclosed hosted Python was 3.12.10. The historical command failed in replay26 -> checkout26 line 191 -> bytes26 line 52 -> R26_REPLAY_CHANGED, before historical installation. This remains a failed historical observation. It was not rerun or relabeled PASS. No original Security job logs were accessed.

## Minimal new runner

Implement a separately identified `replay27.py`; do not monkeypatch bytes26 inside the original consumer and call that historical success. Execute original consumers24/25/26 and original checkers as subprocesses in independent, exact detached clones, after authenticating full tree/index/raw working bytes and mandatory installed toolchain. Pin checker/consumer hashes and blobs listed in `historical-pins.json`.

For the new byte reader, retain raw ctime and exact mode (including execute bits) within path/path and handle/handle domains. On Windows compare birthtime across domains when present, and normalize only the cross-domain suffix-derived executable-bit presentation; still validate regular type, permissions, link count, reparse flags, parent identity, inode/device, size and mtime. Retain byte count, bounded complete reads and Git blob identity. The existing immutable regular23 and working26_guard show the time-domain split, but normalize Windows execute bits in all stamps; the new reader can make that normalization narrower.

Preserve false admissions, exact result counters and qualifications. A new receipt must require all three records, fresh nonce/current source context, exact tools, before/after checkout identities, actual npm ci and mandatory patch checks, and source checker/consumer subprocess exit/result validation. Schema positives do not establish execution. A receipt verifier must not accept a stale self-consistent receipt as proof for a different current run.

## Governance successor

The exact PR30 checker contains 189 original top-level functions. Preserve its entire prefix before the terminal main block, and all 189 original function ASTs. Append only the Release27 declarations/functions and the new dispatch. The original current-head source26_guard and validate26_checker are not callable against an extended Release27 head: their finite scope/appendix checks correctly reject it. Do not mutate their globals or run a historical consumer at the new head to avoid that rejection.

The successor should independently bind PR30 base/tree, the sole first-child immutable plan, exact finite path sets, the actual new PR number, complete linear transition chronology, every blob/mode, hidden index flags and untracked/ignored source, one producer-only worklist child, and exactly one checkpoint+handoff tail. The inherited full26_store/tree26/working26_guard primitives are independently reusable without weakening their code; source26 endpoint/history semantics are specific to the old campaign.

Freeze risk: every committed intermediate workflow/consumer/checker identity must be recognized by the final transition validator. Either finalize those governance bytes in one substantive commit or explicitly pin any prior legitimate transitions in new Release27 governance. Never amend old commits to make an evolving self-pin fit, and never permit arbitrary historical intermediate governance bytes.

## Current limits

Local original helper behavior was reproduced on real Windows 3.9/3.11/3.12.14. Hosted 3.12.10 was observed from immutable historical CI evidence; no new hosted execution has yet been performed by this reviewer. POSIX, complete installed replay and Release27 negative controls remain for implementation verification. G97 FAIL/NO_GO and all qualified approval boundaries remain closed.
