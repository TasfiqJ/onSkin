"""External Campaign27 witness: unchanged original consumers at their own commits."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import stat
import subprocess
import sys
import time

RUN = Path(__file__).resolve().parent.parent
OUT = RUN/'history-execution'
HIST = RUN/'archive-review/authenticated-payload/evidence/historical26'
PINS = json.loads((HIST/'authentic-historical-pins.json').read_text())['runs']
NATIVE = json.loads((HIST/'authenticated-native-fixture-pins.json').read_text())
PYTHON = r'C:\Python39\python.exe'
ENV = {k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_')) and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
ENV['GIT_TERMINAL_PROMPT'] = '0'
ENV['PATH'] = str(RUN.parent/'campaign26-run-1b46eb3809914b21a97234dcffb185dc/security26-tools') + os.pathsep + ENV['PATH']

def sha(raw): return hashlib.sha256(raw).hexdigest()

def git(root, *args):
    child = subprocess.run(['git','--no-replace-objects','-c','core.hooksPath=','-c','core.autocrlf=false','-c','core.longpaths=true',*args],cwd=root,env=ENV,capture_output=True,timeout=600)
    if child.returncode: raise RuntimeError('HISTORY_GIT_FAILED')
    return child.stdout

def stable(a,b):
    fields=[n for n in dir(a) if n.startswith('st_') and n not in ('st_atime','st_atime_ns')]
    return all(getattr(a,n)==getattr(b,n) for n in fields)

def inventory(root, commit):
    assert git(root,'rev-parse','HEAD').decode().strip()==commit
    assert not git(root,'status','--porcelain=v1','--untracked-files=all','-z')
    tree=git(root,'ls-tree','-r','-z',commit)
    count=total=0
    for row in tree.split(b'\0'):
        if not row:continue
        meta,name=row.split(b'\t',1);mode,kind,oid=meta.split()
        assert kind==b'blob' and mode in (b'100644',b'100755')
        target=root/name.decode('utf-8');before=target.lstat()
        assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and not getattr(before,'st_file_attributes',0)&1024 and before.st_size<=128*1024*1024
        digest=hashlib.sha1(b'blob '+str(before.st_size).encode()+b'\0');size=0
        with target.open('rb') as stream:
            opened=os.fstat(stream.fileno())
            assert all(getattr(before,f)==getattr(opened,f) for f in ('st_dev','st_ino','st_nlink','st_size','st_mtime_ns'))
            while True:
                block=stream.read(min(1024*1024,before.st_size-size+1))
                if not block:break
                size+=len(block);assert size<=before.st_size;digest.update(block)
            finished=os.fstat(stream.fileno())
        assert stable(opened,finished) and stable(before,target.lstat()) and size==before.st_size and digest.hexdigest()==oid.decode()
        count+=1;total+=size
    assert not git(root,'status','--porcelain=v1','--untracked-files=all','-z')
    return {'trackedFiles':count,'trackedBytes':total,'treeMetadataSHA256':sha(tree),'tree':git(root,'rev-parse','HEAD^{tree}').decode().strip()}

def run_case(root, pin):
    release=pin['release'];start=time.monotonic()
    print(json.dumps({'release':release,'status':'STARTED'}),flush=True)
    git(root,'checkout','--detach',pin['source'])
    assert git(root,'rev-parse','HEAD^{tree}').decode().strip()==pin['tree']
    for label,path in [('scriptIdentity',pin['script']),('checkerIdentity','scripts/release/full-app-j01/check.py')]:
        raw=(root/path).read_bytes();expected=pin[label]
        assert len(raw)==expected['bytes'] and sha(raw)==expected['sha256']
        assert raw==git(root,'show',pin['source']+':'+path)
        assert git(root,'ls-tree',pin['source'],'--',path).decode().strip()==expected['mode']+' blob '+expected['blob']+'\t'+path
    before=inventory(root,pin['source'])
    command=[PYTHON,'-B',pin['script']]
    stdout=OUT/('release'+release+'.stdout.log');stderr=OUT/('release'+release+'.stderr.log')
    timeout=False
    with stdout.open('xb') as out,stderr.open('xb') as err:
        try:
            child=subprocess.run(command,cwd=root,env=ENV,stdout=out,stderr=err,timeout=1800)
            exit_code=child.returncode
        except subprocess.TimeoutExpired:
            timeout=True;exit_code=None
    after=inventory(root,pin['source'])
    assert before==after
    raw=stdout.read_bytes();errors=stderr.read_bytes();terminal=None
    for line in reversed(raw.decode('utf-8',errors='replace').splitlines()):
        try:terminal=json.loads(line);break
        except json.JSONDecodeError:continue
    receipt={'release':release,'source':pin['source'],'tree':pin['tree'],'scriptIdentity':pin['scriptIdentity'],
        'checkerIdentity':pin['checkerIdentity'],'argv':command,'exit':exit_code,'timeout':timeout,'elapsedSeconds':time.monotonic()-start,
        'before':before,'after':after,'cleanAfter':True,'stdoutSHA256':sha(raw),'stderrSHA256':sha(errors),'terminalResult':terminal,
        'qualification':'ORIGINAL_UNCHANGED_CONSUMER_AT_AUTHENTIC_FULL_CHECKOUT;INTERNAL_SYNTHETIC_AND_NATIVE_PIN_FIXTURE_QUALIFICATIONS_PRESERVED;NOT_CURRENT_ACCEPTANCE',
        'nativeInputs':'TEN_AUTHENTICATED_PUBLIC_SOURCE_PINS_FROM_CURRENT_REAL_INSTALL;NOT_A_HISTORICAL_NPM_INSTALL',
        'acceptanceGranted':False,'releaseStatus':'NO_GO'}
    (OUT/('release'+release+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'release':release,'exit':exit_code,'timeout':timeout,'cleanAfter':True,'terminalResult':terminal}),flush=True)
    return receipt

def worker(label,pins):
    root=OUT/label
    assert not root.exists()
    git(OUT,'clone','--no-checkout','--single-branch','--branch','stage/m1-first-value-recovery26','--no-hardlinks','https://github.com/TasfiqJ/onSkin.git',str(root))
    assert git(root,'rev-parse','--is-shallow-repository').strip()==b'false'
    assert (root/'.git').is_dir() and not (root/'.git/objects/info/alternates').exists()
    for path in (root/'.git/objects').rglob('*'):
        info=path.lstat()
        assert not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024
        if stat.S_ISREG(info.st_mode):assert info.st_nlink==1
    git(root,'fsck','--full','--strict','--no-reflogs','--no-dangling')
    materialized=[]
    for row in NATIVE:
        body=(RUN/'source'/row['path']).read_bytes()
        assert len(body)==row['bytes'] and sha(body)==row['sha256']
        target=root/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream:stream.write(body)
        materialized.append({'path':row['path'],'bytes':len(body),'sha256':sha(body)})
    provenance={'group':label,'complete':True,'separateObjectStore':True,'noAlternates':True,'fullFsckExit':0,
        'source':'FRESH_GITHUB_CLONE','nativeInputQualification':'AUTHENTICATED_NATIVE_SOURCE_PIN_FIXTURES_ONLY;NOT_FULL_NPM_INSTALL',
        'nativeInputs':materialized,'python':subprocess.check_output([PYTHON,'--version']).decode().strip(),
        'pythonSHA256':sha(Path(PYTHON).read_bytes())}
    (OUT/(label+'-provenance.json')).write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
    return [run_case(root,pin) for pin in pins]

def main():
    OUT.mkdir(exist_ok=False)
    pins=[p for p in PINS if 9<=int(p['release'])<=23]
    # The original semantic fixture checker identity is separately frozen in the
    # unchanged Release23 fixture authority and is not a current-head oracle.
    semantic={'release':'08-original151','source':'d08347f0011672cd309d835628c094b5e9f4725d',
        'tree':'0998881bc543840395dca375769ea1b7c9a8d4c7','script':'scripts/release/full-app-j01/test_contract.py',
        'scriptIdentity':{'sha256':'191f74631da86413c687801c7a620bbe01c0bd7d98c83f6bdd72947faf2ec455','bytes':9083,'mode':'100644','blob':'bccb30b28278a03a1d4d65e7d1f08f3fd79c1c67'},
        'checkerIdentity':{'sha256':'7118308899a2b6b89e98680697d486b85dacd9b9fad8702cdf39a54751f6b822','bytes':21598,'mode':'100644',
            'blob':git(RUN/'source','rev-parse','d08347f0011672cd309d835628c094b5e9f4725d:scripts/release/full-app-j01/check.py').decode().strip()}}
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(worker,'early',[semantic]+pins[:7]),pool.submit(worker,'late',pins[7:])]
        for future in concurrent.futures.as_completed(futures):results.extend(future.result())
    summary={'runs':sorted(results,key=lambda p:p['release']),'acceptanceGranted':False,'release':'NO_GO'}
    (OUT/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'completed':len(results),'failed':sum(r['exit']!=0 for r in results),'release':'NO_GO'}),flush=True)

if __name__=='__main__':main()
