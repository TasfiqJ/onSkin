"""Build the new five-file checkpoint externally after the single worklist freeze."""
import sys
if sys.flags.optimize:
    raise SystemExit('ASSERTIONS_REQUIRED')
from pathlib import Path
import importlib.util, io, hashlib, json, stat, subprocess, zipfile

run=Path(__file__).resolve().parent
root=run/'source'
spec=importlib.util.spec_from_file_location('artifact27',run/'packaging/verify27.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
git=lambda *args:subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
encoded=lambda obj:(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
def zip_bytes(files):
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,raw in sorted(files.items()):
            entry=zipfile.ZipInfo(name,(2026,10,29,0,0,0));entry.create_system=3
            entry.external_attr=(stat.S_IFREG|0o644)<<16
            entry.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(entry,raw)
    return stream.getvalue()
def witness(raw):return dict(bytes=len(raw),sha256=sha(raw))
def collect_evidence():
    evidence={}
    def add(path,name):
        assert name not in evidence
        evidence[name]=v.read_regular(path)
    for path in run.iterdir():
        if path.is_file() and path.suffix in ('.json','.log','.py'):
            add(path,'evidence/local/'+path.name)
    for area in ('context','history-review','history-execution','archive-review','app-evidence'):
        for path in ((run/area).rglob('*') if area=='context' else (run/area).iterdir()):
            if path.is_file() and path.suffix in ('.json','.jsonl','.md','.log','.py','.ts','.mjs','.cjs'):
                if path.name in ('R27_02_INDEPENDENT_REVIEW.json','R27_02_EXECUTED_COVERAGE_SUPPLEMENT.json',
                    'core05-pr28.stdout.log','core05-pr29.stdout.log','core05-call-diagnosis.json',
                    'CORE05_DIAGNOSIS_UNAPPLIED.md','ARCHIVE_CORE_REVIEW.md'):continue
                add(path,'evidence/'+area+'/'+path.relative_to(run/area).as_posix())
    for path in (run/'app-evidence/verifier-review').iterdir():
        if path.is_file() and path.suffix in ('.json','.md','.log','.py'):
            add(path,'evidence/app-evidence/verifier-review/'+path.name)
    for path in (run/'ci-prefreeze').rglob('*'):
        if path.is_file() and path.suffix in ('.json','.jsonl','.md','.log','.tap','.py'):
            add(path,'evidence/ci-prefreeze/'+path.relative_to(run/'ci-prefreeze').as_posix())
    add(run.parent/'campaign27_bootstrap.py','evidence/bootstrap/campaign27_bootstrap.py')
    add(run/'packaging/PREFREEZE_GATE.json','evidence/packaging/PREFREEZE_GATE.json')
    screenshot=run/'archive-review/authenticated-payload/evidence/browser-evidence/final-source26-360x640-doubletext-remove.png'
    add(screenshot,'evidence/historical-browser/final-source26-360x640-doubletext-remove.png')
    return evidence

def main():
    assert not git('status','--porcelain=v1','--untracked-files=all')
    frozen=git('rev-parse','HEAD');runtime=git('rev-parse','HEAD^')
    assert runtime=='97bb8341e979e5eb38034419fd0e5a106b794d90'
    assert set(git('diff','--name-only',runtime,frozen).splitlines())==v.WORKLIST
    source=dict(base=v.BASE,baseTree=v.BASE_TREE,runtimeHead=runtime,runtimeTree=git('rev-parse',runtime+'^{tree}'),sourceHead=frozen,sourceTree=git('rev-parse',frozen+'^{tree}'))
    evidence=collect_evidence()
    selection=json.loads((run/'packaging/EVIDENCE_SELECTION.json').read_bytes())
    assert selection['qualification']=='EXACT_REVIEWED_TECHNICAL_EVIDENCE_INVENTORY_NOT_ACCEPTANCE'
    assert selection['files']=={name:witness(raw) for name,raw in sorted(evidence.items())}
    evidence['evidence/SEAL_PROVENANCE.json']=encoded(dict(source=source,planCommit=v.PLAN_COMMIT,planSHA256=v.PLAN_SHA256,
        checkpointVerifierSHA256=sha(v.read_regular(run/'packaging/verify27.py')),checkerSHA256=v.CHECKER_SHA256,
        qualification='PREFREEZE_EXECUTION_AND_WORKLIST_FREEZE_NOT_FINAL_HEAD_CI',acceptanceGranted=False,release='NO_GO'))
    evidence['evidence/CATALOG_AT_SEAL.json']=encoded({name:witness(raw) for name,raw in sorted(evidence.items())})
    payload=zip_bytes(evidence)
    report=(run/'packaging/REPORT_DRAFT.md').read_bytes()+b'\n## Source seal identities\n\n```json\n'+encoded(source)+b'```\n'
    readme=("# Campaign27 source checkpoint\n\nSUBMITTED_REVIEW_REQUIRED / NO_GO. Exactly five files. No acceptance granted.\n\n"
        "The external manifest/verifier anchors authenticate this checkpoint. It binds exact PR30, the immutable first-child plan, "
        "the substantive source and its sole two-worklist child. The future evidence-tail head and final-head CI are deliberately outside "
        "this seal to avoid circular hashes. Artifact-only VERIFIED is integrity only. Complete Git and unchanged Phase4/source checks "
        "require the separately supplied exact final head/tree and --execute-source-checks.\n\n"
        "Preserve all failed/skipped/NOT_RUN qualifications in REPORT.md and payload evidence. R27-02 remains OPEN_REQUIRED / UNAPPLIED; "
        "CORE-05 remains UNAPPLIED; browser/native and qualified external gates remain closed. USD0. NO MERGES.\n").encode()
    files={'README.md':readme,'REPORT.md':report,'payload.zip':payload,'verify27.py':v.read_regular(run/'packaging/verify27.py')}
    manifest=dict(schema=1,authority=v.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO',
        inputManifestSHA256=v.INPUT,source=source,files={name:witness(raw) for name,raw in sorted(files.items())},
        payload=dict(schema=1,qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',files={name:witness(raw) for name,raw in sorted(evidence.items())}))
    files['manifest.json']=encoded(manifest)
    target=run/'packaging/checkpoint';target.mkdir()
    for name,raw in files.items():
        with (target/name).open('xb') as stream:stream.write(raw)
    anchor=sha(files['manifest.json']);v.checkpoint(v.Directory(target),anchor)
    seal=dict(source=source,manifestSHA256=anchor,verifierSHA256=sha(files['verify27.py']),payloadFiles=len(evidence),
        files={name:witness(raw) for name,raw in sorted(files.items())},status='ARTIFACT_PREFLIGHT_PASS_NOT_FULL_SOURCE',acceptanceGranted=False,release='NO_GO')
    (run/'packaging/checkpoint-seal.json').write_bytes(encoded(seal))
    print(json.dumps(seal,sort_keys=True))
if __name__=='__main__':main()
