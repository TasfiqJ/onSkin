"""Bind observed prefreeze proof; this is not acceptance or final-head CI."""
import sys
if sys.flags.optimize: raise SystemExit('ASSERTIONS_REQUIRED')
from pathlib import Path
import hashlib,json,subprocess
run=Path(__file__).resolve().parent;root=run/'source'
head='97bb8341e979e5eb38034419fd0e5a106b794d90'
prior='f20a58c09fefb9b9b15d10bc59119462ecdec386'
refs={}
def raw(name):
    body=(run/name).read_bytes()
    refs[name]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    return body.decode('utf-8-sig')
def obj(name):return json.loads(raw(name))
def last(name):return json.loads(raw(name).splitlines()[-1])
git=lambda *args:subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1','--untracked-files=all')
assert set(git('diff','--name-only',prior,head).splitlines())=={
    'scripts/release/full-app-j01/check.py','scripts/release/full-app-j01/replay27.test.py',
    'scripts/release/full-app-j01/source_consumer27.test.py'}
source=last('current-source27-diagnostic-addendum.log')
assert source['valid'] is True and source['acceptanceGranted'] is False and not any(source['admissions'].values())
assert source['source27']['checkoutHead']==head and source['source27']['trackedWorkingBlobsHashedLocally']==23519
consumer=last('consumer27-diagnostic-addendum.log')
assert consumer['status']=='PASS' and (consumer['positiveControls'],consumer['refusals'],consumer['inheritedFunctions'])==(26,198,189)
for name,counts in [('reader27-diagnostic-addendum-312.log',(32,10,2)),('reader27-diagnostic-addendum-39.log',(30,10,2))]:
    value=last(name)
    assert value['status']=='PASS' and tuple(value[k] for k in ('positiveControls','refusals','notRun'))==counts
local=obj('LOCAL_VALIDATION.json')
assert local['sourceHead']==prior and local['sourceClean'] is True and local['acceptanceGranted'] is False
for row in local['records']:
    body=raw(row['log']).encode('utf-8')
    original=(run/row['log']).read_bytes()
    assert len(original)==row['logBytes'] and hashlib.sha256(original).hexdigest()==row['logSHA256']
history=obj('history-execution/SUMMARY.json')
assert len(history['runs'])==16 and all(row['exit']==0 and row['timeout'] is False for row in history['runs'])
replay=obj('archive-review/local-replay27-authenticated.runner-receipt.json')
assert replay['status']=='PASS' and replay['context']['head']==prior and len(replay['records'])==3
platforms={}
for platform,folder in [('linux','public-ci-verified-q8gi044z'),('windows','public-ci-verified-1b137a1f')]:
    prefix='ci-prefreeze/'+folder+'/'
    public=obj(prefix+'security22-public.json');historical=obj(prefix+'security27-historical-receipt.json')
    assert public['source']['head']==prior and public['executionComplete'] is True and public['candidateReady'] is False
    assert historical['status']=='PASS' and historical['context']['head']==prior
    platforms[platform]=dict(sourceHead=prior,historicalReplay='PASS',executionComplete=True,candidateReady=False)
steps=obj('ci-prefreeze/diagnostic-addendum/READER_STEPS_COMPLETE_LOGS_PENDING.json')
assert steps['sourceHead']==head and len(steps['jobs'])==2
assert all(len(job['readerSteps'])==3 and all(step['status']=='completed' and step['conclusion']=='success' for step in job['readerSteps']) for job in steps['jobs'])
prs={row['number']:row for row in obj('ci-prefreeze/live-pr-identities-before-freeze.json')}
for number,expected in [(29,'52a3d01ebb36a6845d0ac21935ad35520732633f'),(30,'8c02a02afd7f2e9775dcc512c800d4f71f733234'),(31,head)]:
    p=prs[number]
    assert p['head']==expected and p['draft'] is True and p['merged'] is False and p['state']=='open'
assert prs[31]['maintainerCanModify'] is False and prs[31]['autoMerge'] is None
review=obj('app-evidence/verifier-review/results.json')
assert len(review['results'])==46 and all(row['passed'] is True for row in review['results'])
assert review['verifierSHA256']==hashlib.sha256((run/'packaging/verify27.py').read_bytes()).hexdigest()
gate=dict(schema=1,sourceHead=head,sourceTree=git('rev-parse','HEAD^{tree}'),readyForWorklistFreeze=True,
    qualification='COMPLETED_SUBSTANTIVE_TESTS_WITH_EXPLICIT_PRIOR_HEAD_AND_PENDING_FINAL_HEAD_PROOF_NOT_ACCEPTANCE',
    acceptanceGranted=False,release='NO_GO',sourceClean=True,addendumChangedPaths=3,
    unchangedApplicationRuntimeAndWorkflowSince=prior,currentConsumer=consumer,
    completedPriorHeadPlatforms=platforms,currentHostedReaderSteps='SUCCESS_BOTH_PLATFORMS_AND_PYTHONS',
    currentHostedFieldDiagnostics='PENDING_LOG_EXPORT',currentFullCI='IN_PROGRESS_NOT_CLAIMED_PASS',
    finalHeadCI='NOT_RUN',finalHeadClones='NOT_RUN',R27_02='OPEN_REQUIRED_UNAPPLIED',R27_03='UNAPPLIED',
    browser='NOT_RUN',protectedGates='CLOSED',evidence=refs)
output=run/'packaging/PREFREEZE_GATE.json'
with output.open('x',encoding='utf-8') as stream:json.dump(gate,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(dict(sourceHead=head,readyForWorklistFreeze=True,acceptanceGranted=False,release='NO_GO',evidence=len(refs))))
