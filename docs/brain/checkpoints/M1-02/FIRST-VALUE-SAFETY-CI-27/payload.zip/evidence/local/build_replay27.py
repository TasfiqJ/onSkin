from pathlib import Path
import re

root=Path(__file__).parent/'source'
old=(root/'scripts/release/full-app-j01/source_consumer26.test.py').read_text(encoding='utf-8')
body=old[:old.index('\ndef main():')]
body=body.replace('26','27')
body=body.replace('"""Release27 refusal controls. Synthetic controls remain separate from authenticated full-checkout historical replay."""',
    '"""Release27 independent historical runner. Original Release24/25/26 scripts are never modified."""')
# Literal hashes/commits contain 26 too; reconstruct the header from original,
# replacing identifiers only, never hexadecimal identities.
body=old[:old.index('\ndef main():')]
body=re.sub(r'\b([A-Za-z_][A-Za-z_0-9]*)26([A-Za-z_0-9]*)\b',lambda m:m[0] if re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',m[0]) else m[1]+'27'+m[2],body)
body=body.replace('Release27 refusal controls. Synthetic controls remain separate from authenticated full-checkout historical replay.',
    'Release27 independent historical runner. Original Release24/25/26 scripts are never modified.')
body=body.replace('R26_', 'R27_').replace('release26-historical-', 'release27-historical-')
end=body.index('\nLOCK27_SHA256=')
body=body[:end].rstrip().removesuffix(')')+'''    dict(release=26,head='8c02a02afd7f2e9775dcc512c800d4f71f733234',tree='ff0f76d11fa7775e27732f54ce7fdfbd51c8c676',
        branch='stage/m1-first-value-recovery26',checkerSHA256='23b5e760944ee7c8163aee79a5132c1b329ec126b3e20f3c8e1fd96dab6807a3',
        checkerBlob='d7dd3c559572fbcdaa5ce42e3a7d70bcfe046c5d',consumerSHA256='8429fbd1f200b6d63064d524675c81d021f77228cfb232e8168df49ea88ff678',
        consumerBlob='4562a277aceade31a0e52aef560e0eaa58dbd293',positiveControls=26,refusals=198,
        qualification='SYNTHETIC_GIT_AND_SCHEMA_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_APP_PRIVACY_PROOF'),
)
'''+body[end:]
start=body.index('def bytes27(');end=body.index('\ndef tool27(',start)
body=body[:start]+'''def same27(left, right):
    fields = tuple(name for name in dir(left) if name.startswith('st_') and name not in ('st_atime', 'st_atime_ns'))
    return fields == tuple(name for name in dir(right) if name.startswith('st_') and name not in ('st_atime', 'st_atime_ns')) and all(
        getattr(left, name) == getattr(right, name) for name in fields)


def cross27(path, named, opened):
    fields = ('st_dev', 'st_ino', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_uid', 'st_gid')
    if not all(getattr(named, field) == getattr(opened, field) for field in fields): return False
    if os.name != 'nt': return named.st_mode == opened.st_mode and named.st_ctime_ns == opened.st_ctime_ns
    # Windows infers pathname execute bits from suffix; a descriptor has no suffix.
    execute = 0o111 if Path(path).suffix.lower() in ('.exe', '.com', '.bat', '.cmd') else 0
    if opened.st_mode & 0o111 or named.st_mode != opened.st_mode | execute: return False
    for field in ('st_file_attributes', 'st_reparse_tag'):
        if hasattr(named, field) != hasattr(opened, field): return False
        if hasattr(named, field) and getattr(named, field) != getattr(opened, field): return False
    if hasattr(named, 'st_birthtime_ns') != hasattr(opened, 'st_birthtime_ns'): return False
    field = 'st_birthtime_ns' if hasattr(named, 'st_birthtime_ns') else 'st_ctime_ns'
    return getattr(named, field) == getattr(opened, field)


def regular27(info, bound):
    require27(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0) & 1024 and
        not info.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX) and 0 <= info.st_size <= bound, 'R27_REPLAY_REGULAR')


def bytes27(path, bound=128*1024*1024):
    path = Path(os.path.abspath(path))
    parents = {}
    for parent in path.parents:
        info = parent.lstat()
        require27(stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024, 'R27_REPLAY_PARENT')
        parents[parent] = (info.st_dev, info.st_ino, info.st_mode)
    before = path.lstat(); regular27(before, bound)
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    try:
        opened = os.fstat(descriptor); regular27(opened, bound)
        require27(cross27(path, before, opened), 'R27_REPLAY_CROSS_IDENTITY')
        blocks = []; total = 0
        while True:
            block = os.read(descriptor, min(1024*1024, before.st_size-total+1))
            if not block: break
            total += len(block)
            require27(total <= before.st_size, 'R27_REPLAY_READ_SIZE')
            blocks.append(block)
        finished = os.fstat(descriptor); regular27(finished, bound)
        after = path.lstat(); regular27(after, bound)
        require27(total == before.st_size and same27(opened, finished) and same27(before, after) and
            cross27(path, after, finished), 'R27_REPLAY_CHANGED')
    finally: os.close(descriptor)
    for parent, expected in parents.items():
        info = parent.lstat()
        require27((info.st_dev, info.st_ino, info.st_mode) == expected and not getattr(info, 'st_file_attributes', 0) & 1024,
            'R27_REPLAY_PARENT')
    return b''.join(blocks)

''' + body[end:]
# Executable bytes use the same bounded, identity-preserving reader.
start=body.index('def tool27(');end=body.index('\ndef tools27(',start)
body=body[:start]+'''def tool27(path):
    raw=bytes27(Path(path).resolve(strict=True),128*1024*1024)
    return dict(executableSHA256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))

'''+body[end:]
# The separate runner is authenticated by the Release27 successor, not by the
# consumer's identity and not by changing any original test module's globals.
body=body.replace("source/'scripts/release/full-app-j01/source_consumer27.test.py'", "source/'scripts/release/full-app-j01/replay27.py'")
body=body.replace('check.RELEASE27_CONSUMER_SHA256', 'check.RELEASE27_REPLAY_SHA256')
body=body.replace('len(records)==2', 'len(records)==3')
body=body.replace("currentConsumerSHA256=", "currentReplaySHA256=")
body=body.replace("    if os.environ.get('GITHUB_ACTIONS')=='true':require27(proof['phase']=='TAIL','R27_REPLAY_FINAL_SOURCE_REQUIRED')", "    require27(proof['phase'] in ('SOURCE','FROZEN','TAIL'),'R27_REPLAY_SOURCE_PHASE')")
body=body.replace("context=dict(head=proof['endpoint'],tree=proof['tree'],runId=", "context=dict(head=proof['endpoint'],tree=proof['tree'],sourcePhase=proof['phase'],runId=")
body=body.replace("not any((root/'apps').glob('*/node_modules'))", "not any(p.exists() for area in ('apps','packages') for p in (root/area).glob('*/node_modules'))")
body=body.replace("        tree=check.tree27('HEAD');", """        ignored=check.git23('ls-files','--others','--ignored','--exclude-standard','--directory','--no-empty-directory','-z').decode('utf-8').split('\\0')
        identities={}
        for path in ignored:
            if not path:continue
            check.name27(path.rstrip('/'),identities)
            require27(re.fullmatch(r'(?:node_modules/|(?:apps|packages)/[^/]+/node_modules/|'
                r'\\.turbo/|(?:apps|packages)/[^/]+/\\.turbo/|\\.expo/|apps/mobile/\\.expo/|\\.tmp/|'
                r'apps/mobile/(?:ios|android)/|apps/mobile/expo-env\\.d\\.ts|'
                r'(?:[^/]+|(?:apps|packages)/[^/]+/[^/]+)\\.tsbuildinfo)',path) is not None,'R27_REPLAY_IGNORED_SOURCE')
        tree=check.tree27('HEAD');""")
body=body.replace('    proof=check.source27_guard()', '''    proof=check.source27_guard()
    require27(not check.git23('status','--porcelain=v1','--untracked-files=all','-z'),'R27_REPLAY_CURRENT_DIRTY')
    check.working27_guard(check.tree27('HEAD'))''')
body=body.replace("    require27(check.source27_guard()==proof and tools27(source)==tools,'R27_REPLAY_CURRENT_SOURCE_CHANGED')", """    require27(check.source27_guard()==proof and tools27(source)==tools and
        not check.git23('status','--porcelain=v1','--untracked-files=all','-z'),'R27_REPLAY_CURRENT_SOURCE_CHANGED')
    check.working27_guard(check.tree27('HEAD'))""")
# Preserve existing whole-checkout reconciliation, and add this reader for every
# tracked file so a same-domain mode change cannot be normalized away.
body=body.replace("count=check.working27_guard(index)", """count=check.working27_guard(index)
        for path, (mode, oid) in index.items():
            data=bytes27(root/path)
            require27(hashlib.sha1(('blob '+str(len(data))+'\\0').encode()+data).hexdigest()==oid,'R27_REPLAY_BLOB')
            if os.name!='nt':require27(bool((root/path).lstat().st_mode&0o111)==(mode=='100755'),'R27_REPLAY_MODE')""")
body += '''
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--receipt',type=Path,required=True)
    args=parser.parse_args()
    source=Path(__file__).resolve().parents[3]
    actual=source/'scripts/release/full-app-j01/check.py'
    namespace={'__name__':'release27_runner','__file__':str(actual)}
    exec(compile(bytes27(actual),str(actual),'exec'),namespace)
    class Module: pass
    check=Module();check.__dict__=namespace
    replay27(source,check,args.receipt)


if __name__=='__main__':
    try:
        main()
    except Exception as error:
        code=error.args[0] if type(error) is ValueError and len(error.args)==1 else None
        # Never report arbitrary exception data, source paths or subprocess logs.
        allowed=set(re.findall(r"['\\\"](R27_[A-Z_]+)['\\\"]",Path(__file__).read_text(encoding='utf-8')))
        print(json.dumps(dict(status='REFUSED',code=code if type(code) is str and code in allowed else 'R27_REPLAY_INCOMPLETE',
            acceptanceGranted=False,release='NO_GO')),flush=True)
        raise SystemExit(1) from None
'''
codes=tuple(sorted(set(re.findall(r"['\"](R27_[A-Z_]+)['\"]",body))))
body='\n'.join('        allowed='+repr(codes) if line.strip().startswith('allowed=set(re.findall') else line for line in body.split('\n'))
target=root/'scripts/release/full-app-j01/replay27.py'
target.write_bytes(body.encode('utf-8'))
compile(body,str(target),'exec')
print('replay27 written and syntax checked')
