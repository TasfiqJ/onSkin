"""Record the already reviewed external verifier's actual directory CLI control."""
import sys
if sys.flags.optimize: raise SystemExit('ASSERTIONS_REQUIRED')
from pathlib import Path
import hashlib,json,subprocess
run=Path(__file__).resolve().parent
area=run/'app-evidence/verifier-review'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
verifier=run/'packaging/verify27.py'
review=json.loads((area/'results.json').read_bytes())
assert review['verifierSHA256']==sha(verifier.read_bytes()) and len(review['results'])==46
assert all(row['passed'] is True for row in review['results'])
fixtures=[p for p in area.glob('unchanged_directory-*') if (p/'verify27.py').read_bytes()==verifier.read_bytes()]
assert fixtures
fixture=max(fixtures,key=lambda p:p.stat().st_mtime_ns)
argv=[sys.executable,'-I','-B',str(verifier),'--root',str(fixture),
    '--expected-manifest-sha256',sha((fixture/'manifest.json').read_bytes()),
    '--expected-verifier-sha256',sha(verifier.read_bytes())]
child=subprocess.run(argv,capture_output=True,timeout=60)
assert child.returncode==0 and not child.stderr
result=json.loads(child.stdout)
assert result['status']=='VERIFIED' and result['sourceChecks']['state']=='NOT_RUN' and result['acceptanceGranted'] is False
receipt=dict(argv=argv,exit=child.returncode,result=result,reviewedControls=46,
    qualification='ACTUAL_ARTIFACT_ONLY_CLI_NOT_FINAL_SOURCE_VERIFICATION',acceptanceGranted=False,release='NO_GO')
(area/'directory-cli-addendum-results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status='PASS',controls=46,artifactCLIExit=0,sourceChecks='NOT_RUN')))
