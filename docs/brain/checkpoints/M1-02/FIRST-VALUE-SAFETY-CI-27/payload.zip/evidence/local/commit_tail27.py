"""Commit exactly the five checkpoint files and the root handoff after sealing."""
import sys
if sys.flags.optimize: raise SystemExit('ASSERTIONS_REQUIRED')
from pathlib import Path
import hashlib,json,subprocess
from build_checkpoint27 import v,encoded
run=Path(__file__).resolve().parent;root=run/'source'
git=lambda *args:subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
seal=json.loads((run/'packaging/checkpoint-seal.json').read_bytes())
frozen='82a8ffbeab2c740a75b96fabdd7ddf4016e122c9'
assert git('rev-parse','HEAD')==frozen==seal['source']['sourceHead']
assert not git('status','--porcelain=v1','--untracked-files=all')
v.checkpoint(v.Directory(run/'packaging/checkpoint'),seal['manifestSHA256'])
assert v.sha(v.read_regular(run/'packaging/checkpoint/verify27.py'))==seal['verifierSHA256']
target=root/v.CHECKPOINT
assert not target.exists()
target.mkdir()
paths=[]
for name in sorted(v.CHECKPOINT_FILES):
    raw=v.read_regular(run/'packaging/checkpoint'/name)
    with (target/name).open('xb') as stream:stream.write(raw)
    paths.append(v.CHECKPOINT+name)
handoff=f'''CAMPAIGN27 - SUBMITTED_REVIEW_REQUIRED / NO_GO
Authority: BRAIN-M1X-POSTDISPATCH-SAFETY-CI27-CANDIDATE-01
Independent Brain retains ordinary source acceptance; qualified owners retain
Security, database, native, clinical/legal/Apple and release gates. USD0. NO MERGES.

One new open draft PR31: https://github.com/TasfiqJ/onSkin/pull/31
Branch stage/m1-first-value-safety-ci27, stacked on stage/m1-first-value-recovery26.
Auto-merge OFF; maintainer modification OFF. Prior PRs and commits unchanged.
Pinned PR30: {v.BASE}
Pinned PR30 tree: {v.BASE_TREE}
Pinned PR29: 52a3d01ebb36a6845d0ac21935ad35520732633f
Pinned PR29 tree: ef49a81ca814f3d82b8a868e0308b6dda09c9cca
External context manifest: {v.INPUT}
Original ZIP: 42150 bytes; SHA256
2c5443fb399830bf2f971c4f7457258134e3df2669cff8930759ed065d830338
Original authenticated verifier exit0 / VERIFIED14 / identical directives.
Context integrity is not source or release acceptance.

Immutable first-child plan: {v.PLAN_COMMIT}
Plan SHA256: {v.PLAN_SHA256}
Frozen substantive head: {seal['source']['runtimeHead']}
Substantive tree: {seal['source']['runtimeTree']}
Sole worklist child: {frozen}
Worklist tree: {seal['source']['sourceTree']}
Unchanged original Phase4 producer executed once from clean committed source,
exit0; only the two generated worklists changed in that child.
This handoff plus exactly five checkpoint files forms the sole evidence tail.
No subsequent source change or second evidence tail is authorized by this seal.

Checkpoint: {v.CHECKPOINT}
Checkpoint manifest SHA256: {seal['manifestSHA256']}
Checkpoint verifier SHA256: {seal['verifierSHA256']}
Checkpoint payload SHA256: {seal['files']['payload.zip']['sha256']}
Standalone checkpoint preflight passed; full final-head source checks NOT_RUN
at seal. Final head/tree, complete CI, two independent final clones and actual
source/artifact 0/1/0 proofs belong outside this seal to avoid circular hashes.
Generated GitHub PR test-merge objects are separate from source commits and
are not actual merged PRs. The final return records each observed identity.

R27-01: new independently pinned Windows-safe historical reader and runner;
original24/25/26 bytes unchanged, actual complete fresh historical installs.
Local and hosted f20 replay passed all originals. New97bb consumer26positive/
198refusals and189 original function ASTs; current source check exit0 with
23519 raw tracked blobs. Both hosted/3.12 reader steps passed on both platforms;
field-level logs were PENDING_LOG_EXPORT at seal. Final-head proof remains pending.
Original sealed Windows26 launcher failure remains an immutable observation.
Original151 semantic negatives and authentic09-23 consumers passed with their
fixture/install qualifications. App validation at f20:6370 mobile,24 operator,
forced zero-cache lint/typecheck/tests, F09 layout15+focused97, both clear-cache
unsigned exports. Application/runtime/workflow bytes unchanged through97bb.

R27-02 OPEN_REQUIRED / UNAPPLIED: stronger pending Remove cancellation still
fails after Query replacement or unmount. Existing privateKV guard can cancel
until logical operation success with compensation, but may restore already
adapter-visible bytes. The allowed Shelf callback lacks a precise native
commit boundary. No app fence or protected storage change was shipped.
R27-03 UNAPPLIED: original CORE05 exact-string suite35PASS/1FAIL at PR28/29;
specific structural-test proposal remains outside scope. SQL evidence is separate.
New viewport/keyboard/focus/scroll measures NOT_RUN: browser control unavailable.
Authenticated historical screenshot and mounted tests are not device/VoiceOver proof.

Canonical DB and actual PG15/17 mechanics passed on the earlier f20 PR test
merge, with reset/SQL/RLS/lint/empty drift/type parity qualifications. Local
Docker unavailable. Pre-freeze Quality failed stale worklists and skipped its
later app checks; final-head Quality is not assumed. Public components completed
on Linux/Windows and remained nonready/nonzero for findings/custody gaps.
The independently downloaded Campaign26 binary passed its full original verifier.

G97 FAIL/NO_GO. DB06/DB08/R2B NOT_ACCEPTED. M1-03 BLOCKED_EXTERNAL_CUSTODY/
NOT_ACCEPTED. M2 NOT_AUTHORIZED. J01 optical G1/G2/G3/G5 and longitudinal G4
NOT_ACCEPTED. Native iPhone/VoiceOver, provider, paid, professional, clinical,
legal/licensing, Apple and public release CLOSED. Preserve genuine non-Korean
F01-F17/F19-F20, C01-C12, P01-P06, private F09 diary/manual compare and only
independently qualified J01 Visible Pores. F18 and J02-J27 including J05 deferred.
Full evidence and explicit remaining work are in REPORT.md and the final return.
Prior Campaign26 handoff remains immutable at PR30; it is historical context.
'''.encode()
(root/'ONSKIN_BRAIN_HANDOFF.txt').write_bytes(handoff);paths.append('ONSKIN_BRAIN_HANDOFF.txt')
expected=set(paths)
subprocess.run(['git','-C',str(root),'add','--',*paths],check=True,capture_output=True)
assert set(git('diff','--cached','--name-only').splitlines())==expected
assert not git('diff','--name-only') and not git('ls-files','--others','--exclude-standard')
subprocess.run(['git','-C',str(root),'commit','-m','docs(campaign27): seal checkpoint and independent-review handoff'],check=True,capture_output=True)
assert git('rev-parse','HEAD^')==frozen and not git('status','--porcelain=v1','--untracked-files=all')
assert set(git('diff','--name-only',frozen,'HEAD').splitlines())==expected
for path in paths:
    assert git('ls-tree','HEAD','--',path).startswith('100644 blob ')
    assert subprocess.check_output(['git','-C',str(root),'show','HEAD:'+path])==(root/path).read_bytes()
receipt=dict(status='COMMITTED_SOLE_SIX_PATH_EVIDENCE_TAIL',head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
    parent=frozen,paths=sorted(paths),checkpointManifestSHA256=seal['manifestSHA256'],checkpointVerifierSHA256=seal['verifierSHA256'],
    cleanAfter=True,acceptanceGranted=False,release='NO_GO',finalHeadCI='NOT_RUN',finalClones='NOT_RUN')
output=run/'final-verification';output.mkdir(exist_ok=True)
with (output/'TAIL_RECEIPT.json').open('xb') as stream:stream.write(encoded(receipt))
print(json.dumps(receipt,sort_keys=True))
