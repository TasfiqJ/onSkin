"""One-shot original-producer worklist freeze, after all substantive validation."""
import sys
if sys.flags.optimize:
    raise SystemExit('ASSERTIONS_REQUIRED')
from pathlib import Path
import hashlib,json,os,subprocess,time

run=Path(__file__).resolve().parent;root=run/'source'
runtime='97bb8341e979e5eb38034419fd0e5a106b794d90'
base='8c02a02afd7f2e9775dcc512c800d4f71f733234'
paths=['docs/phase-4/generated/source-worklist.json','docs/phase-4/generated/source-worklist.md']
producer='scripts/phase4/build-source-worklist.mjs'
git=lambda *args:subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
encoded=lambda value:(json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def main():
    output=run/'WORKLIST_FREEZE_RECEIPT.json'
    assert not output.exists()
    assert git('rev-parse','HEAD')==runtime and not git('status','--porcelain=v1','--untracked-files=all')
    assert sha((root/'docs/brain/task-specs/M1X-27/SCOPE_PLAN.md').read_bytes())=='638e6c931b6effd6a8b93045c650c486d6be5e898a3c7214b673a0d996a8cc1f'
    original=subprocess.check_output(['git','-C',str(root),'show',base+':'+producer])
    assert (root/producer).read_bytes()==original
    gate=json.loads((run/'packaging/PREFREEZE_GATE.json').read_bytes())
    assert gate['sourceHead']==runtime and gate['readyForWorklistFreeze'] is True and gate['acceptanceGranted'] is False
    node=run.parent/'campaign26-run-1b46eb3809914b21a97234dcffb185dc/security26-tools/node.exe'
    environment={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','NPM_','PYTHON','GITHUB_','PHASE4_'))
        and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
    environment['PATH']=str(node.parent)+os.pathsep+environment['PATH']
    receipt=dict(sourceHead=runtime,sourceTree=git('rev-parse','HEAD^{tree}'),producer=producer,producerSHA256=sha(original),
        invocation=[str(node),producer,'--strict'],nodeSHA256=sha(node.read_bytes()),producerInvocations=1,
        environmentQualification='TASK_OVERRIDES_AND_TOOL_INJECTION_VARIABLES_REMOVED',cleanBefore=True,acceptanceGranted=False,release='NO_GO',status='STARTED')
    with output.open('xb') as stream:stream.write(encoded(receipt))
    started=time.monotonic()
    try:
        child=subprocess.run(receipt['invocation'],cwd=root,capture_output=True,timeout=300,env=environment)
    except (subprocess.TimeoutExpired,OSError) as error:
        receipt.update(status='FAILED_OR_INCOMPLETE',failureCategory='PRODUCER_TIMEOUT' if isinstance(error,subprocess.TimeoutExpired) else 'PRODUCER_EXECUTION_FAILURE')
        output.write_bytes(encoded(receipt));raise RuntimeError(receipt['failureCategory']) from None
    (run/'phase4-producer27.stdout.log').write_bytes(child.stdout)
    (run/'phase4-producer27.stderr.log').write_bytes(child.stderr)
    receipt.update(producerExit=child.returncode,elapsedSeconds=round(time.monotonic()-started,3),stdoutSHA256=sha(child.stdout),stderrSHA256=sha(child.stderr))
    output.write_bytes(encoded(receipt))
    assert child.returncode==0
    assert set(git('diff','--name-only').splitlines())==set(paths)
    assert not git('diff','--cached','--name-only') and not git('ls-files','--others','--exclude-standard')
    receipt['worklists']={p:dict(bytes=len((root/p).read_bytes()),sha256=sha((root/p).read_bytes())) for p in paths}
    subprocess.run(['git','-C',str(root),'add','--',*paths],check=True,capture_output=True)
    assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
    subprocess.run(['git','-C',str(root),'commit','-m','docs(campaign27): freeze original Phase4 worklists'],check=True,capture_output=True)
    assert git('rev-parse','HEAD^')==runtime and not git('status','--porcelain=v1','--untracked-files=all')
    assert set(git('diff','--name-only',runtime,'HEAD').splitlines())==set(paths)
    for path in paths:
        committed=subprocess.check_output(['git','-C',str(root),'show','HEAD:'+path])
        assert committed==(root/path).read_bytes() and sha(committed)==receipt['worklists'][path]['sha256']
        assert git('ls-tree','HEAD','--',path).startswith('100644 blob ')
    receipt.update(status='COMMITTED_SOLE_WORKLIST_CHILD',sourceHead=git('rev-parse','HEAD'),sourceTree=git('rev-parse','HEAD^{tree}'),
        runtimeHead=runtime,runtimeTree=git('rev-parse',runtime+'^{tree}'),changedPaths=paths,cleanAfter=True)
    output.write_bytes(encoded(receipt));print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__':
    try:main()
    except BaseException:
        output=run/'WORKLIST_FREEZE_RECEIPT.json'
        if output.exists():
            receipt=json.loads(output.read_bytes())
            if receipt.get('status')!='COMMITTED_SOLE_WORKLIST_CHILD':
                receipt.update(status='FAILED_OR_INCOMPLETE',failureCategory=receipt.get('failureCategory','FREEZE_INCOMPLETE'))
                output.write_bytes(encoded(receipt))
        raise
