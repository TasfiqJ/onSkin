"""Stage the hosted field diagnostic externally while the current replay finishes."""
from pathlib import Path
import hashlib

run=Path(__file__).resolve().parent
target=run/'source/scripts/release/full-app-j01/replay27.test.py'
raw=target.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8c9e835888578590d721ba015396112518477e7b6d109020b08b1c66f5f2997d'
source=raw.decode().replace('import hashlib\n','import ast\nimport hashlib\n',1).replace('import tempfile\n','import tempfile\nimport subprocess\nimport time\n',1)
diagnostic=r'''
def original_reader_domain27(target, expected):
    # Only these two unchanged helper ASTs execute. The original consumer/main
    # is never invoked here; full pinned consumer execution is a separate job.
    pin = replay.PINNED27[2]
    script = 'scripts/release/full-app-j01/source_consumer26.test.py'
    root = Path(replay.__file__).resolve().parents[3]
    def git(*args):
        child = subprocess.run(['git', '--no-replace-objects', *args], cwd=root, capture_output=True, timeout=30)
        assert child.returncode == 0 and len(child.stdout) <= 1024*1024
        return child.stdout
    raw = git('show', pin['head']+':'+script)
    proof = {'helper_only_not_consumer': True,
        'helper_sha256_match': hashlib.sha256(raw).hexdigest() == pin['consumerSHA256'],
        'helper_git_blob_match': hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest() == pin['consumerBlob'],
        'helper_git_mode_match': git('ls-tree', pin['head'], '--', script).decode().strip() == '100644 blob '+pin['consumerBlob']+'\t'+script,
        'helper_pinned_tree_match': git('rev-parse', pin['head']+'^{tree}').decode().strip() == pin['tree']}
    assert all(proof.values())
    nodes = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef) and node.name in ('require26', 'bytes26')]
    assert len(nodes) == 2 and {node.name for node in nodes} == {'require26', 'bytes26'} and all(not node.decorator_list for node in nodes)
    namespace = dict(Path=Path, os=os, stat=stat)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<authenticated-original-reader-helpers>', 'exec'), namespace)
    proof['unchanged_original_helper_asts'] = True
    # Finish all setup before measurement. This leaves bytes unchanged and gives
    # Windows creation/change metadata an opportunity to represent distinct times.
    setup = target.lstat(); time.sleep(0.02)
    os.utime(target, ns=(setup.st_atime_ns, setup.st_mtime_ns+1000000))
    before = target.lstat()
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_birthtime_ns')
    with target.open('rb') as stream:
        opened = os.fstat(stream.fileno())
        observed = stream.read(len(expected)+1)
        read_finished = os.fstat(stream.fileno())
        after_read = target.lstat()
        original_returned = original_refused = False
        try:
            original_returned = namespace['bytes26'](target) == expected
        except ValueError as error:
            assert error.args == ('R26_REPLAY_CHANGED',)
            original_refused = True
        current_returned = replay.bytes27(target) == expected
        finished = os.fstat(stream.fileno())
        after = target.lstat()
    assert replay.same27(before, after_read) and replay.same27(before, after)
    assert replay.same27(opened, read_finished) and replay.same27(opened, finished)
    assert observed == expected and current_returned and replay.bytes27(target) == expected
    assert replay.same27(after, target.lstat())
    for field in fields:
        available = all(hasattr(info, field) for info in (before, after, opened, finished))
        proof[field+'_available'] = available
        proof['path_before_after_'+field+'_equal'] = available and getattr(before, field) == getattr(after, field)
        proof['handle_before_after_'+field+'_equal'] = available and getattr(opened, field) == getattr(finished, field)
        proof['path_handle_before_'+field+'_equal'] = available and getattr(before, field) == getattr(opened, field)
        proof['path_handle_after_'+field+'_equal'] = available and getattr(after, field) == getattr(finished, field)
    proof['regular_type_equal'] = stat.S_ISREG(before.st_mode) and stat.S_ISREG(opened.st_mode)
    proof['execute_bits_equal'] = before.st_mode & 0o111 == opened.st_mode & 0o111
    proof['nonexecute_mode_equal'] = before.st_mode & ~0o111 == opened.st_mode & ~0o111
    stamp_fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    compatible = all(getattr(before, field) == getattr(opened, field) == getattr(finished, field) == getattr(after, field) for field in stamp_fields)
    assert original_returned == compatible and original_refused == (not compatible)
    proof.update(original_stamp_compatible=compatible, original_helper_returned_expected_bytes=original_returned,
        original_helper_refused_R26_REPLAY_CHANGED=original_refused, current_reader_returned_expected_bytes=current_returned,
        fixture_bytes_unchanged=True, path_metadata_stable_excluding_only_atime=True, handle_metadata_stable_excluding_only_atime=True)
    assert all(type(value) is bool for value in proof.values())
    print(json.dumps(proof, sort_keys=True), flush=True)


'''
# The staged text must contain real Python escapes for the unchanged Git header.
diagnostic=diagnostic.replace("+'\\\\0'", "+'\\0'").replace("+'\\\\t'", "+'\\t'")
source=source.replace('\ndef main():\n','\n'+diagnostic+'def main():\n',1)
source=source.replace("        case('unchanged-real-filesystem',equal_read)\n", "        case('unchanged-real-filesystem',equal_read)\n        case('authenticated-original-helper-domain-observation',lambda:original_reader_domain27(target,original))\n",1)
compile(source,str(target),'exec')
staged=run/'packaging/replay27.test.next.py';staged.write_bytes(source.encode())
print(hashlib.sha256(staged.read_bytes()).hexdigest())
