"""Prepare new artifact verifier outside source; no checkpoint before freeze."""
from pathlib import Path
import ast, hashlib, json, re

run=Path(__file__).parent;root=run/'source'
source=(root/'docs/brain/checkpoints/M1-02/FIRST-VALUE-RECOVERY-26/verify26.py').read_text(encoding='utf-8')
plan=(root/'docs/brain/task-specs/M1X-27/SCOPE_PLAN.md').read_bytes()
grant=json.loads(re.search(rb'```json\n(.*?)\n```',plan,re.S)[1])
sha=lambda body:hashlib.sha256(body).hexdigest()
updates=dict(AUTHORITY=grant['authority'],INPUT='cb1e3106f40b2a81872bdfc0c4f2642a0700d113bbb0a43fd33e8da09fe0d2b0',
    BASE=grant['baseHead'],BASE_TREE=grant['baseTree'],CHECKPOINT='docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27/',
    CHECKPOINT_FILES={'README.md','REPORT.md','manifest.json','payload.zip','verify27.py'},
    EXISTING=set(grant['existingAppPaths']+grant['otherExistingPaths']),NEW=set(grant['newAppTestHelperPaths']+grant['otherNewPaths']),
    PLAN='docs/brain/task-specs/M1X-27/SCOPE_PLAN.md',PLAN_COMMIT='b26c229aa140910ac34e1217f7bdad118c191e7f',
    PLAN_SHA256=sha(plan),CHECKER_SHA256=sha((root/'scripts/release/full-app-j01/check.py').read_bytes()))
for key,value in updates.items():
    representation='{'+', '.join(repr(item) for item in sorted(value))+'}' if type(value) is set else repr(value)
    source=re.sub(r'(?m)^'+key+r' = .*$',lambda _:key+' = '+representation,source)
source=source.replace('Campaign26','Campaign27').replace('verify_return26.py','verify_return27.py').replace('verify26.py','verify27.py')
source=source.replace('verify-return26-','verify-return27-').replace('stage/m1-first-value-recovery26','stage/m1-first-value-safety-ci27')
source=source.replace('EXACT_PR29_DELTA_OBJECTS','EXACT_PR30_DELTA_OBJECTS').replace('RELEASE26_','RELEASE27_').replace("'source26'","'source27'").replace('dict(release26=', 'dict(release27=')
reader=(root/'scripts/release/full-app-j01/replay27.py').read_text(encoding='utf-8')
reader=reader[reader.index('def same27('):reader.index('def tool27(')]
reader=reader.replace('same27','stable_metadata').replace('cross27','cross_metadata').replace('regular27','regular_metadata')
reader=reader.replace('bytes27','read_regular').replace('require27','need').replace('bound=128*1024*1024','limit=MAX_FILE').replace('bound)', 'limit)')
# regular_metadata retains its own bound argument; only read_regular uses limit.
reader=reader.replace('def regular_metadata(info, limit):','def regular_metadata(info, bound):')
start=source.index('def read_regular(');end=source.index('\nclass Directory:',start)
source=source[:start]+reader+source[end:]
source=source.replace('        self.root = Path(os.path.abspath(root))\n', '        self.root = Path(os.path.abspath(root))\n        self.snapshot = None\n        self.reads = {}\n        self.expected = None\n', 1)
source=source.replace("        return read_regular(self.root.joinpath(*name.split('/')))\n", """        path = self.root.joinpath(*name.split('/'))
        before = path.lstat(); raw = read_regular(path); after = path.lstat()
        need(stable_metadata(before, after), 'ARTIFACT_CHANGED')
        witness = (after, sha(raw))
        if name in self.reads:
            old, digest = self.reads[name]
            need(stable_metadata(old, after) and digest == witness[1], 'ARTIFACT_CHANGED')
        self.reads[name] = witness
        return raw

    def seal(self):
        need(self.expected is not None, 'EXACT_INVENTORY_MISMATCH')
        self.exact(self.expected)
        for name in tuple(self.reads): self.read(name)
        self.exact(self.expected)
""", 1)
source=source.replace('        directories = paths(expected)\n', "        directories = paths(expected)\n        self.expected = set(expected)\n        observed = {}\n", 1)
source=source.replace('            parent = stack.pop()\n            with os.scandir(parent)', "            parent = stack.pop()\n            observed[parent] = node(parent, True)\n            with os.scandir(parent)", 1)
source=source.replace('                    info = path.lstat()\n                    if stat.S_ISDIR', '                    info = path.lstat()\n                    observed[path] = info\n                    if stat.S_ISDIR', 1)
source=source.replace("        need(actual == set(expected) and found_dirs == directories, 'EXACT_INVENTORY_MISMATCH')\n", """        need(actual == set(expected) and found_dirs == directories, 'EXACT_INVENTORY_MISMATCH')
        for path, info in observed.items():
            need(stable_metadata(info, path.lstat()), 'ARTIFACT_CHANGED')
        if self.snapshot is not None:
            need(set(observed) == set(self.snapshot) and all(stable_metadata(info, self.snapshot[path])
                 for path, info in observed.items()), 'ARTIFACT_CHANGED')
        self.snapshot = observed
""", 1)
source=source.replace('    return len(expected)\n', '    if isinstance(container, Directory): container.seal()\n    return len(expected)\n', 1)
source=source.replace('        print(json.dumps(result, sort_keys=True)); return 0', '        if isinstance(container, Directory): container.seal()\n        print(json.dumps(result, sort_keys=True)); return 0', 1)
source=source.replace("    requirements = [line[1:41].decode('ascii')", "    need(all(re.fullmatch(rb'-[0-9a-f]{40} [^\\r\\n]*', line) for line in lines if line.startswith(b'-')), 'RETURN_GIT_BUNDLE_HEADER')\n    requirements = [line[1:41].decode('ascii')", 1)
start=source.index('    def identity(info, comparable=False):',source.index('def hash_worktree'))
end=source.index('    for parent, expected in identities.items():',start)
source=source[:start]+'''    for name, (mode, oid) in tree.items():
        path=root/name;before=node(path)
        if os.name!='nt':need(bool(before.st_mode & 0o111)==(mode=='100755'),'GIT_WORKING_MODE')
        raw=read_regular(path)
        need(hashlib.sha1(('blob '+str(len(raw))+'\\0').encode()+raw).hexdigest()==oid,'GIT_WORKING_BLOB_MISMATCH')
'''+source[end:]
codes=sorted(set(re.findall(r"['\"](R27_[A-Z_]+)['\"]",source)))
source=source.replace("if __name__ == '__main__':\n    sys.exit(main())", 'PUBLIC_CODES = PUBLIC_CODES | frozenset('+repr(sorted(set(codes)|{'ARTIFACT_CHANGED'}))+ ")\n\nif __name__ == '__main__':\n    sys.exit(main())")
compile(source,'verify27.py','exec')
stage=run/'packaging';stage.mkdir(exist_ok=True)
(stage/'verify27.py').write_bytes(source.encode())
(stage/'verify_return27.py').write_bytes(source.replace("MODE = 'checkpoint'","MODE = 'return'",1).encode())
print(json.dumps(dict(checkpointVerifierSHA256=sha(source.encode()),checkerSHA256=updates['CHECKER_SHA256'])))
