"""Index already observed local command exits and exact task-owned evidence bytes."""
from pathlib import Path
import hashlib,json,subprocess
run=Path(__file__).resolve().parent;root=run/'source'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
assert head=='f20a58c09fefb9b9b15d10bc59119462ecdec386'
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain=v1','--untracked-files=all'])
cases=[
 ('authenticated-normal-install','npm-ci27-authenticated.log',0,'Actual npm11.20.0 CLI from validated standalone prefix; normal mandatory hooks; 1028 packages'),
 ('mandatory-patches','postinstall27-authenticated.log',0,'Original postinstall --check; native and tooling security patches checked'),
 ('full-forced-test','test27-authenticated-forced.log',0,'Direct installed turbo run test --force; mobile6370/496 files; operator24;2tasks/0cached'),
 ('forced-typecheck','typecheck27-authenticated-forced.log',0,'Direct installed turbo run typecheck --force;3tasks/0cached'),
 ('forced-lint','lint27-authenticated-forced.log',0,'Direct installed turbo run lint --force;3tasks/0cached;types package declares no lint'),
 ('cached-wrapper-attempt','full-tests27-authenticated.log',0,'Cached logs only;2cached;NOT a fresh test execution; superseded by direct forced test'),
 ('source27-clean-substantive','current-source27-prefreeze.log',0,'Actual exact-head local check;SOURCE phase permits finite pending;23519 raw tracked blobs reconciled'),
 ('reader27-windows312','reader27-final-python312.log',0,'Actual local Windows3.12.14;31positive/10refusal/2NOT_RUN;not historical execution'),
 ('f09-original-layout15-focused97','photo15-97-27.log',0,'112 original tests/9 files at unchanged app source'),
 ('advisory-patch-controls','advisory27.log',0,'16 synthetic behavior/patch controls;no advisory or Security acceptance'),
 ('launch-contracts','launch-contracts27.log',0,'Original launch/private-route/privacy contract chain;not native admission'),
 ('native-strict-readiness','native27.log',1,'Authentic native/readiness prerequisites missing;not waived'),
 ('unsigned-ios-export','export27-authenticated-ios.log',0,'Actual clear-cache Expo iOS export;development;unsigned;no device proof'),
 ('unsigned-android-export','export27-authenticated-android.log',0,'Actual clear-cache Expo Android export;development;unsigned;no device proof'),
 ('initial-local-historical-replay','historical27-local.log',1,'Refused R27_REPLAY_CHILD_FAILURE;independent default PATH tool identity NPM_TOOL_CHANGED;preserved'),
 ('original-context-verifier-repeat','bootstrap-original-verifier.log',0,'Original exact ASCII-option command;VERIFIED14files/triad;context only'),
]
records=[]
for label,name,exit_code,qualification in cases:
    raw=(run/name).read_bytes()
    records.append(dict(case=label,log=name,logBytes=len(raw),logSHA256=sha(raw),observedExit=exit_code,qualification=qualification))
exports={}
for platform in ('ios','android'):
    directory=run/('export27-authenticated-'+platform);files={}
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            raw=path.read_bytes();files[path.relative_to(directory).as_posix()]=dict(bytes=len(raw),sha256=sha(raw))
    assert files and 'metadata.json' in files
    exports[platform]=dict(files=files,qualification='UNSIGNED_CLEAR_CACHE_DEVELOPMENT_EXPORT_NOT_NATIVE_DEVICE_OR_RELEASE_ACCEPTANCE')
receipt=dict(schema=1,sourceHead=head,sourceTree=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD^{tree}']).decode().strip(),
    qualification='OBSERVED_EXECUTION_EXIT_AND_LOG_INDEX_NOT_INDEPENDENT_ACCEPTANCE',records=records,exports=exports,
    localDatabase='NOT_RUN_DOCKER_DAEMON_UNAVAILABLE',browser='NOT_RUN_LOCAL_BROWSER_USE_DISABLED_IN_WORK_SETTINGS',
    sourceClean=True,acceptanceGranted=False,release='NO_GO')
(run/'LOCAL_VALIDATION.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n',encoding='utf8')
print(json.dumps(dict(records=len(records),exportFiles={p:len(v['files']) for p,v in exports.items()},head=head)))
