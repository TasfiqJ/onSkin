"""Freeze the exact reviewed technical evidence inventory for checkpoint assembly."""
import sys
if sys.flags.optimize: raise SystemExit('ASSERTIONS_REQUIRED')
import json
from build_checkpoint27 import collect_evidence,run,v,witness,encoded
evidence=collect_evidence()
v.paths(evidence)
excluded={'R27_02_INDEPENDENT_REVIEW.json','R27_02_EXECUTED_COVERAGE_SUPPLEMENT.json',
    'core05-pr28.stdout.log','core05-pr29.stdout.log','core05-call-diagnosis.json',
    'CORE05_DIAGNOSIS_UNAPPLIED.md','ARCHIVE_CORE_REVIEW.md'}
assert not any(name.rsplit('/',1)[-1] in excluded for name in evidence)
assert all(not name.endswith('.zip') for name in evidence)
selection=dict(qualification='EXACT_REVIEWED_TECHNICAL_EVIDENCE_INVENTORY_NOT_ACCEPTANCE',
    acceptanceGranted=False,release='NO_GO',files={name:witness(raw) for name,raw in sorted(evidence.items())})
path=run/'packaging/EVIDENCE_SELECTION.json'
with path.open('xb') as stream:stream.write(encoded(selection))
print(json.dumps(dict(files=len(evidence),bytes=sum(len(raw) for raw in evidence.values()),
    inventorySHA256=v.sha(path.read_bytes()),acceptanceGranted=False,release='NO_GO')))
