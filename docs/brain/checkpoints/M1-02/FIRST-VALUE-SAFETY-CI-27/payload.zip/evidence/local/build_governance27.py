from pathlib import Path
import ast, hashlib, json, re, subprocess

run=Path(__file__).parent
root=run/'source'
area=root/'scripts/release/full-app-j01'
base='8c02a02afd7f2e9775dcc512c800d4f71f733234'
original=subprocess.check_output(['git','show',base+':scripts/release/full-app-j01/check.py'],cwd=root)
terminal=b"if __name__ == '__main__':\n    sys.exit(main())\n"
old=original.decode()
start=old.index('# Release26 successor.')
extension=old[start:-len(terminal)]
def rename(text):
    text=re.sub(r'\b([A-Za-z_][A-Za-z_0-9]*)26([A-Za-z_0-9]*)\b',lambda m:m[0] if re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',m[0]) else m[1]+'27'+m[2],text)
    return text.replace('R26_','R27_').replace('M1X-26/','M1X-27/').replace('FIRST-VALUE-RECOVERY-26/','FIRST-VALUE-SAFETY-CI-27/').replace('verify26.py','verify27.py')
extension=rename(extension)
plan=(root/'docs/brain/task-specs/M1X-27/SCOPE_PLAN.md').read_bytes()
paths=json.loads(re.search(rb'```json\n(.*?)\n```',plan,re.S)[1])
plancommit=subprocess.check_output(['git','rev-list','--reverse',base+'..HEAD'],cwd=root).decode().splitlines()[0]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
constants=dict(RELEASE27_BASE=base,RELEASE27_TREE='ff0f76d11fa7775e27732f54ce7fdfbd51c8c676',
    RELEASE27_AUTHORITY=paths['authority'],RELEASE27_INPUT='cb1e3106f40b2a81872bdfc0c4f2642a0700d113bbb0a43fd33e8da09fe0d2b0',
    RELEASE27_PLAN_COMMIT=plancommit,RELEASE27_PLAN_SHA256=sha(plan),RELEASE27_APPENDIX_SHA256='0'*64,
    RELEASE27_EXISTING_APP=set(paths['existingAppPaths']),RELEASE27_NEW_APP=set(paths['newAppTestHelperPaths']),
    RELEASE27_OTHER_EXISTING=set(paths['otherExistingPaths']),RELEASE27_OTHER_NEW=set(paths['otherNewPaths']))
previous_commit='f20a58c09fefb9b9b15d10bc59119462ecdec386'
previous_files={}
for name in ('check.py','source_consumer27.test.py','replay27.test.py'):
    path='scripts/release/full-app-j01/'+name
    body=subprocess.check_output(['git','show',previous_commit+':'+path],cwd=root)
    mode,kind,blob=subprocess.check_output(['git','ls-tree',previous_commit,'--',path],cwd=root).decode().split('\t')[0].split()
    assert mode=='100644' and kind=='blob'
    previous_files[path]=dict(mode=mode,blob=blob,sha256=sha(body))
constants['RELEASE27_PREVIOUS_GOVERNANCE']=dict(commit=previous_commit,tree='4fdd7eca278a8e9cd963b74ed2b066b848eb6dd3',
    parent='b26c229aa140910ac34e1217f7bdad118c191e7f',parentTree='8fcb40f51013292566cfc9b7b705f853eb3a5631',files=previous_files)
# Produce a distinct consumer, preserving the original historical test bytes.
original_consumer=(area/'source_consumer26.test.py').read_text(encoding='utf-8')
imports=original_consumer[:original_consumer.index('# These pins')]
imports=imports.replace('Release26 refusal controls.', 'Release27 refusal controls.',1)
consumer=rename(original_consumer[original_consumer.index('def main():'):])
consumer=consumer.replace("    if args.historical_replay:\n        replay27(source,check,args.receipt)\n        return\n", "    require27(not args.historical_replay,'R27_SEPARATE_REPLAY_COMMAND')\n")
consumer=consumer.replace('check.__dict__=namespace\n', '''check.__dict__=namespace
    runner=source/'scripts/release/full-app-j01/replay27.py'
    runner_raw=runner.read_bytes()
    assert hashlib.sha256(runner_raw).hexdigest()==check.RELEASE27_REPLAY_SHA256
    replay_namespace={'__name__':'release27_controls','__file__':str(runner)}
    exec(compile(runner_raw,str(runner),'exec'),replay_namespace)
    for name in ('require27','PINNED27','LOCK27_SHA256','NATIVE27_PINS_SHA256','receipt27_guard',
        'consumer_result27','child27','replay27','installation27','checkout27'):
        globals()[name]=replay_namespace[name]
''')
# require27 is needed for CLI rejection before loading the runner.
imports += "def require27(value, code):\n    if not value: raise ValueError(code)\n\n\n"
consumer=consumer.replace("'source_consumer27.test.py --historical-replay --receipt '","'replay27.py --receipt '")
consumer=consumer.replace("with patch.object(check,'validate25'", "with patch.object(check,'validate26'")
consumer=consumer.replace('Published ac01','Published f20a58c').replace('published-C26','published-C27')
consumer=consumer.replace('stage/m1-real-first-value25','stage/m1-first-value-recovery26').replace('stage/m1-first-value-recovery27','stage/m1-first-value-safety-ci27')
consumer=consumer.replace("put('.github/workflows/security-candidate22.yml',(source/'.github/workflows/security-candidate22.yml').read_bytes())", """put('.github/workflows/security-candidate22.yml',(source/'.github/workflows/security-candidate22.yml').read_bytes())
        for script in ('replay27.py','replay27.test.py'):
            put('scripts/release/full-app-j01/'+script,(source/'scripts/release/full-app-j01'/script).read_bytes())""")
# A new 27 checker preserves26; older25 fallback is not the successor route.
consumer=consumer.replace("release26-", "release27-").replace("Synthetic Release26", "Synthetic Release27")
(area/'source_consumer27.test.py').write_bytes((imports+consumer).encode())
constants.update(RELEASE27_CONSUMER_SHA256=sha((area/'source_consumer27.test.py').read_bytes()),
    RELEASE27_WORKFLOW_SHA256=sha((root/'.github/workflows/security-candidate22.yml').read_bytes()),
    RELEASE27_REPLAY_SHA256=sha((area/'replay27.py').read_bytes()),
    RELEASE27_REPLAY_TEST_SHA256=sha((area/'replay27.test.py').read_bytes()))
for key,value in constants.items():
    representation='{'+', '.join(repr(p) for p in sorted(value))+'}' if isinstance(value,set) else repr(value)
    pattern=r'(?m)^'+key+r' = .*$'
    if re.search(pattern,extension): extension=re.sub(pattern,lambda _:key+' = '+representation,extension)
    else: extension=extension.replace('\n\ndef name27', '\n'+key+' = '+representation+'\n\ndef name27',1)
extension=extension.replace("'RELEASE27_WORKFLOW_SHA256', 'RELEASE27_PREVIOUS_GOVERNANCE')", "'RELEASE27_WORKFLOW_SHA256', 'RELEASE27_PREVIOUS_GOVERNANCE', 'RELEASE27_REPLAY_SHA256', 'RELEASE27_REPLAY_TEST_SHA256')")
extension=extension.replace("len(raw) == 10122", 'len(raw) == '+str(len(plan)))
extension=extension.replace('6c0f5f6d4f66612551e79216e49b698fe487b9d3cefc0c3f0cf1bb30b9fbd7e7',sha(plan))
extension=extension.replace("pr['base'].get('ref') == 'stage/m1-real-first-value25'", "pr['base'].get('ref') == 'stage/m1-first-value-recovery26'")
extension=extension.replace("pr['head'].get('ref') == 'stage/m1-first-value-recovery27'", "pr['head'].get('ref') == 'stage/m1-first-value-safety-ci27'")
begin=extension.index("        if prior and path in previous['files']:")
finish=extension.index('    return seen',begin)
prior_branch=extension[begin:extension.index('        else:',begin)]
extension=extension[:begin]+prior_branch+'''        else:
            if path == 'scripts/release/full-app-j01/check.py': validate27_checker(data)
            pins = {'scripts/release/full-app-j01/source_consumer27.test.py': RELEASE27_CONSUMER_SHA256,
                '.github/workflows/security-candidate22.yml': RELEASE27_WORKFLOW_SHA256,
                'scripts/release/full-app-j01/replay27.py': RELEASE27_REPLAY_SHA256,
                'scripts/release/full-app-j01/replay27.test.py': RELEASE27_REPLAY_TEST_SHA256}
            if path in pins: require(sha(data) == pins[path], 'R27_SOURCE_TOOL_IDENTITY')
'''+extension[finish:]
extension=extension.replace("    # Empty all external Git conversion", """    for path, expected in [('replay27.py', RELEASE27_REPLAY_SHA256), ('replay27.test.py', RELEASE27_REPLAY_TEST_SHA256)]:
        require(sha(regular23(ROOT/'scripts/release/full-app-j01'/path)) == expected, 'R27_SOURCE_TOOL_IDENTITY')
    # Empty all external Git conversion""")
extension=extension.replace("'.github/workflows/security-candidate22.yml', 'docs/brain/task-specs/M1X-27/TASK.md'}", "'.github/workflows/security-candidate22.yml', 'docs/brain/task-specs/M1X-27/TASK.md',\n            'scripts/release/full-app-j01/replay27.py', 'scripts/release/full-app-j01/replay27.test.py'}")
extension=extension.replace('if not current: return validate25(bundle)', 'if not current: return validate26(bundle)')
extension=extension.replace("inherited_release25='IMMUTABLE_PR29_DEFINITIONS;AUTHENTIC_HISTORICAL_REPLAY_REQUIRED'", "inherited_release26='IMMUTABLE_PR30_DEFINITIONS;AUTHENTIC_HISTORICAL_REPLAY_REQUIRED'")
extension=extension.replace("'R27_CONSUMER_IDENTITY',", "'R27_SOURCE_TOOL_IDENTITY', 'R27_CONSUMER_IDENTITY',")
extension=extension.replace('# Release27 successor. Every inherited Release08-25 byte/definition remains immutable.', '# Release27 successor. Every inherited Release08-26 byte/definition remains immutable.')
digest=sha(extension.encode())
extension=extension.replace("RELEASE27_APPENDIX_SHA256 = '"+'0'*64+"'", "RELEASE27_APPENDIX_SHA256 = '"+digest+"'")
result=original[:-len(terminal)]+extension.encode()+terminal
compile(result,'check.py','exec')
(area/'check.py').write_bytes(result)
contract=dict(schema=1,authority=paths['authority'],status='SUBMITTED_REVIEW_REQUIRED',base=base,tree=constants['RELEASE27_TREE'],
    scopeCommit=plancommit,scopePlanSHA256=sha(plan),inputManifestSHA256=constants['RELEASE27_INPUT'],acceptanceGranted=False,
    admissions=dict(G97=False,DB=False,M103=False,M2=False,J01=False,PUBLIC=False),pr=31)
target=root/'docs/brain/contracts/M1X-27/source27.v1.json';target.parent.mkdir(parents=True,exist_ok=True)
target.write_bytes((json.dumps(contract,indent=2)+'\n').encode())
print(json.dumps(dict(planCommit=plancommit,planSHA256=sha(plan),appendixSHA256=digest)))
