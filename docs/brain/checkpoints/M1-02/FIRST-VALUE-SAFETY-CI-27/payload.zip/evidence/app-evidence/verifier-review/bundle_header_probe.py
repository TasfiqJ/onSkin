"""Synthetic artifact-only bundle-header parser assay; no Git or source writes."""
from pathlib import Path
import hashlib, importlib.util, io, json, stat, struct, zipfile, zlib
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('v',ROOT/'packaging/verify_return27.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)

def zipbytes(entries):
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w') as z:
        for name,raw in entries.items():
            i=zipfile.ZipInfo(name,(2026,10,29,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16
            z.writestr(i,raw)
    return out.getvalue()
def encoded(obj):return json.dumps(obj,sort_keys=True).encode()
def witnesses(entries):return {p:dict(bytes=len(b),sha256=v.sha(b)) for p,b in entries.items()}
source=dict(base=v.BASE,baseTree=v.BASE_TREE,runtimeHead='1'*40,runtimeTree='2'*40,sourceHead='3'*40,sourceTree='4'*40)
payload={'evidence.txt':b'probe'}
cp={'README.md':b'readme','REPORT.md':b'report','verify27.py':(ROOT/'packaging/verify27.py').read_bytes(),'payload.zip':zipbytes(payload)}
cpmanifest=dict(schema=1,authority=v.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO',inputManifestSHA256=v.INPUT,source=source,files=witnesses(cp),payload=dict(schema=1,files=witnesses(payload),qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE'))
cp['manifest.json']=encoded(cpmanifest)
source={**source,'candidateHead':'5'*40,'candidateTree':'6'*40}
w=dict(mode='100644',blob='a'*40,bytes=1,sha256='b'*64)
def row(path,status):return dict(path=path,status=status,before=None if status=='A' else w,after=w)
def rows(paths):return [row(p,'M' if p in v.EXISTING else 'A') for p in sorted(paths)]
history=dict(schema=1,qualification='GIT_HISTORY_AND_BLOB_IDENTITIES_NOT_ACCEPTANCE',base=v.BASE,baseTree=v.BASE_TREE,head=source['candidateHead'],tree=source['candidateTree'],scopeCommit=v.PLAN_COMMIT,scopePlanSHA256=v.PLAN_SHA256,
 commits=[dict(commit=v.PLAN_COMMIT,parent=v.BASE,tree='7'*40,changes=rows({v.PLAN})),
          dict(commit=source['runtimeHead'],parent=v.PLAN_COMMIT,tree=source['runtimeTree'],changes=rows({'scripts/release/full-app-j01/replay27.py'})),
          dict(commit=source['sourceHead'],parent=source['runtimeHead'],tree=source['sourceTree'],changes=rows(v.WORKLIST)),
          dict(commit=source['candidateHead'],parent=source['sourceHead'],tree=source['candidateTree'],changes=rows({v.CHECKPOINT+n for n in v.CHECKPOINT_FILES}|{'ONSKIN_BRAIN_HANDOFF.txt'}))],
 delta=rows({v.PLAN,'scripts/release/full-app-j01/replay27.py'}|v.WORKLIST|{v.CHECKPOINT+n for n in v.CHECKPOINT_FILES}|{'ONSKIN_BRAIN_HANDOFF.txt'}))
body=b'PACK'+struct.pack('>II',2,1)+b'\x33'+zlib.compress(b'foo');body+=hashlib.sha1(body).digest()
result=[]
for label,requirement in [('valid_prerequisite',('-'+v.BASE+' pinned base').encode()),('missing_separator',('-'+v.BASE+'junk').encode()),('bare_hash',('-'+v.BASE).encode())]:
    bundle=b'# v2 git bundle\n'+requirement+b'\n'+source['candidateHead'].encode()+b' HEAD\n\n'+body
    files={'FINAL_REPORT.md':b'probe','verify_return27.py':(ROOT/'packaging/verify_return27.py').read_bytes(),**{'checkpoint/'+p:b for p,b in cp.items()},'history.json':encoded(history),'delta.bundle':bundle}
    manifest=dict(schema=1,authority=v.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO',inputManifestSHA256=v.INPUT,source=source,files=witnesses(files),qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',checkpoint=dict(path='checkpoint',manifestSHA256=v.sha(cp['manifest.json'])),gitDelta=dict(path='delta.bundle',base=v.BASE,baseTree=v.BASE_TREE,head=source['candidateHead'],tree=source['candidateTree']),gitHistory=dict(path='history.json'))
    files['manifest.json']=encoded(manifest)
    try:
        actual=v.return_packet(v.Archive(zipbytes(files)),v.sha(files['manifest.json']))
        outcome=actual['status']
    except v.Refusal as e:outcome=str(e)
    result.append(dict(control=label,result=outcome,expected='VERIFIED' if label=='valid_prerequisite' else 'REFUSAL'))
out=dict(qualification='SYNTHETIC_ARTIFACT_ONLY_HEADER_PARSER_NOT_GIT_SEMANTIC_OR_FINAL_ACCEPTANCE',verifierSHA256=v.sha((ROOT/'packaging/verify_return27.py').read_bytes()),checkpointVerifierSHA256=v.sha((ROOT/'packaging/verify27.py').read_bytes()),results=result)
(Path(__file__).parent/'bundle-header-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
