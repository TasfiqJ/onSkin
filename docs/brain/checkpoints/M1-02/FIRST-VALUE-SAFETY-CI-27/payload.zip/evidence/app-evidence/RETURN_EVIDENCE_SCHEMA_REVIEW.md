# Proposed final return evidence binding

This documents a **proposal**, not executed final verification or existing CI receipts. `build_return27.reviewed.py` is intended to replace the external run-root `build_return27.py` after review; do not execute it from this evidence directory. No source file, freeze, checkpoint or return ZIP was changed or created by this proposal.

The builder still supplies artifact-integrity evidence, never independent acceptance. API snapshots and runner logs remain external observations. Their hashes bind the observed files; they are not GitHub signatures or proof that a caller cannot fabricate files. The independent Brain must assess provenance.

## Shared file reference

Every reference has exactly `path`, `bytes`, `sha256`. Paths are return-member paths beginning `evidence/ci-final/` or `evidence/final-verification/`; bytes is a nonnegative integer, never a Boolean; SHA256 is 64 lowercase hexadecimal characters. Every reference must resolve to the exact selected bytes. No raw protected source or new protected-file digest belongs in these areas.

## Exact final selection

Create `packaging/FINAL_EVIDENCE_SELECTION.json` **after** the final receipts and their index are complete and reviewed. It has exactly:

- `schema`: integer 1.
- `qualification`: `EXACT_REVIEWED_FINAL_EVIDENCE_INVENTORY_NOT_ACCEPTANCE`.
- `head`, `tree`: actual final candidate identities.
- `acceptanceGranted`: false; `release`: `NO_GO`.
- `files`: map from exact return-member names to objects containing exactly `bytes` and `sha256`.
- `excluded`: map with the same witness fields plus `reason`. Only raw `.zip` downloads under `evidence/ci-final/` may be excluded, using reason `RAW_CI_DOWNLOAD_NOT_EMBEDDED`.

The union is an exact inventory of both local directories. Unexpected files, omitted files, changed bytes, links, reparse points, aliases, clone/checkout/node_modules directories and changed directory inventories are refused. The builder emits the reviewed selection and a derived binding summary in the return. The selection itself resides outside these two input directories, avoiding a self-hash.

Do not generate and approve this inventory blindly from a directory glob. Review every selected file's intended disclosure. Actual clones, caches and checkpoint copies belong under `final-clones/`, outside both evidence directories. Raw public artifact ZIPs are checked by the external CI helper and identified here, but their mixed ZIP descriptor format is not embedded in the strict return packet.

## Final receipt index

`final-verification/FINAL_EVIDENCE_INDEX.json` has exactly:

- `schema`: integer 1.
- `qualification`: `FINAL_HEAD_RECEIPT_REFERENCES_NOT_ACCEPTANCE`.
- `head`, `tree`, `checkpointManifestSHA256`, `checkpointVerifierSHA256`: actual external identities.
- `acceptanceGranted`: false; `release`: `NO_GO`.
- `cloneReceipts`: exactly two shared file references, one for each actual clone run.
- `ciReceipt`: one shared file reference to the CI observation document described below.

Do not put asserted clone counts or 0/1/0 arrays in the index. The replacement derives them from the actual `final_clone27.py` receipts and authenticated per-command logs.

Each selected clone receipt must match the final head/tree/checkpoint anchors and the currently reviewed external harness bytes. It must have the harness's exact terminal PASS status, distinct clone-a/clone-b workspace names and object-store device/inode identities, clean restored source, fresh authenticated npm11.20.0 installation and normal hooks, and all twelve actual step records. Every recorded stdout/stderr identity must resolve to selected bytes. Five identical full-verifier command arrays must produce actual 0/1/0/1/0 outputs. The two refused outputs must respectively report `GIT_CHECKOUT_DIRTY` and `ARTIFACT_HASH_MISMATCH`; timeout or generic failure cannot pass. The three successful outputs must report exact source identities and source/Phase4 verification. Restored metadata/byte equality must be recorded without publishing protected raw bytes or new hashes. Earlier failed harness attempts should also remain selected evidence, but cannot serve as either successful clone reference.

## Final CI observation document

Choose a reviewed file under `ci-final/` or `final-verification/`. It has exactly:

- `schema`: integer 1.
- `qualification`: `ACTUAL_FINAL_HEAD_CI_OBSERVATIONS_NOT_ACCEPTANCE`.
- `head`, `tree`: final candidate identities, not a PR merge substitute.
- `acceptanceGranted`: false; `release`: `NO_GO`.
- `publicPlatforms`: an object with exactly `linux` and `windows` entries.
- `otherChecks`: an array including reporting labels `postgresql15`, `postgresql17`, `canonical-database`, and `quality`. Add other actually observed checks as needed.

Each platform entry has exactly `availability`, `reason`, `run`, `job`, `apiRunHeadSHA`, `artifact`, and `publicCommandExit`.

`availability` is one of `RECORDED`, `NOT_RUN`, `BLOCKED_EXTERNAL_CUSTODY`. `reason` is one of `NONE`, `NO_FINAL_RUN`, `EXTERNAL_CUSTODY`, `ARTIFACT_UNAVAILABLE`, `RUN_INCOMPLETE`, `JOB_DID_NOT_PRODUCE_ARTIFACT`.

For NOT_RUN or BLOCKED_EXTERNAL_CUSTODY, reason must be non-NONE and all remaining fields are null. If run/job metadata exists but artifact access is blocked, use RECORDED with the real run/job, null artifact, and the actual reason.

For RECORDED, `run` and `job` are GitHub observation objects. Each has exactly `id` (positive integer), `url` (actual onSkin GitHub Actions link), `status`, `conclusion`, and `metadata` (a nonempty list of shared file references to saved API/tool responses supporting that observation). Status may be queued, in_progress, completed, waiting, requested or pending. Conclusion is the actual GitHub conclusion or null. A noncompleted observation must have null conclusion. Never invent a successful conclusion to fill the schema.

`apiRunHeadSHA` is the head SHA actually returned by GitHub, or null when unavailable. It is separate from the checkout head and the `ciEventCommit` found in the current-source receipt. When both are available, the builder checks that it matches the candidate or observed CI event commit. `publicCommandExit` is the actual command exit if observed, otherwise null. An unexpected zero is retained as a diagnostic flag, not silently called the required nonzero result.

An artifact, when available, has exactly `id`, `githubDigest` (`sha256:` plus the actual GitHub digest), `githubSize` (actual byte length), `metadata` (shared file reference to the strict CI helper's metadata receipt), and `files` (map from each actually exported allowlisted basename to its shared file reference). Its digest, size, explicit platform profile and complete export inventory must match that helper receipt. No original Security logs may be referenced or exported.

The builder independently reads available current-source, historical-replay, public-component and reader receipts. Explicit stale head/tree evidence is refused. Valid positive source/historical receipts must bind the exact final tail. Missing, empty or failed outputs remain partial evidence and never become positive proof. Public components remain candidateReady false and NO_GO. Reader summaries and the flat helper diagnostic are separately reported; the helper diagnostic is not a historical consumer run.

Each `otherChecks` row has exactly `label` (unique short label), `availability`, `reason` (short factual text), and `observation`. RECORDED requires a GitHub observation object. Other availability values require null observation and a nonempty reason. PostgreSQL/quality/other failed, skipped or blocked jobs remain as observed; this schema demands reporting, not synthetic success or database acceptance.

## Precise optimize guards

Place this immediately after each module docstring and before existing imports with side effects in external `freeze_worklists27.py` and `build_checkpoint27.py`:

```python
import sys
if sys.flags.optimize:
    raise RuntimeError('ASSERTIONS_MUST_BE_ENABLED')
```

The proposed return builder already includes this guard. It does not alter the original producer, source checker or packet verifier.

## Work after assembly

This proposal does not upload anything, perform the fresh download, create a final annex, or claim CI completion. Assemble the final report with the actual pass/fail/blocked findings. After creating the sole ZIP, run the unchanged final return verifier against a complete exact final checkout, publish the authorized download, freshly download and rehash that exact ZIP, and supply ZIP/manifest/verifier anchors and actual link externally. Those post-assembly delivery receipts cannot be embedded in the same ZIP without a circular dependency; preserve them outside the seal. No second evidence tail or source change is implied.
