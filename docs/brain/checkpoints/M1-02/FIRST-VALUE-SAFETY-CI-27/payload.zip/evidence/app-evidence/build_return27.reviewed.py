"""Proposed replacement for run/build_return27.py; do not execute this draft.

Copy to the original builder location after review. The external selection,
index and CI receipt schemas are documented in RETURN_EVIDENCE_SCHEMA_REVIEW.md.
"""
import sys
if sys.flags.optimize:
    raise RuntimeError('ASSERTIONS_MUST_BE_ENABLED')

from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
from build_checkpoint27 import zip_bytes, witness, encoded

run=Path(__file__).resolve().parent
root=run/'source'
spec=importlib.util.spec_from_file_location('return27',run/'packaging/verify_return27.py')
v=importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
git=lambda *args:subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
HEX40=re.compile('[0-9a-f]{40}')
HEX64=re.compile('[0-9a-f]{64}')
AREAS=('ci-final','final-verification')
CLONE_PASS='PASS_FINAL_CLONE_SOURCE_CHECKPOINT_PHASE4_AND_REAL_CONTROLS'
FULL_STEPS=('baseline-full','protected-source-tampered','protected-source-restored','artifact-tampered','artifact-restored')
PRE_STEPS=('clone','checkout','fsck','toolchain-before','normal-npm-ci','mandatory-hooks','toolchain-after')
STATUSES={'queued','in_progress','completed','waiting','requested','pending'}
CONCLUSIONS={None,'success','failure','neutral','cancelled','skipped','timed_out','action_required','stale','startup_failure'}
AVAILABILITY={'RECORDED','NOT_RUN','BLOCKED_EXTERNAL_CUSTODY'}
PUBLIC_FILES={'security22-public.json','security23-toolchain-controls.json','security23-native-controls.json',
    'security24-advisory-controls.tap','security27-hosted-reader.jsonl','security27-python312-reader.jsonl',
    'security27-historical-receipt.json','security27-historical-controls.jsonl','security27-source-controls.jsonl',
    'security27-current-source.json'}


def need(condition, code):
    if not condition: raise ValueError(code)


def fields(value, expected, code):
    need(type(value) is dict and set(value)==set(expected),code)


def natural(value):
    return type(value) is int and value>=0


def sha(value):
    return hashlib.sha256(value).hexdigest()


def no_acceptance(value):
    need(value.get('acceptanceGranted') is False and value.get('release')=='NO_GO','FALSE_ADMISSIONS_REQUIRED')


def checked_ref(ref, evidence):
    fields(ref,('path','bytes','sha256'),'EVIDENCE_REFERENCE_SCHEMA')
    path=ref['path'];v.safe_path(path)
    need(path in evidence and natural(ref['bytes']) and type(ref['sha256']) is str and HEX64.fullmatch(ref['sha256']),
         'EVIDENCE_REFERENCE_SCHEMA')
    raw=evidence[path]
    need(len(raw)==ref['bytes'] and sha(raw)==ref['sha256'],'EVIDENCE_REFERENCE_IDENTITY')
    return raw


def final_evidence(source):
    raw=v.read_regular(run/'packaging/FINAL_EVIDENCE_SELECTION.json')
    selection=v.loads(raw)
    fields(selection,('schema','qualification','head','tree','acceptanceGranted','release','files','excluded'),
           'FINAL_SELECTION_SCHEMA')
    need(type(selection['schema']) is int and selection['schema']==1 and
         selection['qualification']=='EXACT_REVIEWED_FINAL_EVIDENCE_INVENTORY_NOT_ACCEPTANCE' and
         selection['head']==source['candidateHead'] and selection['tree']==source['candidateTree'],'FINAL_SELECTION_IDENTITY')
    no_acceptance(selection)
    need(type(selection['files']) is dict and type(selection['excluded']) is dict and
         not set(selection['files']) & set(selection['excluded']),'FINAL_SELECTION_INVENTORY')
    combined={**selection['files'],**selection['excluded']}
    need(combined,'FINAL_SELECTION_EMPTY')
    v.paths(combined)
    for name,item in combined.items():
        parts=v.safe_path(name)
        need(len(parts)>=3 and parts[0]=='evidence' and parts[1] in AREAS and
             not any(part in ('.git','node_modules','checkout','checkpoint-copy','npm-cache','final-clones') for part in parts),
             'FINAL_SELECTION_PATH')
        expected=('bytes','sha256') if name in selection['files'] else ('bytes','sha256','reason')
        fields(item,expected,'FINAL_SELECTION_WITNESS')
        need(natural(item['bytes']) and item['bytes']<=v.MAX_FILE and
             type(item['sha256']) is str and HEX64.fullmatch(item['sha256']),'FINAL_SELECTION_WITNESS')
        if name in selection['excluded']:
            need(item['reason']=='RAW_CI_DOWNLOAD_NOT_EMBEDDED' and parts[1]=='ci-final' and name.endswith('.zip'),
                 'FINAL_SELECTION_EXCLUSION')
        else:
            need(Path(name).suffix in ('.json','.jsonl','.log','.md','.py','.tap','.txt'),'FINAL_SELECTION_TYPE')
    evidence={}
    for area in AREAS:
        container=v.Directory(run/area)
        prefix='evidence/'+area+'/'
        expected={name[len(prefix):] for name in combined if name.startswith(prefix)}
        container.exact(expected)
        for relative in sorted(expected):
            name=prefix+relative;item=combined[name];body=container.read(relative)
            need(len(body)==item['bytes'] and sha(body)==item['sha256'],'FINAL_SELECTION_BYTES')
            if name in selection['files']:evidence[name]=body
        container.seal()
    return evidence,raw


def clone_receipt(ref,evidence,source,seal):
    receipt=v.loads(checked_ref(ref,evidence))
    need(re.fullmatch(r'evidence/final-verification/clone-[ab]-[^/]+/final-clone-receipt\.json',ref['path']) is not None,
         'FINAL_CLONE_RECEIPT_PATH')
    no_acceptance(receipt)
    need(receipt.get('schema')==1 and type(receipt['schema']) is int and receipt.get('status')==CLONE_PASS and
         receipt.get('label') in ('clone-a','clone-b') and receipt.get('head')==source['candidateHead'] and
         receipt.get('tree')==source['candidateTree'] and receipt.get('finalHead')==source['candidateHead'] and
         receipt.get('finalTree')==source['candidateTree'] and receipt.get('manifestSHA256')==seal['manifestSHA256'] and
         receipt.get('verifierSHA256')==seal['verifierSHA256'],'FINAL_CLONE_IDENTITY')
    for key in ('cleanAfter','fullCommandIdenticalAcrossFiveInvocations','artifactCopyOutsideSource','finalHeadCINotClaimed'):
        need(receipt.get(key) is True,'FINAL_CLONE_QUALIFICATION')
    need(receipt.get('helperSHA256')==sha(v.read_regular(run/'app-evidence/final_clone27.py')),'FINAL_CLONE_HELPER_IDENTITY')
    need(receipt.get('protectedRawBytesOrNewHashesDisclosed') is False,'FINAL_CLONE_DISCLOSURE')
    for key in ('sourceTamperSequence','artifactTamperSequence'):
        need(type(receipt.get(key)) is list and len(receipt[key])==3 and
             all(type(x) is int for x in receipt[key]) and receipt[key]==[0,1,0],'FINAL_CLONE_SEQUENCE')
    proof=receipt.get('cloneProof');need(type(proof) is dict,'FINAL_CLONE_STORE')
    for key in ('complete','separateObjectStore','noAlternates','noSharedOrHardlinkedObjectFiles'):
        need(proof.get(key) is True,'FINAL_CLONE_STORE')
    need(proof.get('remote')=='https://github.com/TasfiqJ/onSkin.git' and proof.get('rawBlobDigestsDisclosed') is False,
         'FINAL_CLONE_STORE')
    store=proof.get('objectStoreDirectoryIdentity');fields(store,('device','inode'),'FINAL_CLONE_STORE')
    need(all(natural(store[k]) for k in store) and store['inode']>0,'FINAL_CLONE_STORE')
    count=proof.get('trackedRawBlobsReconciled')
    need(natural(count) and count>0 and type(receipt.get('trackedRawBlobsReconciledAfter')) is int and
         receipt['trackedRawBlobsReconciledAfter']==count,'FINAL_CLONE_RECONCILIATION')
    installation=receipt.get('installation');need(type(installation) is dict,'FINAL_CLONE_INSTALLATION')
    need(installation.get('npmVersion')=='11.20.0' and installation.get('installationModelSHA256')==
         'c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9','FINAL_CLONE_INSTALLATION')
    for key in ('normalCiExit','postinstallCheckExit'):
        need(type(installation.get(key)) is int and installation[key]==0,'FINAL_CLONE_INSTALLATION')
    for key in ('freshCache','freshNodeModules','mandatoryHooks','nativeSourceOnlyNotDeviceAcceptance'):
        need(installation.get(key) is True,'FINAL_CLONE_INSTALLATION')
    command=receipt.get('unchangedFullCommand')
    need(type(command) is list and len(command)==17 and all(type(x) is str for x in command) and
         command[1:3]==['-I','-B'] and command[4]=='--root' and command[6]=='--git-root' and
         command[8:]==['--expected-manifest-sha256',seal['manifestSHA256'],
                      '--expected-verifier-sha256',seal['verifierSHA256'],
                      '--expected-head',source['candidateHead'],'--expected-tree',source['candidateTree'],
                      '--execute-source-checks'],'FINAL_CLONE_COMMAND')
    name=Path(ref['path']).parent.name
    need(name.startswith(receipt['label']+'-'),'FINAL_CLONE_RECEIPT_PATH')
    workspace=run/'final-clones'/name
    need(Path(command[3])==workspace/'checkpoint-copy/verify27.py' and Path(command[5])==workspace/'checkpoint-copy' and
         Path(command[7])==workspace/'checkout','FINAL_CLONE_COMMAND_PATHS')
    records=receipt.get('records')
    need(type(records) is list and len(records)==len(PRE_STEPS)+len(FULL_STEPS) and
         [r.get('label') if type(r) is dict else None for r in records]==list(PRE_STEPS+FULL_STEPS),'FINAL_CLONE_RECORDS')
    directory=ref['path'].rsplit('/',1)[0]
    full=[]
    for record in records:
        label=record['label'];expected=1 if label.endswith('-tampered') else 0
        need(type(record.get('exit')) is int and record['exit']==expected and
             type(record.get('expectedExit')) is int and record['expectedExit']==expected and
             record.get('interruptedOrFailed') is not True,'FINAL_CLONE_EXIT')
        output={}
        for stream in ('stdout.log','stderr.log'):
            item=record.get(stream);fields(item,('path','bytes','sha256'),'FINAL_CLONE_LOG')
            need(item['path']==label+'.'+stream,'FINAL_CLONE_LOG')
            output[stream]=checked_ref({**item,'path':directory+'/'+item['path']},evidence)
        if label in FULL_STEPS:
            need(record.get('argv')==command,'FINAL_CLONE_CHANGED_COMMAND')
            result=v.loads(output['stdout.log']);no_acceptance(result)
            if expected:
                category='GIT_CHECKOUT_DIRTY' if label.startswith('protected-') else 'ARTIFACT_HASH_MISMATCH'
                need(result.get('status')=='CONTEXT_INVALID' and result.get('error')==category,'FINAL_CLONE_REFUSAL_REASON')
            else:
                need(result.get('status')=='VERIFIED' and result.get('git',{}).get('head')==source['candidateHead'] and
                     result.get('git',{}).get('tree')==source['candidateTree'] and
                     result.get('git',{}).get('trackedWorkingBlobsHashedLocally')==count and
                     result.get('sourceChecks',{}).get('release27')=='PASS_FINITE_SOURCE_GOVERNANCE_ONLY' and
                     result.get('sourceChecks',{}).get('phase4')=='PASS_UNCHANGED_PRODUCER_STRICT_CHECK','FINAL_CLONE_FULL_PROOF')
            full.append(record['exit'])
        elif label=='mandatory-hooks':
            hooks=v.loads(output['stdout.log']);need(hooks.get('check') is True and hooks.get('toolingSecurity')=='checked',
                                                   'FINAL_CLONE_HOOK_PROOF')
    need(full==[0,1,0,1,0],'FINAL_CLONE_SEQUENCE')
    for label,category in (('protected-source','GIT_CHECKOUT_DIRTY'),('artifact','ARTIFACT_HASH_MISMATCH')):
        refusal=receipt.get(label+'Refusal')
        fields(refusal,('expected','observed','matched'),'FINAL_CLONE_REFUSAL_REASON')
        need(refusal['expected']==refusal['observed']==category and refusal['matched'] is True,'FINAL_CLONE_REFUSAL_REASON')
        restoration=receipt.get(label+'Restoration');need(type(restoration) is dict,'FINAL_CLONE_RESTORATION')
        for key in ('exactBytes','identityModeAndLinks','originalModificationTimeRestored'):
            need(restoration.get(key) is True,'FINAL_CLONE_RESTORATION')
        need(restoration.get('changeTimeResetClaim') is False and restoration.get('protectedContentOrDigestDisclosed') is False,
             'FINAL_CLONE_RESTORATION')
    return dict(label=receipt['label'],store=(store['device'],store['inode']),workspace=name,tracked=count)


def observed_json(raw):
    # Preserve empty, interrupted and failed job output as evidence. It cannot
    # become a positive proof merely because the ZIP itself was authenticated.
    try:
        value=v.loads(raw)
    except v.Refusal:
        return None
    return value if type(value) is dict else None


def reader_observation(raw):
    rows=[observed_json(line) for line in raw.splitlines() if line.strip()]
    if not rows or any(row is None for row in rows):
        return dict(status='UNPARSEABLE_OR_EMPTY',originalHelperObservation=False)
    terminal=rows[-1]
    diagnostics=[row for row in rows if row.get('helper_only_not_consumer') is True]
    observed=False;ctime=None;original_refused=None
    if len(diagnostics)==1:
        diagnostic=diagnostics[0]
        required=('helper_sha256_match','helper_git_blob_match','helper_git_mode_match','helper_pinned_tree_match',
                  'unchanged_original_helper_asts','fixture_bytes_unchanged','current_reader_returned_expected_bytes',
                  'path_metadata_stable_excluding_only_atime','handle_metadata_stable_excluding_only_atime')
        observed=all(type(item) is bool for item in diagnostic.values()) and all(diagnostic.get(key) is True for key in required)
        observed=(observed and diagnostic.get('original_helper_returned_expected_bytes') is diagnostic.get('original_stamp_compatible') and
                  diagnostic.get('original_helper_refused_R26_REPLAY_CHANGED') is (not diagnostic.get('original_stamp_compatible')))
        ctime=diagnostic.get('path_handle_before_st_ctime_ns_equal')
        original_refused=diagnostic.get('original_helper_refused_R26_REPLAY_CHANGED')
    if terminal.get('status')=='PASS':no_acceptance(terminal)
    return dict(status=terminal.get('status','INCOMPLETE'),originalHelperObservation=observed,
        observedCrossCtimeEqual=ctime,originalHelperRefusedChanged=original_refused)


def github_observation(value,evidence):
    fields(value,('id','url','status','conclusion','metadata'),'CI_GITHUB_SCHEMA')
    need(type(value['id']) is int and value['id']>0 and type(value['url']) is str and
         value['url'].startswith('https://github.com/TasfiqJ/onSkin/actions/') and
         value['status'] in STATUSES and value['conclusion'] in CONCLUSIONS,'CI_GITHUB_SCHEMA')
    need(value['status']=='completed' or value['conclusion'] is None,'CI_GITHUB_STATUS')
    need(type(value['metadata']) is list and value['metadata'],'CI_METADATA_REQUIRED')
    for ref in value['metadata']:checked_ref(ref,evidence)


def ci_receipt(ref,evidence,source):
    value=v.loads(checked_ref(ref,evidence))
    fields(value,('schema','qualification','head','tree','acceptanceGranted','release','publicPlatforms','otherChecks'),
           'FINAL_CI_SCHEMA')
    no_acceptance(value)
    need(type(value['schema']) is int and value['schema']==1 and
         value['qualification']=='ACTUAL_FINAL_HEAD_CI_OBSERVATIONS_NOT_ACCEPTANCE' and
         value['head']==source['candidateHead'] and value['tree']==source['candidateTree'],'FINAL_CI_IDENTITY')
    fields(value['publicPlatforms'],('linux','windows'),'FINAL_CI_PLATFORMS')
    outcomes={}
    for platform,row in value['publicPlatforms'].items():
        fields(row,('availability','reason','run','job','apiRunHeadSHA','artifact','publicCommandExit'),'FINAL_CI_PLATFORM_SCHEMA')
        need(row['availability'] in AVAILABILITY and row['reason'] in
             ('NONE','NO_FINAL_RUN','EXTERNAL_CUSTODY','ARTIFACT_UNAVAILABLE','RUN_INCOMPLETE','JOB_DID_NOT_PRODUCE_ARTIFACT'),
             'FINAL_CI_AVAILABILITY')
        need(row['publicCommandExit'] is None or type(row['publicCommandExit']) is int,'FINAL_CI_EXIT')
        if row['availability']!='RECORDED':
            need(row['reason']!='NONE' and row['run'] is None and row['job'] is None and row['artifact'] is None and
                 row['apiRunHeadSHA'] is None and row['publicCommandExit'] is None,'FINAL_CI_UNAVAILABLE')
            outcomes[platform]=dict(availability=row['availability'],reason=row['reason'])
            continue
        github_observation(row['run'],evidence);github_observation(row['job'],evidence)
        need(row['apiRunHeadSHA'] is None or type(row['apiRunHeadSHA']) is str and HEX40.fullmatch(row['apiRunHeadSHA']),
             'CI_RUN_HEAD_SCHEMA')
        artifact=row['artifact']
        if artifact is None:
            need(row['reason']!='NONE','CI_MISSING_ARTIFACT_REASON')
            outcomes[platform]=dict(availability='RECORDED',conclusion=row['job']['conclusion'],artifact='UNAVAILABLE')
            continue
        fields(artifact,('id','githubDigest','githubSize','metadata','files'),'CI_ARTIFACT_SCHEMA')
        need(type(artifact['id']) is int and artifact['id']>0 and natural(artifact['githubSize']) and
             type(artifact['githubDigest']) is str and re.fullmatch('sha256:[0-9a-f]{64}',artifact['githubDigest']),
             'CI_ARTIFACT_SCHEMA')
        meta=v.loads(checked_ref(artifact['metadata'],evidence))
        need(meta.get('status')=='VERIFIED_PUBLIC_ARTIFACT_BYTES_ONLY' and meta.get('sourceAcceptance') is False and
             meta.get('releaseAcceptance') is False and meta.get('decision')=='NO_GO' and
             meta.get('archive',{}).get('sha256')==artifact['githubDigest'][7:] and
             meta.get('archive',{}).get('bytes')==artifact['githubSize'] and
             meta.get('archive',{}).get('expectedPlatform')==platform,'CI_ARTIFACT_IDENTITY')
        exports=meta.get('exported');need(type(exports) is list and all(type(x) is dict for x in exports),'CI_ARTIFACT_EXPORTS')
        names=[item.get('name') for item in exports]
        need(len(names)==len(set(names)) and set(names)<=PUBLIC_FILES and type(artifact['files']) is dict and
             set(artifact['files'])==set(names),'CI_ARTIFACT_EXPORTS')
        bodies={}
        for item in exports:
            name=item['name'];body=checked_ref(artifact['files'][name],evidence)
            need(item.get('bytes')==len(body) and item.get('sha256')==sha(body),'CI_ARTIFACT_EXPORTED_IDENTITY')
            bodies[name]=body
        current=None;current_pass=False;historical_pass=False
        if 'security27-current-source.json' in bodies:
            current=observed_json(bodies['security27-current-source.json'])
            proof=current.get('source27',{}) if current else {}
            need(type(proof) is dict,'CI_CURRENT_SOURCE_SCHEMA')
            for key,expected in (('endpoint',source['candidateHead']),('checkoutHead',source['candidateHead']),
                                 ('tree',source['candidateTree']),('checkoutTree',source['candidateTree'])):
                need(proof.get(key) is None or proof[key]==expected,'CI_STALE_SOURCE_IDENTITY')
            if current and current.get('valid') is True:
                no_acceptance(current)
                need(proof.get('endpoint')==proof.get('checkoutHead')==source['candidateHead'] and
                     proof.get('tree')==proof.get('checkoutTree')==source['candidateTree'] and proof.get('phase')=='TAIL' and
                     proof.get('workingQualification')=='RAW_TRACKED_BLOBS_EXACT','CI_CURRENT_SOURCE_IDENTITY')
                current_pass=True
            need(proof.get('ciEventCommit') is None or type(proof['ciEventCommit']) is str and HEX40.fullmatch(proof['ciEventCommit']),
                 'CI_EVENT_COMMIT_SCHEMA')
            if current_pass and row['apiRunHeadSHA'] is not None:
                need(row['apiRunHeadSHA'] in (source['candidateHead'],proof.get('ciEventCommit')),'CI_API_SOURCE_DISAGREEMENT')
        if 'security27-historical-receipt.json' in bodies:
            history=observed_json(bodies['security27-historical-receipt.json'])
            context=history.get('context',{}) if history else {}
            need(type(context) is dict and (context.get('head') is None or context['head']==source['candidateHead']) and
                 (context.get('tree') is None or context['tree']==source['candidateTree']),'CI_STALE_HISTORICAL_SOURCE')
            if history and history.get('status')=='PASS':
                no_acceptance(history)
                need(context.get('head')==source['candidateHead'] and context.get('tree')==source['candidateTree'] and
                     context.get('sourcePhase')=='TAIL' and context.get('runId')==str(row['run']['id']) and
                     context.get('platform')=={'linux':'linux','windows':'win32'}[platform],'CI_HISTORICAL_CONTEXT')
                historical_pass=True
        component=None
        if 'security22-public.json' in bodies:
            component=observed_json(bodies['security22-public.json'])
            component_source=component.get('source',{}) if component else {}
            need(type(component_source) is dict and
                 (component_source.get('head') is None or component_source['head']==source['candidateHead']) and
                 (component_source.get('tree') is None or component_source['tree']==source['candidateTree']),'CI_STALE_PUBLIC_SOURCE')
            if component and component.get('executionComplete') is True:
                no_acceptance(component)
                need(component_source.get('head')==source['candidateHead'] and component_source.get('tree')==source['candidateTree'] and
                     component.get('candidateReady') is False,'CI_PUBLIC_SOURCE_OR_ADMISSION')
        outcomes[platform]=dict(availability='RECORDED',conclusion=row['job']['conclusion'],
            currentSourcePassed=current_pass,historicalReplayPassed=historical_pass,
            ciEventCommit=current.get('source27',{}).get('ciEventCommit') if current else None,
            publicExecutionComplete=component.get('executionComplete') if component else None,
            publicCommandExit=row['publicCommandExit'],candidateReady=component.get('candidateReady') if component else None,
            unexpectedZeroPublicExit=row['publicCommandExit']==0)
        for filename,label in (('security27-hosted-reader.jsonl','hostedReader'),
                               ('security27-python312-reader.jsonl','python312Reader')):
            outcomes[platform][label]=reader_observation(bodies[filename]) if filename in bodies else dict(status='NOT_RUN_OR_NOT_PRODUCED')
    need(type(value['otherChecks']) is list,'CI_OTHER_CHECKS')
    labels=set()
    for item in value['otherChecks']:
        fields(item,('label','availability','reason','observation'),'CI_OTHER_CHECK_SCHEMA')
        need(type(item['label']) is str and 0<len(item['label'])<=120 and item['label'] not in labels and
             item['availability'] in AVAILABILITY and type(item['reason']) is str and len(item['reason'])<=240,'CI_OTHER_CHECK_SCHEMA')
        labels.add(item['label'])
        if item['availability']=='RECORDED':github_observation(item['observation'],evidence)
        else:need(item['observation'] is None and bool(item['reason']),'CI_OTHER_CHECK_UNAVAILABLE')
    # These are mandatory reporting rows, not a demand for synthetic success.
    need({'postgresql15','postgresql17','canonical-database','quality'}<=labels,'CI_REQUIRED_REPORTING_ROWS')
    return outcomes


def bind_final_evidence(evidence,source,seal):
    index_path='evidence/final-verification/FINAL_EVIDENCE_INDEX.json'
    need(index_path in evidence,'FINAL_INDEX_REQUIRED')
    index=v.loads(evidence[index_path])
    fields(index,('schema','qualification','head','tree','checkpointManifestSHA256','checkpointVerifierSHA256',
                  'acceptanceGranted','release','cloneReceipts','ciReceipt'),'FINAL_INDEX_SCHEMA')
    no_acceptance(index)
    need(type(index['schema']) is int and index['schema']==1 and
         index['qualification']=='FINAL_HEAD_RECEIPT_REFERENCES_NOT_ACCEPTANCE' and index['head']==source['candidateHead'] and
         index['tree']==source['candidateTree'] and index['checkpointManifestSHA256']==seal['manifestSHA256'] and
         index['checkpointVerifierSHA256']==seal['verifierSHA256'],'FINAL_INDEX_IDENTITY')
    need(type(index['cloneReceipts']) is list and len(index['cloneReceipts'])==2,'FINAL_TWO_CLONES')
    clones=[clone_receipt(ref,evidence,source,seal) for ref in index['cloneReceipts']]
    need({r['label'] for r in clones}=={'clone-a','clone-b'} and len({r['store'] for r in clones})==2 and
         len({r['workspace'] for r in clones})==2 and len({r['tracked'] for r in clones})==1,'FINAL_CLONE_INDEPENDENCE')
    return dict(clones=2,sourceTamperSequences=[[0,1,0],[0,1,0]],artifactTamperSequences=[[0,1,0],[0,1,0]],
        distinctObjectStores=True,ci=ci_receipt(index['ciReceipt'],evidence,source),acceptanceGranted=False,release='NO_GO')


def main():
    need(not git('status','--porcelain=v1','--untracked-files=all'),'RETURN_SOURCE_DIRTY')
    seal=v.loads(v.read_regular(run/'packaging/checkpoint-seal.json'))
    head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
    source={**seal['source'],'candidateHead':head,'candidateTree':tree}
    need(git('rev-parse','HEAD^')==source['sourceHead'],'RETURN_TAIL_PARENT')
    expected={v.CHECKPOINT+n for n in v.CHECKPOINT_FILES}|{'ONSKIN_BRAIN_HANDOFF.txt'}
    need(set(git('diff','--name-only',source['sourceHead'],head).splitlines())==expected,'RETURN_TAIL_SCOPE')
    evidence,selection_raw=final_evidence(source)
    proof=bind_final_evidence(evidence,source,seal)
    files=dict(evidence)
    files['evidence/FINAL_EVIDENCE_SELECTION.json']=selection_raw
    files['evidence/FINAL_BINDING_VERIFICATION.json']=encoded(proof)
    def add(path,name):
        need(name not in files,'RETURN_FILE_COLLISION');files[name]=v.read_regular(path)
    add(run/'packaging/verify_return27.py','verify_return27.py')
    for name in sorted(v.CHECKPOINT_FILES):add(root/v.CHECKPOINT/name,'checkpoint/'+name)
    files['source/GIT_HISTORY.json']=encoded(v.git_history(root,source))
    rows=[]
    for record in subprocess.check_output(['git','-C',str(root),'ls-tree','-r','-l','-z','HEAD']).split(b'\0'):
        if not record:continue
        metadata,name=record.split(b'\t',1);mode,kind,blob,size=metadata.decode().split()
        need(kind=='blob','RETURN_GIT_TREE')
        rows.append(dict(path=name.decode(),mode=mode,blob=blob,bytes=int(size)))
    files['source/TRACKED_GIT_IDENTITIES.json']=encoded(dict(head=head,tree=tree,files=rows,
        qualification='ALL_TRACKED_GIT_MODE_BLOB_SIZE_METADATA;PRIVATE_LOCAL_RAW_BYTE_RECONCILIATION_IN_FULL_VERIFIER_RECEIPTS',
        protectedContentDisclosed=False,acceptanceGranted=False))
    bundle=run/'packaging/campaign27-pr30-required.bundle'
    need(not bundle.exists(),'RETURN_BUNDLE_ALREADY_EXISTS')
    subprocess.run(['git','-C',str(root),'bundle','create',str(bundle),'HEAD','^'+v.BASE],check=True,capture_output=True)
    add(bundle,'source/campaign27-pr30-required.bundle')
    report=v.read_regular(root/v.CHECKPOINT/'REPORT.md')+b'\n## Final candidate verification annex\n\n'+v.read_regular(run/'packaging/FINAL_ANNEX.md')
    files['FINAL_REPORT.md']=report
    manifest=dict(schema=1,authority=v.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO',
        inputManifestSHA256=v.INPUT,qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',source=source,
        files={name:witness(raw) for name,raw in sorted(files.items())},
        checkpoint=dict(path='checkpoint',manifestSHA256=seal['manifestSHA256']),gitHistory=dict(path='source/GIT_HISTORY.json'),
        gitDelta=dict(path='source/campaign27-pr30-required.bundle',base=v.BASE,baseTree=v.BASE_TREE,head=head,tree=tree))
    files['manifest.json']=encoded(manifest)
    raw=zip_bytes(files);anchor=sha(files['manifest.json'])
    v.return_packet(v.Archive(raw),anchor)
    need(git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and
         not git('status','--porcelain=v1','--untracked-files=all'),'RETURN_SOURCE_CHANGED')
    output=run/'onSkin_Campaign27_Postdispatch_Safety_Windows_CI_Return_2026-10-29.zip'
    with output.open('xb') as stream:stream.write(raw)
    (run/'FINAL_REPORT.md').write_bytes(report)
    anchors=dict(head=head,tree=tree,base=v.BASE,baseTree=v.BASE_TREE,zipName=output.name,zipBytes=len(raw),
        zipSHA256=sha(raw),manifestSHA256=anchor,verifierSHA256=sha(files['verify_return27.py']),
        filesIncludingManifest=len(files),checkpointManifestSHA256=seal['manifestSHA256'],checkpointVerifierSHA256=seal['verifierSHA256'],
        status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO')
    (run/'EXTERNAL_ANCHORS27.json').write_bytes(encoded(anchors))
    print(json.dumps(anchors,sort_keys=True))


if __name__=='__main__':main()
