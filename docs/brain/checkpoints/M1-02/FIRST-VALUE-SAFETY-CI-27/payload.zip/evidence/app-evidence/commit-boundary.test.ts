import { randomUUID } from 'node:crypto';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import type { QueryClient } from '@tanstack/react-query';
import { close26, flush26, ports26, reset26 } from '@/features/shelf/firstValue26TestPorts';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { addProduct, loadShelf } from '@/features/shelf/store';
import { getPrivateItem, updatePrivateItem } from '@/lib/storage/privateKV';

// External read-only API probe. Actual privateKV/encryption/health/store source;
// only native storage is the existing Campaign26 in-memory platform adapter.
// A synthetic canonical name change exercises the primitive; this is not a
// product mutation implementation and does not claim mirror-outbox correctness.
const KEY = 'layerwell.shelf.v1';
let client: QueryClient;
beforeEach(async () => {
  client = await reset26();
  await addProduct({ operationId: randomUUID(), name: 'Synthetic boundary probe', category: 'moisturiser', addedVia: 'manual' });
});
afterEach(async () => { vi.restoreAllMocks(); await close26(client); });

function changedState(raw: string | null): string {
  const state = JSON.parse(raw!);
  state.products[0].name = 'Synthetic changed boundary probe';
  return JSON.stringify(state);
}

function holdSecondRead() {
  const original = AsyncStorage.getItem;
  let count = 0;
  let release: (() => void) | undefined;
  vi.spyOn(AsyncStorage, 'getItem').mockImplementation(async (key) => {
    const raw = await original(key);
    if (key === KEY && ++count === 2) await new Promise<void>((resolve) => { release = resolve; });
    return raw;
  });
  return () => { expect(release).toBeTypeOf('function'); release!(); };
}

it('proves updater-only cancellation ends before the asynchronous conflict read', async () => {
  const before = ports26.bytes.get(KEY);
  let current = true;
  let prepared = false;
  const release = holdSecondRead();
  const pending = updatePrivateItem(KEY, (raw) => {
    expect(current).toBe(true);
    prepared = true;
    return changedState(raw);
  });
  await flush26();
  expect(prepared).toBe(true);
  expect(ports26.bytes.get(KEY)).toBe(before);
  current = false;
  release();
  await pending;
  expect(ports26.bytes.get(KEY)).not.toBe(before);
  expect(await loadShelf()).toHaveLength(1);
});

it('proves the existing additional guard cancels after preparation before native commit', async () => {
  const before = ports26.bytes.get(KEY);
  let current = true;
  const release = holdSecondRead();
  const writes = vi.spyOn(AsyncStorage, 'setItem');
  const pending = updatePrivateItem(KEY, changedState, () => {
    if (!current) throw new Error('EXTERNAL_UI_OPERATION_RETIRED');
  }).then(() => 'committed', (error: Error) => error.message);
  await flush26();
  current = false;
  release();
  expect(await pending).toBe('EXTERNAL_UI_OPERATION_RETIRED');
  expect(ports26.bytes.get(KEY)).toBe(before);
  expect(writes).not.toHaveBeenCalled();
});

it('proves the same additional guard restores bytes already stored before native promise settlement', async () => {
  const before = ports26.bytes.get(KEY);
  let current = true;
  let release: (() => void) | undefined;
  let first = true;
  const original = AsyncStorage.setItem;
  const writes = vi.spyOn(AsyncStorage, 'setItem').mockImplementation(async (key, raw) => {
    await original(key, raw);
    if (key === KEY && first) {
      first = false;
      await new Promise<void>((resolve) => { release = resolve; });
    }
  });
  const pending = updatePrivateItem(KEY, changedState, () => {
    if (!current) throw new Error('EXTERNAL_UI_OPERATION_RETIRED');
  }).then(() => 'committed', (error: Error) => error.message);
  await flush26();
  expect(release).toBeTypeOf('function');
  expect(ports26.bytes.get(KEY)).not.toBe(before);
  expect(JSON.parse((await getPrivateItem(KEY))!).products[0].name).toBe('Synthetic changed boundary probe');
  current = false;
  release!();
  expect(await pending).toBe('EXTERNAL_UI_OPERATION_RETIRED');
  expect(ports26.bytes.get(KEY)).toBe(before);
  expect(writes).toHaveBeenCalledTimes(2);
  expect(await loadShelf()).toHaveLength(1);
});

it('does not reverse an already completed operation when its additional guard later retires', async () => {
  let current = true;
  const writes = vi.spyOn(AsyncStorage, 'setItem');
  await updatePrivateItem(KEY, changedState, () => {
    if (!current) throw new Error('EXTERNAL_UI_OPERATION_RETIRED');
  });
  const committed = ports26.bytes.get(KEY);
  current = false;
  await flush26();
  expect(ports26.bytes.get(KEY)).toBe(committed);
  expect(writes).toHaveBeenCalledTimes(1);
  expect(await loadShelf()).toHaveLength(1);
});
