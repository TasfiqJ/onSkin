"""Independent external verifier probes; no source tree mutation."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import io
import json
import os
import stat
import struct
import tempfile
from types import SimpleNamespace
import zipfile

ROOT = Path(__file__).resolve().parents[2]
PATH = ROOT / 'packaging/verify27.py'
spec = importlib.util.spec_from_file_location('reviewed_verifier27', PATH)
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
results = []

def record(name, expected, operation):
    try:
        operation()
        outcome = 'accepted'
    except v.Refusal as error:
        outcome = str(error)
    except Exception as error:
        outcome = 'EXCEPTION_' + type(error).__name__
    results.append({'name': name, 'expected': expected, 'actual': outcome,
                    'passed': outcome == expected if expected == 'accepted' else outcome != 'accepted'})

def archive(entries):
    target = io.BytesIO()
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for name, data in entries:
            item = zipfile.ZipInfo(name, (2026, 10, 29, 0, 0, 0))
            item.create_system = 3
            item.external_attr = (stat.S_IFREG | 0o644) << 16
            item.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(item, data)
    return target.getvalue()

def checked_archive(raw):
    a = v.Archive(raw)
    for name in a.members: a.read(name)

valid = archive([('a.txt', b'one'), ('parent/b.txt', b'two')])
record('valid_archive', 'accepted', lambda: checked_archive(valid))
for label, names in (
    ('traversal', ['../a']), ('absolute', ['/a']), ('drive', ['C:/a']),
    ('device', ['NUL.txt']), ('trailing_dot', ['a.']),
    ('duplicate', ['a','a']), ('casefold', ['A','a']),
    ('implicit_parent_casefold', ['A/x','a/y']), ('nfkc', ['K/x','\u212a/y']),
    ('parent_file_collision', ['a','a/b']), ('parent_file_collision_reverse', ['a/b','a']),
):
    raw = archive([(name,b'x') for name in names])
    record(label, 'refused', lambda raw=raw: checked_archive(raw))

# ZipInfo itself normalizes Windows separators, so construct the malicious
# member by changing both framed names after writing a normal ZIP.
backslash=archive([('a/b',b'x')]).replace(b'a/b',b'a\\b')
record('backslash', 'refused', lambda: checked_archive(backslash))

def changed_byte(raw, position, value):
    out=bytearray(raw); out[position]=value; return bytes(out)

record('trailing_archive_bytes', 'refused', lambda: checked_archive(valid+b'x'))
record('local_timestamp_mismatch', 'refused', lambda: checked_archive(changed_byte(valid, 10, valid[10]^1)))
record('local_name_mismatch', 'refused', lambda: checked_archive(changed_byte(valid, 30, ord('b'))))
record('local_crc_mismatch', 'refused', lambda: checked_archive(changed_byte(valid, 14, valid[14]^1)))
central=valid.index(b'PK\x01\x02')
link=bytearray(valid); struct.pack_into('<I',link,central+38,(stat.S_IFLNK|0o777)<<16)
record('symlink_member', 'refused', lambda: checked_archive(bytes(link)))
record('json_duplicate_key', 'refused', lambda: v.loads(b'{"a":1,"a":2}'))
record('json_float', 'refused', lambda: v.loads(b'{"a":1.0}'))
record('json_nonfinite', 'refused', lambda: v.loads(b'{"a":NaN}'))
record('inventory_boolean_size', 'refused', lambda: v.inventory({'a':{'bytes':True,'sha256':'0'*64}}))

disk_root=Path(tempfile.mkdtemp(prefix='reader-',dir=Path(__file__).parent))
plain=disk_root/'plain.txt';plain.write_bytes(b'original file')
record('unchanged_real_reader','accepted',lambda:v.read_regular(plain))
linked=disk_root/'linked.txt';os.link(plain,linked)
record('hardlink_reader','refused',lambda:v.read_regular(plain))
linked.unlink()
record('restored_single_link_reader','accepted',lambda:v.read_regular(plain))
original_read=v.os.read
mutated=[False]
def mutating_read(fd,count):
    raw=original_read(fd,count)
    if not mutated[0]:
        mutated[0]=True
        with plain.open('ab') as file:file.write(b' mutation')
    return raw
v.os.read=mutating_read
record('real_midread_append','refused',lambda:v.read_regular(plain))
v.os.read=original_read
plain.write_bytes(b'original file')
record('restored_bytes_reader','accepted',lambda:v.read_regular(plain))
stamp=dict(st_atime=1,st_atime_ns=1,st_ctime=2,st_ctime_ns=2,st_mtime=3,st_mtime_ns=3,st_mode=stat.S_IFREG|0o644,st_ino=4,st_dev=5,st_nlink=1,st_size=6)
for field in stamp:
    other={**stamp,field:stamp[field]+1}
    equal=v.stable_metadata(SimpleNamespace(**stamp),SimpleNamespace(**other))
    expected=field in ('st_atime','st_atime_ns')
    results.append({'name':'same_domain_'+field,'expected':expected,'actual':equal,'passed':expected==equal})

payload=archive([('evidence.txt',b'qualified evidence')])
members={'README.md':b'readme','REPORT.md':b'report','payload.zip':payload,'verify27.py':PATH.read_bytes()}
manifest={'schema':1,'authority':v.AUTHORITY,'status':'SUBMITTED_REVIEW_REQUIRED','acceptanceGranted':False,
 'release':'NO_GO','inputManifestSHA256':v.INPUT,'source':{'base':v.BASE,'baseTree':v.BASE_TREE,
 'runtimeHead':'1'*40,'runtimeTree':'2'*40,'sourceHead':'3'*40,'sourceTree':'4'*40},
 'files':{name:{'bytes':len(raw),'sha256':v.sha(raw)} for name,raw in members.items()},
 'payload':{'schema':1,'files':{'evidence.txt':{'bytes':len(b'qualified evidence'),'sha256':v.sha(b'qualified evidence')}},
 'qualification':'SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE'}}

def packet(value):
    raw=json.dumps(value,sort_keys=True).encode(); return v.Archive(archive([*members.items(),('manifest.json',raw)])),v.sha(raw)
for label, mutate in (
 ('manifest_boolean_schema',lambda m:m.update(schema=True)),
 ('manifest_fake_acceptance',lambda m:m.update(acceptanceGranted=True)),
 ('manifest_wrong_base',lambda m:m['source'].update(base='9'*40)),
):
    val=copy.deepcopy(manifest);mutate(val); container,anchor=packet(val)
    record(label,'refused',lambda container=container,anchor=anchor:v.checkpoint(container,anchor))
container,anchor=packet(manifest)
record('valid_checkpoint_archive_artifact_only','accepted',lambda:v.checkpoint(container,anchor))

for mode in ('unchanged_directory','extra_after_inventory','alter_previously_read_member','same_size_restored_mtime_member'):
    root=Path(tempfile.mkdtemp(prefix=mode+'-',dir=Path(__file__).parent))
    all_members={**members,'manifest.json':json.dumps(manifest,sort_keys=True).encode()}
    for name,raw in all_members.items(): (root/name).write_bytes(raw)
    class MutatingDirectory(v.Directory):
        armed=False
        changed=False
        def exact(self,expected):
            super().exact(expected); self.armed=True
        def read(self,name):
            raw=super().read(name)
            if self.armed and not self.changed:
                if mode=='extra_after_inventory':
                    (self.root/'unexpected.txt').write_bytes(b'unlisted')
                    self.changed=True
                elif name=='REPORT.md' and mode!='unchanged_directory':
                    target=self.root/'README.md'
                    prior=target.stat()
                    target.write_bytes(b'xxxxxx' if mode=='same_size_restored_mtime_member' else b'CHANGED AFTER AUTHENTICATED READ')
                    if mode=='same_size_restored_mtime_member': os.utime(target,ns=(prior.st_atime_ns,prior.st_mtime_ns))
                    self.changed=True
            return raw
    container=MutatingDirectory(root)
    record(mode,'accepted' if mode=='unchanged_directory' else 'refused',lambda container=container:v.checkpoint(container,v.sha(all_members['manifest.json'])))

output={'verifierSHA256':hashlib.sha256(PATH.read_bytes()).hexdigest(),
 'returnVerifierSHA256':hashlib.sha256((ROOT/'packaging/verify_return27.py').read_bytes()).hexdigest(),
 'modeOnlyDifference':(ROOT/'packaging/verify_return27.py').read_bytes().replace(b"MODE = 'return'",b"MODE = 'checkpoint'",1)==PATH.read_bytes(),
 'qualification':'SYNTHETIC_HELPER_REVIEW_NOT_FINAL_SOURCE_OR_ARTIFACT_ACCEPTANCE','results':results}
(Path(__file__).parent/'results.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
