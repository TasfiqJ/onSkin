export default {
  "root": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/apps/mobile",
  "cacheDir": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-evidence/vite-cache",
  "resolve": {
    "alias": {
      "@": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/apps/mobile/src",
      "react": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/node_modules/react",
      "react-test-renderer": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/node_modules/react-test-renderer",
      "@tanstack/react-query": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/node_modules/@tanstack/react-query",
      "vitest": "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/node_modules/vitest/dist/index.js"
    }
  },
  "test": {
    "environment": "node",
    "include": [
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-evidence/detail-pending-retirement.test.ts",
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/apps/mobile/src/features/shelf/detailActionSheet.campaign26.test.ts",
      "C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign27-run-taxf1ogb/app-review/apps/mobile/src/features/shelf/manualDraftRecovery.campaign26.test.ts"
    ]
  }
};
