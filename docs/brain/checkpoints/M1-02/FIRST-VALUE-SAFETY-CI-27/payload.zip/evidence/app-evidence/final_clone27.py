"""External final-head proof harness. Run only after the sole evidence tail.

Creates one fresh full remote clone per invocation, with an independent object
store and fresh npm cache. Changes only that disposable test clone and a
separate checkpoint copy. Protected bytes stay in memory and are never emitted.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tempfile
import time
import types

RUN = Path(__file__).resolve().parents[1]
REMOTE = 'https://github.com/TasfiqJ/onSkin.git'
CHECKPOINT = 'docs/brain/checkpoints/M1-02/FIRST-VALUE-SAFETY-CI-27'
PRIVATE_SOURCE = 'apps/mobile/src/lib/storage/privateKV.ts'
NPM_MODEL = 'c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9'


class Stop(ValueError):
    pass


def need(ok, category):
    if not ok:
        raise Stop(category)


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()


def load_verifier(anchor):
    path = RUN/'packaging/verify27.py'
    with path.open('rb') as stream:
        raw = stream.read(100001)
    need(len(raw) <= 100000 and hashlib.sha256(raw).hexdigest() == anchor, 'EXTERNAL_VERIFIER_ANCHOR')
    module = types.ModuleType('final_clone_anchored_verifier27')
    module.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    need(module.read_regular(path, 100000) == raw, 'EXTERNAL_VERIFIER_CHANGED')
    return module


def write_new(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)


def identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink)


class Harness:
    def __init__(self, args, verifier):
        self.args, self.v = args, verifier
        self.environment = {key: value for key, value in os.environ.items()
            if not key.upper().startswith(('GIT_', 'NPM_', 'PYTHON', 'GITHUB_', 'PHASE4_'))
            and key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
        self.environment['PATH'] = str(Path(args.npm_prefix).absolute())+os.pathsep+self.environment['PATH']
        clones, receipts = RUN/'final-clones', RUN/'final-verification'
        for area in (clones, receipts):
            area.mkdir(exist_ok=True)
            verifier.node(area, True)
        self.workspace = Path(tempfile.mkdtemp(prefix=args.label+'-', dir=clones))
        self.output = receipts/self.workspace.name
        self.output.mkdir()
        self.clone, self.artifact = self.workspace/'checkout', self.workspace/'checkpoint-copy'
        self.records = []
        self.summary = dict(schema=1, label=args.label, head=args.expected_head, tree=args.expected_tree,
            manifestSHA256=args.expected_manifest_sha256, verifierSHA256=args.expected_verifier_sha256,
            helperSHA256=verifier.sha(verifier.read_regular(Path(__file__))),
            status='RUNNING', acceptanceGranted=False, release='NO_GO',
            source='FRESH_FULL_REMOTE_CLONE', sourceTamperSequence=[], artifactTamperSequence=[],
            protectedRawBytesOrNewHashesDisclosed=False, records=self.records)
        self.persist()

    def persist(self):
        # External mutable progress, outside clone and the sealed checkpoint.
        (self.output/'final-clone-receipt.json').write_bytes(encode(self.summary))

    def command(self, label, argv, cwd, expected=0, timeout=900):
        need(not any(item['label'] == label for item in self.records), 'DUPLICATE_STEP')
        started = time.monotonic()
        record = dict(label=label, argv=[str(a) for a in argv], expectedExit=expected, exit=None)
        self.records.append(record)
        self.persist()
        try:
            code, stdout, stderr = self.v._execute([str(a) for a in argv], cwd, timeout,
                32*1024*1024, supplied_env=self.environment)
            record['exit'] = code
            record['elapsedMilliseconds'] = round((time.monotonic()-started)*1000)
            for suffix, raw in (('stdout.log', stdout), ('stderr.log', stderr)):
                name = label+'.'+suffix
                write_new(self.output/name, raw)
                record[suffix] = dict(path=name, bytes=len(raw), sha256=self.v.sha(raw))
            self.persist()
            need(code == expected, 'UNEXPECTED_STEP_EXIT')
            return stdout
        except BaseException:
            record['interruptedOrFailed'] = True
            self.persist()
            raise

    def git(self, *args):
        return self.v.git(self.clone, *args).decode().strip()

    def clean(self):
        need(self.git('rev-parse', 'HEAD') == self.args.expected_head and
             self.git('rev-parse', 'HEAD^{tree}') == self.args.expected_tree, 'FINAL_IDENTITY')
        need(not self.git('status', '--porcelain=v1', '--untracked-files=all'), 'CHECKOUT_DIRTY')

    def verify(self, label, expected=0):
        raw = self.command(label, self.full_command, self.clone, expected=expected, timeout=2400)
        try:
            result = json.loads(raw)
        except ValueError:
            raise Stop('VERIFIER_OUTPUT_SCHEMA') from None
        need(type(result) is dict and result.get('acceptanceGranted') is False and
             result.get('release') == 'NO_GO', 'VERIFIER_OUTPUT_SCHEMA')
        if expected == 0:
            need(result.get('status') == 'VERIFIED' and result.get('git', {}).get('head') == self.args.expected_head and
                 result.get('git', {}).get('tree') == self.args.expected_tree and
                 result.get('sourceChecks', {}).get('release27') == 'PASS_FINITE_SOURCE_GOVERNANCE_ONLY' and
                 result.get('sourceChecks', {}).get('phase4') == 'PASS_UNCHANGED_PRODUCER_STRICT_CHECK',
                 'FULL_SOURCE_PROOF_MISSING')
        else:
            need(result.get('status') == 'CONTEXT_INVALID', 'REFUSAL_PROOF_MISSING')
        return result

    def mutation_control(self, path, payload, label, expected_refusal):
        before = path.lstat()
        original = self.v.read_regular(path)
        need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1, 'MUTATION_TARGET')
        try:
            with path.open('r+b') as stream:
                stream.seek(0, 2)
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            need(identity(path.lstat()) == identity(before) and self.v.read_regular(path) == original+payload,
                 'MUTATION_NOT_APPLIED')
            refusal = self.verify(label+'-tampered', 1)
            self.summary[label+'Refusal'] = dict(expected=expected_refusal,
                observed=refusal.get('error'), matched=refusal.get('error') == expected_refusal)
            self.persist()
            need(refusal.get('error') == expected_refusal, 'UNEXPECTED_REFUSAL_CATEGORY')
        finally:
            # Do not leave even the isolated clone's protected bytes modified.
            with path.open('r+b') as stream:
                stream.seek(0)
                stream.write(original)
                stream.truncate()
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(path, stat.S_IMODE(before.st_mode))
            os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
            need(identity(path.lstat()) == identity(before) and self.v.read_regular(path) == original,
                 'RESTORATION_FAILED')
            self.summary[label+'Restoration'] = dict(exactBytes=True, identityModeAndLinks=True,
                originalModificationTimeRestored=path.stat().st_mtime_ns == before.st_mtime_ns,
                changeTimeResetClaim=False, protectedContentOrDigestDisclosed=False)
            self.persist()
        restored = self.verify(label+'-restored', 0)
        return refusal, restored

    def run(self):
        args, v = self.args, self.v
        git = shutil.which('git')
        need(git is not None, 'GIT_UNAVAILABLE')
        self.command('clone', [git, '-c', 'core.hooksPath=', '-c', 'core.autocrlf=false', '-c', 'core.longpaths=true',
            'clone', '--no-local', '--no-hardlinks', '--no-checkout', '-c', 'core.autocrlf=false',
            '-c', 'core.longpaths=true', REMOTE, self.clone], self.workspace)
        self.command('checkout', [git, '-c', 'core.hooksPath=', 'checkout', '--detach', args.expected_head], self.clone)
        self.clean()
        need(self.git('rev-parse', '--is-shallow-repository') == 'false' and not (self.clone/'.git/shallow').exists(),
             'INCOMPLETE_CLONE')
        need(not (self.clone/'.git/objects/info/alternates').exists(), 'SHARED_OBJECTS')
        v.standalone_git_store(self.clone)
        self.command('fsck', [git, '--no-replace-objects', 'fsck', '--full', '--strict'], self.clone)
        tracked = v.git_tree(self.clone, 'HEAD')
        count = v.hash_worktree(self.clone, tracked)
        store = (self.clone/'.git/objects').lstat()
        self.summary['cloneProof'] = dict(remote=REMOTE, complete=True, separateObjectStore=True,
            objectStoreDirectoryIdentity=dict(device=store.st_dev, inode=store.st_ino),
            noAlternates=True, noSharedOrHardlinkedObjectFiles=True, trackedRawBlobsReconciled=count,
            rawBlobDigestsDisclosed=False)
        self.persist()
        need(not (self.clone/'node_modules').exists() and
             not any(p.exists() for area in ('apps', 'packages') for p in (self.clone/area).glob('*/node_modules')),
             'FRESH_INSTALL_REQUIRED')
        loader = "import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
        tools_raw = self.command('toolchain-before', [sys.executable, '-I', '-B', '-c', loader], self.clone)
        tools = json.loads(tools_raw)
        need(tools.get('tools', {}).get('npm', {}).get('version') == '11.20.0' and
             tools['tools']['npm'].get('installationModelSHA256') == NPM_MODEL, 'UNSUPPORTED_TOOLCHAIN')
        node = Path(args.npm_prefix).absolute()/('node.exe' if os.name == 'nt' else 'bin/node')
        npm = Path(args.npm_prefix).absolute()/('node_modules/npm/bin/npm-cli.js' if os.name == 'nt' else 'lib/node_modules/npm/bin/npm-cli.js')
        need(v.sha(v.read_regular(node)) == tools['tools']['node']['executableSHA256'] and
             v.sha(v.read_regular(npm)) == tools['tools']['npm']['cliSHA256'], 'TOOL_PREFIX_IDENTITY')
        cache = self.workspace/'npm-cache'
        cache.mkdir()
        empty_config = self.workspace/'empty-global.npmrc'
        write_new(empty_config, b'')
        self.command('normal-npm-ci', [node, npm, 'ci', '--ignore-scripts=false', '--cache', cache,
            '--userconfig', os.devnull, '--globalconfig', empty_config, '--no-audit', '--no-fund'], self.clone)
        hooks_raw = self.command('mandatory-hooks', [node, 'scripts/postinstall.mjs', '--check'], self.clone)
        hooks = json.loads(hooks_raw)
        need(hooks.get('check') is True and hooks.get('toolingSecurity') == 'checked', 'MANDATORY_HOOKS')
        tools_after = json.loads(self.command('toolchain-after', [sys.executable, '-I', '-B', '-c', loader], self.clone))
        need(tools_after == tools, 'TOOLCHAIN_CHANGED')
        self.clean()
        need(v.hash_worktree(self.clone, tracked) == count, 'POSTINSTALL_SOURCE_CHANGED')
        self.summary['installation'] = dict(npmVersion='11.20.0', installationModelSHA256=NPM_MODEL,
            normalCiExit=0, freshCache=True, freshNodeModules=True, mandatoryHooks=True,
            postinstallCheckExit=0, nativeSourceOnlyNotDeviceAcceptance=True)
        self.artifact.mkdir()
        for name in sorted(v.CHECKPOINT_FILES):
            write_new(self.artifact/name, v.read_regular(self.clone/CHECKPOINT/name))
        need(v.sha(v.read_regular(self.artifact/'manifest.json')) == args.expected_manifest_sha256 and
             v.sha(v.read_regular(self.artifact/'verify27.py')) == args.expected_verifier_sha256,
             'CHECKPOINT_EXTERNAL_ANCHORS')
        v.checkpoint(v.Directory(self.artifact), args.expected_manifest_sha256)
        self.full_command = [sys.executable, '-I', '-B', str(self.artifact/'verify27.py'),
            '--root', str(self.artifact), '--git-root', str(self.clone),
            '--expected-manifest-sha256', args.expected_manifest_sha256,
            '--expected-verifier-sha256', args.expected_verifier_sha256,
            '--expected-head', args.expected_head, '--expected-tree', args.expected_tree, '--execute-source-checks']
        self.summary['unchangedFullCommand'] = self.full_command
        self.verify('baseline-full', 0)
        self.clean()
        private_mode, private_blob = tracked[PRIVATE_SOURCE]
        self.summary['protectedTarget'] = dict(path=PRIVATE_SOURCE, gitMode=private_mode, gitBlob=private_blob,
            rawBytesAndAdditionalHashesPublished=False)
        self.mutation_control(self.clone/PRIVATE_SOURCE, b'\n// Campaign27 isolated tamper-control comment.\n',
            'protected-source', 'GIT_CHECKOUT_DIRTY')
        self.summary['sourceTamperSequence'] = [0, 1, 0]
        self.clean()
        self.mutation_control(self.artifact/'REPORT.md', b'\nCampaign27 isolated artifact corruption control.\n',
            'artifact', 'ARTIFACT_HASH_MISMATCH')
        self.summary['artifactTamperSequence'] = [0, 1, 0]
        self.clean()
        v.standalone_git_store(self.clone)
        need(v.hash_worktree(self.clone, tracked) == count, 'FINAL_RAW_BLOB_RECONCILIATION')
        need({p.name for p in self.artifact.iterdir()} == v.CHECKPOINT_FILES and
             all(v.read_regular(self.artifact/name) == v.read_regular(self.clone/CHECKPOINT/name)
                 for name in v.CHECKPOINT_FILES), 'ARTIFACT_EXACT_RESTORATION')
        verifier_steps = [item for item in self.records if item['label'] in (
            'baseline-full', 'protected-source-tampered', 'protected-source-restored', 'artifact-tampered', 'artifact-restored')]
        need(len(verifier_steps) == 5 and all(item['argv'] == self.full_command for item in verifier_steps),
             'CHANGED_FULL_COMMAND')
        self.summary.update(status='PASS_FINAL_CLONE_SOURCE_CHECKPOINT_PHASE4_AND_REAL_CONTROLS',
            cleanAfter=True, finalHead=self.git('rev-parse', 'HEAD'), finalTree=self.git('rev-parse', 'HEAD^{tree}'),
            trackedRawBlobsReconciledAfter=count, fullCommandIdenticalAcrossFiveInvocations=True,
            artifactCopyOutsideSource=True, finalHeadCINotClaimed=True)
        self.persist()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('label', 'npm-prefix', 'expected-head', 'expected-tree', 'expected-manifest-sha256', 'expected-verifier-sha256'):
        parser.add_argument('--'+name, required=True)
    args = parser.parse_args()
    need(re.fullmatch('clone-[ab]', args.label) is not None, 'LABEL_SCHEMA')
    for name in ('expected_head', 'expected_tree'):
        need(re.fullmatch('[0-9a-f]{40}', getattr(args, name)) is not None, 'SOURCE_ANCHOR_SCHEMA')
    for name in ('expected_manifest_sha256', 'expected_verifier_sha256'):
        need(re.fullmatch('[0-9a-f]{64}', getattr(args, name)) is not None, 'HASH_ANCHOR_SCHEMA')
    need(sys.version_info >= (3, 12) and sys.flags.optimize == 0, 'PYTHON_RUNTIME_REQUIRED')
    verifier = load_verifier(args.expected_verifier_sha256)
    harness = Harness(args, verifier)
    try:
        harness.run()
    except BaseException as error:
        category = error.args[0] if isinstance(error, Stop) else 'FINAL_CLONE_EXECUTION_FAILURE'
        harness.summary.update(status='FAILED_OR_INCOMPLETE', failureCategory=category)
        harness.persist()
        print(json.dumps({'status': 'FAILED_OR_INCOMPLETE', 'category': category, 'receiptDirectory': harness.output.name}))
        return 1
    print(json.dumps({'status': harness.summary['status'], 'receiptDirectory': harness.output.name,
                      'sourceTamperSequence': harness.summary['sourceTamperSequence'],
                      'artifactTamperSequence': harness.summary['artifactTamperSequence'], 'acceptanceGranted': False, 'release': 'NO_GO'}))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Stop, OSError, ValueError):
        print(json.dumps({'status': 'FAILED_OR_INCOMPLETE', 'category': 'HARNESS_BOOTSTRAP'}))
        raise SystemExit(1)
