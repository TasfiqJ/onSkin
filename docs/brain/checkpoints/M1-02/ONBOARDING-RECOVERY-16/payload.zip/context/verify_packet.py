#!/usr/bin/env python3
"""Verify Campaign16 context using the manifest digest pasted OUTSIDE the ZIP."""
import argparse,hashlib,json,stat,sys,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parent
AUTH='BRAIN-M1X-ONBOARDING-RESILIENCE16-CANDIDATE-01'

def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,why):
    if not ok: raise ValueError(why)
def read(path):
    cur=path
    while True:
        s=cur.lstat()
        need(not stat.S_ISLNK(s.st_mode) and not bool(getattr(s,'st_file_attributes',0)&1024),'LINK')
        if cur==path:need(stat.S_ISREG(s.st_mode) and s.st_size<=1024*1024 and s.st_nlink==1,'FILE')
        else:need(stat.S_ISDIR(s.st_mode),'DIR')
        if cur==cur.parent:break
        cur=cur.parent
    return path.read_bytes()
def run(anchor):
    need(len(anchor)==64 and all(c in '0123456789abcdef' for c in anchor),'ANCHOR_FORMAT')
    raw=read(ROOT/'MANIFEST.json');need(sha(raw)==anchor,'EXTERNAL_ANCHOR_MISMATCH')
    def pairs(items):
        d={}
        for k,v in items:need(k not in d,'DUP_KEY');d[k]=v
        return d
    m=json.loads(raw,object_pairs_hook=pairs)
    need(m['schema']==1 and m['authorization']==AUTH,'AUTHORITY')
    expected=set(m['files'])|{'MANIFEST.json','EXACT_PROMPT.md'}
    actual=set(p.name for p in ROOT.iterdir())
    need(actual==expected,'INVENTORY')
    seen=set()
    for name,rec in m['files'].items():
        need('/' not in name and '\\' not in name and name not in ('.','..') and name.strip()==name,'PATH')
        folded=unicodedata.normalize('NFKC',name).casefold()
        need(folded not in seen,'COLLISION');seen.add(folded)
        data=read(ROOT/name)
        need(len(data)==rec['bytes'] and sha(data)==rec['sha256'],'FILE:'+name)
    template=read(ROOT/'PROMPT_TEMPLATE.md')
    expected=template.replace(b'<EXTERNAL_MANIFEST_SHA256>',anchor.encode())
    need(template.count(b'<EXTERNAL_MANIFEST_SHA256>')==1,'PROMPT_TEMPLATE_SHAPE')
    need(read(ROOT/'EXACT_PROMPT.md')==expected,'PROMPT_DERIVATION')
    print('VERIFIED '+str(len(m['files']))+' authenticated files; EXACT_PROMPT derived; CONTEXT ONLY, no Git/Security/DB/product acceptance')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--expected-manifest-sha256',required=True);a=p.parse_args()
    try:run(a.expected_manifest_sha256)
    except Exception as e:print('CONTEXT_INVALID '+type(e).__name__);sys.exit(1)
