# onSkin V2 — Campaign16 full-app onboarding recovery

Authorization `BRAIN-M1X-ONBOARDING-RESILIENCE16-CANDIDATE-01`. This is ONE new non-Korean iPhone client-experience task, not M2 engineering, Security acceptance, or launch. The founder uploads one ZIP and pastes the COMPLETE direct prompt. The independent ChatGPT Brain alone later accepts scoped source. Codex is the sole new-branch writer.

Live authenticated starting target: PR19 draft HEAD `b79e6d1e21a367be5cea5d0b333de9f2a144d41f` with tree `ca7b6ac8ebcc0086b338b784f110b411400361b0`. Its source ancestor is `d04c36a025a0b0666e4f5f5253c65806b1fc49cf`, tree `98702f9112659e705b10d5914d0c4a6a6e4e32f4`. Main and Security are still protected; no merge.

Direction: full functioning real non-Korean app plus only possible Korean J01 Visible Pores after G1/G2/G3/G5, optional change G4; F09 photo history/manual compare retained, F18 and J02–J27 deferred. The original G97 source candidate is NOT accepted by its qualified owner; no Security/DB/device/paid/provider/clinical/Apple/release GO. Work ONLY on the permitted client-facing onboarding/resilience surfaces and source custody. No new real provider, OS push grant, cloud sync or model feature.
