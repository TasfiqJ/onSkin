# Campaign16 actual source and UX report

Authority: BRAIN-M1X-ONBOARDING-RESILIENCE16-CANDIDATE-01. Source-only candidate, submitted for independent Brain review. Overall PARTIAL_BLOCKED by original Security/DB/device/external gates. No acceptance, merge, main promotion, provider enablement or paid service.

Draft PR20: https://github.com/TasfiqJ/onSkin/pull/20. Branch `stage/m1-first-session-recovery16`; exact base `stage/m103-g97-coverage-candidate15` / b79e6d1e21a367be5cea5d0b333de9f2a144d41f, tree ca7b6ac8ebcc0086b338b784f110b411400361b0. Draft/open/unmerged, auto-merge OFF, maintainer modification OFF independently read through GitHub. Main and PR10–19 remain pinned and read-only.

Frozen source 3970ed1802ea928e50db1b12ec7e08a020355b09, tree 3da45d639deac52858480e982cbc19f438eb5f88. Runtime/test code freeze 015e3e8676dda6fd8c63b8de6de0ebe5c4b35345, tree 39f38e1a9c8eec2c1d68c30d07811ec45c67d7cd. The following source commit only corrects generated worklist metadata through the unchanged producer. Every intermediate commit, changed path, Git mode, blob, SHA256 and byte size is in `proof/intermediate-changes.json` and `proof/source-delta.json`. The complete source and identical baseline frontier are in the two compressed JSONL inventories. Exact final evidence-head/tree/CI are supplied post-tail in the external return, avoiding circular commit identities.

Context authentication: the one supplied ZIP was extracted into a new empty task directory after path/mode/reparse/Unicode NFKC-casefold collision and overwrite checks. From that root, exactly `python -B verify_packet.py --expected-manifest-sha256 e5c069d8ebda68a3d04469af7bd613a266bbc7393775a194946c813362674f7f` returned exit0, VERIFIED 7 authenticated files, EXACT_PROMPT derived. Nine regular files are accounted for by the seven authenticated members, externally anchored manifest and derived prompt. The context grants no product or Security authority. Historical Campaign15 source d04c36a025a0b0666e4f5f5253c65806b1fc49cf / tree 98702f9112659e705b10d5914d0c4a6a6e4e32f4 was checked as an ancestor of the exact base.

## Delivered behavior

Reminder recovery uses a synchronous admission ref, exact focus/health lease checks, visible accessible notices and explicit continuation. Storage failure cannot silently advance. NotificationPreferenceSaveError is distinguished from a failed save. Retry uses the original ordered application queue with an empty patch, so it applies current durable intent and never replays permission or an older opt-in. Denied/blocked/unavailable outcomes only describe OFF after the original durable write succeeds. When OFF is durable but native convergence fails, an explicit acknowledgement can retry durable OFF and continue with cancellation/delivery honestly unconfirmed; existing reminders may remain. A later failed write cannot inherit the old OFF receipt. No changes to applyPreferences.ts, its tests, durable schema or native scheduler were necessary.

Quiz navigation admits one transition per rendered question and resets its route sentinel on real focus after Products→Back. Reentry checks consent again. Stale Back/Next callbacks cannot skip unanswered questions or double navigate. The installed Expo NavigationContext is imported directly from its pure module; SDK upgrades must reverify that internal import. Current Expo web, TypeScript and original mounted route tests exercise it. Questions, content/scoring contracts, pregnancy handling, age/health consent and profile persistence remain untouched.

The compact Products footer retains an explicit Skip/Continue-with-N action while typing. Unsaved text requires Keep editing or explicit Continue without adding it; editing retains the text. Existing Shelf availability, category/name limits, opened-date intake, current health generation, missing-goal recovery and removal barriers remain. This improves manual intake only and establishes no catalog/provider readiness. No new app network, provider or telemetry call was added.

## Tests and evidence qualifications

| Evidence | Actual result | Scope |
| --- | --- | --- |
| New mounted component/pure tests | 28 PASS | Real route components and production reminder store/ordered queue/health leases, synthetic external ports; not OS delivery |
| Forced root tests | 6194 mobile +24 operator =6218 PASS, zero cache hits | Local recorded command and identities retained; exact final-head CI supplied separately |
| Typecheck / lint | PASS | Forced repository commands; full receipts retained |
| Release16 | 153 refusals +6 positive controls PASS | Synthetic Git index/history fixtures, allocated PR20; not independent-checkout proof |
| Source09–15 | All seven original source consumers PASS | Exact historical full materializations, shared Git objects; not independent clones |
| Dependency11/12/13 | Original 9/49/66 controls PASS | Exact original readers/fixtures |
| Original governed provenance | 66 PASS | Original finite-buffer/provenance tests unchanged |
| Original Security14 Python tests | 6 PASS | Separate source/inventory tests; no Security acceptance |
| Native privacy source/archive probes | 315 PASS, 4 SKIP | Windows cannot create required file links; source-only, no signed archive/device proof |
| Independent complete checkout | Source current/tampered/restored 0/1/0 | Full clone, no alternates, no hardlinks, complete objects; authenticated installed native source pins copied solely for source probes, no independent npm install/build claim |
| Independent original Phase4 consumer | Semantic current/forged/restored 0/1/0 | Exact same complete checkout; forged sourcePathCount421 rejected, original420 restored |
| Real Expo web matrix | PASS at 360×640,375×667,390×844,430×932 | Existing dev-only synthetic adult/anonymous-owner fixture; 53 screenshots + UI JSON snapshots, executed driver and console/network logs |
| Original151 semantic negatives | Local command started; completion/status is explicit in receipts or progress record | Exact final-head CI result is post-tail evidence, never inferred from an incomplete local run |

Browser evidence proves fresh start/direct age fencing→adult→dedicated consent→goals→unchanged 12-question quiz→Products→real Back→mounted final Quiz→Products. It covers empty Shelf and one actually saved manual product, long labels, unsaved choice/Keep editing, storage failure staying on Reminders, actual keyboard Enter Retry, current OFF receipt and explicit Account continuation. All53 snapshots have zero horizontal overflow; no console error/exception was recorded; all app network origins were localhost. The five runtime source files were verified byte-identical between the browser's tested commit and the final frozen source, and the captured executed driver SHA256 matches the frozen driver.

Keyboard-open pressure is a reduced browser viewport, not a native keyboard. Text pressure doubles existing DOM leaf text, and mounted tests also use fontScale2. Reduced-motion media was enabled. Browser Notification.requestPermission was replaced by a rejecting test port before navigation: one request was blocked per viewport, and no real OS permission request was made. Those unavailable/OFF observations are synthetic-port web evidence, not OS-denied/device evidence. There is no Playwright/video or native simulator claim.

Before-fix failures were reproduced with mounted actual route components under synthetic ports; no before-fix browser screenshot is claimed. Storage/scheduling/owner outcomes outside web capability are tested with explicit synthetic ports and remain separate from real browser evidence.

## Bug records (repository E2E template fields)

### Reminder error silently advances

Severity High. Surface Mixed: mounted actual route reproduction plus post-fix Expo web. Fixture: synthetic adult/current health lease; no provider/destructive action. Reproduce: mount soft ask, refuse preference persistence or scheduling, tap the choice. Expected: stay, explain failure, offer recovery. Actual base: finally always pushes Account, including retired-owner and unmounted completions. Frequency deterministic. Cause: unconditional finally navigation and React-state-only admission. Fix: synchronous admission, lease/focus fencing, explicit saved/error states and current-intent retry. Post-fix: reminder-red-mounted log records initial failures; new 14 reminder tests pass; browser reminder-storage-failure/retry-off and keyboard snapshots at all four sizes pass. Remaining risk: native delivery/cancellation/permission sheet and VoiceOver NOT_RUN.

### Final Quiz return cannot continue

Severity Medium. Surface mounted route plus real Expo web post-fix. Reproduce: finish final answer, go Products, return to the same mounted Quiz, press final action again; include rapid queued Back/Next. Expected: one valid continuation per focus/render. Actual base: navigationIndex remains beyond the final rendered question, so final action is inert; stale Back can overwrite the navigation sentinel. Cause: unrecovered ref state. Fix: deterministic transition helper and focus-bound consent/reset. Post-fix: actual browser mounted-return snapshots at all four sizes and original/new mounted tests pass. No quiz content/scoring/answer storage changed. Native stack/device behavior remains NOT_RUN.

### Typed compact Products hides continuation

Severity Medium. Surface mounted route and real Expo web. Reproduce: type into Product name in compact keyboard/text pressure with empty or populated Shelf. Expected: discoverable Skip or Continue with N, with an explicit unsaved choice. Actual base: compactFooterAdds swaps the primary to Add and suppresses Continue. Fix: retain secondary continuation and explicit unsaved-text choice in a scrollable footer, retaining goals/health/removal barriers. Post-fix: empty and one-saved-product real web paths, 0/1/2/3/20 fixture counts, long labels and reduced motion pass. Physical keyboard/Dynamic Type/VoiceOver and full catalog onboarding remain NOT_RUN/not established.

## Failures retained and corrected

All exploratory command/browser failures are retained, not recast as passes. Initial incorrect Vitest root selection found no tests; the corrected mounted invocation reproduced the defects. The first full root run exposed legacy mock assumptions and two lint errors; production focus handling and lint were corrected within permitted files. A later full run overlapped a Git commit and failed its status-stability assertion; the stable forced rerun passed all6218. Browser harness corrections added visible-element filtering, radio locators, correct Enter text and visible input selection for stacked screens. Earlier browser failures, snapshots and executed-driver hashes (where captured) remain separate. No unavailable earlier driver snapshot is invented.

An initial Phase4 producer run captured dirty checkout metadata. The unchanged producer was then run from the clean code freeze; a projection-only commit now passes clean check with14 original tasks,7 blocked/7 scaffold,420 occurrences,0 missing. No projection was hand edited. The first independent worklist negative fixture only added whitespace, which the original semantic consumer correctly normalizes; the corrected semantic mutation421 is refused and original420 restored. Missing historical dependency filenames were invocation mistakes; exact original dependency_guard11/12/13 commands subsequently passed. All records distinguish those attempts from the final proof.

## Protected and unapplied boundaries

All root/nested instructions and the authenticated00–04 packet were read for this scoped work. Only the finite authorized source paths changed. Complete inventories prove base path/mode/blob/SHA identities and absences; .github, original launch/phase2/phase4/phase9 producers/consumers, Security/scanners/custody/history/manifests, dependencies/locks/native mappings, OnboardingContext, immutable quiz/scoring, age/consent/storage, Supabase/SQL/RLS/Edge, providers and all old checkpoints/state remain unchanged. The sole later root handoff delta is separately identified in the evidence tail.

G97 FAIL/NO_GO; PR19 source coverage candidate remains OWNER_REVIEW_REQUIRED. DB06/DB08/R2B NOT_ACCEPTED. M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED. M2 NOT_AUTHORIZED. CAT07/readiness, real native phone/OS delivery, signed binary, VoiceOver, provider/paid, Apple/App Store, human legal/clinical consent, J01 authenticated dossier and public-release gates remain closed/NOT_RUN. First PUBLIC iPhone still requires full real non-Korean F01–F17/F19–F20,12 V2-C and6 P groups and J01 only after independent G1/G2/G3/G5 (plus G4 for longitudinal change); F09 private encrypted diary/history/manual comparison remains required. F18 automated trends and J02–J27 including J05 remain deferred. No pore/medical/accuracy output or gate admission was added.

Local WSL could not start because its configured VHDX path is absent; native/signed/hosted/professional evidence is not fabricated. Original CI remains fail-closed: source snapshot has Security static/code/secret/acceptance failures, live Supabase skipped, canonical DB H01_SQL_PROBE_FAILED / Data limit exceeded; PG15/17 and iOS source checks pass. This source CI snapshot is not final-head CI. Final delivery jobs, all failures/skips, live refs, clean/0-unpushed and final artifact falsification are supplied after the sole tail in the external return.

USD0 incremental paid services/purchases; no dependencies installed/changed, no actual account/health/photo data, no provider contacted or enabled, no merge, force-push, reset, rebase, stash-overwrite or unknown-file deletion on the implementation checkout. Founder makes no technical choices. Independent Brain acceptance remains required.
