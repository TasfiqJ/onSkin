from pathlib import Path
import subprocess, json, hashlib

repo = Path(r'C:\Users\jasim\Desktop\WeddingCards\work\m102-retained-resilience')
out = Path(__file__).parent
anchor = 'f3543284d388334c7d9a6155fc408aea2a1b272e'
source = '3b7e212a7ae37f44759d52e1b4220507cf3965e0'
checkpoint = 'docs/brain/checkpoints/M1-02/LEAN-V1-FIRST-WEEK-EXPERIENCE-07'
def git(*args): return subprocess.check_output(['git', *args], cwd=repo)
paths = git('diff', '--name-only', anchor, source).decode().splitlines()
assert len(paths) == 11, paths
def entry(ref, path):
    raw = git('ls-tree', '-z', ref, '--', path)
    if not raw: return None
    mode, kind, oid = raw.split(b'\t', 1)[0].decode().split()
    assert kind == 'blob'
    data = git('cat-file', 'blob', oid)
    return dict(mode=mode, blob=oid, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
changes = [dict(path=p, before=entry(anchor,p), after=entry(source,p)) for p in paths]
exempt = paths + [checkpoint, 'ONSKIN_BRAIN_HANDOFF.txt']
witnesses = []
def walk(prefix=''):
    for line in git('ls-tree', '-z', anchor+(':'+prefix if prefix else '')).split(b'\0'):
        if not line: continue
        meta, name = line.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        path = (prefix+'/' if prefix else '')+name.decode()
        if path in exempt: continue
        if any(p.startswith(path+'/') for p in exempt):
            assert kind == 'tree'; walk(path)
        else:
            assert git('ls-tree','-z',source,'--',path).split(b'\t',1)[0] == meta, path
            witnesses.append(dict(path=path, mode=mode, kind=kind, object=oid))
walk()
absent = ['apps/mobile/ios','apps/mobile/android','apps/mobile/app.config.ts']
for path in absent: assert not git('ls-tree',source,'--',path)
history = []
for commit in git('rev-list','--reverse',anchor+'..'+source).decode().splitlines():
    changed = git('diff-tree','--no-commit-id','--name-only','-r',commit).decode().splitlines()
    assert set(changed) <= set(paths), (commit,changed)
    history.append(dict(commit=commit, tree=git('rev-parse',commit+'^{tree}').decode().strip(), changed=changed))
result = dict(anchor=anchor, anchor_tree=git('rev-parse',anchor+'^{tree}').decode().strip(),
              source=source, source_tree=git('rev-parse',source+'^{tree}').decode().strip(),
              changes=changes, protected_frontier=witnesses, protected_absences=absent,
              intermediate_commits=history,
              semantics='An exhaustive unchanged Git tree/blob frontier outside the exact finite source and additive evidence grants; not Security/source acceptance.')
(out/'source-scope.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(changed=len(changes),protected_frontier=len(witnesses),absences=len(absent),commits=len(history))))
