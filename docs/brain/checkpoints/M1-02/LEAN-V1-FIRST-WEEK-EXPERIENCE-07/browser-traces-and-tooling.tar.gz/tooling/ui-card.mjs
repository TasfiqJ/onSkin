import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { registerHooks } from 'node:module';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const target = pathToFileURL(resolve('scripts/e2e/onboarding-first-session.mjs')).href;
const fragment = readFileSync(new URL('./card-probe.txt', import.meta.url), 'utf8');
registerHooks({ load(url, context, next) {
  const result = next(url, context);
  if (url !== target) return result;
  const original = String(result.source);
  let source = original;
  const replace = (anchor, value) => {
    if (source.split(anchor).length !== 2) throw new Error('Driver anchor mismatch: '+anchor);
    source = source.replace(anchor, value);
  };
  replace('`npm --workspace apps/mobile run web -- --port ${appPort} --host localhost`,', '`npm --workspace apps/mobile run web -- --port ${appPort} --host localhost --max-workers 1`,');
  replace('async function screenshot(client, name) {', `async function screenshot(client, name) { if (!/^(04-consent|14-reveal|20-shelf|M102-(03|04a|06)|J06-(01|02|03|04|05|06|07|08)|07-dock-|07-next-|CO-(03|07|09b|13)|FAILURE)/.test(name)) return;`);
  replace('async function clickByText(client, label, { exact = true, timeoutMs = 30_000 } = {}) {', `async function clickByText(client, label, { exact = true, timeoutMs = 30_000 } = {}) { writeFileSync(path.join(evidenceDir,'actions.jsonl'),JSON.stringify({action:'tap',label})+'\\n',{flag:'a'});`);
  if (!process.argv.includes('--cross-owner')) replace('    let ageReverificationBefore = null;', fragment+'\n    let ageReverificationBefore = null;');
  replace('  const userDataDir = path.join(tmpdir(), `layerwell-onboarding-e2e-${Date.now()}`);', '  const userDataDir = path.join("C:/Users/jasim/Documents/ChatGPT/MasterV2Code/campaign07-run/ui-runtime", `profile-${Date.now()}`);');
  replace("      '--hide-scrollbars',", "      '--hide-scrollbars', '--disk-cache-size=1048576', '--media-cache-size=1048576', '--disable-gpu-shader-disk-cache', '--disable-breakpad', '--disable-component-update', '--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost, EXCLUDE 127.0.0.1, EXCLUDE [::1]', '--disable-features=OptimizationHints,OptimizationGuideModelDownloading,OptimizationTargetPrediction,OptimizationGuideOnDeviceModel',");
  process.once('exit', () => {
    writeFileSync(resolve(process.env.ONBOARDING_E2E_EVIDENCE_DIR,'executed-driver.mjs'),source);
    writeFileSync(resolve(process.env.ONBOARDING_E2E_EVIDENCE_DIR,'driver-binding.json'),JSON.stringify({originalSha256:createHash('sha256').update(original).digest('hex'),executedSha256:createHash('sha256').update(source).digest('hex')},null,2)+'\n');
  });
  return {...result,source};
} });
await import(target);
