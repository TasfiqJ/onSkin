from pathlib import Path

base = Path(__file__).parent
old = Path(r'C:\Users\jasim\AppData\Local\Temp\onskin-campaign06-j68rjqlz\ui-fragment.txt').read_text(encoding='utf-8')
old = old.replace("const n=document.querySelector('[aria-label=${JSON.stringify(label)}]');", "const n=document.querySelector('[aria-label=${JSON.stringify(label)}]')??[...document.querySelectorAll('[role=\"tab\"]')].find(n=>n.textContent.trim()===${JSON.stringify(label)});")
old = old.replace('J06 Crème Sérum with a very long', 'J06 Crème Sérum العربية セラム with a very long')
old = old.replace("    await fillByLabel(client,'Quick Find saved products','elan creme');", "    const filterStart=performance.now();\n    await fillByLabel(client,'Quick Find saved products','elan creme');", 1)
old = old.replace("    await waitForText(client,'J06 Crème Sérum');", "    await waitForText(client,'J06 Crème Sérum');\n    writeJson('07-filter-performance.json',{savedProducts:seeded.after,wallMs:performance.now()-filterStart,surface:'actual Chrome DOM after input and result wait; development runtime, not native benchmark',domNodes:await evaluate(client,'document.querySelectorAll(\"*\").length')});", 1)
old = old.replace("    await j06Key('Clear Quick Find');\n    await clickByText(client,'Expiring');", "    const mountStart=performance.now();\n    await j06Key('Clear Quick Find');\n    await waitForCondition(client,`document.querySelectorAll('[role=\"button\"][aria-label*=\", Date unknown\"]').length>=${seeded.after}`,30000,'all admitted saved rows');\n    writeJson('07-mount-performance.json',{savedProducts:seeded.after,wallMs:performance.now()-mountStart,domNodes:await evaluate(client,'document.querySelectorAll(\"*\").length'),scope:'actual complete saved-card list after Clear; includes keyboard/transport latency'});\n    await clickByText(client,'Expiring');")
probe = (base/'dock-probe.txt').read_text(encoding='utf-8')
probe = probe.replace('[[375,667,1],[360,640,2]]', '[[360,640,1],[360,640,2],[375,667,1],[375,667,2],[390,844,1],[390,844,2],[430,932,1],[430,932,2]]')
probe = probe.replace('    for (const [width,height,scale]', "    await client.send('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});\n    for (const [width,height,scale]")
probe = probe.replace('      const metrics=await evaluate', '      await delay(200);\n      const metrics=await evaluate')
probe = probe.replace('          return{text,selected', '          return{color:s.color,background:getComputedStyle(dock.firstElementChild).backgroundColor,text,selected')
probe = probe.replace('return{dock:rect(dock),labels};', "return{dock:rect(dock),labels,reducedMotion:matchMedia('(prefers-reduced-motion: reduce)').matches,transform:getComputedStyle(dock).transform};")
probe = probe.replace("      writeJson('07-dock-metrics-", "      assert(metrics.labels.length===4&&metrics.labels.every(n=>n.tab.height>=48&&n.tab.width>=48),'Dock touch target or identity failed');\n      assert(metrics.reducedMotion,'Reduced motion media missing');\n      writeJson('07-dock-metrics-")
post = '''
    await retainedRoute(client,'/shelf');await waitForText(client,'QUICK FIND');
    await j06Key('You');await waitForPath(client,'/you',30000);
    await j06Key('Shelf');await waitForPath(client,'/shelf',30000);
    await retainedRoute(client,'/today?routine=PM');
    await client.send('Page.reload',{ignoreCache:true});
    await waitForText(client,'For your next visit',60000);
    await scrollTextIntoView(client,'Reminder options');
    writeJson('07-pm-dock.json',await evaluate(client,`(()=>{const d=document.querySelector('[data-testid="floating-dock"]');return{labels:[...d.querySelectorAll('[role="tab"]')].map(n=>({name:n.getAttribute('aria-label'),selected:n.getAttribute('aria-selected'),color:getComputedStyle([...n.querySelectorAll('*')].find(t=>[...t.childNodes].some(c=>c.nodeType===3&&c.textContent.trim()))).color})),background:getComputedStyle(d.firstElementChild).backgroundColor};})()`));
    await captureStep(client,'07-next-visit-pm',{assertClean:false});
    await j06Key('Reminder options');await waitForText(client,'Morning routine');
    await captureStep(client,'07-next-visit-reminders',{assertClean:false});
    await client.send('Page.getNavigationHistory').then(async h=>{const e=h.entries[h.currentIndex-1];if(e)await client.send('Page.navigateToHistoryEntry',{entryId:e.id});});
    await waitForText(client,'For your next visit',60000);
    await j06Key('Review this week');await waitForText(client,'Subscribe to Pro');
    await clickByText(client,'Maybe later');
    writeJson('07-next-visit-actions.json',{confirmedPM:true,keyboardReminderNavigation:true,back:true,nativePermission:'NOT_RUN',delivery:'NOT_RUN'});
'''
anchor = "    await retainedRoute(client,'/shelf');\n    await waitForText(client,'QUICK FIND');"
assert old.count(anchor) == 1
# Confirm the new card before the volume mutation changes the current routine.
old = old.replace(anchor, post+'\n'+anchor, 1)
(base/'final-fragment.txt').write_text(old+'\n'+probe,encoding='utf-8')
print('UTF8 fixture and bounded browser extensions prepared')
