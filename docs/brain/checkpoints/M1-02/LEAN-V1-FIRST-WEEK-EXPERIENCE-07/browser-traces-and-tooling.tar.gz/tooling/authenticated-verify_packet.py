#!/usr/bin/env python3
"""Verify a safely extracted, independently pinned onSkin M1X-07 context packet.

Does not verify repo Git state, Security/DB/CI admission, native device or release.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST = ROOT / "manifest.json"
EXCLUDED = {"manifest.json", "EXACT_PROMPT.md"}


def fail(reason):
    print("CONTEXT_INVALID:", reason, file=sys.stderr)
    sys.exit(2)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_name(name):
    if not isinstance(name, str) or not name or "\\" in name or "\x00" in name or ":" in name:
        fail("unsafe member name")
    p = PurePosixPath(name)
    if p.is_absolute() or any(part in {"", ".", ".."} for part in name.split("/")) or p.as_posix() != name:
        fail("path traversal or noncanonical member")
    return p


def actual_files(root):
    output = {}
    for parent, dirs, files in os.walk(root, topdown=True, followlinks=False):
        here = Path(parent)
        for name in dirs + files:
            path = here / name
            if path.is_symlink():
                fail("symlink in extracted packet")
        for name in files:
            path = here / name
            rel = path.relative_to(root).as_posix()
            safe_name(rel)
            if not stat.S_ISREG(path.lstat().st_mode):
                fail("nonregular file")
            if rel.casefold() in output:
                fail("casefold name collision")
            output[rel.casefold()] = rel
    return set(output.values())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--expected-manifest-sha256", required=True)
    args = parser.parse_args()
    want = args.expected_manifest_sha256.strip().lower()
    if not re.fullmatch("[0-9a-f]{64}", want):
        fail("external digest must be exact sha256")
    if not MANIFEST.is_file() or MANIFEST.is_symlink():
        fail("missing or linked manifest")
    raw = MANIFEST.read_bytes()
    if digest(raw) != want:
        fail("EXTERNAL_MANIFEST_SHA256_MISMATCH")
    try:
        manifest = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        fail("invalid manifest json")
    if set(manifest) != {"schema", "task", "admission", "files", "excluded_prompt"}:
        fail("unexpected manifest shape")
    if manifest["schema"] != 1 or manifest["task"] != "M1X-LEAN-V1-FIRST-WEEK-EXPERIENCE07-CANDIDATE-01":
        fail("wrong task manifest")
    if manifest["admission"] != "TRANSPORT_INTEGRITY_ONLY" or manifest["excluded_prompt"] != "EXACT_PROMPT.md":
        fail("forged admission or prompt scope")
    files = manifest["files"]
    if not isinstance(files, list) or len(files) < 18:
        fail("insufficient declared files")
    names, folded, total = set(), set(), 0
    for record in files:
        if not isinstance(record, dict) or set(record) != {"path", "bytes", "sha256"}:
            fail("invalid record shape")
        name = record["path"]
        safe_name(name)
        if name in EXCLUDED or name.startswith("_") or name in names or name.casefold() in folded:
            fail("duplicate or excluded record")
        names.add(name)
        folded.add(name.casefold())
        n = record["bytes"]
        s = record["sha256"]
        if type(n) is not int or n < 0 or not isinstance(s, str) or not re.fullmatch("[0-9a-f]{64}", s):
            fail("invalid size/hash metadata")
        path = ROOT.joinpath(*name.split("/"))
        if not path.is_file() or path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):
            fail("file missing or not regular: " + name)
        body = path.read_bytes()
        if len(body) != n or digest(body) != s:
            fail("source bytes mismatch: " + name)
        total += n
    if "verify_packet.py" not in names:
        fail("unanchored verifier")
    present = actual_files(ROOT)
    if present != names | EXCLUDED:
        fail("unexpected/missing members: " + repr(sorted((present ^ (names | EXCLUDED)))[:10]))
    print("VERIFIED", len(names), "anchored regular context files (", total, "bytes)")
    print("EXTERNAL_MANIFEST_SHA256", want)
    print("TRANSPORT_INTEGRITY_ONLY — NOT CI / Security / DB / native / release approval")


if __name__ == "__main__":
    main()
