// Tooling only: preserve bytes while avoiding a 16 MB uncompressed SSR map.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
if (process.argv.some(arg => /\/expo\/bin\/cli$/.test(arg.replaceAll('\\', '/')))) {
  const target = path.join(os.tmpdir(), `require-utils-${process.pid}-render.js.bundle.map`);
  if (!fs.existsSync(target)) {
    fs.writeFileSync(target, '', { flag: 'wx' });
    execFileSync('C:/Windows/System32/compact.exe', ['/C', '/I', '/Q', target], { windowsHide: true, stdio: 'pipe' });
    fs.writeFileSync(path.join(__dirname, `own-compressed-map-${process.pid}.json`), JSON.stringify({
      pid: process.pid, path: target, kind: 'New task-owned Expo SSR map; lossless NTFS compression before first write',
    })+'\n');
  }
}
