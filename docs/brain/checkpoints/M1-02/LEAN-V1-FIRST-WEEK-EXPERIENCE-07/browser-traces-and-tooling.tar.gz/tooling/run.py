from pathlib import Path
import subprocess, sys, json, hashlib, datetime, time, os, shutil

sys.stdout.reconfigure(encoding='utf-8')
root = Path(__file__).parent
repo = Path(r'C:\Users\jasim\Desktop\WeddingCards\work\m102-retained-resilience')
name, *cmd = sys.argv[1:]
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()
log = root / (name + '.log')
assert not log.exists(), 'Use a fresh receipt name'
started = time.time()
receipt = dict(cwd=str(repo), command=cmd, start=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), status_before=git('status', '--porcelain=v1'))
with log.open('wb') as stream:
    result = subprocess.Popen(cmd, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    while result.poll() is None:
        if os.environ.get('C07_UI_DISK_GUARD') and shutil.disk_usage('C:/').free < 8 * 1024 * 1024:
            subprocess.run(['taskkill', '/PID', str(result.pid), '/T', '/F'], stdout=stream, stderr=subprocess.STDOUT)
            receipt['disk_guard'] = 'Stopped this task process tree below 8 MiB free; no other process or file changed.'
            break
        time.sleep(0.5)
    result.wait()
raw = log.read_bytes()
receipt.update(exit=result.returncode, seconds=round(time.time()-started, 2), status_after=git('status', '--porcelain=v1'),
               sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
(root / (name + '.json')).write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
print(raw.decode('utf-8', errors='replace')[-2200:])
sys.exit(result.returncode)
