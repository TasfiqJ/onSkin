from pathlib import Path
import datetime
import hashlib
import json
import platform
import shutil
import subprocess
import sys
import zipfile
import stat

sys.stdout.reconfigure(encoding='utf-8')
base = Path(__file__).parent
repo = Path(r'C:\Users\jasim\Desktop\WeddingCards\work\m102-retained-resilience')
packet = base.parent/'context_FIRST_WEEK07_8422a916b44a49d0bb4ed70192e82ee3'
upload = Path(r'C:\Users\jasim\.codex\codex-remote-attachments\01a16f0c-c3d7-7e30-bcd6-45fca5f036b5\566C431D-EE33-40FD-BE1D-E6B025CC349A\1-onSkin_Codex_M1_First_Week_Experience07_2026-10-24-2.zip')
anchor = '424b3561ab2f6d216cba33d44239e8ff9fef516f8d153da4365b86d2d52719cb'
def git(*args): return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
def save(name,value): (base/name).write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
names = set()
with zipfile.ZipFile(upload) as archive:
    members = archive.infolist()
    for item in members:
        name = item.filename
        assert name and not name.startswith(('/', '\\')) and '\\' not in name and ':' not in name
        assert '..' not in name.split('/') and '.' not in name.split('/')
        assert name.casefold() not in names
        names.add(name.casefold())
        mode = item.external_attr >> 16
        assert not stat.S_ISLNK(mode)
        assert item.is_dir() or stat.S_IFMT(mode) in (0,stat.S_IFREG)
    regular = [m for m in members if not m.is_dir()]
command = ['python','-B','verify_packet.py','--expected-manifest-sha256',anchor]
result = subprocess.run(command,cwd=packet,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(base/'context-reverify.log').write_bytes(result.stdout)
assert result.returncode == 0, result.stdout
save('authentication.json',dict(externally_pasted_anchor=anchor,zip_sha256=hashlib.sha256(upload.read_bytes()).hexdigest(),
    fresh_extraction=str(packet),regular_members=len(regular),expanded_bytes=sum(m.file_size for m in regular),
    command=command,cwd=str(packet),exit=result.returncode,log_sha256=hashlib.sha256(result.stdout).hexdigest(),
    note='Initial fresh extraction and anchored PASS preceded repository work. This is a later read-only revalidation; EXACT_PROMPT is excluded and pasted prompt governs. Authentication is orientation only.',
    observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
tracked=git('ls-files','-z').split('\0')
tracked=[p for p in tracked if p]
missing=[p for p in tracked if not (repo/p).is_file()]
size=sum((repo/p).stat().st_size for p in tracked if (repo/p).is_file())
assert not missing
save('final-source-environment.json',dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    cwd=str(repo),source_commit=git('rev-parse','HEAD'),source_tree=git('rev-parse','HEAD^{tree}'),
    source_status=git('status','--porcelain=v1'),stage_ancestry_to_pinned_main=git('rev-list','--parents','HEAD'),
    worktrees=git('worktree','list','--porcelain'),shallow=git('rev-parse','--is-shallow-repository'),
    remote_refs=git('ls-remote','origin','refs/heads/main','refs/heads/stage/m1-gate-recovery','refs/heads/stage/m1-retained-resilience'),
    node=subprocess.check_output(['node','--version']).decode().strip(),
    npm=subprocess.check_output(['npm.cmd','--version']).decode().strip(),git=git('--version'),
    python=platform.python_version(),os=platform.platform(),complete_tracked_files=len(tracked),
    complete_tracked_bytes=size,missing_tracked_files=missing,free_host_bytes=shutil.disk_usage('C:/').free,
    independent_worklist='NOT_QUALIFIED',
    independent_reason='Only C: is usable. A fresh complete checkout needs at least the complete tracked bytes plus Git objects, dependencies if needed, and safe host reserve. Observed headroom is insufficient; no independent clone attempted, no substitute asserted.',
    volume_inventory='C: only usable data volume; small recovery/system volumes are not workspace capacity. WSL verification distribution fails mount Error6; no Docker/WSL changes.',
    spend_usd=0))
print('Recorded context PASS and current complete-checkout/disk/ancestry observations')
