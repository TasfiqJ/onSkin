# Campaign17 bug records

Date: 2026-10-26. Tester: Codex under BRAIN-M1X-PRIVACY-REENTRY17-REPAIR-01. Environment: source based on immutable PR20; controlled synthetic React ports and actual Chrome Expo web. No real account, patient or provider.

## Q17 — mounted Quiz revalidation exposes retained controls

Severity: Critical. Feature/scope: `apps/mobile/src/app/onboarding/quiz.tsx`; synthetic owner, no external service. Frequency: deterministic mounted return with a pending check.

Reproduction: admit consent, select an answer, blur, hold the next consent promise and refocus; invoke a previously captured selection/Next callback. Expected: no sensitive question/answer controls and no write, analytics or navigation until current focus/owner/lease admission. Actual before repair: old controls remain and old selection writes. Evidence: `commands/regression-before.log` (mocked mounted real route); the old browser build was not claimed reproduced.

Suspected cause/minimal fix: retained `consentChecked=true` plus unfenced answer callbacks. Retire synchronously, mask with current external lease state, capture focus/health authority, and refuse unowned inherited drafts.

Verification: focused tests cover pending approval/denial, stale completion, blur/unmount, old question callbacks, same-owner regrant and A→B→A. Actual Expo web returns Products→Quiz with held canonical consent, captures checking pixels, approves and returns to Products; another run clears canonical consent during the pending check and reaches privacy. Post-fix evidence: `browser/sixth/*quiz-pending-return.png`, `*quiz-approved-mounted-return.png`, `withdrawal-pending.png`, `withdrawal-denied-private-route.png`, and focused command receipts.

Remaining risk: protected provider-wide owner tagging/cleanup is UNAPPLIED; the actual-provider test documents masking and explicit reset while retained raw provider memory remains. Physical/native/provider acceptance is NOT_RUN.

## P17 — missing goals redirects before unsaved-name choice

Severity: Medium. Feature/scope: Products direct entry with a synthetic typed name and missing goals. Frequency: deterministic. No external service or destructive provider action.

Reproduction: enter Products after admitted age/consent but without provider goals, type an unsaved name, press Skip/Continue. Expected: Keep editing or explicit Continue without adding it before the goals guard. Actual before repair: immediate goals replacement discards the local input. Evidence: five pre-repair component cases in `commands/regression-before.log`.

Suspected cause/minimal fix: early goals branch in `go()`. Move unsaved acknowledgement ahead of the existing goals redirect; retire acknowledgement after editing/cancelling.

Verification: 0/1/2/3/20-item component cases, current-owner lease/removal barriers and captured stale acknowledgement. Actual browser captures `direct-products-unsaved-before-goals.png` and `direct-products-acknowledged-goals-guard.png`; Keep editing retains the name, explicit acknowledgement returns to goals. Actual manual Shelf counts 0–3 at all four viewports and 0–6 at 390px; 20 is component-fixture evidence only.

Remaining risk: real catalog/provider availability is not exercised or invented. Native keyboard/VoiceOver are NOT_RUN.

## N17 — old reminder callbacks inherit a later focus

Severity: High. Feature/scope: allowed onboarding reminder UI only. Frequency: deterministic controlled callback boundary; no real OS permission or delivery.

Reproduction: save an OFF choice, retain Continue, blur/refocus (including same-owner regrant or A→B→A) and invoke old Continue. Separately hold schedule success/failure through same-lease blur/refocus. Expected: no old navigation or success/error publication under the new focus. Actual before repair: old Continue navigates and old schedule settlement publishes a notice. Evidence: six failing pre-repair component cases in `commands/regression-before.log`.

Suspected cause/minimal fix: mutable focus/authority refs have no immutable focus token or current-notice identity. Fence the UI callbacks and settlements; preserve backend/durable preference ordering.

Verification: `reminderBoundary17.test.ts`, unchanged real durable-store recovery cases, actual browser failed-write/Retry/explicit Continue at all four viewports. Post-fix evidence: focused receipts plus `browser/sixth/*reminder-storage-failure.png` and `*reminder-current-intent-retry.png`.

Remaining risk: OS permission/delivery and native cancellation remain NOT_RUN; browser never claims a delivered reminder. Protected queue/store/delivery/native files are unchanged.

## L17 — category footer crowds the focused input under keyboard/text pressure

Severity: Medium. Surface: 360px Chrome viewport reduced to 380px high, text/line-height ×2; browser simulation only. Frequency: reproducible. Feature/scope: Products footer.

Reproduction: type an unsaved product, reduce viewport while keeping the input focused. Expected: readable input access plus complete Add and Skip/Continue. Actual first pass: category footer consumes most usable height and the input is outside the visible form. Evidence: `browser/failures/first-keyboard.png`.

Minimal fix: category access moves into the scrollable form below 460px height. Continue/Skip stays in the footer. Verification: actual final keyboard PNGs for all saved counts and representative glyph inspection. Post-fix: `browser/sixth/360x640-keyboard-open-simulated-text200.png` and `360x640-keyboard-1/2/3-simulated.png`; all primary action text is complete, including wrapped labels. The lower-priority category control can be partially outside the scrollable form viewport and is reachable by scrolling.

Remaining risk: a genuine native keyboard/Dynamic Type run is NOT_RUN; no physical-device readability acceptance is implied.

## Retained exploratory implementation/harness failures

The second browser attempt captured a temporary JSX object rendered as a child; it was fixed before the final source candidate. Other failures were harness issues: a hidden historical input selected during assertion, unstable coordinates during resize, the normal 430px Continue label, and scenario reset through a correctly closed lifecycle shell. Each ERROR record and representative actual failure PNG is retained. They are not reported as unresolved production defects or successful evidence.
