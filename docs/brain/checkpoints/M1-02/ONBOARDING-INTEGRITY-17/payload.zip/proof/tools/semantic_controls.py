"""Unchanged original 151 bundle cases; in-process CLI adapter, immutable Git-object cache only.

Every source guard, index, worktree and untracked check still executes per case.
Only content-addressed Git reads are memoized. This is simulated bundle-fixture
evidence, never the independent full-checkout CLI proof or release acceptance.
"""
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
root = Path.cwd()
here = root/'scripts/release/full-app-j01'
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value
check = module('semantic_check17', here/'check.py')
test = module('original_semantic_test', here/'test_contract.py')
real_run = subprocess.run
real_git = check.git
cache = {}
def immutable(argument):
    return bool(re.fullmatch(r'[0-9a-f]{40}(?:\^\{tree\}|:[^\r\n]+|\.\.[0-9a-f]{40})?', argument))
def cached_git(*args):
    revisions = [a for a in args[1:] if not a.startswith('-')]
    eligible = (args[0] in ('show','rev-parse','rev-list','ls-tree','diff') and
                bool(revisions) and all(immutable(a) for a in revisions))
    if args[0] == 'diff':
        eligible = eligible and len(revisions) == 2 and '--cached' not in args
    if not eligible: return real_git(*args)
    if args not in cache: cache[args] = real_git(*args)
    return cache[args]
check.git = cached_git
calls = 0
def cli_adapter(command, *args, **kwargs):
    global calls
    if isinstance(command, list) and '--bundle-dir' in command and str(here/'check.py') in command:
        calls += 1
        try:
            output = check.validate(Path(command[command.index('--bundle-dir')+1])); code = 0
        except (ValueError, KeyError, TypeError, OSError, subprocess.SubprocessError) as error:
            output = dict(valid=False, release='NO_GO', error=str(error)); code = 1
        return subprocess.CompletedProcess(command, code, json.dumps(output,sort_keys=True)+'\n', '')
    return real_run(command,*args,**kwargs)
subprocess.run = cli_adapter
try:
    test.main()
finally:
    subprocess.run = real_run
    print(json.dumps(dict(adapter='IN_PROCESS_UNMODIFIED_BUNDLE_CASES',source_guard='EXECUTED_EACH_CASE',
        dynamic_git='UNCACHED',immutable_object_cache_entries=len(cache),cli_invocations=calls,
        qualification='SIMULATED_BUNDLE_FIXTURES_NOT_INDEPENDENT_CHECKOUT')))
