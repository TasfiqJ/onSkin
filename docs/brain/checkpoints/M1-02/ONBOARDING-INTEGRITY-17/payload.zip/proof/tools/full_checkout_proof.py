"""Actual separately fetched complete checkout; real CLI current/tampered/restored."""
import json
from pathlib import Path
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')
out=Path(__file__).resolve().parent
source='27b2171385a56cace13d485e2a5280da1d45dcf1'
def git(*args):return subprocess.check_output(['git',*args])
assert git('rev-parse','HEAD').decode().strip()==source
assert git('rev-parse','HEAD^{tree}').decode().strip()=='a084d538d3d45e92f40103623376fe77b5b8b733'
assert git('status','--porcelain=v1','-uall')==b''
def run(label,expected):
    result=subprocess.run([sys.executable,'-B',str(out/'run.py'),'independent-'+label,
        sys.executable,'-B','scripts/release/full-app-j01/check.py'])
    assert result.returncode==expected,(label,result.returncode)
    return result.returncode
values=[run('current',0)]
target=Path('package.json'); original=target.read_bytes()
try:
    target.write_bytes(original+b'\n')
    values.append(run('tampered',1))
finally:
    target.write_bytes(original)
values.append(run('restored',0))
assert git('status','--porcelain=v1','-uall')==b''
value=dict(qualification='INDEPENDENT_GITHUB_FETCHED_COMPLETE_CHECKOUT_REAL_CLI',cwd=str(Path.cwd()),
    source=source,tree=git('rev-parse','HEAD^{tree}').decode().strip(),paths=len(git('ls-files','-z').split(b'\0'))-1,
    current_tampered_restored=values,tamper='disposable checkout package.json newline; exact original restored',
    clean=True,source_acceptance=False,release='NO_GO')
(out/'proof'/'independent-complete-checkout.json').write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps(value))
