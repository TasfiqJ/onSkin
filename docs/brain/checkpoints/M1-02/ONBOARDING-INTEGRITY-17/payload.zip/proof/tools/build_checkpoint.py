"""Build only the new finite Campaign17 evidence directory, without circular HEAD/CI claims."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import unicodedata
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
run=Path(__file__).resolve().parent
root=Path.cwd()
source='27b2171385a56cace13d485e2a5280da1d45dcf1'
packet=Path(r'C:\Users\jasim\Documents\ChatGPT\Campaign17_R1_context_20261026_9ff28748f918')
required=['historical15-unchanged','dependency_guard12-historical','dependency_guard13','quality_projection10']
for name in required:
    value=json.loads((run/'commands'/(name+'.json')).read_bytes())
    assert value['exit_code']==0,(name,value['exit_code'])
assert subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==source
assert subprocess.check_output(['git','status','--porcelain=v1','-uall'])==b''
provenance=json.loads((run/'proof/source-provenance.json').read_bytes())
proof=json.loads((run/'proof/independent-complete-checkout.json').read_bytes())
assert proof['current_tampered_restored']==[0,1,0] and proof['clean']
assert json.loads((run/'browser/sixth/summary.json').read_bytes())['status']=='PASS'

summaries=[]
for p in sorted((run/'commands').glob('*.json')):
    value=json.loads(p.read_bytes());log=run/'commands'/value['log']
    value['receipt_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    value['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
    summaries.append(value)
(run/'proof/command-index.json').write_bytes((json.dumps(summaries,indent=2)+'\n').encode())

members={}
def add(name, data):
    assert not name.startswith('/') and '..' not in name.split('/') and '\\' not in name
    assert unicodedata.normalize('NFKC',name).casefold() not in {unicodedata.normalize('NFKC',x).casefold()for x in members}
    members[name]=data
def add_file(name,path):
    assert path.is_file() and not path.is_symlink() and path.stat().st_nlink==1
    add(name,path.read_bytes())
add_file('IMPLEMENTATION_REPORT.md',run/'IMPLEMENTATION_REPORT.md')
for p in sorted((run/'commands').iterdir()):
    if p.is_file():add_file('commands/'+p.name,p)
for p in sorted((run/'proof').iterdir()):
    if p.is_file():add_file('proof/'+p.name,p)
for name in ['run.py','inventory.py','historical_controls.py','full_checkout_proof.py','semantic_controls.py','build_checkpoint.py']:
    add_file('proof/tools/'+name,run/name)
for p in sorted((run/'browser/sixth').iterdir()):
    if p.is_file() and p.suffix in ('.json','.png','.log'):add_file('browser/sixth/'+p.name,p)
for attempt,prefix in [('first','360x640'),('second','360x640'),('third','360x640'),('fourth','430x932'),('fifth','direct-products')]:
    folder=run/'browser'/attempt
    for suffix in ['.png','.json']:
        path=folder/(prefix+'-FAILURE'+suffix)
        if path.exists():add_file('browser/failures/'+attempt+'-FAILURE'+suffix,path)
    add_file('browser/failures/'+attempt+'-ERROR.json',folder/'ERROR.json')
add_file('browser/failures/first-keyboard.png',run/'browser/first/360x640-keyboard-open-simulated-text200.png')
for p in sorted(packet.iterdir()):add_file('authenticated-input/'+p.name,p)
for row in provenance['source_delta']:
    data=subprocess.check_output(['git','show',source+':'+row['path']])
    assert hashlib.sha256(data).hexdigest()==row['after']['sha256']
    add('source/'+row['path'],data)

def summary(name):
    p=run/'commands'/(name+'.log');last={}
    for line in p.read_text(encoding='utf-8',errors='replace').splitlines():
        try:
            item=json.loads(line)
            if isinstance(item,dict) and item.get('passed') is True:last=item
        except ValueError:pass
    return last
rows=[]
for i in range(9,18):
    name='final-source17-controls'if i==17 else f'historical{i:02}-unchanged'
    receipt=json.loads((run/'commands'/(name+'.json')).read_bytes())
    rows.append((i,receipt['exit_code'],summary(name)))
text=['# Campaign17 checkpoint validation results','',
    'All results below precede exactly one evidence-only delivery tail. The external FINAL_REPORT.md supplies that tail and exact final-head CI identities. No source or release acceptance is granted.','',
    '| Check | Result / exit | Evidence |','| --- | --- | --- |',
    '| Focused routes, including real protected provider | 74 tests pass across the focused runs; new 23 cases also run in the full suite | command receipts and test sources |',
    '| Forced full root | FAIL / 1; mobile 6,213 pass, four protected lease-less fixture failures; operator 24 pass; zero Turbo cache hits | commands/final-root-forced.log |',
    '| Forced typecheck and lint | PASS / 0, all three workspaces, zero cache hits | final-typecheck / final-lint |',
    '| Original Release08 semantics | Actual unchanged GitHub CLI: 151 negatives; current/tampered/restored 0/1/0 | proof/source-ci-final.json |',
    '| Separate full checkout | Actual GitHub-fetched 23,362-path checkout, real source CLI 0/1/0, exact bytes restored and clean | proof/independent-complete-checkout.json |',
    '| Original Phase4 producer + falsification | PASS / 0; real producer 0/1/0, bounded fixture labelled separately | quality_projection10 and final-worklist-check |',
    '| Frozen-source iOS / Android Expo exports | PASS / 0; receipts bind identical before/after source SHA/tree | frozen-expo-ios / frozen-expo-android |',
    '| iOS source-only probes | PASS / 0; 410 pass, five Windows skips; no installed native build | ios-source-only |',
    '| Local DB contract | PASS / 0; 171 tests | db-local-contract |',
    '| Local canonical DB reset | FAIL / 1, H01_SQL_PROBE_FAILED, Docker engine unavailable | canonical-db-attempt |',
    '| Local PG15 / PG17 rehearsals | NOT_RUN: unavailable local Docker engine | docker-precondition |',
    '| Source-head GitHub PG15 / PG17 | SUCCESS, separate jobs | proof/source-ci-final.json |',
    '| Source-head GitHub canonical DB | FAILURE: public image registry Data limit exceeded | proof/source-ci-final.json |',
    '| Source-head Quality / iOS | FAILURE: Test / Run safe repository checks; four protected navigation fixtures | proof/source-ci-final.json |',
    '| Source-head Security | FAILURE in code, secret, static/OSV and acceptance; live Supabase skipped | proof/source-ci-final.json |',
    '| Source-head CI Expo | SKIPPED after checks failure; local exports above are separately identified | proof/source-ci-final.json |','',
    'Historical control scripts below are unchanged and executed at their own pinned historical source versions. Their internal synthetic Git/materialized fixtures are not promoted to independent complete-checkout proof.','',
    '| Release | Exit | Summary |','| --- | --- | --- |']
for i,code,value in rows:text.append(f'| {i:02} | {code} | `{json.dumps(value,sort_keys=True)}` |')
text.extend(['','Dependency guards 11/12/13 retain 9/49/66 refusals. The first dependency12 run on the later native-mapping source failed; its own unchanged historical version is the correct passing replay. Both receipts are retained.','',
    'The redundant local 151-case adapter was stopped incomplete after the actual frozen-source GitHub CLI completed all 151 negatives. It is never counted as a completed local pass. No gate is waived.','',
    'Detailed commands, cwd, actual exits, receipts, logs and hashes: proof/command-index.json. Actual browser: browser/sixth/summary.json and 94 PNGs; explicit exploratory errors: browser/failures/. No browser profiles, private storage or export binaries are packaged.'])
add('VALIDATION_REPORT.md',('\n'.join(text)+'\n').encode())
assert len(members)<=1024 and sum(map(len,members.values()))<=128*1024*1024
checkpoint=root/'docs/brain/checkpoints/M1-02/ONBOARDING-INTEGRITY-17'
checkpoint.mkdir(parents=True,exist_ok=False)
(checkpoint/'README.md').write_bytes((run/'CHECKPOINT_README.md').read_bytes())
(checkpoint/'verify17.py').write_bytes((run/'verify17.py').read_bytes())
with zipfile.ZipFile(checkpoint/'payload.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as archive:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.create_system=3
        info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data)
def witness(path):
    data=path.read_bytes();return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
manifest=dict(schema=1,authority='BRAIN-M1X-PRIVACY-REENTRY17-REPAIR-01',status='SOURCE_ONLY_CANDIDATE',
    release='NO_GO',acceptanceGranted=False,admissions=dict(G97=False,DB=False,M103=False,M2=False,J01=False,PUBLIC=False),
    input_manifest_sha256='d2c9cbf835145ba4f98bc1c4162e9264ff81b4ce4982951c3d20e36c2b98a628',
    base=provenance['base'],source=provenance['source'],
    files={name:witness(checkpoint/name)for name in ['README.md','payload.zip','verify17.py']},
    members={name:dict(mode='100644',bytes=len(data),sha256=hashlib.sha256(data).hexdigest())for name,data in sorted(members.items())})
(checkpoint/'manifest.json').write_bytes((json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())
sha=witness(checkpoint/'manifest.json')['sha256']
(run/'proof/checkpoint-anchor.json').write_bytes((json.dumps(dict(path=str(checkpoint),manifest_sha256=sha,members=len(members),payload_bytes=(checkpoint/'payload.zip').stat().st_size),indent=2)+'\n').encode())
print(json.dumps(dict(checkpoint=str(checkpoint),manifest_sha256=sha,members=len(members),payload_bytes=(checkpoint/'payload.zip').stat().st_size)))
