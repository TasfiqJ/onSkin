"""Read-only historical source controls in the independently fetched detached checkout."""
from pathlib import Path
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')
runner=Path(__file__).with_name('run.py')
pins=[(9,'28953aa3a84fed0684b80b442d0cd9c2de0663b2'),
      (10,'14805e7f708297e72419035f517acc41ba52da70'),
      (11,'9e3ba80e09579ee4855948f13297049791c4d5d7'),
      (12,'bbbd59073b7add22ac350bced0d9a34124c12ffb'),
      (13,'d0c5ad49ba22c8da7136d59a399589af1cea0e82'),
      (14,'53cf869c5fc5f13ecd18dc1ef9c3a6288eaae51a'),
      (15,'b79e6d1e21a367be5cea5d0b333de9f2a144d41f')]
for release,commit in pins:
    assert subprocess.check_output(['git','status','--porcelain=v1','-uall'])==b''
    subprocess.run(['git','switch','--detach',commit],check=True)
    script=f'scripts/release/full-app-j01/source_consumer{release:02}.test.py'
    assert Path(script).read_bytes()==subprocess.check_output(['git','show',commit+':'+script])
    subprocess.run([sys.executable,'-B',str(runner),f'historical{release:02}-unchanged',
                    sys.executable,'-B',script],check=False)
subprocess.run(['git','switch','--detach','28953aa3a84fed0684b80b442d0cd9c2de0663b2'],check=True)
