"""Content-addressed Git provenance only; never scanner or source acceptance."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
sys.stdout.reconfigure(encoding='utf-8')
out=Path(__file__).resolve().parent/'proof'
base='28953aa3a84fed0684b80b442d0cd9c2de0663b2'
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
def git(*args):return subprocess.check_output(['git',*args])
def tree(commit):
    result={}
    for item in git('ls-tree','-r','-z',commit).split(b'\0'):
        if not item:continue
        meta,name=item.split(b'\t',1);mode,kind,blob=meta.decode().split()
        result[name.decode('utf-8')]=dict(mode=mode,kind=kind,blob=blob)
    return result
batch=subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
cache={}
def witness(oid):
    if oid not in cache:
        batch.stdin.write((oid+'\n').encode());batch.stdin.flush()
        fields=batch.stdout.readline().decode().split();assert fields[:2]==[oid,'blob']
        raw=batch.stdout.read(int(fields[2]));assert batch.stdout.read(1)==b'\n'
        assert hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()==oid
        cache[oid]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    return cache[oid]
before,after=tree(base),tree(head)
spec=importlib.util.spec_from_file_location('guard17',Path('scripts/release/full-app-j01/check.py'))
check=importlib.util.module_from_spec(spec);spec.loader.exec_module(check)
protected=[];changed=[];added=[]
for name,entry in before.items():
    if name not in check.RELEASE17_EXISTING:
        assert after.get(name)==entry,('PROTECTED_SOURCE_DRIFT',name)
        protected.append(name)
    if after.get(name)!=entry:changed.append(name)
for name in after:
    if name not in before:assert check.allowed17(name),name;added.append(name)
for name in changed:assert check.allowed17(name),name
for label,commit,entries in [('baseline',base,before),('source',head,after)]:
    with gzip.GzipFile(filename=str(out/(label+'-inventory.jsonl.gz')),mode='wb',mtime=0)as stream:
        for name,entry in sorted(entries.items()):
            assert entry['kind']=='blob',name
            stream.write((json.dumps(dict(path=name,commit=commit,**entry,**witness(entry['blob'])),sort_keys=True)+'\n').encode())
def delta(left,right):
    a,b=tree(left),tree(right);rows=[]
    for name in sorted(set(a)|set(b)):
        if a.get(name)==b.get(name):continue
        def row(entry):return None if entry is None else dict(**entry,**witness(entry['blob']))
        rows.append(dict(path=name,before=row(a.get(name)),after=row(b.get(name))))
    return rows
commits=[]
for commit in git('rev-list','--reverse',base+'..'+head).decode().splitlines():
    parents=git('rev-list','--parents','-n','1',commit).decode().split();assert len(parents)==2
    commits.append(dict(sha=commit,tree=git('rev-parse',commit+'^{tree}').decode().strip(),parent=parents[1],
        changes=delta(parents[1],commit),cumulative_changes=delta(base,commit)))
value=dict(base=dict(sha=base,tree=git('rev-parse',base+'^{tree}').decode().strip(),paths=len(before)),
    source=dict(sha=head,tree=git('rev-parse',head+'^{tree}').decode().strip(),paths=len(after)),
    code=dict(sha='2f70429be4233d45cf48ea5acf4a0e6e1f9be727',tree='e25556dc666365e858424d13da871a1d2a03cd74'),
    protected_identical=len(protected),changed_existing=changed,added=added,commits=commits,
    source_delta=delta(base,head),source_acceptance=False,release='NO_GO')
(out/'source-provenance.json').write_bytes((json.dumps(value,indent=2)+'\n').encode())
batch.stdin.close();batch.wait();assert batch.returncode==0
print(json.dumps({k:value[k]for k in ['base','source','protected_identical','changed_existing','added']}))
