import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding='utf-8')
folder = Path(__file__).resolve().parent / 'commands'
name, *command = sys.argv[1:]
env = os.environ.copy()
env.update(CI='1', EXPO_NO_TELEMETRY='1', DO_NOT_TRACK='1', TURBO_TELEMETRY_DISABLED='1')
for key in list(env):
    if key.startswith(('EXPO_PUBLIC_', 'SUPABASE_', 'REVENUECAT_', 'POSTHOG_', 'SENTRY_AUTH_', 'OPENAI_API_', 'ANTHROPIC_API_')):
        del env[key]
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
def identity():
    try:
        return dict(sha=subprocess.check_output(['git','rev-parse','HEAD'],stderr=subprocess.DEVNULL).decode().strip(),
                    tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],stderr=subprocess.DEVNULL).decode().strip())
    except subprocess.SubprocessError:
        return None
before = identity()
log = folder / (name + '.log')
with log.open('wb') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, env=env, stdin=subprocess.DEVNULL)
receipt = dict(name=name, command=command, cwd=os.getcwd(), started_utc=start,
               elapsed_seconds=round(time.monotonic()-clock, 3), exit_code=result.returncode,
               log=log.name, git_before=before, git_after=identity())
(folder / (name + '.json')).write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt))
print(log.read_text(encoding='utf-8', errors='replace')[-4000:])
sys.exit(result.returncode)
