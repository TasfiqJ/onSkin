# Campaign17 implementation and evidence boundaries

Status: PARTIAL_BLOCKED / SUBMITTED_REVIEW_REQUIRED. This is an engineering candidate under BRAIN-M1X-PRIVACY-REENTRY17-REPAIR-01. The independent Brain remains the source-acceptance auditor and sole later ordinary main-promotion decision-maker.

## Repairs

Quiz closes synchronous action admission and removes sensitive content on each real focus while the canonical current-consent read is pending. An immutable focus token and captured owner/health lease fence completions, answer writes, navigation and analytics. Blur, unmount, expiry, withdrawal, same-owner regrant and A→B→A retire that authority. React's external-store subscription masks lease changes; actual failures show privacy recovery instead of indefinite checking. Current mounted-owner drafts survive approved return. An unknown inherited draft is masked and requires explicit reset through the existing provider API, followed by goals. Original questions, scoring, age, pregnancy, consent and completeness modules are unchanged.

Products asks for the unsaved-name decision before its missing-goals redirect. Editing or cancelling retires an old acknowledgement. Pending removal and its durable refetch retain the navigation barrier. In a reduced short viewport, category access moves into the scrollable form so Add and Skip/Continue retain space. The original real Shelf, consent, owner lease, manual name bounds, category choices and opened-date intake remain required; no catalog availability is invented.

Reminder regressions demonstrated that an old saved Continue callback could inherit a later focus and that a schedule result could publish after same-lease blur/refocus. The allowed UI repair adds a focus token and current-notice identity. Durable preference serialization, current-intent retry, permission/delivery backends and native APIs are unchanged. Failed storage never becomes saved or navigation success; OFF with cancellation unconfirmed still requires explicit acknowledgement.

## Unapplied protected work

1. `apps/mobile/src/features/onboarding/OnboardingContext.tsx` owns untagged raw in-memory answers. Route admission cannot provide provider-wide ownership tagging or synchronous cleanup when the route is absent. The real-provider regression deliberately confirms that limitation while proving masking and explicit reset. No provider-wide privacy acceptance is claimed.
2. `apps/mobile/src/features/onboarding/quizNavigation.test.ts` is outside the finite edit grant. Its four historical fixtures supply consent=true but no owner/health lease. They fail under current strict admission. The fixture file is byte-identical to PR20; the authorized Campaign16 navigation tests preserve usable navigation under a real synthetic lease. No test-only bypass, global fake lease or waiver is introduced. The full root and dependent CI results remain FAIL.

## Evidence quality

| Evidence | What actually ran | Limit |
| --- | --- | --- |
| PNGs | Actual Chrome pixels from the Expo web development build | Synthetic local profile; no physical phone |
| Browser | UI-driven adult/consent/quiz/manual-Shelf flow at four viewports, direct entry, real mounted focus return, held canonical consent read, actual local consent withdrawal, unsaved decisions, failed write/retry and held delete/refetch | Disclosed JavaScript port delays/faults; no fabricated consent or Shelf/provider data |
| Text/keyboard | Persistent DOM font and line-height ×2 at 360×640; focused input with reduced viewport; representative glyph pixels and complete wrapped action labels inspected | Browser simulation, not native Dynamic Type or an OS keyboard |
| React tests | Real routes with controlled ports; one test uses the real protected provider | Mocked platform/transport; no device/provider proof |
| Source exports | Expo iOS and Android bundles and source maps | No native compilation, installation, signing or delivery |
| Git fixtures | Synthetic index/history/merge-event falsification | Explicitly distinct from complete-checkout proof |
| Complete checkout | Separately fetched full GitHub checkout; real current/tampered/restored source CLI | Source consistency only |
| Semantic fixtures | Exact frozen-source GitHub Quality job ran the unchanged CLI script: all 151 negatives, current/tampered/restored 0/1/0. The redundant local in-process replay was stopped incomplete and is not counted as a pass | Bundle fixture; distinct from independent complete-checkout proof and root tests |

The final browser run has 94 PNGs, zero console errors, 59 development/environment warnings, and only localhost network origins. Logs omit request bodies/headers and raw quiz selections. Native installed iPhone, genuine OS notification permission/delivery, VoiceOver, native keyboard/Dynamic Type, paid services, provider functionality, Apple review and clinical/legal proof are NOT_RUN.

## Exploratory failures retained

The pre-repair focused regressions produced 20 failures and one pass. Subsequent failed attempts remain in the packet: a hidden historical input selected by the browser harness; a temporary JSX category-render error; a resize/click timing error; a 430px continuation-label expectation; and a fresh-scenario reset blocked by the correctly closed health lifecycle. Those were corrected before the final browser pass. Initial lint ref-render errors, the additive guard's initial inherited-checker mismatch, and an incorrect create-versus-edit negative expectation are also retained. The semantic adapter was first stopped and corrected so no dynamic Git diff is cached; its later redundant replay was stopped after the exact-source CI completed the actual unchanged 151-case CLI run. Neither stopped local run is counted as a completed pass.

## Provenance and unchanged gates

The source base has 23,354 paths; the frozen source has 23,362. Eight existing source paths changed and eight were added. All 23,342 paths outside the existing-file grant are identical by Git mode/kind/blob; every baseline and source blob was also SHA256-hashed from Git objects. Source/projection commits are linear. Full per-file and per-commit modes, blobs, byte counts and SHA256 witnesses are in `proof/source-provenance.json` and the two compressed inventories. Original Release08–16 controls are byte-identical, 76 inherited function ASTs are unchanged, and only the original source-guard dispatcher receives the finite successor branch/union. The new segment preserves all original gate values and source witnesses.

The unchanged Phase4 producer generated both projections after code freeze: 14 items, seven blocked/seven local scaffolds, 420 source occurrences and zero missing paths. This does not admit catalog readiness.

First public release remains all genuinely working non-Korean F01–F17/F19–F20, 12 C and six P groups, plus exactly J01 Visible Pores after independent qualified G1/G2/G3/G5 proof; G4 additionally gates change/trend. F09 private manual photos remain required; F18 and J02–J27 including J05 remain deferred. G97 is FAIL/NO_GO; 5,534 original potential findings and 1,255 supplemental potential matches remain privately undispositioned. Local Security commit 3bc6b787/workspace was not used or accessed. DB06/DB08/R2B remain NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED. All native/device/provider/paid/legal/clinical/Apple/public-release gates stay closed. USD0; no merge or source acceptance.
