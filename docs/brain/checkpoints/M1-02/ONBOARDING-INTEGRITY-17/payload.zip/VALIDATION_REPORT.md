# Campaign17 checkpoint validation results

All results below precede exactly one evidence-only delivery tail. The external FINAL_REPORT.md supplies that tail and exact final-head CI identities. No source or release acceptance is granted.

| Check | Result / exit | Evidence |
| --- | --- | --- |
| Focused routes, including real protected provider | 74 tests pass across the focused runs; new 23 cases also run in the full suite | command receipts and test sources |
| Forced full root | FAIL / 1; mobile 6,213 pass, four protected lease-less fixture failures; operator 24 pass; zero Turbo cache hits | commands/final-root-forced.log |
| Forced typecheck and lint | PASS / 0, all three workspaces, zero cache hits | final-typecheck / final-lint |
| Original Release08 semantics | Actual unchanged GitHub CLI: 151 negatives; current/tampered/restored 0/1/0 | proof/source-ci-final.json |
| Separate full checkout | Actual GitHub-fetched 23,362-path checkout, real source CLI 0/1/0, exact bytes restored and clean | proof/independent-complete-checkout.json |
| Original Phase4 producer + falsification | PASS / 0; real producer 0/1/0, bounded fixture labelled separately | quality_projection10 and final-worklist-check |
| Frozen-source iOS / Android Expo exports | PASS / 0; receipts bind identical before/after source SHA/tree | frozen-expo-ios / frozen-expo-android |
| iOS source-only probes | PASS / 0; 410 pass, five Windows skips; no installed native build | ios-source-only |
| Local DB contract | PASS / 0; 171 tests | db-local-contract |
| Local canonical DB reset | FAIL / 1, H01_SQL_PROBE_FAILED, Docker engine unavailable | canonical-db-attempt |
| Local PG15 / PG17 rehearsals | NOT_RUN: unavailable local Docker engine | docker-precondition |
| Source-head GitHub PG15 / PG17 | SUCCESS, separate jobs | proof/source-ci-final.json |
| Source-head GitHub canonical DB | FAILURE: public image registry Data limit exceeded | proof/source-ci-final.json |
| Source-head Quality / iOS | FAILURE: Test / Run safe repository checks; four protected navigation fixtures | proof/source-ci-final.json |
| Source-head Security | FAILURE in code, secret, static/OSV and acceptance; live Supabase skipped | proof/source-ci-final.json |
| Source-head CI Expo | SKIPPED after checks failure; local exports above are separately identified | proof/source-ci-final.json |

Historical control scripts below are unchanged and executed at their own pinned historical source versions. Their internal synthetic Git/materialized fixtures are not promoted to independent complete-checkout proof.

| Release | Exit | Summary |
| --- | --- | --- |
| 09 | 0 | `{"original_151_fixture_script": "BYTE_IDENTICAL", "original_semantic_functions": "UNCHANGED_AST", "passed": true, "qualification": "BOUNDED_REAL_GIT_DELTA_FIXTURES_ONLY", "rejected": 23, "release": "NO_GO"}` |
| 10 | 0 | `{"passed": true, "previous_tests": "BYTE_IDENTICAL", "qualification": "BOUNDED_ACTUAL_GIT_INDEX_AND_HISTORY_NOT_FULL_CHECKOUT", "rejected": 44, "release": "NO_GO", "semantic_functions": "UNCHANGED_AST"}` |
| 11 | 0 | `{"inherited_semantics": "UNCHANGED_AST", "passed": true, "qualification": "DISPOSABLE_GIT_CONTROLS", "rejected": 58, "release": "NO_GO"}` |
| 12 | 0 | `{"passed": true, "pr": 16, "qualification": "DISPOSABLE_GIT_AND_MATERIALIZED_FIXTURE; NOT_INDEPENDENT_COMPLETE_CHECKOUT", "rejected": 55, "release": "NO_GO"}` |
| 13 | 0 | `{"passed": true, "pr": 17, "qualification": "DISPOSABLE_GIT_AND_MATERIALIZED_FIXTURE; NOT_INDEPENDENT_COMPLETE_CHECKOUT", "rejected": 68, "release": "NO_GO"}` |
| 14 | 0 | `{"passed": true, "positive_controls": 8, "pr": 18, "qualification": "SYNTHETIC_GIT_NOT_INDEPENDENT_COMPLETE_CHECKOUT", "refusals": 89, "release": "NO_GO"}` |
| 15 | 0 | `{"passed": true, "positive_controls": 6, "pr": 19, "qualification": "SYNTHETIC_GIT_NOT_INDEPENDENT_COMPLETE_CHECKOUT", "refusals": 115, "release": "NO_GO"}` |
| 16 | 0 | `{"passed": true, "positive_controls": 6, "pr": 20, "qualification": "SYNTHETIC_GIT_NOT_INDEPENDENT_COMPLETE_CHECKOUT", "refusals": 153, "release": "NO_GO"}` |
| 17 | 0 | `{"passed": true, "positive_controls": 6, "pr": 21, "qualification": "SYNTHETIC_GIT_NOT_INDEPENDENT_COMPLETE_CHECKOUT", "refusals": 161, "release": "NO_GO"}` |

Dependency guards 11/12/13 retain 9/49/66 refusals. The first dependency12 run on the later native-mapping source failed; its own unchanged historical version is the correct passing replay. Both receipts are retained.

The redundant local 151-case adapter was stopped incomplete after the actual frozen-source GitHub CLI completed all 151 negatives. It is never counted as a completed local pass. No gate is waived.

Detailed commands, cwd, actual exits, receipts, logs and hashes: proof/command-index.json. Actual browser: browser/sixth/summary.json and 94 PNGs; explicit exploratory errors: browser/failures/. No browser profiles, private storage or export binaries are packaged.
