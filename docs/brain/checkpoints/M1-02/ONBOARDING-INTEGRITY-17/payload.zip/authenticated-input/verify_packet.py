"""Campaign17 context authenticity only; never Security, DB or source acceptance."""
from pathlib import Path
from pathlib import PurePosixPath
import argparse
import hashlib
import json
import os
import re
import stat
import sys
import unicodedata

MAGIC = 'BRAIN-M1X-PRIVACY-REENTRY17-REPAIR-01'
REVISION = 'R1_AUTH_TEXT_CORRECTION'
TOKEN = b'@@EXTERNAL_MANIFEST_SHA256@@'

def check(ok, why):
    if not ok:
        raise ValueError(why)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def pairs(items):
    out = {}
    for k, v in items:
        check(k not in out, 'DUPLICATE_JSON_KEY')
        out[k] = v
    return out

def safe(path):
    if not isinstance(path, str) or not re.fullmatch(r'[A-Za-z0-9._/-]+', path):
        return False
    if PurePosixPath(path).is_absolute():
        return False
    for segment in path.split('/'):
        if not segment or segment in ('.', '..') or segment.startswith('.') or segment.endswith('.'):
            return False
        if re.fullmatch(r'(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?', segment, re.I):
            return False
    return True

def regular(path):
    resolved = path.resolve(strict=True)
    check(resolved == path.absolute(), 'NONCANONICAL_PATH')
    for p in (path, *path.parents):
        mode = p.lstat().st_mode
        check(not stat.S_ISLNK(mode) and not getattr(p.lstat(), 'st_file_attributes', 0) & 1024, 'LINK_OR_REPARSE')
    s = path.stat()
    check(stat.S_ISREG(s.st_mode) and s.st_nlink == 1, 'NONREGULAR_OR_HARDLINK')
    return path.read_bytes()

def verify(root, expected):
    check(re.fullmatch(r'[0-9a-f]{64}', expected or '') is not None, 'EXPECTED_SHA_INVALID')
    raw = regular(root / 'CONTEXT_MANIFEST.json')
    check(digest(raw) == expected, 'EXTERNAL_MANIFEST_MISMATCH')
    obj = json.loads(raw, object_pairs_hook=pairs)
    check(obj.get('authority') == MAGIC and obj.get('schema') == 1 and obj.get('revision') == REVISION, 'IDENTITY')
    check(obj.get('status') == 'CODEX_REPAIR_CONTEXT_ONLY' and obj.get('grants_release') is False, 'NO_RELEASE')
    content = obj.get('files')
    check(isinstance(content, dict) and len(content) >= 6, 'INVENTORY')
    check(all(x in content for x in ['PROMPT_TEMPLATE.md', 'verify_packet.py', 'TASK_DIRECTIVE.md']), 'PROMPT_TASK_OR_VERIFIER_UNLISTED')
    desired = set(content) | {'CONTEXT_MANIFEST.json', 'EXACT_PROMPT.md'}
    check(all(safe(x) for x in desired), 'UNSAFE_FILE_NAME')
    existing = set()
    seen = set()
    for path in root.rglob('*'):
        name = path.relative_to(root).as_posix()
        check(safe(name), 'UNSAFE_PATH:' + name)
        key = unicodedata.normalize('NFKC', name).casefold()
        check(key not in seen, 'COLLIDING_PATH'); seen.add(key)
        check(path.is_file(), 'NONFILE_MEMBER')
        existing.add(name)
    check(existing == desired, 'EXACT_INVENTORY_DIFF')
    for name, witness in content.items():
        data = regular(root / name)
        check(len(data) == witness.get('bytes') and digest(data) == witness.get('sha256'), 'CONTENT_MISMATCH:' + name)
    template = regular(root / 'PROMPT_TEMPLATE.md')
    check(template.count(TOKEN) == 1, 'PROMPT_TEMPLATE_TOKEN')
    derived = template.replace(TOKEN, expected.encode('ascii'))
    check(regular(root / 'EXACT_PROMPT.md') == derived, 'PROMPT_NOT_DERIVED')
    return {'status': 'VERIFIED', 'authenticated_files': len(content), 'derived_prompt_match': True, 'full_task_authenticated': True, 'revision': REVISION,
            'external_manifest_sha256': expected, 'git_source_accepted': False, 'security_db_release_accepted': False}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-manifest-sha256', required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(verify(Path(__file__).resolve().parent, args.expected_manifest_sha256), sort_keys=True))
        return 0
    except (OSError, ValueError, KeyError, TypeError, UnicodeError) as exc:
        print(json.dumps({'status': 'CONTEXT_INVALID', 'error': str(exc)}))
        return 1

if __name__ == '__main__':
    sys.exit(main())
