# Independent Brain PR20 source finding — 2026-10-26

Repository `TasfiqJ/onSkin`, PR20 `https://github.com/TasfiqJ/onSkin/pull/20`.

Verified live source chain (linear parentage / git-tree metadata):

- PR19 base `b79e6d1e21a367be5cea5d0b333de9f2a144d41f`, tree `ca7b6ac8ebcc0086b338b784f110b411400361b0`
- first Campaign16 source `f3c568540ad8ccf5882e97d1b2a13b6341e1f13a`, tree `0ab1ca3a552ae2e3a4d419a22e7a4843b9b52a18`
- source guard `015e3e8676dda6fd8c63b8de6de0ebe5c4b35345`, tree `39f38e1a9c8eec2c1d68c30d07811ec45c67d7cd`
- frozen source `3970ed1802ea928e50db1b12ec7e08a020355b09`, tree `3da45d639deac52858480e982cbc19f438eb5f88`
- evidence HEAD `28953aa3a84fed0684b80b442d0cd9c2de0663b2`, tree `6776b61b49c63345e992da63f82920fedd07518b`

GitHub confirms 21 changed paths within Campaign16 finite scope; modified files and new 100644 files shown in PR diff, no deletes/renames/mode changes shown. Draft/open/unmerged at audit; verify fresh before editing.

Independent checkpoint manifest SHA256 from GitHub live UTF-8 bytes MATCHES external `20e72188bfcca1b1319caa19f261444c41ace344efc193db2caa81e8c479dfd9`. Verified README and `verify16.py` file byte-size and SHA256 matches corresponding manifest entries. `payload.zip` is 6,276,868 bytes per manifest and was **not independently extracted or byte-hashed** here. Manifest lists 341 evidence members including 53 main browser-state screenshots; listed bytes are not inspected pixels. Therefore the previous 360x640/200%-text glyph claim and 0/1/0 complete checkout have NOT been independently reproduced.

Exact PR20 HEAD CI observed: Quality run `40272850558` SUCCESS all 6 jobs incl local canonical DB, PG15/PG17, Expo iOS/Android; iOS source-only run `40272850548` SUCCESS; Security run `40272850572` FAILURE four jobs with Live Supabase SKIPPED. Protected gates remain NO_GO.

## Concrete source defect justifying REPAIR_REQUIRED

At frozen PR20 source `apps/mobile/src/app/onboarding/quiz.tsx`, the new `focus()` at lines 32–47 sets `navigationIndex.current = -1` and awaits `hasCurrentHealthDataCollectionConsent()` but does **NOT** reset `consentChecked` to false at start of every focus. If the same mounted route previously checked consent, `consentChecked` may remain true during new asynchronous revalidation (for instance when returning from Products after consent withdrawal). The previously collected sensitive quiz answers and answer controls can remain rendered in the revalidation window. Further, `selectSingle` and `toggleMulti` at lines 92–100 call `setAnswer` without a focus/consent/lease admission guard. `OnboardingContext.tsx` lines 58–60 updates in-memory raw quiz responses in `setAnswer` synchronously; its guarded persistence path does not inherently protect this in-memory mutation. The route's `next` is protected by `quizNavigation16` index matching, but answer selection is not.

Repair must fail closed from the first focus event, suppress/mask question content and answer actions until current consent has been revalidated, cancel stale async completions, account for epoch/owner A->B->A/same-owner revoke/regrant, and prevent stale closures from changing another owner's quiz state. Test an actual mounted navigation return with pending/delayed consent, denial, owner change, renewal, rapid inputs, direct entry, and explicit reentry after reapproval. Do not claim previous tests covered it. Do not silently wipe legitimate current-owner drafts or leak/display another-owner's raw answers. If a correctly scoped, safe fix would require changing protected core, leave that portion unapplied with exact blocker; do NOT relax the core admissions.

## Additional regression to verify, not an adjudicated root-cause verdict

`products.tsx` frozen source calls the missing-goals redirect early in `go()` before the unsaved-name acknowledgement branch (lines 292–307). Reproduce whether an entered unsaved product can be lost without an explicit choice on that edge path; fix only if actual route behavior violates privacy/UX, preserving missing-goals correctness.

The independent audit has NOT granted Campaign16 source acceptance, UI screenshot/physical glyph acceptance, original Security acceptance, DB custody, M1-03, M2, J01 scientific/rights, native delivery/VoiceOver or public release.
