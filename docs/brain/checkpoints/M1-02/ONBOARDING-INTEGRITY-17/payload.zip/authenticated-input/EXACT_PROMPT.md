CAMPAIGN17 R1 - AUTHENTICATION CORRECTION AND ENGINEERING RESTART
Authority: BRAIN-M1X-PRIVACY-REENTRY17-REPAIR-01

You correctly stopped the earlier Campaign17 attempt before repository changes because the UI rendered my previous Markdown differently from the text inside the ZIP. This corrected instruction supersedes ONLY that defective chat-byte-comparison requirement; the engineering scope and protected gates are unchanged. CONTINUE THIS EXISTING CAMPAIGN17 CODEX CHAT.

The founder attaches ONE NEW ZIP named onSkin_Campaign17_Codex_Context_R1_2026-10-26.zip. IGNORE the old Campaign17 ZIP and do not reuse extracted older contents. Safely extract the NEW ZIP to a fresh empty directory, rejecting traversal, symlinks, reparse points, nonregular entries, name collisions and overwrites. From the newly extracted packet root run EXACTLY:

python -B verify_packet.py --expected-manifest-sha256 d2c9cbf835145ba4f98bc1c4162e9264ff81b4ce4982951c3d20e36c2b98a628

If the verifier does not return VERIFIED, STOP as CONTEXT_INVALID. The verifier MUST authenticate every declared file, the exact inventory, TASK_DIRECTIVE.md, and the derived EXACT_PROMPT.md. Do NOT compare UI-rendered text pasted in this chat byte-for-byte with EXACT_PROMPT.md; that old rule is formally withdrawn. The NEW externally anchored manifest and derived prompt are authoritative. Do NOT disable or weaken the verifier.

Read README_FIRST.md, BRAIN_SOURCE_AUDIT.md, SANITIZED_SECURITY_STATUS.md, FULL_APP_J01_SCOPE.md, PROTECTED_GATES.md and then TASK_DIRECTIVE.md, in that order. TASK_DIRECTIVE.md is the FULL, binding engineering assignment, including branch, finite edit allowlist, privacy repair, real tests, evidence, return packet and no-release limitations. Independently check live repository TasfiqJ/onSkin, pinned PR20 head 28953aa3a84fed0684b80b442d0cd9c2de0663b2 and tree 6776b61b49c63345e992da63f82920fedd07518b, and applicable AGENTS.md before changes.

Create a NEW isolated Campaign17 development branch rooted at the pinned immutable PR20 head; open only a NEW DRAFT PR based on the PR20 branch. NEVER edit PR20, PR10-19, main, or the security professional's local 3bc6b787 commit/workspace; never merge, auto-merge, access private security finding data, bypass gates or spend money. Resolve implementation decisions autonomously inside the authenticated scope. Security/G97 stays NO_GO and original Security CI failure stays honest. DB/J01/native/clinical/legal/public-release gates remain closed.

Execute the complete substantive work and validation in authenticated TASK_DIRECTIVE.md. Finish with a complete FINAL_REPORT.md, return ZIP, source/CI identities, evidence and all remaining limitations. End the final response with: Codex is done.
