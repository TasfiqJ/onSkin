# Campaign17 R1 - correction of prompt transport, NOT a new scope

The previous Campaign17 Codex run stopped at CONTEXT_INVALID because UI-rendered Markdown lost literal Markdown syntax. No repository changes occurred. That was an instruction-transport fault, not a failure of the prior cryptographic packet verifier. This R1 packet supersedes the older ZIP and fixes the ambiguous byte-comparison rule.

IMPORTANT TRUST RULE: Require the EXTERNAL SHA256 in the newly pasted R1 bootstrap. The verified manifest authenticates the technical TASK_DIRECTIVE.md and the derived EXACT_PROMPT.md. There is NO requirement to compare raw text of the founder's chat/paste byte-for-byte against the authenticated EXACT_PROMPT.md: Markdown renderers rewrite formatting and that comparison was unsuitable. Never skip manifest/file/derivation checks; if they fail, STOP CONTEXT_INVALID.

Read in order: README_FIRST.md, BRAIN_SOURCE_AUDIT.md, SANITIZED_SECURITY_STATUS.md, FULL_APP_J01_SCOPE.md, PROTECTED_GATES.md, TASK_DIRECTIVE.md. Then independently read live GitHub, repo AGENTS.md and source. Remain on a NEW isolated one-writer Campaign17 branch based on immutable PR20 evidence HEAD (no edits to PR20); draft/open PR only; no merge or auto-merge, USD0 incremental spend. Complete full engineering directive in TASK_DIRECTIVE.md.

All protected gates remain closed, including Security/G97, DB, J01, native, clinical/legal and public release. Local confidential security findings and commit 3bc6b787 are off limits. Source, CI and browser-only work cannot accept these gates.
