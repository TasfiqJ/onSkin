# Campaign17 R1 - Authenticated full engineering directive

Authority: BRAIN-M1X-PRIVACY-REENTRY17-REPAIR-01. This is the complete technical scope of the previously assigned Campaign17, copied without reducing its engineering work. The independently anchored R1 bootstrap prompt controls extraction/authentication, and supersedes the old requirement to byte-compare UI-rendered chat text with EXACT_PROMPT.md. Do NOT use the old Campaign17 ZIP. The source restrictions and all protected gates below remain unchanged.

Before implementation, read the other authenticated context files, inspect live GitHub and all applicable AGENTS.md, and verify the pinned source identity.

## 1. Exact trusted source and branch grant

Repo: `TasfiqJ/onSkin`. Campaign16 immutable DRAFT PR20 source candidate: https://github.com/TasfiqJ/onSkin/pull/20; branch `stage/m1-first-session-recovery16`, evidence HEAD `28953aa3a84fed0684b80b442d0cd9c2de0663b2`, tree `6776b61b49c63345e992da63f82920fedd07518b`. Its PR19 base: `b79e6d1e21a367be5cea5d0b333de9f2a144d41f`. Independently verify the exact ref SHA and Git commit-tree chain. **Never modify PR20, PR10–19 or `main`; never cherry-pick/mix local Security commit `3bc6b787` or any scanner artifacts.** If a remote ref moved, do not overwrite or rebase it: use immutable pinned source in a fresh isolated worktree/clone and report drift, continuing only if a correct independent draft branch remains safe.

**Make a NEW one-writer branch** `stage/m1-first-session-integrity17` rooted at the immutable PR20 HEAD; no reused local dirty checkout. Open ONE new DRAFT PR targeting PR20's branch. GitHub allocates its number; do not predict it. Preserve exact path/mode/source identity; keep auto-merge OFF and maintainer modifications OFF, with no merge of any branch. USD0 incremental spend, no paid API/provider/account/credential use or external uploads. If an authorized scope becomes blocked, solve safe independent streams and disclose unapplied items; no founder technical questions.

## 2. Real engineering work (not receipt-only)

**A. Repair the demonstrated mounted Quiz privacy re-entry defect.** In `apps/mobile/src/app/onboarding/quiz.tsx`, re-focus starts asynchronous current health consent verification while old `consentChecked=true` can render old raw quiz answers. `selectSingle/toggleMulti` remain writable during revalidation and directly update memory. Implement deterministic fail-closed revalidation upon every real focus, prevent answer/view/analytics effects until CURRENT consent and CURRENT owner/health epoch/focus token are admitted, retire stale asynchronous completions and old callbacks across blur, unmount, same-owner regrant/withdrawal and owner A→B→A. Preserve legitimate current-owner answers after approved return, force privacy route when denied, and never leak/show stale owner answers. Preserve immutable quiz/scoring/age/pregnancy/consent contracts and answer completeness; avoid fake “checking” after actual failure. If fully safe owner-private answer clearing requires protected core outside grant, report exact UNAPPLIED blocker, do not weaken it. Test restored Products→Quiz→Products, rapid taps, direct entry, stale denial/approval and old-owner answer selection.

**B. Complete Products unsaved-draft & real short-phone continuation.** Reproduce `products.tsx` missing-goals direct-entry with a typed unsaved name, since it redirects before unsaved-name confirmation; repair if it silently discards user input, while preserving goals guard and lease/Shelf owner isolation. Fully exercise typed unsaved name with 0,1,2,3 and larger Shelf, pending delete/refetch, keyboard, accessibility large labels, reduced motion, category sheet; keep explicit Continue/Skip at 360×640 text 200%, 375×667, 390×844, 430×932. Do not fake licensed catalog/Shelf availability or skip required consent. Inspect *visible real glyph pixels*, wrapped button labels and actionable touch regions; DOM dimensions alone do not prove readability.

**C. Reminder/route boundary regression and accessible recovery.** Recheck current-intent retry, storage write failure vs durable saved-but-unscheduled, unavailable vs denied OS notifications, rapid taps, old owner A→B→A, revoke/regrant, failed schedule/unmount and explicit off-unconfirmed continuation in Campaign16. Repair narrow defects if observed in allowed UI files only; do NOT alter original durable preference queue, delivery/permission backend or native permissions, and do not claim native delivery. Verify navigation does not silently advance on failed storage, stale lease, or hidden actions.

**D. Reproducible synthetic human-simulated browser E2E.** In a real Expo web build drive adult synthetic flow + direct entry, lifecycle focus/blur, consent withdrawn *during pending check*, retry and unsaved branch at four viewports. Capture truthful PNG pixel evidence including 360×640 at 200% text and keyboard-open, visible full text/action labels and genuine console/network logs. Use no real patient, photo, credential, account or production provider. Flag native installed iPhone, genuine OS permission/delivery, VoiceOver, paid services, Apple review, clinical/legal and provider functionality as `NOT_RUN`. Include an evidence-quality discriminator between screenshots, browser simulation, mocked React tests, source-only export, and physical device.

**E. Additive source provenance & exhaustive negatives.** Add Release17 source guard as **append-only successor** preserving original Release08–16 predicates, all 151 original semantic negatives, 153 Campaign16 refusals, 65-row/38-required Release08 identities, 47 tasks/51 ADRs, G97 fail-closed original inventory, DB06/DB08/R2B, M1-03, M2/J01 gate semantics. Verify exact changed-path/mode/index/commits and all 23k-plus protected baseline paths vs pinned PR20 using Git object blobs. No original checkpoint/version rewriting. Test synthetic hidden commit, forged base, old owner navigation, closure race, untracked hidden changes, symlink, rename, casefold and response/no-consent positives. Source-only status cannot become release acceptance.

**F. Test and deliver.** Run targeted tests, full forced root tests without warm-cache acceptance, lint/typecheck, unmodified historical controls, Release08–17 positives/negatives, Expo iOS/Android exports, iOS source-only, canonical credential-free local DB/PG15+17 where safely available, and exact final HEAD GitHub CI; report failures and NOT_RUN without waivers. Use separate full-checkout proof (positive, tampered negative, restored positive) and label simulated-fixture proof separately. Source commits followed by exactly ONE new compact EVIDENCE-ONLY tail. Produce an independently verifiable checkpoint with external manifest SHA256 and source/evidence SHA+trees, every changed file blob/mode/SHA256, honest screenshot/traces/commands/exits. Provide one return ZIP with SHA256 and a complete `FINAL_REPORT.md`. No secrets or synthetic health data in logs.

## 3. Finite EDIT / CREATE authorization

May EDIT existing paths only for A–F:
- `apps/mobile/src/app/onboarding/quiz.tsx`
- `apps/mobile/src/app/onboarding/products.tsx`
- `apps/mobile/src/app/onboarding/notifications.tsx` ONLY if concrete C repair proves necessary
- `apps/mobile/src/features/onboarding/quizNavigation16.ts` and `quizNavigation16.test.ts` for state focus guard tests, preserving prior positive cases
- `apps/mobile/src/features/onboarding/productsFooter16.test.ts`
- `apps/mobile/src/features/notifications/reminderRecovery16.test.ts`
- `docs/USER_FLOW_TREE.md` — one additive Campaign17 section only
- `scripts/release/full-app-j01/check.py` — additive Release17 segment only; inherited Release08–16 behavior unchanged
- `docs/phase-4/generated/source-worklist.json` and `.md` — ONLY outputs from the unchanged original producer after source freeze
- `ONSKIN_BRAIN_HANDOFF.txt` — factual newest pointer only, never acceptance claim.

May CREATE only:
- `apps/mobile/src/features/onboarding/quizFocus17.test.ts`, `productsDraft17.test.ts` and `onboardingPrivacy17.test.ts` (focused tests, if justified)
- `apps/mobile/src/features/notifications/reminderBoundary17.test.ts` if a new observed boundary needs testing
- `scripts/m1/onboarding_integrity17_browser.mjs` (new real browser reproducer; no new package dependencies)
- `scripts/release/full-app-j01/source_consumer17.test.py`
- `docs/brain/contracts/M1X-17/**`, `docs/brain/task-specs/M1X-17/**` (non-admitting candidates)
- `docs/brain/checkpoints/M1-02/ONBOARDING-INTEGRITY-17/**` (new finite checkpoint + verifier + sanitized proof).

**All other paths READ-ONLY**, notably PR20's old evidence/checkpoint/manifest/verifier, original QA/security scanner, `.github/**`, `scripts/phase9/**`, `scripts/security14/**`, `scripts/security15/**`, `scripts/phase4/**` producer, `docs/brain/state/**`, original launch/Release08–16 contracts and tests, `apps/mobile/src/features/onboarding/OnboardingContext.tsx`, raw health consent/age/profile/persistence, encrypted store, DB/Supabase/RLS/Edge, native iOS/Android, `package.json`/lockfiles, payment/catalog/providers, J01 research/model/images, and Security local 3bc6b787 workspace. If any true repair requires an unauthorized file, report precise blocker; continue everything else safely. Never bypass read/write/consent or original Source Inventory failure for a green check.

## 4. Binding final gates & return

First public release remains **ALL genuinely working non-Korean F01–F17/F19–F20 + 12 C + 6 P groups PLUS exactly J01 Visible Pores** after independent G1/G2/G3/G5 supported-phone/rights/ground truth/fairness/privacy/qualified proof; G4 only if longitudinal change later. F09 manual private photos required; F18 automated trend and J02–J27 (including J05 Spots) deferred. `G97=FAIL/NO_GO`; qualified Security 5,534 original potential findings and supplemental 1,255 privately undispositioned; local 3bc6b787 does NOT accept the original scanner. `DB06/DB08/R2B=NOT_ACCEPTED`; `M1-03=BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED`; `M2=NOT_AUTHORIZED`. Device, provider, legal, clinical, Apple, public release CLOSED. Never claim native tests/rights/real measurement where only synthetic source/browser tests exist. USD0. No merge.

**Final output must include** exact new branch and GitHub draft PR, base/head SHA+trees, intermediate changed paths/modes/blobs, exit-coded tests and negatives, browser screenshots and failures, manifest and return ZIP SHA256, final-head Quality/Security/iOS/DB/PG/Expo results, checkout clean/0 unpushed and all blocked protected gates. End with the literal line: `Codex is done.`
