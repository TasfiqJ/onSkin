import hashlib,json,pathlib,re,subprocess,sys,time
sys.stdout.reconfigure(encoding='utf-8')
run=pathlib.Path(__file__).resolve().parent;root=run/'repo';logs=run/'receipts';logs.mkdir(exist_ok=True)
policy=root/'apps/mobile/src/features/photos/manualCompare20.ts';route=root/'apps/mobile/src/app/(tabs)/progress.tsx'
original={p:p.read_bytes() for p in [policy,route]}
def digest(data):return hashlib.sha256(data).hexdigest()
mutations=[('duplicate-policy',policy,lambda s:s.replace("  if (before.id === after.id) return { status: 'missing' };",'  // SYNTHETIC MUTATION: duplicate guard removed'), 'src/features/photos/manualCompare20.test.ts'),
('stale-fallback',policy,lambda s:s.replace("    return { status: 'missing' };",'    return manualCompare20(photos);',1),'src/features/photos/manualCompare20.test.ts'),
('retired-picker',route,lambda s:re.sub(r'\s*\|\| pickerGeneration\.current !== pickerRevision','',s),'src/features/photos/manualCompare20Route.test.ts')]
rows=[]
for label,path,change,suite in mutations:
    before=original[path];mutated=change(before.decode()).encode();assert mutated!=before
    start=time.time()
    try:
        path.write_bytes(mutated)
        argv=['cmd.exe','/d','/s','/c','npm.cmd --workspace apps/mobile exec -- vitest run '+suite]
        with (logs/('mutation-'+label+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=root,stdout=f,stderr=subprocess.STDOUT)
        log=(logs/('mutation-'+label+'.log')).read_bytes()
        assert r.returncode==1 and b'AssertionError' in log and b'Failed Tests' in log,(label,r.returncode,log[-1000:])
    finally:path.write_bytes(before)
    assert path.read_bytes()==before
    receipt=dict(case=label,argv=argv,cwd=str(root),exit=r.returncode,expectedExit=1,mutationKilled=True,source=str(path.relative_to(root)),originalSHA256=digest(before),mutationSHA256=digest(mutated),restoredSHA256=digest(path.read_bytes()),logSHA256=digest(log),durationSeconds=round(time.time()-start,3))
    (logs/('mutation-'+label+'.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode());rows.append(receipt);print(json.dumps(receipt),flush=True)
(run/'mutation20-summary.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode())
