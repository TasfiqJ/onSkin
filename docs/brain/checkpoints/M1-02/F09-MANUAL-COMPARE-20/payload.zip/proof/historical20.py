import ast,concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,sys,time
sys.stdout.reconfigure(encoding='utf-8')
run=pathlib.Path(__file__).resolve().parent;primary=run/'repo';logs=run/'receipts';logs.mkdir(exist_ok=True)
source=(primary/'scripts/release/full-app-j01/check.py').read_bytes();values={}
for node in ast.parse(source).body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        try:values[node.targets[0].id]=ast.literal_eval(node.value)
        except (ValueError,TypeError):pass
endpoints={8:values['RELEASE08'],9:values['RELEASE09'],**{n:values['RELEASE'+str(n+1)+'_BASE'] for n in range(10,19)},19:values['RELEASE20_BASE']}
pins=json.loads((primary/values['RELEASE13_MANIFEST']).read_bytes())['unchangedNativeMappings']
paths={pin['path'] for row in pins for pin in row['notes']['sourcePins']}
base=run/'historical';base.mkdir(exist_ok=True)
def worker(n):
    root=base/('release'+str(n));root.mkdir()
    def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false','-c','core.longpaths=true',*args],cwd=root,stderr=subprocess.PIPE)
    git('init','--quiet');git('config','core.autocrlf','false');git('config','core.longpaths','true')
    (root/'.git/objects/info/alternates').write_bytes(((primary/'.git/objects').as_posix()+'\n').encode())
    git('read-tree',endpoints[n]);git('update-ref','HEAD',endpoints[n]);git('checkout-index','--all','--force')
    for name in paths:
        target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((primary/name).read_bytes())
    tasks=['test_contract.py'] if n==8 else ['source_consumer'+str(n).zfill(2)+'.test.py']
    if n==10:tasks.insert(0,'quality_projection10.test.py')
    if n in [11,12,13]:tasks.insert(0,'dependency_guard'+str(n)+'.test.py')
    results=[]
    for name in tasks:
        label='historical-release'+str(n)+'-'+name.removesuffix('.py')
        started=time.time();script=root/'scripts/release/full-app-j01'/name
        with (logs/(label+'.log')).open('wb') as f:result=subprocess.run([sys.executable,'-B',str(script)],cwd=root,stdout=f,stderr=subprocess.STDOUT)
        data=(logs/(label+'.log')).read_bytes();checker=root/'scripts/release/full-app-j01/check.py'
        receipt=dict(label=label,argv=[sys.executable,'-B',str(script)],cwd=str(root),head=endpoints[n],tree=git('rev-parse','HEAD^{tree}').decode().strip(),exit=result.returncode,durationSeconds=round(time.time()-started,3),testSHA256=hashlib.sha256(script.read_bytes()).hexdigest(),checkerSHA256=hashlib.sha256(checker.read_bytes()).hexdigest(),logSHA256=hashlib.sha256(data).hexdigest(),installedSource='Exact native source pins copied from independently npm-ci-installed unchanged Release13+ lock; full native install not inferred')
        (logs/(label+'.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode());results.append(receipt)
        print(json.dumps(dict(label=label,exit=result.returncode,seconds=receipt['durationSeconds'],tail=data.decode('utf-8',errors='replace')[-600:])),flush=True)
    return results
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    jobs={pool.submit(worker,n):n for n in range(8,19)}
    results=[]
    for task in concurrent.futures.as_completed(jobs):
        try:results.extend(task.result())
        except Exception as e:results.append(dict(release=jobs[task],error=str(e),exit=1));print(json.dumps(results[-1]),flush=True)
(run/'historical20-summary.json').write_bytes((json.dumps(results,indent=2)+'\n').encode())
sys.exit(int(any(row['exit'] for row in results)))
