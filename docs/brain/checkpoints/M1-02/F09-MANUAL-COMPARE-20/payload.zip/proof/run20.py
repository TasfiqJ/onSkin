import sys,subprocess,pathlib,json,time,hashlib,datetime,os
sys.stdout.reconfigure(encoding='utf-8')
root=pathlib.Path(__file__).resolve().parent
label=sys.argv[1];args=sys.argv[2:]
if args and args[0]=='--':args=args[1:]
if args[0] in ('npm','npx'):args=['cmd.exe','/d','/s','/c',subprocess.list2cmdline([args[0]+'.cmd',*args[1:]])]
logs=root/'receipts';logs.mkdir(exist_ok=True)
cwd=os.environ.get('C20_RUN_CWD',str(root/'repo'))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd).decode().strip()
start=time.time();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (logs/(label+'.log')).open('wb') as f:r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
data=(logs/(label+'.log')).read_bytes()
receipt=dict(label=label,argv=args,cwd=cwd,head=head,startedAt=now,durationSeconds=round(time.time()-start,3),exit=r.returncode,logBytes=len(data),logSHA256=hashlib.sha256(data).hexdigest())
(logs/(label+'.json')).write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt));print(data.decode('utf-8',errors='replace')[-3000:])
sys.exit(r.returncode)
