"""Verify independently SHA256-anchored Campaign20 context packet. Grants no Git/release acceptance."""
from pathlib import Path
import hashlib,json,os,re,stat,sys,unicodedata,argparse

def sha(data): return hashlib.sha256(data).hexdigest()
def need(condition,name):
    if not condition: raise ValueError(name)
def pairs(xs):
    d={}
    for k,v in xs:
        need(k not in d,'DUPLICATE_JSON_KEY'); d[k]=v
    return d

def name_ok(name):
    return isinstance(name,str) and bool(re.fullmatch(r'[A-Za-z0-9._-]+',name)) and name not in ('.','..') and not name.startswith('.') and not name.endswith('.') and not re.fullmatch(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?',name,re.I)

def strict_file(path,root):
    need(root.resolve()==root,'ROOT_NOT_RESOLVED')
    for p in [path,*path.parents]:
        if p == root.parent: break
        s=p.lstat()
        need(not stat.S_ISLNK(s.st_mode) and not bool(getattr(s,'st_file_attributes',0)&1024),'LINK_OR_REPARSE')
    s=path.lstat()
    need(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'REGULAR_SINGLE_LINK_REQUIRED')
    return path.read_bytes()

def verify(root,expected):
    need(re.fullmatch('[0-9a-f]{64}',expected) is not None,'EXTERNAL_SHA_FORMAT')
    root=root.resolve(strict=True)
    raw=strict_file(root/'manifest.json',root)
    need(sha(raw)==expected,'EXTERNAL_MANIFEST_SHA256_MISMATCH')
    m=json.loads(raw,object_pairs_hook=pairs)
    need(set(m)=={'schema','authority','status','acceptanceGranted','files','promptIdentical'},'MANIFEST_SCHEMA')
    need(m['schema']==1 and m['authority']=='BRAIN-M1X-F09-MANUAL-PHOTO-COMPARE20-CANDIDATE-01','MANIFEST_IDENTITY')
    need(m['status']=='SOURCE_ONLY_NON_ADMITTING' and m['acceptanceGranted'] is False and m['promptIdentical'] is True,'NO_ADMISSION')
    declared=m['files']
    need(isinstance(declared,dict) and len(declared)==9,'FINITE_INVENTORY')
    actual=[]
    for path,dirs,names in os.walk(root,topdown=True,followlinks=False):
        need(not dirs,'DIRECTORY_NOT_ALLOWED')
        for n in names:
            need(name_ok(n),'UNSAFE_NAME'); actual.append(n)
    need(len(actual)==len(set(unicodedata.normalize('NFKC',x).casefold() for x in actual)),'COLLISION')
    need(set(actual)==set(declared)|{'manifest.json'},'EXACT_INVENTORY')
    for n,v in declared.items():
        need(name_ok(n),'UNSAFE_DECLARED_NAME')
        data=strict_file(root/n,root)
        need(set(v)=={'bytes','sha256'} and len(data)==v['bytes'] and sha(data)==v['sha256'],'FILE_AUTH:'+n)
    need(strict_file(root/'EXACT_PROMPT.md',root)==strict_file(root/'PROMPT_TEMPLATE.md',root)==strict_file(root/'TASK_DIRECTIVE.md',root),'PROMPT_TRIAD_MISMATCH')
    return {'status':'VERIFIED','files':len(declared),'authority':m['authority'],'admission':'NONE'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--expected-manifest-sha256',required=True)
    args=p.parse_args()
    try:
        print(json.dumps(verify(Path(__file__).resolve().parent,args.expected_manifest_sha256),sort_keys=True)); return 0
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as e:
        print(json.dumps({'status':'CONTEXT_INVALID','error':str(e)}));return 1
if __name__=='__main__':sys.exit(main())
