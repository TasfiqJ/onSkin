# Acceptance and returns

The founder expects a single substantial Codex task, a new isolated draft PR and a complete report. Codex chooses internal UI algorithm, hooks, tests and bug fixes autonomously within finite paths. Keep all original gates, all 151 historical semantic negatives, full-app J01 65/38 and historical 47 tasks/51 ADRs, and prior Release08–19 positive/negative checks unchanged.

Synthetic E2E may use the existing dev-only EXPO_PUBLIC_E2E_PROGRESS_PHOTOS=populated and EXPO_PUBLIC_E2E_PROGRESS_STORAGE_FAILURE fixture switches only under __DEV__; identify those explicitly. Real Expo web screenshots and DOM text/keyboard pressure are not device or VoiceOver proof. Store exact original test names and show new negative mutations for same-ID comparison, stale pair and consent loss.

After source freeze produce original Phase4 generated worklists ONLY using unchanged producer from a clean committed source; check the strict original source-worklist guard both final HEAD and a fresh full checkout after final evidence-only tail. If status is stale, repair safely before sealing; never waive. One final evidence-only tail, manifest SHA256 external, exact Git blob/mode trees/commits, and all commands/exit codes and CI as actually observed. Return one ZIP and final report. Reviewer may accept scoped source without approving physical F09, Security or release.
