onSkin V2 / MasterV2 — Campaign20 Codex context

Authority: BRAIN-M1X-F09-MANUAL-PHOTO-COMPARE20-CANDIDATE-01. This is a new isolated SOURCE-ONLY, non-admitting app experience workstream following scoped acceptance of Campaign19's compatibility repair. Full product launch remains NO_GO.

Authenticate this packet against the manifest SHA-256 supplied externally by the ChatGPT Brain. Treat the separately pasted instruction as the task and the internally identical TASK_DIRECTIVE.md, EXACT_PROMPT.md and PROMPT_TEMPLATE.md as authenticated text. Do not compare rich-chat Markdown rendering byte-for-byte.

Read 01_SOURCE_PR23_AND_CI.md, 02_F09_IMPLEMENTATION_CONTEXT.md, 03_PROTECTED_SCOPE_GATES.md, 04_EVIDENCE_AND_RETURNS.md, then TASK_DIRECTIVE.md. Re-fetch actual GitHub, read AGENTS.md/CLAUDE.md and relevant docs, and obey current live code over these dated notes.

This packet is deliberately self-contained and contains no private security scanner artifacts, user photos, credentials or medical data. Its authentication proves packet integrity only, not repository or public product acceptance.
