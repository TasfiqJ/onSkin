"""Bounded external reproduction of the new29 temporary-path assumption.

Uses the actual Windows 8.3 API and authenticated current test bytes. No source
file is modified and no historical failure exception is inferred.
"""
import contextlib
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent/'c29-src'
PIN='2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
REL='scripts/release/full-app-j01/replay29.test.py'


def main():
    assert os.name=='nt' and not sys.flags.optimize
    git=lambda *args:subprocess.check_output(['git','--no-replace-objects',*args],cwd=ROOT)
    assert git('rev-parse','HEAD').decode().strip()==PIN
    assert not git('status','--porcelain=v1','--untracked-files=all')
    original=(ROOT/REL).read_bytes();assert original==git('show',PIN+':'+REL)
    old=b"prefix=Path(directory)/'prefix';npm="
    new=b"prefix=Path(directory).resolve()/'prefix';npm="
    assert original.count(old)==1
    corrected=original.replace(old,new,1)
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetShortPathNameW.argtypes=(ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint)
    kernel.GetShortPathNameW.restype=ctypes.c_uint
    temporary=tempfile.TemporaryDirectory
    aliases=[]
    class AliasTemporary:
        def __init__(self,*args,**kwargs):
            self.inner=temporary(*args,**kwargs);self.alias=False
            self.is_target=kwargs.get('prefix')=='release29-preobservation-'
        def __enter__(self):
            name=self.inner.__enter__()
            if not self.is_target:return name
            output=ctypes.create_unicode_buffer(32768)
            length=kernel.GetShortPathNameW(name,output,len(output))
            assert 0<length<len(output)
            alias=Path(output.value)
            self.alias=alias.resolve()!=alias;aliases.append(self.alias)
            assert self.alias,'NATIVE_SHORT_PATH_ALIAS_UNAVAILABLE'
            return str(alias)
        def __exit__(self,*args):return self.inner.__exit__(*args)
    rows=[]
    for label,body in (('authenticated-original-current-test',original),('external-one-line-canonical-fixture',corrected)):
        namespace={'__name__':'external_replay29_diagnostic','__file__':str(ROOT/REL)}
        exec(compile(body,'<authenticated new29 controls>','exec'),namespace)
        output=io.StringIO();failure=None
        with patch.object(tempfile,'TemporaryDirectory',AliasTemporary),contextlib.redirect_stdout(output):
            try:namespace['main']()
            except Exception as error:
                failure=dict(exceptionType=type(error).__name__)
                if type(error) is ValueError and len(error.args)==1 and type(error.args[0]) is str and re.fullmatch('[A-Z0-9_]+',error.args[0]):
                    failure['staticCode']=error.args[0]
        raw=output.getvalue().encode();(HERE/('temp-alias-'+label+'.jsonl')).write_bytes(raw)
        values=[json.loads(line) for line in output.getvalue().splitlines()]
        cases=[value['case'] for value in values if 'case' in value]
        rows.append(dict(case=label,failure=failure,lastCompletedCase=cases[-1] if cases else None,
            terminal=values[-1] if values else None,stdout=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),
            sourceTestSHA256=hashlib.sha256(body).hexdigest(),sourceIsUnmodified=body==original))
    assert rows[0]['failure']==dict(exceptionType='ValueError',staticCode='R29_NPM_METADATA_PATH')
    assert rows[0]['lastCompletedCase']=='synthetic-historical-mutated-ref-refused-before-scripts'
    assert rows[1]['failure'] is None and rows[1]['terminal']['status']=='PASS'
    assert rows[1]['terminal']['positiveControls']==5 and rows[1]['terminal']['refusals']==74
    assert len(aliases)==2 and all(aliases)
    assert not git('status','--porcelain=v1','--untracked-files=all')
    receipt=dict(schema=1,status='PASS_NATIVE_83_TEMP_ALIAS_CONTROLLED_REPRODUCTION',head=PIN,
        sourceTestSHA256=hashlib.sha256(original).hexdigest(),pythonVersion=list(sys.version_info[:3]),
        nativeShortAliasesObserved=2,records=rows,
        proposedChange='Only canonicalize the new test temporary fixture prefix with Path(directory).resolve()',
        historicalHostedException='UNKNOWN_SUPPRESSED;CONTROLLED_REPRODUCTION_IS_SEPARATE',
        sourceModified=False,qualification='SYNTHETIC_PLATFORM_PATH_REPRODUCTION_NOT_HISTORICAL_FAILURE_FINGERPRINT',
        acceptanceGranted=False,release='NO_GO')
    (HERE/'REPLAY_TEMP_ALIAS_DIAGNOSIS29.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(json.dumps(receipt,sort_keys=True))


if __name__=='__main__':main()
