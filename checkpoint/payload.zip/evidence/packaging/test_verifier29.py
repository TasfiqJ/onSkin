"""External synthetic artifact controls. No source, release or Brain acceptance."""
import ast
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import subprocess
import sys
import tempfile
from unittest.mock import patch
import zipfile
import zlib


OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent.parent/'c29-src'
BASE = 'bace116586d58ed955f0a024ca96ae9f4ad9286d'
TREE = '6951590547b79a869464df987d16da6552907846'
AUTH = 'BRAIN-M1X-WINDOWS-READER-INTEGRITY29-CANDIDATE-01'
INPUT = '7a94feecb69b09d46acb6465972f1c7b809fbfa9e657aa50c1f7bc4523643579'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()


def witness(raw):
    return dict(bytes=len(raw), sha256=sha(raw))


def archive(files, special=None):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_STORED) as target:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 10, 30, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG|0o644) << 16
            if special and name in special:
                info.external_attr = special[name]
            target.writestr(info, data)
    return stream.getvalue()


def loader(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def fixture(module, verifier):
    payload_files = {'evidence/SYNTHETIC_ONLY.txt': b'Public synthetic fixture; not evidence of source acceptance.\n'}
    files = {'README.md': b'# SYNTHETIC CONTROL ONLY\n',
             'REPORT.md': b'No source execution or acceptance is claimed.\n',
             'payload.zip': archive(payload_files), 'verify29.py': verifier}
    source = dict(base=BASE, baseTree=TREE, runtimeHead='1'*40, runtimeTree='2'*40,
                  sourceHead='3'*40, sourceTree='4'*40)
    value = dict(schema=1, authority=AUTH, status='SUBMITTED_REVIEW_REQUIRED',
                 acceptanceGranted=False, release='NO_GO', inputManifestSHA256=INPUT,
                 source=source, files={name: witness(raw) for name, raw in files.items()},
                 payload=dict(schema=1, qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',
                              files={name: witness(raw) for name, raw in payload_files.items()}))
    files['manifest.json'] = encoded(value)
    return files


def synthetic_return(module, checkpoint_files, returned):
    """Shape-only bundle/history: full-Git mode must separately prove semantics."""
    checkpoint_manifest = json.loads(checkpoint_files['manifest.json'])
    source = {**checkpoint_manifest['source'], 'candidateHead': '5'*40, 'candidateTree': '6'*40}
    def change(path):
        raw = b'synthetic shape witness\n'
        after = dict(mode='100644', blob='7'*40, **witness(raw))
        return dict(path=path, status='M' if path in module.EXISTING else 'A',
                    before=after if path in module.EXISTING else None, after=after)
    groups = [[module.PLAN], ['scripts/release/full-app-j01/readerTrace29.py'],
              sorted(module.WORKLIST), sorted({module.CHECKPOINT+n for n in module.CHECKPOINT_FILES}|{'ONSKIN_BRAIN_HANDOFF.txt'})]
    identities = [(module.PLAN_COMMIT, BASE, '8'*40), (source['runtimeHead'], module.PLAN_COMMIT, source['runtimeTree']),
                  (source['sourceHead'], source['runtimeHead'], source['sourceTree']),
                  (source['candidateHead'], source['sourceHead'], source['candidateTree'])]
    history = dict(schema=1, qualification='GIT_HISTORY_AND_BLOB_IDENTITIES_NOT_ACCEPTANCE',
        base=BASE, baseTree=TREE, head=source['candidateHead'], tree=source['candidateTree'],
        scopeCommit=module.PLAN_COMMIT, scopePlanSHA256=module.PLAN_SHA256,
        commits=[dict(commit=ident[0], parent=ident[1], tree=ident[2], changes=[change(p) for p in group])
                 for ident, group in zip(identities, groups)],
        delta=[change(p) for p in sorted({p for group in groups for p in group})])
    blob = b'public synthetic delta\n'; size = len(blob)
    first = (3 << 4)|(size & 15); size >>= 4
    header = bytes([first|128, size]) if size else bytes([first])
    pack = b'PACK'+struct.pack('>II', 2, 1)+header+zlib.compress(blob)
    pack += hashlib.sha1(pack).digest()
    bundle = (b'# v2 git bundle\n-'+BASE.encode()+b' synthetic prerequisite\n'+
              source['candidateHead'].encode()+b' HEAD\n\n'+pack)
    files = {'FINAL_REPORT.md': b'# SYNTHETIC CONTROL; NOT A REAL RETURN\n',
             'verify_return29.py': returned, 'source/GIT_HISTORY.json': encoded(history),
             'source/synthetic-pr32-required.bundle': bundle,
             **{'checkpoint/'+name: raw for name, raw in checkpoint_files.items()}}
    value = dict(schema=1, authority=AUTH, status='SUBMITTED_REVIEW_REQUIRED', acceptanceGranted=False,
        release='NO_GO', inputManifestSHA256=INPUT, source=source,
        files={name: witness(raw) for name, raw in files.items()},
        qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
        checkpoint=dict(path='checkpoint', manifestSHA256=sha(checkpoint_files['manifest.json'])),
        gitHistory=dict(path='source/GIT_HISTORY.json'),
        gitDelta=dict(path='source/synthetic-pr32-required.bundle', base=BASE, baseTree=TREE,
                      head=source['candidateHead'], tree=source['candidateTree']))
    files['manifest.json'] = encoded(value)
    return files


def alias_attack(module, directory):
    target = directory/'alias-reader-fixture.bin'
    original = b'public synthetic reader content\n'*4096
    target.write_bytes(original); named = target.lstat()
    real_open, real_read, real_fstat, real_lstat = os.open, os.read, os.fstat, Path.lstat
    descriptor = opened = None
    calls = 0
    consumed = None
    def open_source(path, flags, *args, **kwargs):
        nonlocal descriptor, opened
        fd = real_open(path, flags, *args, **kwargs)
        if Path(path) == target:
            descriptor, opened = fd, real_fstat(fd)
        return fd
    def read_source(fd, size):
        nonlocal calls, consumed
        block = real_read(fd, min(size, 32))
        if fd == descriptor:
            calls += 1
            if calls == 1:
                consumed = block
                with target.open('r+b') as stream: stream.write(b'X')
        return block
    def fstat_source(fd):
        return opened if fd == descriptor else real_fstat(fd)
    def lstat_source(path, *args, **kwargs):
        return named if path == target else real_lstat(path, *args, **kwargs)
    error = None; result = None
    with patch.object(module.os, 'open', open_source), patch.object(module.os, 'read', read_source), \
         patch.object(module.os, 'fstat', fstat_source), patch.object(Path, 'lstat', lstat_source):
        try: result = module.read_regular(target)
        except (ValueError, OSError) as failure:
            error = failure.args[0] if type(failure.args[0]) is str and failure.args[0].startswith(('R29_', 'R27_')) else type(failure).__name__
    assert consumed == original[:32] and target.read_bytes() == b'X'+original[1:]
    closed = False
    try: real_fstat(descriptor)
    except OSError: closed = True
    assert closed
    target.write_bytes(original)
    assert module.read_regular(target) == original
    return dict(refused=error is not None, error=error, returnedOriginal=result == original,
                originalBytesConsumed=32, realBackingInitialByteChanged=True,
                pathnameAndHandleMetadataAliased=True, descriptorClosed=True,
                exactRestoration=True)


def main():
    assert not sys.flags.optimize
    checkpoint_path, return_path = OUT/'verify29.py', OUT/'verify_return29.py'
    checkpoint_body, return_body = checkpoint_path.read_bytes(), return_path.read_bytes()
    module = loader(checkpoint_path, 'verifier29_review')
    assert checkpoint_body.replace(b"MODE = 'checkpoint'", b"MODE = 'return'", 1) == return_body
    assert module.BASE == BASE and module.BASE_TREE == TREE and module.AUTHORITY == AUTH and module.INPUT == INPUT
    assert module.PLAN_COMMIT == '9b395cbee7594f7dc03934aed4e08c4e3ea43c23'
    assert module.PLAN_SHA256 == 'c6548573be9be966446ef5ab7fe78e7b16cdbff0a9eb14559d8019ae7057eabe'
    assert len(module.EXISTING|module.NEW) == 20 and not module.EXISTING & module.NEW
    assert module.CHECKPOINT_FILES == {'README.md', 'REPORT.md', 'manifest.json', 'payload.zip', 'verify29.py'}
    assert "value.get('source29')" in checkpoint_body.decode() and "value.get('source28')" not in checkpoint_body.decode()
    assert "consumer_result.get('inheritedFunctions') == 218" in checkpoint_body.decode()
    assert 'source_consumer28.test.py' not in checkpoint_body.decode()
    assert 'source_consumer29.test.py' in checkpoint_body.decode()
    assert b'EXACT_PR31_DELTA_OBJECTS_NO_SOURCE_OBJECT_WRITES' not in checkpoint_body
    assert b'EXACT_PR32_DELTA_OBJECTS_NO_SOURCE_OBJECT_WRITES' in checkpoint_body
    area = 'scripts/release/full-app-j01/'
    expected_scope = {area+name for name in ('replay27.py', 'replay28.py', 'readerIntegrity29.test.py',
        'readerTrace29.py', 'replay29.py', 'replay29.test.py', 'source_consumer29.test.py', 'check.py')}
    expected_scope |= {'.github/workflows/security-candidate22.yml', 'ONSKIN_BRAIN_HANDOFF.txt',
        'docs/brain/task-specs/M1X-29/SCOPE_PLAN.md', 'docs/brain/task-specs/M1X-29/TASK.md',
        'docs/brain/contracts/M1X-29/source29.v1.json',
        'docs/phase-4/generated/source-worklist.json', 'docs/phase-4/generated/source-worklist.md'}
    expected_scope |= {module.CHECKPOINT+name for name in module.CHECKPOINT_FILES}
    assert module.EXISTING|module.NEW == expected_scope
    workspace = Path(tempfile.mkdtemp(prefix='verifier29-controls-', dir=OUT)).resolve()
    assert workspace.parent == OUT.resolve() and workspace.name.startswith('verifier29-controls-')
    results = []
    try:
        files = fixture(module, checkpoint_body)
        anchor = sha(files['manifest.json'])
        directory = workspace/'checkpoint'; directory.mkdir()
        for name, raw in files.items(): (directory/name).write_bytes(raw)
        archive_path = workspace/'synthetic-checkpoint.zip'; archive_path.write_bytes(archive(files))
        def cli(label, expected, target=archive_path, extra=(), verifier=checkpoint_path,
                manifest_anchor=anchor, verifier_anchor=None, root=False):
            command = [sys.executable, '-I', '-B', str(verifier), '--root' if root else '--archive', str(target),
                       '--expected-manifest-sha256', manifest_anchor,
                       '--expected-verifier-sha256', verifier_anchor or sha(verifier.read_bytes()), *extra]
            child = subprocess.run(command, capture_output=True, timeout=30)
            assert not child.stderr and len(child.stdout) <= 8192
            value = json.loads(child.stdout)
            assert child.returncode == expected and value['release'] == 'NO_GO' and value['acceptanceGranted'] is False, (label, child.returncode, value)
            if expected == 0:
                assert value['status'] == 'VERIFIED' and value['sourceChecks'] == {'state': 'NOT_RUN'}
            else: assert value['status'] == 'CONTEXT_INVALID'
            results.append(dict(case=label, exit=child.returncode, result=value))
        cli('valid-synthetic-checkpoint-archive', 0)
        cli('valid-synthetic-checkpoint-directory', 0, target=directory, root=True)
        cli('wrong-external-manifest', 1, manifest_anchor='0'*64)
        cli('wrong-external-verifier', 1, verifier_anchor='0'*64)
        cli('source-checks-require-full-git', 1, extra=('--execute-source-checks',))
        cli('unknown-argument-refused', 1, extra=('--unknown',))
        extra = directory/'unexpected.txt'; extra.write_bytes(b'public synthetic extra')
        cli('directory-extra-file', 1, target=directory, root=True); extra.unlink()
        saved = (directory/'REPORT.md').read_bytes(); (directory/'REPORT.md').unlink()
        cli('directory-omitted-file', 1, target=directory, root=True)
        (directory/'REPORT.md').write_bytes(saved)
        cli('actual-byte-baseline', 0, target=directory, root=True)
        (directory/'REPORT.md').write_bytes(saved+b'changed')
        cli('actual-byte-tamper', 1, target=directory, root=True)
        (directory/'REPORT.md').write_bytes(saved)
        cli('actual-byte-restoration', 0, target=directory, root=True)
        link = workspace/'outside-hardlink'; os.link(directory/'REPORT.md', link)
        cli('directory-hardlink-refused', 1, target=directory, root=True); link.unlink()
        cli('hardlink-exact-restoration', 0, target=directory, root=True)

        def reject_archive(label, raw):
            path = workspace/(label+'.zip'); path.write_bytes(raw)
            cli(label, 1, target=path)
        reject_archive('archive-extra-file', archive({**files, 'unexpected.txt': b'extra'}))
        reject_archive('archive-omitted-file', archive({key: raw for key, raw in files.items() if key != 'REPORT.md'}))
        for label, names in [('traversal', ('../escape.txt',)), ('absolute', ('/escape.txt',)),
                             ('drive', ('C:/escape.txt',)), ('windows-alias', ('con.txt',)),
                             ('case-alias', ('A.txt', 'a.txt')), ('nfkc-alias', ('A.txt', '\uff21.txt')),
                             ('implicit-parent-collision', ('a', 'a/b.txt'))]:
            reject_archive('archive-'+label, archive({**files, **{name: b'synthetic' for name in names}}))
        for label, attributes in [('symlink', (stat.S_IFLNK|0o777) << 16),
                                  ('special', (stat.S_IFCHR|0o644) << 16),
                                  ('reparse', ((stat.S_IFREG|0o644) << 16)|1024)]:
            reject_archive('archive-'+label, archive(files, {'README.md': attributes}))
        raw = archive(files); cd = raw.index(b'PK\x01\x02'); end = raw.rindex(b'PK\x05\x06')
        with zipfile.ZipFile(io.BytesIO(raw)) as package:
            info = package.getinfo('README.md')
            local = info.header_offset
            start = local+30+len(info.filename.encode())
        changed = bytearray(raw); changed[start] ^= 1
        reject_archive('archive-bad-crc', bytes(changed))
        changed = bytearray(raw); changed[local+30] ^= 1
        reject_archive('archive-local-name-mismatch', bytes(changed))
        changed = bytearray(raw); changed[local+14] ^= 1
        reject_archive('archive-local-crc-mismatch', bytes(changed))
        changed = bytearray(raw); changed[cd+16] ^= 1
        reject_archive('archive-central-crc-mismatch', bytes(changed))
        changed = bytearray(raw); struct.pack_into('<H', changed, end+10, 99)
        reject_archive('archive-central-count-mismatch', bytes(changed))
        changed = bytearray(raw); struct.pack_into('<I', changed, cd+24, module.MAX_FILE+1)
        reject_archive('archive-expansion-bound', bytes(changed))
        changed = bytearray(raw); struct.pack_into('<H', changed, local+6, 8); struct.pack_into('<H', changed, cd+8, 8)
        reject_archive('archive-descriptor-flag-refused', bytes(changed))
        # A descriptor record with no matching supported descriptor protocol is
        # rejected as a gap, even when its location and directory offset agree.
        descriptor = b'PK\x07\x08'+b'\0'*12
        changed = bytearray(raw[:cd]+descriptor+raw[cd:])
        struct.pack_into('<I', changed, end+len(descriptor)+16, cd+len(descriptor))
        reject_archive('archive-unexpected-descriptor-record', bytes(changed))
        reject_archive('archive-truncated-end', raw[:-1])

        returned_files = synthetic_return(module, files, return_body)
        return_archive = workspace/'synthetic-return.zip'; return_archive.write_bytes(archive(returned_files))
        cli('valid-synthetic-return-shape-only', 0, target=return_archive, verifier=return_path,
            manifest_anchor=sha(returned_files['manifest.json']))
        value = json.loads(returned_files['manifest.json'])
        value['source']['base'] = '9'*40
        returned_files['manifest.json'] = encoded(value)
        return_archive.write_bytes(archive(returned_files))
        cli('return-old-or-wrong-base-refused', 1, target=return_archive, verifier=return_path,
            manifest_anchor=sha(returned_files['manifest.json']))

        current = alias_attack(module, workspace)
        assert current['refused'] and current['error'] == 'R29_REPLAY_CHANGED'
        results.append(dict(case='new-verifier-real-consumed-byte-metadata-alias-refusal', result=current))
        raw = subprocess.check_output(['git', '--no-replace-objects', 'show',
            BASE+':docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/verify28.py'], cwd=SOURCE)
        assert sha(raw) == '9769435d01d678fd6acfcd1bd484f493578d2c32e2ecc7d5c431f2925c8d33f7'
        previous_functions = {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(raw).body
                              if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
        current_functions = {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(checkpoint_body).body
                             if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
        assert previous_functions.keys() == current_functions.keys()
        changed = {name for name in previous_functions if previous_functions[name] != current_functions[name]}
        assert changed == {'read_regular', 'return_packet', 'source_checks', 'verify_delta_pack', 'main'}, changed
        results.append(dict(case='finite20-scope-and-exact-inherited-function-AST-review',
                            changedFunctions=sorted(changed), status='PASS'))
        old = type(module)('frozen_verifier28'); old.__dict__['__file__'] = '<authenticated-old-verifier>'
        exec(compile(raw, '<authenticated-old-verifier>', 'exec'), old.__dict__)
        previous = alias_attack(old, workspace)
        assert not previous['refused'] and previous['returnedOriginal']
        results.append(dict(case='frozen-verifier-conditional-gap-contrast', result=previous,
                            qualification='CONTROLLED_METADATA_MODEL_NOT_HISTORICAL_FAILURE_DIAGNOSIS'))
    finally:
        # Every recursive cleanup target is resolved and verified task-local.
        assert workspace.resolve() == workspace and workspace.parent == OUT.resolve() and workspace.name.startswith('verifier29-controls-')
        shutil.rmtree(workspace)
    result = dict(schema=1, status='PASS', controls=len(results), results=results,
        checkpointVerifierSHA256=sha(checkpoint_body), returnVerifierSHA256=sha(return_body),
        checkerAndConsumerPinsQualification='PROTOTYPE_PINS_MUST_BE_REBUILT_AFTER_FINAL_SOURCE',
        qualification='SYNTHETIC_ARTIFACT_AND_CONTROLLED_IO_TESTS_NOT_FINAL_ARTIFACT_FULL_GIT_OR_BRAIN_ACCEPTANCE',
        acceptanceGranted=False, release='NO_GO')
    (OUT/'VERIFIER_CONTROLS29.json').write_bytes(encoded(result))
    print(json.dumps({key: result[key] for key in ('status', 'controls', 'checkpointVerifierSHA256', 'returnVerifierSHA256', 'qualification')}))


if __name__ == '__main__':
    main()
