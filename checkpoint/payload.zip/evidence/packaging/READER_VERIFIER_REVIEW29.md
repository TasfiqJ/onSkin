# Campaign29 independent agent verifier and governance review

This is supplier-side independent-agent review and synthetic control execution,
not independent Brain acceptance, final artifact verification or full-clone proof.
All gates remain NO_GO; sourceAcceptance=false and acceptanceGranted=false.

## Artifact verifier review

No actionable source-binding or integrity defect found in the inspected prototypes.
The checkpoint and return variants differ only in MODE. Their source parent/tree,
new input manifest, first-plan identity, finite20-path set, checkpoint directory,
new29 source/consumer labels, PR32-dependent bundle prerequisite and218 inherited
function count match Campaign29. Older PR27/PR28 constants are authentic ancestry
checks. The remaining verify-return28 temporary-directory prefix and R27 regular-
metadata diagnostic are inherited cosmetic identifiers, not old source authority.

The new read_regular performs two independently bounded reads of the same opened
descriptor and repeats pathname/handle metadata and parent identity validation.
It has the same finite observation boundary as the repaired source reader: two
matching reads cannot establish an unobserved past or prevent an adversarial
change after the last observation. No universal TOCTOU/native claim is supported.

External test_verifier29.py passed39 controls on the fresh authenticated
Python3.12.10 runtime. It tests valid synthetic checkpoint directory/archive and
synthetic return shape; external manifest/verifier anchors; source-check execution
requiring full Git; malformed arguments; extra/omitted members; actual artifact
byte corruption/refusal/restoration0/1/0; hardlink refusal/restoration; traversal,
absolute/drive/Windows/case/NFKC/implicit-parent aliases; archive symlink/special/
reparse modes; bad CRC; inconsistent local/central metadata and count; excessive
expansion; descriptor flag/unexpected descriptor framing; truncation; and wrong
return base. The strict inherited archive protocol rejects descriptor-bearing ZIPs
rather than accepting unsupported framing. Builders must use its supported ZIP
format. Synthetic history/bundle shape deliberately reports full-Git semantics
NOT_CHECKED_WITHOUT_GIT_ROOT, with sourceChecks=NOT_RUN.

An independently implemented real-file attack changes byte0 after32 original
bytes have been consumed and aliases both observed metadata families. The new
verifier refuses R29_REPLAY_CHANGED, closes the descriptor and accepts exact
restoration. The authenticated pinned old verifier returns original bytes while
backing bytes differ in the same conditional model. This contrast is not a
diagnosis of either historical suppressed Windows exception.

AST comparison verifies every inherited function/class is unchanged except the
five intended source/binding functions: read_regular, return_packet, source_checks,
verify_delta_pack and main. New source checker/consumer hashes embedded in the
prototypes must be regenerated after those source bytes become final, then this
control suite rerun against the final verifier bytes. Earlier39-control receipt
hashes identify the inspected prototypes and are not final-verifier anchors.

## Current29 governance and historical runner review

No actionable correctness, scope or security finding in the inspected new29
checker appendix, source consumer, replay runner or receipt controls.

The checker preserves exact PR32 bytes before the old final main terminal and all
218 inherited function ASTs in order. The new appendix has explicit function,
assignment and dispatch scopes plus a normalized appendix hash. Existing reader
exceptions admit only named bytes27/bytes28 with a pinned portable semantic AST
and exact bytes outside those functions. Original reader tests remain unchanged.
The finite grant permits no mobile/app writes or original Security changes.

The new source guard retains standalone complete Git/object-store checks,
no alternates/promisor/grafts/replacements, object integrity, filter neutralization,
exact source/index/history identities, full raw tracked-blob reconciliation and
bounded ignored-generated paths. Pending finite source changes are qualified as
FINITE_PENDING_ALLOWED; FROZEN/TAIL require a clean exact checkout. The history
machine requires the immutable plan first, one worklist-only child and one exact
six-file evidence tail, and rejects later source changes or repeated tails.

CI custody binds the exact repository, PR number, PR32 base branch/head, new29
head branch/commit, draft state, maintainer modification=false, auto_merge=null
and actual fetched test-merge parents/tree. The event's advisory merge snapshot
does not replace that actual object proof. Contract admissions remain false.

The runner pins original24–28 checker/consumer tree, Git blob and SHA identities;
independent Git reads verified all five sets. In particular original27 is pinned
to exact PR31 and original28 to exact PR32. It creates complete fresh remote
clones and empty external npm caches, executes normal mandatory npm hooks and
unchanged consumers/checkers, then reconciles source/tool identities again.
Receipt controls stay explicitly synthetic and do not claim actual replay.
There is no broad inherited-case exclusion: the one recognized original
all-original-function-ASTs-preserved output row is authenticated at its original
pin, while all other original rows require truthful exit/expected-exit semantics.

The historical Windows exception remains UNKNOWN and bounded reproduction may
honestly be NOT_REPRODUCED. Final hosted tests, final artifact checks, two fresh
remote clones and actual final-source0/1/0 controls remain separate required work.
