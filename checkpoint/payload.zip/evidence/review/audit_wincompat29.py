SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Independent, trusted read-only audit. Never executes supplied archive code."""
import ast, hashlib, io, json, pathlib, re, stat, struct, unicodedata, zipfile, zlib

SOURCE = pathlib.Path(r'<LOCAL_HOME>\Downloads\onSkin_Campaign29_Windows_Reader_Integrity_Context_WinCompat_2026-10-30 (1).zip')
ANCHOR = '7a94feecb69b09d46acb6465972f1c7b809fbfa9e657aa50c1f7bc4523643579'
ROOT = pathlib.Path(__file__).parent

def require(ok, code, **details):
    if not ok:
        raise ValueError(code + ':' + json.dumps(details, sort_keys=True, ensure_ascii=True))

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def read_json(blob):
    def pairs(items):
        result = {}
        for k, v in items:
            require(k not in result, 'DUPLICATE_JSON_KEY', key=k)
            result[k] = v
        return result
    return json.loads(blob.decode('utf8'), object_pairs_hook=pairs)

def extras(raw, name):
    result = {}; p = 0
    while p < len(raw):
        require(p + 4 <= len(raw), 'EXTRA_HEADER_TRUNCATED', member=name)
        k, n = struct.unpack_from('<HH', raw, p); p += 4
        require(p + n <= len(raw) and k not in result, 'BAD_OR_DUPLICATE_EXTRA', member=name)
        result[k] = raw[p:p+n]; p += n
    require(1 not in result, 'ZIP64_NOT_SUPPORTED', member=name)
    return result

def audit(raw, label):
    end = raw.rfind(b'PK\x05\x06', max(0, len(raw)-65557))
    require(end >= 0 and end+22 <= len(raw), 'EOCD_MISSING_OR_TRUNCATED', archive=label)
    disk, startdisk, on_disk, count, cd_size, cd_start, comment = struct.unpack_from('<4H2IH', raw, end+4)
    require(end+22+comment == len(raw), 'EOCD_TRAILING_OR_COMMENT_LENGTH', archive=label)
    require(disk == startdisk == 0 and on_disk == count and count < 65535 and count <= 10000, 'MULTIDISK_ZIP64_OR_COUNT', archive=label)
    require(cd_start + cd_size == end, 'CENTRAL_BOUNDARY', archive=label)
    p = cd_start; entries = []; namespace = {}; total = 0; descriptors = 0
    for j in range(count):
        require(p+46 <= end and raw[p:p+4] == b'PK\x01\x02', 'CENTRAL_FRAMING', archive=label, index=j)
        made, needed, flags, method, time, date, crc, compressed, size, nl, xl, cl, diskno, internal, external, offset = struct.unpack_from('<6H3I5H2I', raw, p+4)
        require(p+46+nl+xl+cl <= end, 'CENTRAL_OVERRUN', archive=label, index=j)
        encoded = raw[p+46:p+46+nl]
        require(b'\0' not in encoded, 'NUL_PATH', archive=label, index=j)
        name = encoded.decode('utf8' if flags & 0x800 else 'cp437')
        ex = extras(raw[p+46+nl:p+46+nl+xl], name)
        if 0x7075 in ex:
            u = ex[0x7075]
            require(len(u) >= 5 and u[0] == 1 and struct.unpack_from('<I', u, 1)[0] == (zlib.crc32(encoded)&0xffffffff), 'UNICODE_EXTRA_INVALID', member=name)
            require(u[5:].decode('utf8') == name, 'UNICODE_EXTRA_ALIAS', member=name)
        require(diskno == 0 and flags & ~(0x800|8|6) == 0 and method in (0,8), 'UNSUPPORTED_FLAGS_METHOD', member=name)
        require(not name.startswith(('/', '\\')) and '\\' not in name and ':' not in name, 'ABSOLUTE_DRIVE_BACKSLASH', member=name)
        parts = name.rstrip('/').split('/'); is_dir = name.endswith('/')
        require(all(s and s not in ('.','..') for s in parts), 'TRAVERSAL_EMPTY_PATH', member=name)
        mode = external >> 16; kind = stat.S_IFMT(mode)
        require(kind in (0,stat.S_IFREG,stat.S_IFDIR) and not external & 0x400, 'SPECIAL_SYMLINK_REPARSE', member=name, mode=oct(mode))
        require((kind != stat.S_IFDIR or is_dir) and (kind != stat.S_IFREG or not is_dir) and (not is_dir or size == 0), 'TYPE_NAME_DATA_MISMATCH', member=name)
        normalized = []
        for i,s in enumerate(parts):
            n = unicodedata.normalize('NFKC',s).casefold()
            require(n not in ('','.','..') and not n.endswith((' ','.')) and not any(c in '/\\:<>"|?*' or ord(c)<32 for c in n), 'UNSAFE_NORMALIZED_COMPONENT', member=name)
            require(not re.match(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)', n), 'WINDOWS_RESERVED_NAME', member=name)
            normalized.append(n); key = '/'.join(normalized); spelling = '/'.join(parts[:i+1]); directory = i < len(parts)-1 or is_dir; explicit = i == len(parts)-1
            if key in namespace:
                old = namespace[key]
                require(old[0] == spelling, 'UNICODE_CASE_ALIAS', member=name)
                require(old[1] and directory, 'IMPLICIT_PARENT_FILE_COLLISION', member=name)
                require(not (old[2] and explicit), 'DUPLICATE_MEMBER', member=name)
                namespace[key] = (spelling, directory, old[2] or explicit)
            else:
                namespace[key] = (spelling,directory,explicit)
        require(size < 256*1024*1024 and (size < 1024*1024 or size <= max(compressed,1)*1000), 'EXCESSIVE_MEMBER_EXPANSION', member=name)
        total += size
        require(total < 1024*1024*1024, 'EXCESSIVE_TOTAL_EXPANSION', archive=label)
        require(max(size,compressed,offset) < 0xffffffff, 'ZIP64_VALUES', member=name)
        entries.append(dict(name=name,encoded=encoded,needed=needed,flags=flags,method=method,time=time,date=date,crc=crc,compressed=compressed,size=size,offset=offset,mode=mode))
        p += 46+nl+xl+cl
    require(p == end, 'CENTRAL_SIZE_COUNT_MISMATCH', archive=label)
    next_local = 0
    for e in sorted(entries, key=lambda v:v['offset']):
        p = e['offset']; name = e['name']
        require(p == next_local, 'LOCAL_GAP_OVERLAP_PREAMBLE', member=name)
        require(p+30 <= cd_start and raw[p:p+4] == b'PK\x03\x04', 'LOCAL_FRAMING', member=name)
        needed, flags, method, time, date, crc, compressed, size, nl, xl = struct.unpack_from('<5H3I2H', raw, p+4)
        require(p+30+nl+xl <= cd_start, 'LOCAL_HEADER_OVERRUN', member=name)
        require(raw[p+30:p+30+nl] == e['encoded'], 'LOCAL_CENTRAL_PATH_MISMATCH', member=name)
        extras(raw[p+30+nl:p+30+nl+xl], name)
        require((needed,flags,method,time,date)==tuple(e[k] for k in ('needed','flags','method','time','date')), 'LOCAL_CENTRAL_HEADER_MISMATCH', member=name)
        if flags & 8:
            require(crc in (0,e['crc']) and compressed in (0,e['compressed']) and size in (0,e['size']), 'LOCAL_DESCRIPTOR_PLACEHOLDER', member=name)
        else:
            require((crc,compressed,size)==tuple(e[k] for k in ('crc','compressed','size')), 'LOCAL_CENTRAL_SIZE_CRC_MISMATCH', member=name)
        begin = p+30+nl+xl; finish = begin+e['compressed']
        require(finish <= cd_start, 'LOCAL_DATA_OVERRUN', member=name)
        if method == 8:
            decoder=zlib.decompressobj(-15); decompressed=decoder.decompress(raw[begin:finish])+decoder.flush()
            require(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail, 'DEFLATE_FRAMING', member=name)
        else: decompressed = raw[begin:finish]
        require(len(decompressed)==e['size'] and zlib.crc32(decompressed)&0xffffffff == e['crc'], 'DECOMPRESSION_SIZE_CRC', member=name)
        next_local=finish
        if flags & 8:
            descriptors += 1
            if raw[next_local:next_local+4] == b'PK\x07\x08': next_local += 4
            require(next_local+12 <= cd_start and struct.unpack_from('<3I',raw,next_local)==tuple(e[k] for k in ('crc','compressed','size')), 'DATA_DESCRIPTOR_MISMATCH', member=name)
            next_local += 12
    require(next_local == cd_start, 'LOCAL_CENTRAL_FINAL_BOUNDARY', archive=label)
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require(len(z.infolist())==count, 'STDLIB_COUNT_MISMATCH', archive=label)
        blobs={e['name']:z.read(e['name']) for e in entries}
    return blobs, entries, dict(label=label,bytes=len(raw),sha256=sha(raw),members=count,uncompressed_bytes=total,data_descriptors=descriptors,raw_records_paths_types_aliases_expansion_crc='PASS')

def inventory(blobs, entries, anchor=None):
    require('manifest.json' in blobs, 'MANIFEST_MISSING')
    if anchor: require(sha(blobs['manifest.json'])==anchor, 'MANIFEST_ANCHOR_MISMATCH', actual=sha(blobs['manifest.json']))
    m=read_json(blobs['manifest.json']); declared=m['files']
    require(set(declared)==set(blobs)-{'manifest.json'}, 'MANIFEST_INVENTORY_MISMATCH')
    for name,spec in declared.items():
        require(len(blobs[name])==spec['bytes'] and sha(blobs[name])==spec['sha256'], 'DECLARED_FILE_BYTES_HASH', member=name)
        if 'mode' in spec:
            e=next(e for e in entries if e['name']==name)
            require(format(e['mode'],'o')==spec['mode'], 'DECLARED_ZIP_MODE', member=name)
    return m

raw=SOURCE.read_bytes(); blobs, entries, result=audit(raw, SOURCE.name); manifest=inventory(blobs,entries,ANCHOR)
result.update(manifest_sha256=sha(blobs['manifest.json']),declared_files_verified=len(manifest['files']),verifier_bytes=len(blobs['verify_packet.py']),verifier_sha256=sha(blobs['verify_packet.py']),extracted=False,supplied_code_executed=False)
print(json.dumps(result,sort_keys=True))
print('AUTHENTICATED_MANIFEST_START\n'+blobs['manifest.json'].decode('utf8')+'\nAUTHENTICATED_MANIFEST_END')
print('AUTHENTICATED_VERIFIER_SOURCE_START\n'+blobs['verify_packet.py'].decode('utf8')+'\nAUTHENTICATED_VERIFIER_SOURCE_END')
result['embedded']=[]
constants={}
for node in ast.parse(blobs['verify_packet.py'].decode('utf8')).body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and isinstance(node.value,ast.Constant):
        constants[node.targets[0].id]=node.value.value
for name in sorted(n for n in blobs if n.endswith('.zip')):
    nested, nested_entries, detail=audit(blobs[name],name); nm=inventory(nested,nested_entries)
    detail.update(manifest_sha256=sha(nested['manifest.json']),declared_files_verified=len(nm['files']))
    detail['verifiers']={n:sha(b) for n,b in nested.items() if n.startswith('verify') and n.endswith('.py')}
    if name==constants['ZIP28']:
        require(detail['sha256']==constants['SHA28']==manifest['previousReturnSHA256'] and detail['manifest_sha256']==constants['MAN28'] and detail['verifiers']['verify_return28.py']==constants['VER28'] and detail['members']==205,'RETURN28_TRIAD_ANCHOR_MISMATCH')
    elif name==constants['HAND']:
        require(detail['sha256']==constants['HANDSHA']==manifest['previousBrainSHA256'] and detail['manifest_sha256']==constants['HANDMAN'] and detail['members']==30,'BRAIN_ANCHOR_MISMATCH')
    else: require(False,'UNEXPECTED_EMBEDDED_ZIP',member=name)
    result['embedded'].append(detail)
    print(json.dumps(detail,sort_keys=True))
(ROOT/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
print('INDEPENDENT_WINCOMPAT_AUDIT_PASS')
