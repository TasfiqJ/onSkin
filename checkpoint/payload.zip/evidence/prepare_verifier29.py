"""Build the finite Campaign29 artifact verifier from reviewed pinned scaffolding."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent.parent / 'c29-src'
OUT = Path(__file__).resolve().parent / 'packaging'
BASE = 'bace116586d58ed955f0a024ca96ae9f4ad9286d'
TREE = '6951590547b79a869464df987d16da6552907846'
PLAN = 'docs/brain/task-specs/M1X-29/SCOPE_PLAN.md'
PLAN_COMMIT = '9b395cbee7594f7dc03934aed4e08c4e3ea43c23'
AUTH = 'BRAIN-M1X-WINDOWS-READER-INTEGRITY29-CANDIDATE-01'
INPUT = '7a94feecb69b09d46acb6465972f1c7b809fbfa9e657aa50c1f7bc4523643579'
CHECKPOINT = 'docs/brain/checkpoints/M1-02/WINDOWS-READER-INTEGRITY-29/'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def function(source, name):
    node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == name)
    return ast.get_source_segment(source, node)


def main():
    OUT.mkdir(exist_ok=True)
    origin = 'docs/brain/checkpoints/M1-02/DESTRUCTIVE-COMMIT-CORE05-28/verify28.py'
    inherited = git('show', BASE+':'+origin)
    assert sha(inherited) == '9769435d01d678fd6acfcd1bd484f493578d2c32e2ecc7d5c431f2925c8d33f7'
    source = inherited.decode()
    plan = (ROOT/PLAN).read_bytes()
    granted = json.loads(re.search(rb'```json\n(.*?)\n```', plan, re.S).group(1))
    assert len(granted) == 20 and len(set(granted)) == 20
    existing = {name for name in granted if git('ls-tree', BASE, '--', name)}
    new = set(granted)-existing
    constants = {
        'AUTHORITY': AUTH, 'INPUT': INPUT, 'BASE': BASE, 'BASE_TREE': TREE,
        'CHECKPOINT': CHECKPOINT,
        'CHECKPOINT_FILES': {'README.md', 'REPORT.md', 'manifest.json', 'payload.zip', 'verify29.py'},
        'EXISTING': existing, 'NEW': new, 'PLAN': PLAN, 'PLAN_COMMIT': PLAN_COMMIT,
        'PLAN_SHA256': sha(plan),
        'CHECKER_SHA256': sha((ROOT/'scripts/release/full-app-j01/check.py').read_bytes()),
        'CONSUMER_SHA256': sha((ROOT/'scripts/release/full-app-j01/source_consumer29.test.py').read_bytes()),
    }
    for key, value in constants.items():
        rendered = repr(value) if not isinstance(value, set) else '{'+', '.join(repr(x) for x in sorted(value))+'}'
        source, count = re.subn(r'(?m)^'+key+r' = .*$', lambda _: key+' = '+rendered, source)
        assert count == 1, key
    substitutions = {
        'Campaign28': 'Campaign29', 'verify_return28.py': 'verify_return29.py', 'verify28.py': 'verify29.py',
        'source28.v1.json': 'source29.v1.json',
        'scripts/release/full-app-j01/source_consumer28.test.py': 'scripts/release/full-app-j01/source_consumer29.test.py',
        "value.get('source28')": "value.get('source29')", 'RELEASE28': 'RELEASE29',
        'release28=': 'release29=', 'consumer28=': 'consumer29=',
        'refs/heads/stage/m1-destructive-commit-core05-28': 'refs/heads/stage/m1-windows-reader-integrity29',
        'EXACT_PR31_DELTA_OBJECTS_NO_SOURCE_OBJECT_WRITES': 'EXACT_PR32_DELTA_OBJECTS_NO_SOURCE_OBJECT_WRITES',
        "consumer_result.get('inheritedFunctions') == 202": "consumer_result.get('inheritedFunctions') == 218",
        'SYNTHETIC_GIT_AND_SCHEMA_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_APP_PRIVACY_PROOF':
            'SYNTHETIC_GIT_AND_READER_SCOPE_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_SECURITY_ACCEPTANCE',
    }
    for before, after in substitutions.items():
        source = source.replace(before, after)
    # Use the repaired reader itself, rather than retaining the old scaffold's
    # single-pass consumed-byte blind spot in artifact/source verification.
    reader = function((ROOT/'scripts/release/full-app-j01/replay28.py').read_text(), 'bytes28')
    for before, after in [('bytes28', 'read_regular'), ('bound', 'limit'), ('require28', 'need'),
                          ('regular28', 'regular_metadata'), ('cross28', 'cross_metadata'),
                          ('same28', 'stable_metadata'), ('R28_', 'R29_')]:
        reader = reader.replace(before, after)
    assert 'os.lseek' in reader and 'verified' in reader
    old_reader = function(source, 'read_regular')
    source = source.replace(old_reader, reader, 1)
    terminal = "if __name__ == '__main__':\n    sys.exit(main())\n"
    assert source.endswith(terminal)
    codes = sorted(set(re.findall(r"'(R29_[A-Z0-9_]+)'", reader)))
    source = source[:-len(terminal)] + 'PUBLIC_CODES = PUBLIC_CODES | frozenset('+repr(codes)+')\n\n' + terminal
    ast.parse(source)
    checkpoint = source.encode()
    returned = checkpoint.replace(b"MODE = 'checkpoint'", b"MODE = 'return'", 1)
    for name, body in [('verify29.py', checkpoint), ('verify_return29.py', returned)]:
        (OUT/name).write_bytes(body)
    receipt = {
        'status': 'VERIFIER_PROTOTYPE_BUILT_REQUIRES_CONTROLS', 'base': BASE, 'tree': TREE,
        'scaffoldSHA256': sha(inherited), 'readerSourceSHA256': sha(reader.encode()),
        'checkpointVerifierSHA256': sha(checkpoint), 'returnVerifierSHA256': sha(returned),
        'constants': {key: sorted(value) if isinstance(value, set) else value for key, value in constants.items()},
        'qualification': 'NEW_FINITE_VERIFIER_REVIEW_NOT_ACCEPTANCE', 'acceptanceGranted': False, 'release': 'NO_GO',
    }
    (OUT/'VERIFIER_BUILD29.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps({key:receipt[key] for key in ['status','checkpointVerifierSHA256','returnVerifierSHA256']}))


if __name__ == '__main__':
    main()
