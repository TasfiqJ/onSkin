"""Run the unchanged producer once and create only its two-path child."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent/'c29-src'
BASE = 'bace116586d58ed955f0a024ca96ae9f4ad9286d'
WORKLIST = {'docs/phase-4/generated/source-worklist.json', 'docs/phase-4/generated/source-worklist.md'}
PRODUCER = 'scripts/phase4/build-source-worklist.mjs'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-source-head', required=True)
    args = parser.parse_args()
    receipt = HERE/'WORKLIST_FREEZE29.json'
    intent = HERE/'WORKLIST_PRODUCER29.started.json'
    assert not receipt.exists() and not intent.exists(), 'SECOND_PRODUCER_FORBIDDEN'
    assert git('rev-parse', 'HEAD').decode().strip() == args.expected_source_head
    assert not git('status', '--porcelain=v1', '--untracked-files=all')
    original = git('show', BASE+':'+PRODUCER)
    assert (ROOT/PRODUCER).read_bytes() == original
    assert hashlib.sha256(original).hexdigest() == 'b3882f954498008cd80fe57d50f75c358504bca99f5f97b7481239977af26d1e'
    tools = json.loads((HERE/'runtime/ACTIVE_TOOLCHAIN29.json').read_bytes())
    environment = {key:value for key,value in os.environ.items() if not key.upper().startswith(('PHASE4_', 'GIT_', 'NPM_', 'PYTHON'))}
    for key in list(environment):
        if key.upper() in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN'):del environment[key]
    environment['PATH'] = tools['prefix']+os.pathsep+str(Path(tools['python']).parent)+os.pathsep+environment['PATH']
    argv = [tools['node'], PRODUCER, '--strict']
    state = {'status':'PRODUCER_STARTED_ONCE', 'sourceHead':args.expected_source_head,
             'sourceTree':git('rev-parse', 'HEAD^{tree}').decode().strip(), 'argv':argv,
             'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'producerSHA256':hashlib.sha256(original).hexdigest(), 'producerInvocationCount':1,
             'release':'NO_GO', 'acceptanceGranted':False}
    with intent.open('x') as marker:
        marker.write(json.dumps(state, indent=2)+'\n')
    start = time.monotonic()
    with (HERE/'worklist-producer29.log').open('xb') as output:
        result = subprocess.run(argv, cwd=ROOT, env=environment, stdout=output, stderr=subprocess.STDOUT, timeout=180)
    state['exit'] = result.returncode
    log_body=(HERE/'worklist-producer29.log').read_bytes()
    state['producerLog']={'bytes':len(log_body),'sha256':hashlib.sha256(log_body).hexdigest()}
    state['elapsedMilliseconds'] = round((time.monotonic()-start)*1000)
    state['actualChangedPaths'] = git('diff', '--name-only').decode().splitlines()
    state['status'] = 'PRODUCER_EXIT0_PENDING_TWO_PATH_COMMIT' if result.returncode == 0 else 'BLOCKED_PRODUCER_FAILED_NO_SECOND_INVOCATION'
    receipt.write_text(json.dumps(state, indent=2)+'\n')
    assert result.returncode == 0, state['status']
    assert set(state['actualChangedPaths']) == WORKLIST
    assert not git('ls-files', '--others', '--exclude-standard').strip()
    git('add', '--', *sorted(WORKLIST))
    assert set(git('diff', '--cached', '--name-only').decode().splitlines()) == WORKLIST
    git('commit', '-m', 'docs(campaign29): freeze the original two source worklists')
    state.update(status='PASS_SOLE_TWO_WORKLIST_CHILD', worklistHead=git('rev-parse', 'HEAD').decode().strip(),
                 worklistTree=git('rev-parse', 'HEAD^{tree}').decode().strip())
    assert git('rev-list', '--parents', '-n', '1', 'HEAD').decode().split() == [state['worklistHead'], args.expected_source_head]
    assert not git('status', '--porcelain=v1', '--untracked-files=all')
    state['files'] = {name:{'bytes':len((ROOT/name).read_bytes()),
                          'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in sorted(WORKLIST)}
    receipt.write_text(json.dumps(state, indent=2)+'\n')
    print(json.dumps(state))


if __name__ == '__main__':
    main()
