"""Small independent controlled ZIP checks for the external provider reader."""
import ast,io,pathlib,stat,struct,zipfile
source=pathlib.Path(__file__).with_name('read_public_artifact29.py');tree=ast.parse(source.read_text(encoding='utf8'));ns={};exec(compile(ast.Module(body=[n for n in tree.body if not isinstance(n,ast.If)],type_ignores=[]),str(source),'exec'),ns)
class Stream(io.BytesIO):
    def seekable(self):return False
    def seek(self,*args):raise io.UnsupportedOperation()
def packet(rows,stream=False):
    b=Stream() if stream else io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:
        for name,body,mode in rows:
            i=zipfile.ZipInfo(name);i.create_system=3;i.external_attr=mode<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,body)
    return b.getvalue()
row=('security29-current-source.json',b'{"valid":true}',0o100644)
good=packet([row]);assert ns['inspect'](good)[0][row[0]]==row[1]
streamed=packet([row],True);assert ns['inspect'](streamed)[2]['dataDescriptors']==1
corrupt=bytearray(good);central=corrupt.find(b'PK\x01\x02');crc=struct.unpack_from('<I',corrupt,14)[0]^1;struct.pack_into('<I',corrupt,14,crc);struct.pack_into('<I',corrupt,central+16,crc)
bad=[('CRC',bytes(corrupt),'ZIP_CRC_OR_SIZE'),('casefold',packet([('A/x.json',b'1',0o100644),('a/y.json',b'2',0o100644)]),'ZIP_ALIAS_PARENT_COLLISION'),('NFKC',packet([('K.json',b'1',0o100644),('\u212a.json',b'2',0o100644)]),'ZIP_ALIAS_PARENT_COLLISION'),('implicit-parent',packet([('A',b'1',0o100644),('A/x',b'2',0o100644)]),'ZIP_ALIAS_PARENT_COLLISION'),('traversal',packet([('../x',b'1',0o100644)]),'ZIP_PATH_COMPONENT'),('drive',packet([('C:/x',b'1',0o100644)]),'ZIP_PATH'),('symlink',packet([('x',b'target',stat.S_IFLNK|0o777)]),'ZIP_SPECIAL_REPARSE')]
for label,raw,expected in bad:
    try:ns['inspect'](raw)
    except ValueError as e:assert e.args==(expected,), (label,e.args,expected)
    else:raise AssertionError(label+'_ACCEPTED')
print('PASS:2 authentic regular/descriptor fixtures;7 exact CRC/path/alias/type refusals')
