"""Materialize authenticated GitHub artifact bytes locally with bounded stdout."""
import argparse,datetime,hashlib,json,pathlib,shutil,subprocess,threading,time
p=argparse.ArgumentParser();p.add_argument('--artifact-id',type=int,required=True);p.add_argument('--expected-bytes',type=int,required=True);p.add_argument('--expected-sha256',required=True);p.add_argument('--archive',required=True);p.add_argument('--receipt',required=True);a=p.parse_args();assert 0<a.expected_bytes<=32*1024*1024 and len(a.expected_sha256)==64
target=pathlib.Path(a.archive);receipt=pathlib.Path(a.receipt);assert not target.exists() and not receipt.exists();gh=shutil.which('gh');assert gh is not None
argv=[gh,'api','--method','GET','repos/TasfiqJ/onSkin/actions/artifacts/'+str(a.artifact_id)+'/zip'];started=datetime.datetime.now(datetime.timezone.utc).isoformat();child=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW);blocks=[];state={'bytes':0,'error':None}
def drain():
    try:
        while True:
            part=child.stdout.read(65536)
            if not part:break
            state['bytes']+=len(part)
            if state['bytes']>a.expected_bytes:state['error']='PROVIDER_RESPONSE_BOUND';break
            blocks.append(part)
    except BaseException:state['error']='PROVIDER_STREAM_FAILURE'
    finally:child.stdout.close()
reader=threading.Thread(target=drain,daemon=True);reader.start();deadline=time.monotonic()+180
while child.poll() is None or reader.is_alive():
    if state['error'] or time.monotonic()>deadline:child.kill();child.wait(timeout=15);reader.join(timeout=15);raise ValueError(state['error'] or 'PROVIDER_TIMEOUT')
    time.sleep(.02)
code=child.wait(timeout=10);raw=b''.join(blocks);digest=hashlib.sha256(raw).hexdigest();assert code==0 and len(raw)==a.expected_bytes and digest==a.expected_sha256
with target.open('xb') as f:f.write(raw)
assert target.read_bytes()==raw
result=dict(schema=1,status='ACTUAL_AUTHENTICATED_GITHUB_NETWORK_ARTIFACT_BYTES_MATCH_METADATA',artifactId=a.artifact_id,argv=argv,exit=code,bytes=len(raw),sha256=digest,completeEOF=True,startedUTC=started,completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),redirectHandledByGitHubCLI=True,temporarySignedURLPublished=False,temporarySignedURLPersisted=False,credentialValuesReadOrPublished=False,originalSecurityArtifact=False,qualification='Actual artifact download bytes only; structural safety/export handled by independent reader; source acceptance not granted',acceptanceGranted=False,release='NO_GO')
with receipt.open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status=result['status'],artifactId=a.artifact_id,bytes=len(raw),sha256=digest)),flush=True)
