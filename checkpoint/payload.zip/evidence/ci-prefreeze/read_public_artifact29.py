"""Authenticate provider-digest-bound public CI ZIP; export explicit receipts only."""
import argparse,hashlib,json,os,pathlib,re,stat,struct,unicodedata,zlib
MAX_ARCHIVE=32*1024*1024;MAX_MEMBER=16*1024*1024;MAX_TOTAL=64*1024*1024;MAX_COUNT=1024
ALLOW={
 'security22-public.json','security23-toolchain-controls.json','security23-native-controls.json','security24-advisory-controls.tap',
 'security27-hosted-reader.jsonl','security27-python312-reader.jsonl','security28-reader.jsonl','security28-core05.tap',
 'security29-frozen-reader-diagnostics.jsonl','security29-reader-controls.jsonl','security29-replay-controls.jsonl',
 'security29-historical-receipt.json','security29-historical-controls.jsonl','security29-source-controls.jsonl','security29-current-source.json'}
H=lambda b:hashlib.sha256(b).hexdigest()
def need(v,c):
    if not v:raise ValueError(c)
def regular(i):return stat.S_ISREG(i.st_mode) and i.st_nlink==1 and not getattr(i,'st_file_attributes',0)&1024 and not i.st_mode&(stat.S_ISUID|stat.S_ISGID|stat.S_ISVTX) and 0<=i.st_size<=MAX_ARCHIVE
def stamp(i):return (i.st_dev,i.st_ino,i.st_mode,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns,getattr(i,'st_birthtime_ns',None),getattr(i,'st_file_attributes',None),getattr(i,'st_reparse_tag',None))
def read_stable(path):
    path=pathlib.Path(os.path.abspath(path));parents={}
    for p in path.parents:
        i=p.lstat();need(stat.S_ISDIR(i.st_mode) and not getattr(i,'st_file_attributes',0)&1024,'INPUT_PARENT');parents[p]=(i.st_dev,i.st_ino,i.st_mode)
    a=path.lstat();need(regular(a),'INPUT_REGULAR');fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0))
    try:
        b=os.fstat(fd);need(regular(b) and all(getattr(a,n)==getattr(b,n) for n in ('st_dev','st_ino','st_nlink','st_size','st_mtime_ns')),'INPUT_OPEN_IDENTITY');need(a.st_mode==b.st_mode,'INPUT_MODE')
        if os.name!='nt':need(a.st_ctime_ns==b.st_ctime_ns,'INPUT_CTIME')
        elif hasattr(a,'st_birthtime_ns') and hasattr(b,'st_birthtime_ns'):need(a.st_birthtime_ns==b.st_birthtime_ns,'INPUT_BIRTHTIME')
        chunks=[];total=0
        while True:
            block=os.read(fd,min(1024*1024,a.st_size-total+1))
            if not block:break
            total+=len(block);need(total<=a.st_size,'INPUT_SIZE');chunks.append(block)
        first=b''.join(chunks);need(total==a.st_size and stamp(b)==stamp(os.fstat(fd)),'INPUT_FIRST_CHANGED');os.lseek(fd,0,os.SEEK_SET);offset=0
        while True:
            block=os.read(fd,min(1024*1024,a.st_size-offset+1))
            if not block:break
            need(offset+len(block)<=len(first) and block==first[offset:offset+len(block)],'INPUT_SECOND_BYTES');offset+=len(block)
        need(offset==len(first) and stamp(b)==stamp(os.fstat(fd)) and stamp(a)==stamp(path.lstat()),'INPUT_CHANGED')
    finally:os.close(fd)
    for p,identity in parents.items():
        i=p.lstat();need((i.st_dev,i.st_ino,i.st_mode)==identity and not getattr(i,'st_file_attributes',0)&1024,'INPUT_PARENT_CHANGED')
    return first
def extras(raw,encoded,name):
    p=0;seen=set()
    while p<len(raw):
        need(p+4<=len(raw),'ZIP_EXTRA_FRAME');kind,size=struct.unpack_from('<HH',raw,p);p+=4;need(p+size<=len(raw) and kind not in seen,'ZIP_EXTRA_FRAME');body=raw[p:p+size];p+=size;seen.add(kind);need(kind!=1,'ZIP64_FORBIDDEN')
        if kind==0x7075:need(len(body)>=5 and body[0]==1 and struct.unpack_from('<I',body,1)[0]==zlib.crc32(encoded)&0xffffffff and body[5:].decode('utf8')==name,'ZIP_UNICODE_PATH_ALIAS')
def inspect(raw):
    need(len(raw)<=MAX_ARCHIVE,'ZIP_ARCHIVE_BOUND');end=raw.rfind(b'PK\x05\x06',max(0,len(raw)-65557));need(end>=0 and end+22<=len(raw),'ZIP_END_FRAME')
    disk,startdisk,diskcount,count,cdsize,cdoffset,comment=struct.unpack_from('<4H2IH',raw,end+4);need(disk==startdisk==0 and diskcount==count and count<65535 and count<=MAX_COUNT and cdoffset+cdsize==end and end+22+comment==len(raw),'ZIP_END_BOUND')
    pos=cdoffset;entries=[];namespace={};declared=0
    for _ in range(count):
        need(pos+46<=end and raw[pos:pos+4]==b'PK\x01\x02','ZIP_CENTRAL_FRAME')
        made,version,flags,method,t,d,crc,packed,size,nl,xl,cl,diskno,internal,external,offset=struct.unpack_from('<6H3I5H2I',raw,pos+4)
        need(pos+46+nl+xl+cl<=end and version<=20 and flags&~(0x800|8|6)==0 and method in (0,8) and diskno==0 and max(packed,size,offset)<0xffffffff,'ZIP_CENTRAL_FIELDS')
        encoded=raw[pos+46:pos+46+nl];need(b'\0' not in encoded,'ZIP_NUL_PATH');name=encoded.decode('utf8' if flags&0x800 else 'cp437');need(name and not name.startswith(('/','\\')) and '\\' not in name and ':' not in name,'ZIP_PATH')
        isdir=name.endswith('/');parts=name[:-1].split('/') if isdir else name.split('/');need(all(p and p not in ('.','..') for p in parts) and len(parts)<=12,'ZIP_PATH_COMPONENT');mode=external>>16;kind=stat.S_IFMT(mode)
        need(kind in (0,stat.S_IFREG,stat.S_IFDIR) and not external&1024 and not mode&(stat.S_ISUID|stat.S_ISGID|stat.S_ISVTX),'ZIP_SPECIAL_REPARSE')
        need((kind!=stat.S_IFDIR or isdir) and (kind!=stat.S_IFREG or not isdir) and (not isdir or size==0),'ZIP_MODE_TYPE')
        if not isdir:need(mode in (0,0o100644,0o100666),'ZIP_DATA_MODE')
        keys=[]
        for i,part in enumerate(parts):
            normal=unicodedata.normalize('NFKC',part).casefold();need(normal not in ('','.','..') and not normal.endswith((' ','.')) and not any(c in '/\\:<>"|?*' or ord(c)<32 for c in normal) and not re.match(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)',normal),'ZIP_NORMALIZED_PATH')
            keys.append(normal);key='/'.join(keys);spelling='/'.join(parts[:i+1]);directory=i<len(parts)-1 or isdir;explicit=i==len(parts)-1
            if key in namespace:
                old=namespace[key];need(old[0]==spelling and old[1] and directory and not(old[2] and explicit),'ZIP_ALIAS_PARENT_COLLISION');namespace[key]=(spelling,directory,old[2] or explicit)
            else:namespace[key]=(spelling,directory,explicit)
        need(size<=MAX_MEMBER and (size<=1024*1024 or size<=max(packed,1)*1000),'ZIP_MEMBER_EXPANSION');declared+=size;need(declared<=MAX_TOTAL,'ZIP_TOTAL_EXPANSION')
        extras(raw[pos+46+nl:pos+46+nl+xl],encoded,name)
        entries.append(dict(name=name,encoded=encoded,version=version,flags=flags,method=method,time=t,date=d,crc=crc,packed=packed,size=size,offset=offset,directory=isdir,mode=format(mode,'o')));pos+=46+nl+xl+cl
    need(pos==end,'ZIP_CENTRAL_FINAL');position=0;blobs={};descriptors=0
    for e in sorted(entries,key=lambda r:r['offset']):
        p=e['offset'];need(p==position and p+30<=cdoffset and raw[p:p+4]==b'PK\x03\x04','ZIP_LOCAL_FRAME');version,flags,method,t,d,crc,packed,size,nl,xl=struct.unpack_from('<5H3I2H',raw,p+4)
        need((version,flags,method,t,d)==tuple(e[n] for n in ('version','flags','method','time','date')) and p+30+nl+xl<=cdoffset and raw[p+30:p+30+nl]==e['encoded'],'ZIP_LOCAL_CENTRAL')
        extras(raw[p+30+nl:p+30+nl+xl],e['encoded'],e['name'])
        if flags&8:need(crc in (0,e['crc']) and packed in (0,e['packed']) and size in (0,e['size']),'ZIP_LOCAL_DESCRIPTOR_PLACEHOLDER')
        else:need((crc,packed,size)==tuple(e[n] for n in ('crc','packed','size')),'ZIP_LOCAL_CRC_SIZE')
        begin=p+30+nl+xl;position=begin+e['packed'];need(position<=cdoffset,'ZIP_DATA_BOUND');packedraw=raw[begin:position]
        if method==8:
            decoder=zlib.decompressobj(-15);body=decoder.decompress(packedraw,e['size']+1);need(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail,'ZIP_BOUNDED_DEFLATE')
        else:body=packedraw
        need(len(body)==e['size'] and zlib.crc32(body)&0xffffffff==e['crc'],'ZIP_CRC_OR_SIZE')
        if flags&8:
            descriptors+=1
            if raw[position:position+4]==b'PK\x07\x08':position+=4
            need(position+12<=cdoffset and struct.unpack_from('<3I',raw,position)==tuple(e[n] for n in ('crc','packed','size')),'ZIP_DESCRIPTOR_FRAME');position+=12
        if not e['directory']:blobs[e['name']]=body
    need(position==cdoffset,'ZIP_LOCAL_FINAL');return blobs,entries,dict(members=len(entries),files=len(blobs),expandedBytes=declared,dataDescriptors=descriptors,rawRecordsPathsAliasesModesBoundsCRC='PASS')
def loads(raw):
    def pairs(rows):
        out={}
        for key,value in rows:need(key not in out,'JSON_DUPLICATE_KEY');out[key]=value
        return out
    return json.loads(raw.decode('utf8-sig'),object_pairs_hook=pairs,parse_constant=lambda _:need(False,'JSON_NONFINITE'))
def main():
    p=argparse.ArgumentParser();p.add_argument('--archive',required=True);p.add_argument('--expected-sha256',required=True);p.add_argument('--expected-bytes',required=True,type=int);p.add_argument('--output',required=True);a=p.parse_args();need(re.fullmatch('[0-9a-f]{64}',a.expected_sha256) and 0<=a.expected_bytes<=MAX_ARCHIVE,'EXTERNAL_PROVIDER_ANCHOR')
    raw=read_stable(a.archive);need(len(raw)==a.expected_bytes and H(raw)==a.expected_sha256,'EXTERNAL_PROVIDER_BYTES_HASH');blobs,entries,audit=inspect(raw);manifest=None
    if 'manifest.json' in blobs:
        manifest=loads(blobs['manifest.json']);need(isinstance(manifest,dict) and isinstance(manifest.get('files'),dict) and set(manifest['files'])==set(blobs)-{'manifest.json'},'DECLARED_MANIFEST_INVENTORY')
        for name,row in manifest['files'].items():need(len(blobs[name])==row['bytes'] and H(blobs[name])==row['sha256'],'DECLARED_MANIFEST_MEMBER_HASH')
    out=pathlib.Path(os.path.abspath(a.output));need(not os.path.lexists(out),'OUTPUT_MUST_BE_NEW')
    for parent in out.parents:
        i=parent.lstat();need(stat.S_ISDIR(i.st_mode) and not getattr(i,'st_file_attributes',0)&1024,'OUTPUT_PARENT')
    out.mkdir();exported={}
    for name in sorted(ALLOW & set(blobs)):
        with (out/name).open('xb') as stream:stream.write(blobs[name])
        need(read_stable(out/name)==blobs[name],'EXPORTED_READBACK');exported[name]=dict(bytes=len(blobs[name]),sha256=H(blobs[name]))
    result=dict(schema=1,status='AUTHENTIC_PROVIDER_BYTES_AND_PUBLIC_RECEIPTS_VERIFIED',providerArchiveBytes=len(raw),providerArchiveSHA256=H(raw),audit=audit,manifestDeclarations='ALL_VERIFIED' if manifest is not None else 'NO_MANIFEST_PRESENT_PROVIDER_DIGEST_BINDS_ALL_MEMBER_BYTES',allMembers={name:dict(bytes=len(body),sha256=H(body)) for name,body in sorted(blobs.items())},exported=exported,nonAllowlistedBodiesExported=False,qualification='Artifact integrity and bounded public receipt export only; not acceptance of receipt claims, original Security custody, native or release admission',acceptanceGranted=False,release='NO_GO')
    (out/'PROVIDER_ARTIFACT_RECEIPT29.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=result['status'],members=len(entries),exported=list(exported),archiveSHA256=H(raw))),flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:print(json.dumps(dict(status='CI_ARTIFACT_INVALID',code=e.args[0] if isinstance(e,ValueError) and len(e.args)==1 and re.fullmatch('[A-Z0-9_]+',str(e.args[0])) else type(e).__name__,acceptanceGranted=False,release='NO_GO')),flush=True);raise SystemExit(1)
