SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Direct current C controls, with one real Windows short-TEMP environment."""
from pathlib import Path
import argparse
import ctypes
import hashlib
import json
import os
import subprocess
import tempfile

root = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
evidence = root.parent/'c29-evidence/governance'
tools = json.loads((root.parent/'c29-evidence/runtime/ACTIVE_TOOLCHAIN29.json').read_bytes())
python = Path(tools['python'])
parser = argparse.ArgumentParser()
parser.add_argument('--expected-head', required=True)
parser.add_argument('--expected-tree', required=True)
args = parser.parse_args()
prior = '2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
prior_tree = '015e185b35be44301e6d9a4be0c28d040150aec8'
changed = ['docs/brain/task-specs/M1X-29/TASK.md', 'scripts/release/full-app-j01/check.py', 'scripts/release/full-app-j01/replay29.test.py']
environment = {key: value for key, value in os.environ.items() if not key.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_')) and key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
environment['PATH'] = tools['prefix']+os.pathsep+str(python.parent)+os.pathsep+environment.get('PATH', '')
def git(*values): return subprocess.check_output(['git', '--no-replace-objects', *values], cwd=root, env=environment).decode().strip()
assert git('rev-parse', 'HEAD') == args.expected_head and git('rev-parse', 'HEAD^{tree}') == args.expected_tree
assert git('rev-parse', 'HEAD^') == prior and git('rev-parse', prior+'^{tree}') == prior_tree
assert not git('status', '--porcelain=v1', '--untracked-files=all')
assert git('diff', '--name-only', '--no-renames', prior, 'HEAD').splitlines() == changed
assert git('diff', '--raw', '--no-abbrev', '--no-renames', prior, 'HEAD', '--', '.', *[':(exclude)'+p for p in changed]) == ''
runner_sha = hashlib.sha256((root/'scripts/release/full-app-j01/replay29.py').read_bytes()).hexdigest()
assert runner_sha == '4365e20765752eb9653d3ef35462cc6b86bc63aca83f9185c394c7a0ac3495f4'
target = evidence/'current-controls-revision3.execution.json'
assert not target.exists()
records = []
def execute(label, executable, script, qualification, env):
    command = [str(executable), '-I', '-B', 'scripts/release/full-app-j01/'+script]
    child = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=240, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    assert len(child.stdout) <= 1024*1024 and len(child.stderr) <= 1024*1024
    witnesses = {}
    for stream, body in [('stdout', child.stdout), ('stderr', child.stderr)]:
        path = evidence/('current-controls-revision3.'+label+'.'+stream+'.log')
        with path.open('xb') as output: output.write(body)
        witnesses[stream] = dict(path=path.name, bytes=len(body), sha256=hashlib.sha256(body).hexdigest())
    rows = [json.loads(row) for row in child.stdout.splitlines()]
    result = rows[-1] if rows else None
    expected = (5, 74) if script == 'replay29.test.py' else (17, 127)
    valid = (child.returncode == 0 and type(result) is dict and result.get('status') == 'PASS' and
        (result.get('positiveControls'), result.get('refusals')) == expected and result.get('acceptanceGranted') is False and result.get('release') == 'NO_GO')
    if script == 'source_consumer29.test.py': valid = valid and result.get('inheritedFunctions') == 218
    records.append(dict(label=label, command=command, sourceContext=dict(head=args.expected_head, tree=args.expected_tree),
        environmentQualification=qualification, exit=child.returncode, result=result, valid=bool(valid), **witnesses))
    print(json.dumps(dict(label=label, exit=child.returncode, valid=bool(valid))), flush=True)
    return bool(valid)
valid = execute('python312-replay29', python, 'replay29.test.py', 'OFFICIAL_AUTHENTICATED_PYTHON31210_NORMAL_TEMP', environment)
valid = execute('python312-source29', python, 'source_consumer29.test.py', 'OFFICIAL_AUTHENTICATED_PYTHON31210_NORMAL_TEMP', environment) and valid
with tempfile.TemporaryDirectory(prefix='campaign29-real-short-temp-', dir=evidence) as directory:
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    get_short = kernel.GetShortPathNameW
    get_short.argtypes = [ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_uint]
    get_short.restype = ctypes.c_uint
    buffer = ctypes.create_unicode_buffer(32768)
    length = get_short(directory, buffer, len(buffer))
    assert 0 < length < len(buffer)
    short = Path(buffer.value)
    assert short != short.resolve() and short.samefile(directory) and short.resolve() == Path(directory).resolve()
    alias_environment = dict(environment, TEMP=str(short), TMP=str(short))
    valid = execute('python312-short-temp-replay29', python, 'replay29.test.py', 'OFFICIAL_AUTHENTICATED_PYTHON31210_REAL_WINDOWS_8DOT3_TEMP_ALIAS', alias_environment) and valid
python39 = Path(subprocess.check_output(['py', '-3.9', '-I', '-B', '-c', 'import sys; print(sys.executable)'], env=environment).decode().strip())
valid = execute('python39-replay29', python39, 'replay29.test.py', 'SYSTEM_PYTHON39_ADDITIONAL_SYNTHETIC_PORTABILITY_ONLY', environment) and valid
valid = execute('python39-source29', python39, 'source_consumer29.test.py', 'SYSTEM_PYTHON39_ADDITIONAL_SYNTHETIC_PORTABILITY_ONLY', environment) and valid
head_after = git('rev-parse', 'HEAD'); tree_after = git('rev-parse', 'HEAD^{tree}')
clean_after = not git('status', '--porcelain=v1', '--untracked-files=all')
valid = valid and clean_after and (head_after, tree_after) == (args.expected_head, args.expected_tree)
record = dict(status='PASS_CURRENT_CONTROLS29' if valid else 'FAILED_CURRENT_CONTROLS29', head=args.expected_head, tree=args.expected_tree,
    headAfter=head_after, treeAfter=tree_after, cleanBefore=True, cleanAfter=clean_after,
    checkerSHA256=hashlib.sha256((root/'scripts/release/full-app-j01/check.py').read_bytes()).hexdigest(),
    replayTestSHA256=hashlib.sha256((root/'scripts/release/full-app-j01/replay29.test.py').read_bytes()).hexdigest(),
    consumerSHA256=hashlib.sha256((root/'scripts/release/full-app-j01/source_consumer29.test.py').read_bytes()).hexdigest(),
    scopeTransition=dict(priorHead=prior, priorTree=prior_tree, changedPaths=changed, unchangedRunnerSHA256=runner_sha, allOtherTrackedModesAndBytesExact=True), commands=records)
with target.open('x') as output: output.write(json.dumps(record, indent=2)+'\n')
print(json.dumps(dict(status=record['status'], commands=len(records))))
raise SystemExit(0 if valid else 1)
