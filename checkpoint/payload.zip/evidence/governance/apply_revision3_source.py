SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Apply the authorized three-path C repair only after root releases B hold."""
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

root = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
evidence = root.parent/'c29-evidence/governance'
prior = '2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
def git(*args): return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root)
assert git('rev-parse', 'HEAD').decode().strip() == prior
assert not git('status', '--porcelain=v1', '--untracked-files=all').strip()
execution = json.loads((evidence/'historical29-local-r2.execution.json').read_bytes())
assert execution['status'] == 'PASS' and execution['exit'] == 0 and execution['headAfter'] == prior and execution['cleanAfter'] is True
test = root/'scripts/release/full-app-j01/replay29.test.py'
before = git('show', prior+':scripts/release/full-app-j01/replay29.test.py')
assert test.read_bytes() == before
old = b"prefix=Path(directory)/'prefix'"
assert before.count(old) == 1
test.write_bytes(before.replace(old, b"prefix=Path(directory).resolve()/'prefix'"))
checker = root/'scripts/release/full-app-j01/check.py'
raw = checker.read_bytes()
match = re.search(rb'(?m)^RELEASE29_PREVIOUS_GOVERNANCE = (.*)$', raw)
assert match
values = ast.literal_eval(match.group(1).decode())
addition = json.loads((evidence/'EXACT_PRIOR_REVISION2_GOVERNANCE29.json').read_bytes())
assert set(addition) == {prior} and prior not in values
values.update(addition)
raw = raw[:match.start(1)] + repr(values).encode() + raw[match.end(1):]
checker.write_bytes(raw)
task = root/'docs/brain/task-specs/M1X-29/TASK.md'
body = task.read_bytes()
anchor = b'Source29 history permits the immutable plan, substantive source, exactly one\n'
assert body.count(anchor) == 1
paragraph = b'''At source 2f42fa45, hosted Windows new replay controls returned
R29_REPLAY_CONTROL_FAILED; this required failure remains red. The authentic
hosted original24-28 replay passed separately at that exact source. A separate
real Windows 8.3 temporary-path assay of unchanged source 2f42fa45 reproduced
R29_NPM_METADATA_PATH in the synthetic metadata fixture; canonicalizing only
that fixture prefix produced its unchanged five-positive/74-refusal controls.
The next source revision changes that one fixture line, explicit source pins
and this task record only. Its runner, original guards, reader implementations,
application and workflow remain identical to 2f42fa45. App and authentic
historical execution records retain their exact earlier source provenance;
current controls and the full current checker execute separately at the new
source. The complete exact 2f42fa45 parent/tree and five changed-path witnesses
are pinned alongside the earlier a6f7e681 witnesses, without historical skips.
\n'''
task.write_bytes(body.replace(anchor, paragraph+anchor))
subprocess.run([str(root.parent/'c29-evidence/runtime/fresh-python31210-19e45f0d6f/runtime/python.exe'), '-I', '-B', str(evidence/'finalize29_pins.py')], check=True)
changed = git('diff', '--name-only', '--no-renames').decode().splitlines()
assert changed == ['docs/brain/task-specs/M1X-29/TASK.md', 'scripts/release/full-app-j01/check.py', 'scripts/release/full-app-j01/replay29.test.py']
assert test.read_bytes() == before.replace(old, b"prefix=Path(directory).resolve()/'prefix'")
assert not git('diff', '--raw', '--no-renames', prior, '--', '.', *[':(exclude)'+path for path in changed]).strip()
print(json.dumps(dict(status='C_THREE_PATH_REPAIR_APPLIED_BEFORE_FREEZE', changedPaths=changed,
    checkerSHA256=hashlib.sha256(checker.read_bytes()).hexdigest(), replayTestSHA256=hashlib.sha256(test.read_bytes()).hexdigest()), sort_keys=True))
