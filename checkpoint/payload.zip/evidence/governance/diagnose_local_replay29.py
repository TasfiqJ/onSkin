SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""External-only bounded diagnostics of the retained Release24 clone; not fresh replay proof."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

source = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
root = Path(r'<LOCAL_HOME>/AppData/Local/Temp/release29-historical-bs0lv_9v/release24')
evidence = source.parent/'c29-evidence/governance'
python = source.parent/'c29-evidence/runtime/fresh-python31210-19e45f0d6f/runtime/python.exe'
node = source.parent/'c29-evidence/runtime/fresh-node-npm29-521be43fa8/pinned'
environment = {k: v for k, v in os.environ.items() if not k.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_')) and
    k.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
environment['PATH'] = str(node)+os.pathsep+str(python.parent)+os.pathsep+environment.get('PATH', '')
environment.update(GIT_TERMINAL_PROMPT='0', npm_config_userconfig=os.devnull)
expected = {'head': 'd0ccef65bcbe0c90483e6c0f691ed95f92228c6c',
    'tree': '22f91455d651a81296ab8724f9db7cfead65af08',
    'check.py': '855977dc4fc5ecc57f13b810cac6c63654b72b04bf867412d8c4510efe221145',
    'source_consumer24.test.py': '715920a4dff3757adef2916015a244babef9babf92fea5725b1d2e96abf1c7d1'}
def git(*args): return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root, env=environment).decode().strip()
assert git('rev-parse', 'HEAD') == expected['head'] and git('rev-parse', 'HEAD^{tree}') == expected['tree']
for name in ('check.py', 'source_consumer24.test.py'):
    assert hashlib.sha256((root/'scripts/release/full-app-j01'/name).read_bytes()).hexdigest() == expected[name]
def diagnostic(label, command):
    start = time.monotonic()
    try:
        child = subprocess.run(command, cwd=root, env=environment, capture_output=True, timeout=900)
        out, err = child.stdout, child.stderr
        assert len(out) <= 8*1024*1024 and len(err) <= 1024*1024
        rows = []
        for line in out.splitlines():
            try: value = json.loads(line)
            except (ValueError, UnicodeDecodeError): continue
            if type(value) is dict: rows.append(value)
        final = rows[-1] if rows else {}
        result = {'label': label, 'exit': child.returncode, 'elapsedSeconds': round(time.monotonic()-start, 3),
            'stdoutBytes': len(out), 'stderrBytes': len(err), 'stdoutSHA256': hashlib.sha256(out).hexdigest(),
            'stderrSHA256': hashlib.sha256(err).hexdigest(), 'jsonRows': len(rows)}
        for key in ('status', 'valid', 'passed', 'positiveControls', 'refusals', 'inheritedFunctions', 'release', 'acceptanceGranted', 'check'):
            value = final.get(key)
            if type(value) in (bool, int) or type(value) is str and re.fullmatch(r'[A-Z0-9_ /;-]{1,160}', value):
                result[key] = value
        for key in ('error', 'code'):
            value = final.get(key)
            if type(value) is str:
                prefix = value.split(':', 1)[0].split('|', 1)[0]
                if re.fullmatch(r'[A-Z0-9_]{1,80}', prefix): result['staticCode'] = prefix
        exceptions = re.findall(rb'(?m)^([A-Za-z_][A-Za-z0-9_]*(?:Error|Exception)):', err)
        if exceptions: result['exceptionType'] = exceptions[-1].decode('ascii')
    except subprocess.TimeoutExpired:
        result = {'label': label, 'exit': None, 'timeout': True, 'elapsedSeconds': round(time.monotonic()-start, 3)}
    result.update(qualification='RETAINED_INSTALLED_RELEASE24_EXTERNAL_DIAGNOSTIC_NOT_FRESH_REPLAY_PROOF',
        originalScriptsUnmodified=True, rawOutputsOrPathsPublished=False, acceptanceGranted=False)
    (evidence/('diagnostic-'+label+'.json')).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, sort_keys=True), flush=True)
    return result

identity = "import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
tasks = [
    ('release24-toolchain', [str(python), '-I', '-B', '-c', identity]),
    ('release24-postinstall', [str(node/'node.exe'), 'scripts/postinstall.mjs', '--check']),
    ('release24-consumer', [str(python), '-I', '-B', 'scripts/release/full-app-j01/source_consumer24.test.py']),
    ('release24-checker', [str(python), '-I', '-B', 'scripts/release/full-app-j01/check.py'])]
# Tool inventory is serialized first; the remaining source/test reads are independent.
records = [diagnostic(*tasks[0])]
with ThreadPoolExecutor(max_workers=3) as executor:
    records += list(executor.map(lambda task: diagnostic(*task), tasks[1:]))
summary = dict(status='DIAGNOSTICS_COMPLETED', expectedSource=expected, records=records,
    cleanAfter=not git('status', '--porcelain=v1', '--untracked-files=all'),
    qualification='REUSED_RELEASE24_DIAGNOSTICS_NOT_SUCCESSFUL_FRESH_REPLAY', acceptanceGranted=False, release='NO_GO')
(evidence/'LOCAL_REPLAY29_FAILURE_DIAGNOSIS.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({'status': summary['status'], 'cleanAfter': summary['cleanAfter']}, sort_keys=True))
