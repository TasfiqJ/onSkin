SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Before-freeze only: bind the reviewed current29 source hashes, then seal appendix."""
from pathlib import Path
import ast
import hashlib
import re
import subprocess
import json

root = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
area = root/'scripts/release/full-app-j01'
path = area/'check.py'
raw = path.read_bytes()
base = subprocess.check_output(['git', 'show', 'bace116586d58ed955f0a024ca96ae9f4ad9286d:scripts/release/full-app-j01/check.py'], cwd=root)
terminal = b"if __name__ == '__main__':\n    sys.exit(main())\n"
assert raw.startswith(base[:-len(terminal)]) and raw.endswith(terminal)
def sha(data): return hashlib.sha256(data).hexdigest()
def set_value(name, value):
    global raw
    raw, count = re.subn(rb'(?m)^'+name.encode()+rb' = .*$', lambda _: (name+' = '+repr(value)).encode(), raw)
    assert count == 1, name

pins = {}
for name, rel in [('RELEASE29_CONSUMER_SHA256', 'scripts/release/full-app-j01/source_consumer29.test.py'),
    ('RELEASE29_WORKFLOW_SHA256', '.github/workflows/security-candidate22.yml'),
    ('RELEASE29_REPLAY_SHA256', 'scripts/release/full-app-j01/replay29.py'),
    ('RELEASE29_REPLAY_TEST_SHA256', 'scripts/release/full-app-j01/replay29.test.py')]:
    pins[name] = sha((root/rel).read_bytes());set_value(name, pins[name])
readers = {}
canonical_node = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'ast29_identity')
namespace = {'ast': ast, 'json': json, 'sha': sha}
exec(compile(ast.Module(body=[canonical_node], type_ignores=[]), '<new29-AST-identity>', 'exec'), namespace)
for release in (27, 28):
    rel = 'scripts/release/full-app-j01/replay'+str(release)+'.py'
    target = next(n for n in ast.parse((root/rel).read_bytes()).body if isinstance(n, ast.FunctionDef) and n.name == 'bytes'+str(release))
    readers[rel] = namespace['ast29_identity'](target)
set_value('RELEASE29_READER_AST_SHA256', readers)
tools = {'scripts/release/full-app-j01/'+name: sha((area/name).read_bytes()) for name in ('readerTrace29.py', 'readerIntegrity29.test.py')}
set_value('RELEASE29_READER_TOOLS_SHA256', tools)
set_value('RELEASE29_APPENDIX_SHA256', '0'*64)
appendix = raw[len(base)-len(terminal):-len(terminal)]
set_value('RELEASE29_APPENDIX_SHA256', sha(appendix))
path.write_bytes(raw)
print(json.dumps({'status': 'SOURCE29_PINS_BOUND_BEFORE_FREEZE', 'pins': pins,
    'readerASTs': readers, 'readerTools': tools, 'appendixSHA256': sha(appendix), 'checkerSHA256': sha(raw)}, sort_keys=True))
