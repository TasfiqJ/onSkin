SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Bounded formal CLI execution; no runner/checker or guard replacement."""
from pathlib import Path
import datetime
import argparse
import re
import hashlib
import json
import os
import subprocess
import time

root = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
evidence = root.parent/'c29-evidence/governance'
python = root.parent/'c29-evidence/runtime/fresh-python31210-19e45f0d6f/runtime/python.exe'
node = root.parent/'c29-evidence/runtime/fresh-node-npm29-521be43fa8/pinned'
parser=argparse.ArgumentParser()
parser.add_argument('--expected-head',required=True)
parser.add_argument('--expected-tree',required=True)
parser.add_argument('--label',required=True)
args=parser.parse_args()
assert re.fullmatch('[0-9a-f]{40}',args.expected_head) and re.fullmatch('[0-9a-f]{40}',args.expected_tree) and re.fullmatch('[a-z0-9-]{1,24}',args.label)
stem='historical29-'+args.label
receipt=evidence/(stem+'-receipt.json')
head=args.expected_head;tree=args.expected_tree
assert not receipt.exists()
def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root).decode().strip()
assert git('rev-parse', 'HEAD') == head and git('rev-parse', 'HEAD^{tree}') == tree
assert not git('status', '--porcelain=v1', '--untracked-files=all')
environment = dict(os.environ)
environment['PATH'] = str(node)+os.pathsep+str(python.parent)+os.pathsep+environment['PATH']
command = [str(python), '-I', '-B', 'scripts/release/full-app-j01/replay29.py', '--receipt', str(receipt)]
started = time.monotonic()
stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
stdout = evidence/(stem+'.stdout.log')
stderr = evidence/(stem+'.stderr.log')
record = dict(status='RUNNING', startedUTC=stamp, head=head, tree=tree, command=command,
    checkerSHA256=hashlib.sha256((root/'scripts/release/full-app-j01/check.py').read_bytes()).hexdigest(),
    runnerSHA256=hashlib.sha256((root/'scripts/release/full-app-j01/replay29.py').read_bytes()).hexdigest(),
    timeoutSeconds=7200, stdoutLimit=8*1024*1024, stderrLimit=1024*1024,
    acceptanceGranted=False, release='NO_GO')
progress = evidence/(stem+'.inprogress.json')
progress.write_text(json.dumps(record, indent=2)+'\n')
reason = None
with stdout.open('xb') as output, stderr.open('xb') as errors:
    process = subprocess.Popen(command, cwd=root, env=environment, stdout=output, stderr=errors,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    while process.poll() is None:
        elapsed = time.monotonic()-started
        if elapsed > 7200 or stdout.stat().st_size > 8*1024*1024 or stderr.stat().st_size > 1024*1024:
            reason = 'OUTER_TIMEOUT' if elapsed > 7200 else 'OUTER_OUTPUT_BOUND'
            # The PID is still the live Popen child handle, never an enumerated
            # unrelated process. Terminate its own descendants only.
            subprocess.run(['taskkill.exe', '/PID', str(process.pid), '/T', '/F'], capture_output=True, timeout=30)
            process.wait(timeout=30)
            break
        time.sleep(0.5)
record.update(status='PASS' if process.returncode == 0 else 'FAILED', exit=process.returncode,
    elapsedSeconds=round(time.monotonic()-started, 3), finishedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    outerRefusal=reason, headAfter=git('rev-parse', 'HEAD'), treeAfter=git('rev-parse', 'HEAD^{tree}'),
    cleanAfter=not git('status', '--porcelain=v1', '--untracked-files=all'))
record['logs'] = {name: dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    for name, path in [('stdout', stdout), ('stderr', stderr)]}
if receipt.exists():
    raw = receipt.read_bytes()
    record['receipt'] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    value = json.loads(raw)
    record['historicalRecords'] = [{key: row[key] for key in ('release', 'head', 'tree', 'consumerResult', 'sourceResult', 'installation')}
        for row in value['records']]
assert record['headAfter'] == head and record['treeAfter'] == tree and record['cleanAfter']
target = evidence/(stem+'.execution.json')
target.write_text(json.dumps(record, indent=2)+'\n')
progress.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, sort_keys=True))
raise SystemExit(process.returncode if process.returncode is not None else 1)
