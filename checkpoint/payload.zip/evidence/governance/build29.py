SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess

ROOT = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
AREA = ROOT/'scripts/release/full-app-j01'
BASE = 'bace116586d58ed955f0a024ca96ae9f4ad9286d'
TERMINAL = b"if __name__ == '__main__':\n    sys.exit(main())\n"

def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)

def old(path):
    return git('show', BASE+':'+path)

def renamed(text):
    return re.sub(r'(?<=[A-Za-z_])28(?=\b|_)', '29', text)

def constant(text, name, value):
    text, count = re.subn(r'(?m)^'+name+r' = .*$', lambda _: name+' = '+repr(value), text)
    assert count == 1, name
    return text

def function(text, name, replacement):
    lines = text.splitlines(keepends=True)
    nodes = [n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name]
    assert len(nodes) == 1, name
    node = nodes[0]
    return ''.join(lines[:node.lineno-1])+replacement.rstrip()+'\n'+''.join(lines[node.end_lineno:])

base_checker = old('scripts/release/full-app-j01/check.py')
base_replay = old('scripts/release/full-app-j01/replay28.py').decode()
runner = renamed(base_replay)
pin_value = next(n.value for n in ast.parse(base_replay).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PINNED28' for t in n.targets))
pins = tuple(ast.literal_eval(ast.Dict(keys=[ast.Constant(k.arg) for k in n.keywords], values=[k.value for k in n.keywords]))
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'dict' and not n.args else ast.literal_eval(n)
    for n in pin_value.elts)
pins += ({'release': 28, 'head': BASE, 'tree': '6951590547b79a869464df987d16da6552907846',
    'branch': 'stage/m1-destructive-commit-core05-28',
    'checkerSHA256': hashlib.sha256(base_checker).hexdigest(),
    'checkerBlob': git('rev-parse', BASE+':scripts/release/full-app-j01/check.py').decode().strip(),
    'consumerSHA256': hashlib.sha256(old('scripts/release/full-app-j01/source_consumer28.test.py')).hexdigest(),
    'consumerBlob': git('rev-parse', BASE+':scripts/release/full-app-j01/source_consumer28.test.py').decode().strip(),
    'positiveControls': 29, 'refusals': 216,
    'qualification': 'SYNTHETIC_GIT_AND_SCHEMA_CONTROLS_NOT_INDEPENDENT_FULL_CHECKOUT_OR_APP_PRIVACY_PROOF'},)
runner = function(runner, 'receipt29_guard', ast.get_source_segment(runner, next(n for n in ast.parse(runner).body if isinstance(n, ast.FunctionDef) and n.name == 'receipt29_guard')).replace('len(records)==4', 'len(records)==5'))
pin_node = next(n for n in ast.parse(runner).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PINNED29' for t in n.targets))
lines = runner.splitlines(keepends=True)
runner = ''.join(lines[:pin_node.lineno-1])+'PINNED29 = '+repr(pins)+'\n'+''.join(lines[pin_node.end_lineno:])
# The new runner uses the same reviewed current byte-stability implementation.
current_reader = (AREA/'replay28.py').read_text()
current_node = next(n for n in ast.parse(current_reader).body if isinstance(n, ast.FunctionDef) and n.name == 'bytes28')
runner = function(runner, 'bytes29', renamed(ast.get_source_segment(current_reader, current_node)))
(AREA/'replay29.py').write_bytes(runner.encode())

start = base_checker.index(b'\n\ndef snapshot28')
extension = renamed(base_checker[start:-len(TERMINAL)].decode())
plan_path = 'docs/brain/task-specs/M1X-29/SCOPE_PLAN.md'
plan = (ROOT/plan_path).read_bytes()
grant = json.loads(re.findall(rb'```json\n(.*?)\n```', plan, re.S)[0])
existing = {p for p in grant if subprocess.run(['git', 'cat-file', '-e', BASE+':'+p], cwd=ROOT, capture_output=True).returncode == 0}
new = set(grant)-existing
values = {
    'RELEASE29_BASE': BASE,
    'RELEASE29_TREE': '6951590547b79a869464df987d16da6552907846',
    'RELEASE29_AUTHORITY': 'BRAIN-M1X-WINDOWS-READER-INTEGRITY29-CANDIDATE-01',
    'RELEASE29_INPUT': '7a94feecb69b09d46acb6465972f1c7b809fbfa9e657aa50c1f7bc4523643579',
    'RELEASE29_PLAN': plan_path,
    'RELEASE29_PLAN_COMMIT': '9b395cbee7594f7dc03934aed4e08c4e3ea43c23',
    'RELEASE29_PLAN_SHA256': hashlib.sha256(plan).hexdigest(),
    'RELEASE29_APPENDIX_SHA256': '0'*64,
    'RELEASE29_CANDIDATE': 'docs/brain/contracts/M1X-29/source29.v1.json',
    'RELEASE29_CHECKPOINT': 'docs/brain/checkpoints/M1-02/WINDOWS-READER-INTEGRITY-29/',
    'RELEASE29_EXISTING_APP': set(), 'RELEASE29_NEW_APP': set(),
    'RELEASE29_OTHER_EXISTING': existing, 'RELEASE29_OTHER_NEW': new,
    'RELEASE29_PREVIOUS_GOVERNANCE': {},
}
for name, value in values.items(): extension = constant(extension, name, value)
extension = extension.replace('len(raw) == 11493', 'len(raw) == '+str(len(plan)))
extension = extension.replace('len(RELEASE29_EXISTING_APP) == 4 and len(RELEASE29_NEW_APP) == 4',
    'not RELEASE29_EXISTING_APP and not RELEASE29_NEW_APP and len(expected) == 20')
extension = extension.replace("'stage/m1-first-value-safety-ci27'", "'stage/m1-destructive-commit-core05-28'")
extension = extension.replace("'stage/m1-destructive-commit-core05-29'", "'stage/m1-windows-reader-integrity29'")
extension = extension.replace("pr['head'].get('ref') == 'stage/m1-destructive-commit-core05-28'",
    "pr['head'].get('ref') == 'stage/m1-windows-reader-integrity29'")
extension = extension.replace("'IMMUTABLE_PR31_DEFINITIONS;AUTHENTIC_HISTORICAL_REPLAY_REQUIRED'", "'IMMUTABLE_PR31_AND_PR32_DEFINITIONS;AUTHENTIC_HISTORICAL_REPLAY_REQUIRED'")
extension = extension.replace('inherited_release27=', 'inherited_release28=')
# New current public reader: two bounded complete observations on one descriptor.
regular = '''def regular29(path, limit=128*1024*1024):
    """Observed bounded source stability; not universal adversarial TOCTOU safety."""
    require(isinstance(path, Path) and path.is_absolute() and type(limit) is int and
        0 <= limit <= 128*1024*1024, 'R29_PUBLIC_BOUND')
    try:
        parents = {}
        for parent in path.parents:
            info = parent.lstat()
            require(stat.S_ISDIR(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 1024,
                'R29_PUBLIC_PATH')
            parents[parent] = (info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None))
        before = path.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and
            not before.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX) and
            not getattr(before, 'st_file_attributes', 0) & 1024 and 0 <= before.st_size <= limit,
            'R29_PUBLIC_FILE')
        descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
        try:
            opened = os.fstat(descriptor)
            require(compatible29_metadata(path, before, opened), 'R29_PUBLIC_CHANGED')
            blocks = []; total = 0
            while True:
                block = os.read(descriptor, min(1024*1024, before.st_size-total+1))
                if not block: break
                total += len(block)
                require(total <= before.st_size, 'R29_PUBLIC_CHANGED')
                blocks.append(block)
            finished = os.fstat(descriptor); after = path.lstat()
            require(total == before.st_size and snapshot29(opened) == snapshot29(finished) and
                snapshot29(before) == snapshot29(after) and compatible29_metadata(path, after, finished),
                'R29_PUBLIC_CHANGED')
            body = b''.join(blocks)
            require(os.lseek(descriptor, 0, os.SEEK_SET) == 0, 'R29_PUBLIC_CHANGED')
            total = 0
            while True:
                block = os.read(descriptor, min(1024*1024, before.st_size-total+1))
                if not block: break
                require(total+len(block) <= before.st_size and body[total:total+len(block)] == block,
                    'R29_PUBLIC_CHANGED')
                total += len(block)
            finished = os.fstat(descriptor); after = path.lstat()
            require(total == before.st_size and snapshot29(opened) == snapshot29(finished) and
                snapshot29(before) == snapshot29(after) and compatible29_metadata(path, after, finished),
                'R29_PUBLIC_CHANGED')
        finally: os.close(descriptor)
        for parent, expected in parents.items():
            info = parent.lstat()
            require((info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None)) == expected and
                not getattr(info, 'st_file_attributes', 0) & 1024, 'R29_PUBLIC_PATH')
        return body
    except OSError:
        raise ValueError('R29_PUBLIC_READ_INCOMPLETE') from None
'''
extension = function(extension, 'regular29', regular)
working = '''def working29_guard(index, permitted=()):
    """Two-pass raw reconciliation with the original shared-parent snapshot model."""
    permitted = set(permitted); directories = set(ROOT.parents) | {ROOT}
    for path in index:
        parent = (ROOT/path).parent
        while parent not in directories:
            directories.add(parent); parent = parent.parent
    parents = {}
    for parent in directories:
        info = parent.lstat()
        require(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
            not getattr(info, 'st_file_attributes', 0) & 1024, 'R29_WORKING_PATH')
        parents[parent] = (info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None))
    for path, (mode, oid) in index.items():
        target = ROOT/path; before = target.lstat()
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and not stat.S_ISLNK(before.st_mode) and
            not before.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX) and
            not getattr(before, 'st_file_attributes', 0) & 1024 and 0 <= before.st_size <= 128*1024*1024,
            'R29_WORKING_REGULAR')
        descriptor = os.open(target, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
        try:
            opened = os.fstat(descriptor)
            require(compatible29_metadata(target, before, opened), 'R29_WORKING_CHANGED')
            digest = hashlib.sha1(('blob '+str(before.st_size)+'\\0').encode()); blocks = []; total = 0
            while True:
                block = os.read(descriptor, min(1024*1024, before.st_size-total+1))
                if not block: break
                total += len(block)
                require(total <= before.st_size, 'R29_WORKING_CHANGED')
                digest.update(block); blocks.append(block)
            finished = os.fstat(descriptor); after = target.lstat()
            require(total == before.st_size and snapshot29(opened) == snapshot29(finished) and
                snapshot29(before) == snapshot29(after) and compatible29_metadata(target, after, finished),
                'R29_WORKING_CHANGED')
            body = b''.join(blocks); del blocks
            require(os.lseek(descriptor, 0, os.SEEK_SET) == 0, 'R29_WORKING_CHANGED')
            total = 0
            while True:
                block = os.read(descriptor, min(1024*1024, before.st_size-total+1))
                if not block: break
                require(total+len(block) <= before.st_size and block == body[total:total+len(block)], 'R29_WORKING_CHANGED')
                total += len(block)
            finished = os.fstat(descriptor); after = target.lstat()
            require(total == before.st_size and snapshot29(opened) == snapshot29(finished) and
                snapshot29(before) == snapshot29(after) and compatible29_metadata(target, after, finished),
                'R29_WORKING_CHANGED')
        finally: os.close(descriptor)
        require(digest.hexdigest() == oid or path in permitted, 'R29_WORKING_BLOB')
        if os.name != 'nt':
            require(bool(target.lstat().st_mode & 0o111) == (mode == '100755'), 'R29_WORKING_MODE')
    for parent, expected in parents.items():
        info = parent.lstat()
        require((info.st_dev, info.st_ino, info.st_mode, getattr(info, 'st_reparse_tag', None)) == expected and
            not getattr(info, 'st_file_attributes', 0) & 1024, 'R29_WORKING_PATH')
    return len(index)
'''
extension = function(extension, 'working29_guard', working)
reader_guard = '''def ast29_identity(node):
    """Stable semantic AST digest across hosts with optional empty type_params."""
    def canonical(value):
        if isinstance(value, ast.AST):
            return [type(value).__name__, [[name, canonical(getattr(value, name))] for name in value._fields
                if not (name == 'type_params' and getattr(value, name) == [])]]
        if isinstance(value, list): return [canonical(item) for item in value]
        if isinstance(value, bytes): return ['bytes', value.hex()]
        return value
    return sha(json.dumps(canonical(node), separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode())


def reader29_guard(path, raw):
    """Only the two named reader implementations may differ from exact PR32."""
    names = {'scripts/release/full-app-j01/replay27.py': 'bytes27',
        'scripts/release/full-app-j01/replay28.py': 'bytes28'}
    require(path in names and type(raw) is bytes, 'R29_READER_SCOPE')
    before = git23('show', RELEASE29_BASE+':'+path)
    old_tree = ast.parse(before); new_tree = ast.parse(raw)
    require(len(old_tree.body) == len(new_tree.body), 'R29_READER_SCOPE')
    matched = []
    for left, right in zip(old_tree.body, new_tree.body):
        if isinstance(left, ast.FunctionDef) and left.name == names[path]:
            require(isinstance(right, ast.FunctionDef) and right.name == left.name and
                ast.dump(left.args, include_attributes=False) == ast.dump(right.args, include_attributes=False) and
                left.decorator_list == right.decorator_list == [], 'R29_READER_SCOPE')
            require(ast29_identity(right) == RELEASE29_READER_AST_SHA256[path],
                'R29_READER_IMPLEMENTATION')
            matched.append((left, right))
        else:
            require(ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False),
                'R29_READER_INHERITED_AST')
    require(len(matched) == 1, 'R29_READER_SCOPE')
    left, right = matched[0]
    old_lines = before.splitlines(keepends=True); new_lines = raw.splitlines(keepends=True)
    require(b''.join(old_lines[:left.lineno-1]+old_lines[left.end_lineno:]) ==
        b''.join(new_lines[:right.lineno-1]+new_lines[right.end_lineno:]), 'R29_READER_INHERITED_BYTES')
    return names[path]
'''
extension = extension.replace('\ndef validate29_diff(', '\n'+reader_guard+'\n\ndef validate29_diff(')
extension = extension.replace("'working29_guard', 'source29_guard', 'validate29'}", "'working29_guard', 'source29_guard', 'validate29', 'ast29_identity', 'reader29_guard'}")
extension = extension.replace("'RELEASE29_REPLAY_TEST_SHA256')", "'RELEASE29_REPLAY_TEST_SHA256', 'RELEASE29_READER_AST_SHA256', 'RELEASE29_READER_TOOLS_SHA256')")
extension = extension.replace("            if path in pins: require(sha(data) == pins[path], 'R29_SOURCE_TOOL_IDENTITY')", "            if path in pins: require(sha(data) == pins[path], 'R29_SOURCE_TOOL_IDENTITY')\n            if path in RELEASE29_READER_AST_SHA256: reader29_guard(path, data)\n            if path in RELEASE29_READER_TOOLS_SHA256:\n                require(sha(data) == RELEASE29_READER_TOOLS_SHA256[path], 'R29_SOURCE_TOOL_IDENTITY')")
extension = extension.replace("    # Empty all external Git conversion commands before status/diff can read a", "    for path in RELEASE29_READER_AST_SHA256:\n        reader29_guard(path, regular29(ROOT/path))\n    for path, expected in RELEASE29_READER_TOOLS_SHA256.items():\n        require(sha(regular29(ROOT/path)) == expected, 'R29_SOURCE_TOOL_IDENTITY')\n    # Empty all external Git conversion commands before status/diff can read a")
extension = extension.replace("        known = {'R23_PUBLIC_BOUND'", "        known = {'R29_PUBLIC_BOUND', 'R29_PUBLIC_PATH', 'R29_PUBLIC_FILE', 'R29_PUBLIC_CHANGED', 'R29_PUBLIC_READ_INCOMPLETE', 'R29_READER_SCOPE', 'R29_READER_IMPLEMENTATION', 'R29_READER_INHERITED_AST', 'R29_READER_INHERITED_BYTES', 'R23_PUBLIC_BOUND'")
extension = extension.replace("RELEASE29_REPLAY_TEST_SHA256 =", "RELEASE29_READER_AST_SHA256 = {}\nRELEASE29_READER_TOOLS_SHA256 = {}\nRELEASE29_REPLAY_TEST_SHA256 =")
(AREA/'check.py').write_bytes(base_checker[:-len(TERMINAL)]+extension.encode()+TERMINAL)
contract = dict(schema=1, authority=values['RELEASE29_AUTHORITY'], status='SUBMITTED_REVIEW_REQUIRED', base=BASE,
    tree=values['RELEASE29_TREE'], scopeCommit=values['RELEASE29_PLAN_COMMIT'], scopePlanSHA256=values['RELEASE29_PLAN_SHA256'],
    inputManifestSHA256=values['RELEASE29_INPUT'], acceptanceGranted=False,
    admissions=dict(G97=False, DB=False, M103=False, M2=False, J01=False, PUBLIC=False), pr=33)
p = ROOT/values['RELEASE29_CANDIDATE']; p.parent.mkdir(parents=True, exist_ok=True)
p.write_bytes((json.dumps(contract, indent=2)+'\n').encode())
print(json.dumps({'generated': ['check.py', 'replay29.py', str(p.relative_to(ROOT))], 'inheritedFunctions': 218,
    'grant': len(grant), 'existing': len(existing), 'new': len(new)}))
