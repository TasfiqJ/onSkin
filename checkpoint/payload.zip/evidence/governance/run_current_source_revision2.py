SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Run one explicit full current main after the local historical replay finishes."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path(r'<LOCAL_HOME>/Documents/ChatGPT/MasterV2Code/c29-src')
evidence = root.parent/'c29-evidence/governance'
python = root.parent/'c29-evidence/runtime/fresh-python31210-19e45f0d6f/runtime/python.exe'
prefix = root.parent/'c29-evidence/runtime/fresh-node-npm29-521be43fa8/pinned'
head = '2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
tree = '015e185b35be44301e6d9a4be0c28d040150aec8'
environment = {key: value for key, value in os.environ.items() if not key.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_')) and
    key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
environment['PATH'] = str(prefix)+os.pathsep+str(python.parent)+os.pathsep+environment.get('PATH', '')
def git(*args): return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root, env=environment).decode().strip()
assert git('rev-parse', 'HEAD') == head and git('rev-parse', 'HEAD^{tree}') == tree
assert not git('status', '--porcelain=v1', '--untracked-files=all')
historical = json.loads((evidence/'historical29-local-r2.execution.json').read_bytes())
assert historical['status'] == 'PASS' and historical['exit'] == 0 and historical['headAfter'] == head and historical['treeAfter'] == tree
assert historical['cleanAfter'] is True
target = evidence/'current-source-revision2.execution.json'
assert not target.exists()
stdout = evidence/'current-source-revision2.stdout.log'; stderr = evidence/'current-source-revision2.stderr.log'
command = [str(python), '-I', '-B', 'scripts/release/full-app-j01/check.py']
checker = root/'scripts/release/full-app-j01/check.py'
checksum = hashlib.sha256(checker.read_bytes()).hexdigest()
started = time.monotonic()
with stdout.open('xb') as output, stderr.open('xb') as errors:
    child = subprocess.Popen(command, cwd=root, env=environment, stdout=output, stderr=errors,
        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    while child.poll() is None:
        if time.monotonic()-started > 1200 or stdout.stat().st_size > 1024*1024 or stderr.stat().st_size > 1024*1024:
            subprocess.run(['taskkill.exe', '/PID', str(child.pid), '/T', '/F'], capture_output=True, timeout=30)
            child.wait(timeout=30)
            break
        time.sleep(0.5)
out = stdout.read_bytes(); err = stderr.read_bytes()
try: result = json.loads(out)
except (ValueError, UnicodeDecodeError): result = None
after_head = git('rev-parse', 'HEAD'); after_tree = git('rev-parse', 'HEAD^{tree}')
clean_after = not git('status', '--porcelain=v1', '--untracked-files=all')
valid = (child.returncode == 0 and type(result) is dict and result.get('valid') is True and result.get('release') == 'NO_GO' and
    result.get('source_acceptance') == 'SUBMITTED_REVIEW_REQUIRED' and result.get('current_source_governance') == 'RELEASE29_FINITE_SCOPE_ONLY' and
    result.get('acceptanceGranted') is False and type(result.get('admissions')) is dict and
    set(result['admissions']) == {'G97', 'DB', 'M103', 'M2', 'J01', 'PUBLIC'} and all(value is False for value in result['admissions'].values()))
valid = valid and (after_head, after_tree) == (head, tree) and clean_after and hashlib.sha256(checker.read_bytes()).hexdigest() == checksum
proof = result.get('source29') if type(result) is dict else None
count = len([name for name in git('ls-tree', '-r', '--name-only', '-z', 'HEAD').split('\0') if name])
delta = len([name for name in git('diff', '--name-only', '--no-renames', '-z', 'bace116586d58ed955f0a024ca96ae9f4ad9286d', 'HEAD').split('\0') if name])
valid = (valid and type(proof) is dict and proof.get('endpoint') == proof.get('checkoutHead') == head and
    proof.get('tree') == proof.get('checkoutTree') == tree and proof.get('phase') == 'SOURCE' and
    proof.get('workingQualification') == 'FINITE_PENDING_ALLOWED' and proof.get('ciEventCommit') is None and
    proof.get('metadataFiles') == proof.get('trackedWorkingBlobsHashedLocally') == count and
    proof.get('currentChangedPaths') == proof.get('stagedChangedPaths') == delta)
record = dict(status='PASS_CURRENT_MAIN29' if valid else 'FAILED_CURRENT_MAIN29', head=head, tree=tree,
    headAfter=after_head, treeAfter=after_tree, cleanBefore=True, cleanAfter=clean_after,
    checkerSHA256=checksum, command=command, exit=child.returncode, elapsedSeconds=round(time.monotonic()-started, 3),
    stdout=dict(path=stdout.name, bytes=len(out), sha256=hashlib.sha256(out).hexdigest()),
    stderr=dict(path=stderr.name, bytes=len(err), sha256=hashlib.sha256(err).hexdigest()), result=result)
target.write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, sort_keys=True))
raise SystemExit(0 if valid else 1)
