"""Bounded explicit local named-pipe readiness only; no remote/production use."""
import datetime,hashlib,json,pathlib,subprocess,time
OUT=pathlib.Path(__file__).parent;exe=pathlib.Path(r'C:\Program Files\Docker\Docker\resources\bin\docker.exe');records=[];ready=False
for attempt in range(1,4):
    command=[str(exe),'--host','npipe:////./pipe/dockerDesktopLinuxEngine','info','--format','{{json .ServerVersion}}'];start=time.monotonic()
    try:
        p=subprocess.run(command,capture_output=True,timeout=7,creationflags=subprocess.CREATE_NO_WINDOW);code=p.returncode;out=p.stdout;error=p.stderr;timeout=False
    except subprocess.TimeoutExpired as e:code=None;out=e.stdout or b'';error=e.stderr or b'';timeout=True
    records.append(dict(attempt=attempt,argv=command,exit=code,timeout=timeout,elapsedMilliseconds=round((time.monotonic()-start)*1000),stdout=out.decode('utf8',errors='replace'),stderr=error.decode('utf8',errors='replace')))
    if code==0:ready=True;break
    if attempt<3:time.sleep(1)
receipt=dict(schema=1,status='LOCAL_DOCKER_READY' if ready else 'LOCAL_DB_NOT_RUN_EXPLICIT_LOCAL_DOCKER_DAEMON_UNAVAILABLE',records=records,localEndpointOnly=True,remoteDockerContextUsed=False,databaseCommandsRun=False,productionProviderActions=False,qualification='Actual bounded readiness; hosted credential-free mechanics reported independently and grant no DB acceptance',observedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),acceptanceGranted=False,release='NO_GO')
(OUT/'LOCAL_DOCKER_READINESS29.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=receipt['status'],attempts=len(records),ready=ready)))
