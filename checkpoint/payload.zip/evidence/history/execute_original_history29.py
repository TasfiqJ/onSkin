"""New Campaign29 driver; unchanged original consumers at fresh authentic pins."""
import concurrent.futures,datetime,hashlib,json,os,pathlib,stat,subprocess,sys,time
OUT=pathlib.Path(__file__).parent;CURRENT=OUT.parent.parent/'c29-src'
SPEC=json.loads((OUT/'authenticated-history-pins29.json').read_text(encoding='utf8'));TOOLS=json.loads((OUT.parent/'runtime/ACTIVE_TOOLCHAIN29.json').read_text(encoding='utf8'))
PYTHON=TOOLS['python'];ENV={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','GITHUB_','PYTHON','NPM_')) and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')};ENV['PATH']=TOOLS['prefix']+os.pathsep+ENV['PATH'];ENV['GIT_TERMINAL_PROMPT']='0'
H=lambda b:hashlib.sha256(b).hexdigest()
def need(value,code):
    if not value:raise ValueError(code)
def git(root,*args,timeout=600):
    p=subprocess.run(['git','--no-replace-objects','-c','core.hooksPath=','-c','core.autocrlf=false','-c','core.longpaths=true',*args],cwd=root,env=ENV,capture_output=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
    need(p.returncode==0,'HISTORY_GIT_COMMAND_FAILED');return p.stdout
def stable(a,b):
    names=[n for n in dir(a) if n.startswith('st_') and n not in ('st_atime','st_atime_ns')]
    return names==[n for n in dir(b) if n.startswith('st_') and n not in ('st_atime','st_atime_ns')] and all(getattr(a,n)==getattr(b,n) for n in names)
def regular(i):return stat.S_ISREG(i.st_mode) and i.st_nlink==1 and not getattr(i,'st_file_attributes',0)&1024 and not i.st_mode&(stat.S_ISUID|stat.S_ISGID|stat.S_ISVTX) and 0<=i.st_size<=128*1024*1024
def cross(path,a,b):
    if not all(getattr(a,n)==getattr(b,n) for n in ('st_dev','st_ino','st_nlink','st_size','st_mtime_ns','st_uid','st_gid')):return False
    if os.name!='nt':return a.st_mode==b.st_mode and a.st_ctime_ns==b.st_ctime_ns
    execute=0o111 if path.suffix.lower() in ('.exe','.com','.bat','.cmd') else 0
    if b.st_mode&0o111 or a.st_mode!=b.st_mode|execute:return False
    return all(not(hasattr(a,n) and hasattr(b,n)) or getattr(a,n)==getattr(b,n) for n in ('st_file_attributes','st_reparse_tag','st_birthtime_ns'))
def raw_read(path):
    a=path.lstat();need(regular(a),'HISTORY_REGULAR');fd=os.open(path,os.O_RDONLY|getattr(os,'O_BINARY',0)|getattr(os,'O_NOFOLLOW',0))
    try:
        b=os.fstat(fd);need(regular(b) and cross(path,a,b),'HISTORY_OPEN_IDENTITY');blocks=[];total=0
        while True:
            part=os.read(fd,min(1024*1024,a.st_size-total+1))
            if not part:break
            total+=len(part);need(total<=a.st_size,'HISTORY_READ_BOUND');blocks.append(part)
        first=b''.join(blocks);middle=os.fstat(fd);need(total==a.st_size and stable(b,middle),'HISTORY_FIRST_STABILITY');os.lseek(fd,0,os.SEEK_SET);offset=0
        while True:
            part=os.read(fd,min(1024*1024,a.st_size-offset+1))
            if not part:break
            need(offset+len(part)<=len(first) and part==first[offset:offset+len(part)],'HISTORY_SECOND_BYTES');offset+=len(part)
        final=os.fstat(fd);after=path.lstat();need(offset==len(first) and regular(final) and regular(after) and stable(b,final) and stable(a,after) and cross(path,after,final),'HISTORY_FINAL_STABILITY')
    finally:os.close(fd)
    return first
def inventory(root,pin):
    need(git(root,'rev-parse','HEAD').decode().strip()==pin['source'] and not git(root,'status','--porcelain=v1','--untracked-files=all','-z'),'HISTORY_CHECKOUT_IDENTITY')
    tree=git(root,'ls-tree','-r','-z','HEAD');parents={root,*root.parents};count=total=0
    for row in tree.split(b'\0'):
        if not row:continue
        meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();need(kind==b'blob' and mode in (b'100644',b'100755'),'HISTORY_TREE_TYPE');path=root/name.decode('utf8');parent=path.parent
        while parent not in parents:parents.add(parent);parent=parent.parent
    identities={}
    for p in parents:
        i=p.lstat();need(stat.S_ISDIR(i.st_mode) and not getattr(i,'st_file_attributes',0)&1024,'HISTORY_PARENT');identities[p]=(i.st_dev,i.st_ino,i.st_mode,getattr(i,'st_file_attributes',None),getattr(i,'st_reparse_tag',None))
    for row in tree.split(b'\0'):
        if not row:continue
        meta,name=row.split(b'\t',1);mode,kind,oid=meta.split();path=root/name.decode('utf8');raw=raw_read(path)
        if os.name!='nt':need(bool(path.lstat().st_mode&0o111)==(mode==b'100755'),'HISTORY_WORKING_MODE')
        need(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid.decode(),'HISTORY_RAW_GIT_BLOB');count+=1;total+=len(raw)
    for p,identity in identities.items():
        i=p.lstat();need((i.st_dev,i.st_ino,i.st_mode,getattr(i,'st_file_attributes',None),getattr(i,'st_reparse_tag',None))==identity,'HISTORY_PARENT_CHANGED')
    need(not git(root,'status','--porcelain=v1','--untracked-files=all','-z'),'HISTORY_FINAL_DIRTY')
    return dict(trackedFiles=count,trackedBytes=total,treeMetadataSHA256=H(tree),tree=git(root,'rev-parse','HEAD^{tree}').decode().strip(),rawWorkingQualification='ALL_TRACKED_RAW_GIT_BLOBS_EXACT_TWO_BOUNDED_READS')
def prepare(label):
    root=OUT/('fresh-'+label);need(not root.exists(),'HISTORY_FRESH_DIRECTORY_REQUIRED');started=time.monotonic()
    command=['clone','--no-checkout','--single-branch','--branch','stage/m1-destructive-commit-core05-28','--no-hardlinks','https://github.com/TasfiqJ/onSkin.git',str(root)]
    git(OUT,*command)
    need(git(root,'rev-parse','--is-shallow-repository').strip()==b'false' and (root/'.git').is_dir() and not (root/'.git/objects/info/alternates').exists(),'HISTORY_FULL_INDEPENDENT_STORE')
    for p in (root/'.git/objects').rglob('*'):
        i=p.lstat();need(not stat.S_ISLNK(i.st_mode) and not getattr(i,'st_file_attributes',0)&1024 and (not stat.S_ISREG(i.st_mode) or i.st_nlink==1),'HISTORY_OBJECT_SHARING')
    git(root,'fsck','--full','--strict','--no-reflogs','--no-dangling');i=(root/'.git/objects').lstat();r=dict(group=label,remote='https://github.com/TasfiqJ/onSkin.git',fullRemoteClone=True,objectStoreDevice=i.st_dev,objectStoreInode=i.st_ino,fsckExit=0,elapsedSeconds=time.monotonic()-started)
    (OUT/(label+'-clone-provenance.json')).write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(group=label,status='FRESH_REMOTE_CLONE_READY')),flush=True);return root,r
def materialize(root):
    records=[]
    for row in SPEC['nativePins']:
        raw=raw_read(CURRENT/row['path']);need(len(raw)==row['bytes'] and H(raw)==row['sha256'],'CURRENT_NATIVE_PIN_MISMATCH');target=root/row['path'];need(not target.exists(),'NATIVE_FIXTURE_ALREADY_EXISTS');target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(raw)
        need(raw_read(target)==raw,'NATIVE_FIXTURE_READBACK');records.append(row)
    return records
def run_case(root,pin):
    start=time.monotonic();release=pin['release'];print(json.dumps(dict(release=release,status='STARTED')),flush=True);git(root,'checkout','--detach',pin['source']);need(git(root,'rev-parse','HEAD^{tree}').decode().strip()==pin['tree'],'HISTORY_PIN_TREE')
    for label,path in [('scriptIdentity',pin['script']),('checkerIdentity','scripts/release/full-app-j01/check.py')]:
        raw=raw_read(root/path);expected=pin[label];need(len(raw)==expected['bytes'] and H(raw)==expected['sha256'] and raw==git(root,'show',pin['source']+':'+path) and git(root,'ls-tree',pin['source'],'--',path).decode().strip()==expected['mode']+' blob '+expected['blob']+'\t'+path,'HISTORY_ORIGINAL_SCRIPT_IDENTITY')
    before=inventory(root,pin);command=[PYTHON,'-B',pin['script']];stdout=OUT/('release'+release+'.stdout.log');stderr=OUT/('release'+release+'.stderr.log')
    with stdout.open('xb') as o,stderr.open('xb') as e:
        child=subprocess.run(command,cwd=root,env=ENV,stdout=o,stderr=e,timeout=1800,creationflags=subprocess.CREATE_NO_WINDOW)
    after=inventory(root,pin);need(before==after,'HISTORY_RAW_CHECKOUT_CHANGED');raw=stdout.read_bytes();errors=stderr.read_bytes();terminal=None
    for line in reversed(raw.decode('utf8',errors='replace').splitlines()):
        try:terminal=json.loads(line);break
        except json.JSONDecodeError:continue
    receipt=dict(release=release,source=pin['source'],tree=pin['tree'],scriptIdentity=pin['scriptIdentity'],checkerIdentity=pin['checkerIdentity'],argv=command,exit=child.returncode,timeout=False,elapsedSeconds=time.monotonic()-start,before=before,after=after,cleanAfter=True,stdoutSHA256=H(raw),stderrSHA256=H(errors),terminalResult=terminal,expectedTerminalResult=pin['expectedTerminal'],qualification='ACTUAL_ORIGINAL_CONSUMER_AT_AUTHENTIC_FRESH_FULL_CHECKOUT;INTERNAL_SYNTHETIC_FIXTURE_QUALIFICATIONS_PRESERVED;NOT_CURRENT_ACCEPTANCE',nativeInputs='TEN_CURRENT_REAL_INSTALL_PUBLIC_SOURCE_FIXTURES_ONLY_NOT_HISTORICAL_NPM_INSTALL',acceptanceGranted=False,releaseStatus='NO_GO')
    (OUT/('release'+release+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(release=release,exit=child.returncode,terminalResult=terminal)),flush=True);need(child.returncode==0 and terminal==pin['expectedTerminal'],'HISTORY_CONSUMER_FAILED');return receipt
def worker(label,root,pins):
    native=materialize(root);(OUT/(label+'-native-fixture-provenance.json')).write_text(json.dumps(dict(nativeInputs=native,qualification='CURRENT_INSTALL_FIXTURES_ONLY_NOT_HISTORICAL_NPM_INSTALL'),indent=2)+'\n',encoding='utf8')
    return [run_case(root,pin) for pin in pins]
def main():
    need(not sys.flags.optimize,'PYTHON_OPTIMIZATION_FORBIDDEN');contextBefore=dict(head=git(CURRENT,'rev-parse','HEAD').decode().strip(),tree=git(CURRENT,'rev-parse','HEAD^{tree}').decode().strip(),status=git(CURRENT,'status','--porcelain=v1','--untracked-files=all').decode())
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        prepared=dict(zip(('early','late'),[f.result() for f in [pool.submit(prepare,'early'),pool.submit(prepare,'late')]]))
    need(len({(v[1]['objectStoreDevice'],v[1]['objectStoreInode']) for v in prepared.values()})==2,'HISTORY_DISTINCT_OBJECT_STORES')
    deadline=time.monotonic()+1200
    while not (OUT.parent/'validation/DEPENDENCY_PREPARATION29.json').exists():
        need(time.monotonic()<deadline,'CURRENT_NORMAL_INSTALL_NOT_READY');time.sleep(2)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[pool.submit(worker,'early',prepared['early'][0],SPEC['pins'][:8]),pool.submit(worker,'late',prepared['late'][0],SPEC['pins'][8:])];results=[]
        for f in concurrent.futures.as_completed(futures):results.extend(f.result())
    value=dict(schema=1,status='PASS_NEW_CAMPAIGN29_ORIGINAL151_AND_ORIGINAL09_TO23',runs=sorted(results,key=lambda r:r['release']),contextBefore=contextBefore,contextAfter=dict(head=git(CURRENT,'rev-parse','HEAD').decode().strip(),tree=git(CURRENT,'rev-parse','HEAD^{tree}').decode().strip()),cloneProvenance=[v[1] for v in prepared.values()],driverSHA256=H(pathlib.Path(__file__).read_bytes()),authenticatedPinFileSHA256=H((OUT/'authenticated-history-pins29.json').read_bytes()),runtime=PYTHON,toolchainPrefix=TOOLS['prefix'],nativePins=SPEC['nativePins'],qualification='NEW_ACTUAL_ORIGINAL_EXECUTION_AT_AUTHENTIC_REMOTE_PINS_WITH_INTERNAL_FIXTURE_LIMITS;NOT_BRAIN_SOURCE_OR_RELEASE_ACCEPTANCE',acceptanceGranted=False,release='NO_GO')
    (OUT/'SUMMARY29.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=value['status'],completed=len(results))),flush=True)
if __name__=='__main__':main()
