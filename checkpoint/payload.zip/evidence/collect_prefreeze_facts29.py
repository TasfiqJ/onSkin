"""Validate completed supplier receipts and curate the pre-tail evidence list."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent/'c29-src'
B_HEAD='2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
B_TREE='015e185b35be44301e6d9a4be0c28d040150aec8'
C_PATHS={'scripts/release/full-app-j01/replay29.test.py','scripts/release/full-app-j01/check.py',
    'docs/brain/task-specs/M1X-29/TASK.md'}
AFTER_COLLECTION = ('WORKLIST_FREEZE29.json', 'WORKLIST_PRODUCER29.started.json', 'worklist-producer29.log')
EXPECTED_LABELS = {'clean-toolchain-before29', 'full-forced-quality29', 'clean-postinstall-check29',
    'core05-original29', 'core05-focused29', 'launch-contracts29', 'launch-baseline-check29',
    'launch-baseline-smoke29', 'native-privacy29', 'advisory-patch-controls29',
    'strict-native-readiness29', 'unsigned-ios29', 'unsigned-android29', 'clean-toolchain-after29'}
PRIVATE_PATH = r'(?:[A-Za-z]:[\\/]+Users[\\/]+|/(?:Users|home)/)[^\s"<>]+'
PRIVATE_HOME = r'(?:[A-Za-z]:[\\/]+Users[\\/]+|/(?:Users|home)/)[^\\/\s"<>]+'


def stable_read(path, limit=16*1024*1024):
    """Two bounded observations with same-domain metadata and parent identity."""
    path=Path(os.path.abspath(path)); parents={}
    for parent in path.parents:
        info=parent.lstat()
        assert stat.S_ISDIR(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024
        parents[parent]=(info.st_dev,info.st_ino,info.st_mode)
    stamp=lambda value: {key:getattr(value,key) for key in dir(value)
        if key.startswith('st_') and key not in ('st_atime','st_atime_ns')}
    before=path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink==1 and not getattr(before,'st_file_attributes',0)&1024
    assert not before.st_mode&(stat.S_ISUID|stat.S_ISGID|stat.S_ISVTX) and 0<=before.st_size<=limit
    descriptor=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_BINARY',0))
    try:
        opened=os.fstat(descriptor)
        assert all(getattr(before,key)==getattr(opened,key) for key in
            ('st_dev','st_ino','st_nlink','st_size','st_mtime_ns','st_uid','st_gid'))
        execute=0o111 if os.name=='nt' and path.suffix.lower() in ('.exe','.com','.bat','.cmd') else 0
        assert before.st_mode==opened.st_mode|execute and (os.name!='nt' or not opened.st_mode&0o111)
        assert os.name=='nt' or before.st_ctime_ns==opened.st_ctime_ns
        for key in ('st_file_attributes','st_reparse_tag','st_birthtime_ns'):
            assert not (hasattr(before,key) and hasattr(opened,key)) or getattr(before,key)==getattr(opened,key)
        observations=[]
        for _ in range(2):
            assert os.lseek(descriptor,0,os.SEEK_SET)==0
            blocks=[];total=0
            while True:
                block=os.read(descriptor,min(1024*1024,before.st_size-total+1))
                if not block:break
                total+=len(block);assert total<=before.st_size;blocks.append(block)
            assert total==before.st_size and stamp(opened)==stamp(os.fstat(descriptor)) and stamp(before)==stamp(path.lstat())
            observations.append(b''.join(blocks))
        assert observations[0]==observations[1]
    finally:os.close(descriptor)
    for parent,expected in parents.items():
        info=parent.lstat();assert (info.st_dev,info.st_ino,info.st_mode)==expected and not getattr(info,'st_file_attributes',0)&1024
    return observations[0]


def text_body(body):
    return body.decode('utf-16' if body.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8-sig')


def unsafe_raw_reason(path, body):
    value=text_body(body)
    if re.search(r'https?://[^\s"<>]+[?&](?:token|sig|signature|x-amz-signature)=',value,re.I):
        return 'SIGNED_OR_CREDENTIAL_URL_BODY_OMITTED'
    if path.suffix.lower() in ('.log','.jsonl','.json') and 'Traceback (most recent call last):' in value:
        return 'RAW_EXCEPTION_BODY_OMITTED'
    if path.suffix.lower() in ('.json','.log','.jsonl','.py','.md','.txt') and re.search(PRIVATE_PATH,value):
        return 'RAW_PRIVATE_PATH_BODY_OMITTED'
    return None


def sanitized_body(path,body):
    value=re.sub(PRIVATE_HOME,'<LOCAL_HOME>',text_body(body))
    if path.suffix.lower()=='.json':
        json.loads(value)  # The published derivative retains readable JSON.
        return value.encode()
    prefix='SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED\n'
    return (prefix+value).encode()


def public_evidence(path,body):
    reason=unsafe_raw_reason(path,body)
    raw_witness=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    if reason=='RAW_PRIVATE_PATH_BODY_OMITTED':
        derivative=sanitized_body(path,body)
        assert unsafe_raw_reason(path,derivative) is None
        return derivative,dict(qualification='SANITIZED_LOCAL_HOME_PREFIX_ONLY_ORIGINAL_RETAINED_EXTERNALLY',
            original=raw_witness,published=dict(bytes=len(derivative),sha256=hashlib.sha256(derivative).hexdigest()))
    if reason:
        item=dict(qualification=reason,original=raw_witness,published=None)
        if reason=='RAW_EXCEPTION_BODY_OMITTED':
            item['publicFailureCodes']=sorted(set(re.findall(r'(?:Refusal: |"code":\s*")((?:R\d\d_|NPM_)[A-Z0-9_]{1,100})',text_body(body))))
        return None,item
    return body,None


def literals(body):
    result={}
    for node in ast.parse(body).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            try:result[node.targets[0].id]=ast.literal_eval(node.value)
            except (ValueError,TypeError):pass
    return result


def current_verifier_attestation(head,tree):
    build=json.loads(stable_read(HERE/'packaging/VERIFIER_BUILD29.json'))
    controls=json.loads(stable_read(HERE/'packaging/VERIFIER_CONTROLS29.json'))
    assert controls['status']=='PASS' and controls['controls']>=39
    checkpoint=stable_read(HERE/'packaging/verify29.py');returned=stable_read(HERE/'packaging/verify_return29.py')
    assert literals(checkpoint)['MODE']=='checkpoint' and literals(returned)['MODE']=='return'
    assert checkpoint.replace(b"MODE = 'checkpoint'",b"MODE = 'return'",1)==returned
    for name,body in (('checkpoint',checkpoint),('return',returned)):
        key=name+'VerifierSHA256';assert hashlib.sha256(body).hexdigest()==build[key]==controls[key]
        actual=literals(body)
        for key,expected in build['constants'].items():
            if key in ('EXISTING','NEW','CHECKPOINT_FILES'):expected=set(expected)
            assert actual[key]==expected, key
    source={}
    for name,key in (('check.py','CHECKER_SHA256'),('source_consumer29.test.py','CONSUMER_SHA256')):
        relative='scripts/release/full-app-j01/'+name;body=stable_read(ROOT/relative)
        assert body==git('show',head+':'+relative)
        assert hashlib.sha256(body).hexdigest()==build['constants'][key]
        source[key]=hashlib.sha256(body).hexdigest()
    return dict(schema=1,status='CURRENT_CLEAN_SOURCE_VERIFIER_CONSTANTS_AND_39_CONTROLS_BOUND',
        sourceHead=head,sourceTree=tree,sourcePins=source,checkpointVerifierSHA256=hashlib.sha256(checkpoint).hexdigest(),
        returnVerifierSHA256=hashlib.sha256(returned).hexdigest(),
        historicalControlsQualificationPreserved=controls.get('checkerAndConsumerPinsQualification'),
        qualification='SUPPLIER_PREFREEZE_BINDING_ATTESTATION_NOT_SOURCE_ACCEPTANCE',acceptanceGranted=False,release='NO_GO')


def current_main_receipt(head,tree):
    path=HERE/'governance/current-source-revision3.execution.json'
    receipt=json.loads(stable_read(path))
    assert receipt['status']=='PASS_CURRENT_MAIN29'
    assert receipt['head']==receipt['headAfter']==head and receipt['tree']==receipt['treeAfter']==tree
    assert receipt['cleanBefore'] is True and receipt['cleanAfter'] is True and type(receipt['exit']) is int and receipt['exit']==0
    checker='scripts/release/full-app-j01/check.py';checker_body=stable_read(ROOT/checker)
    assert checker_body==git('show',head+':'+checker)
    assert receipt['checkerSHA256']==hashlib.sha256(checker_body).hexdigest()
    tools=json.loads(stable_read(HERE/'runtime/ACTIVE_TOOLCHAIN29.json'))
    assert receipt['command']==[tools['python'],'-I','-B',checker]
    bodies={}
    for stream in ('stdout','stderr'):
        witness=receipt[stream];assert type(witness['path']) is str and Path(witness['path']).name==witness['path']
        body=stable_read(path.parent/witness['path'])
        assert len(body)==witness['bytes'] and hashlib.sha256(body).hexdigest()==witness['sha256']
        bodies[stream]=body
    result=receipt['result'];assert json.loads(bodies['stdout'])==result
    assert result['valid'] is True and result['release']=='NO_GO' and result['acceptanceGranted'] is False
    assert result['source_acceptance']=='SUBMITTED_REVIEW_REQUIRED' and result['current_source_governance']=='RELEASE29_FINITE_SCOPE_ONLY'
    assert set(result['admissions'])=={'G97','DB','M103','M2','J01','PUBLIC'}
    assert all(flag is False for flag in result['admissions'].values())
    proof=result['source29']
    assert proof['endpoint']==proof['checkoutHead']==head and proof['tree']==proof['checkoutTree']==tree
    assert proof['phase']=='SOURCE' and proof['workingQualification']=='FINITE_PENDING_ALLOWED'
    # These counts are relative to pinned PR32, rather than dirty changes from
    # HEAD. A clean substantive SOURCE checkout therefore still has a delta.
    changed=git('diff','--name-only','-z','bace116586d58ed955f0a024ca96ae9f4ad9286d',head).split(b'\0')[:-1]
    tracked=git('ls-tree','-r','--name-only','-z',head).split(b'\0')[:-1]
    assert proof['currentChangedPaths']==proof['stagedChangedPaths']==len(changed)
    assert proof['trackedWorkingBlobsHashedLocally']==proof['metadataFiles']==len(tracked)>20000
    return path.relative_to(HERE).as_posix()


def reuse_b_evidence(head,tree):
    """Bound reuse to the one canonical fixture correction and its governance."""
    assert head!=B_HEAD and git('rev-parse',B_HEAD+'^{tree}').decode().strip()==B_TREE
    assert git('rev-list','--parents','-n','1',head).decode().split()==[head,B_HEAD]
    def entries(revision):
        result={}
        for entry in git('ls-tree','-r','-z',revision).split(b'\0')[:-1]:
            metadata,name=entry.split(b'\t',1);mode,kind,blob=metadata.decode().split()
            assert kind=='blob' and name not in result
            result[name]=(mode,blob)
        return result
    before=entries(B_HEAD);after=entries(head)
    assert set(before)==set(after)
    changed={name.decode() for name in before if before[name]!=after[name]}
    assert changed==C_PATHS
    assert all(before[name.encode()][0]==after[name.encode()][0]=='100644' for name in changed)
    test='scripts/release/full-app-j01/replay29.test.py';original=git('show',B_HEAD+':'+test)
    old=b"prefix=Path(directory)/'prefix';npm=";new=b"prefix=Path(directory).resolve()/'prefix';npm="
    assert original.count(old)==1 and stable_read(ROOT/test)==git('show',head+':'+test)==original.replace(old,new,1)
    runner='scripts/release/full-app-j01/replay29.py';body=stable_read(ROOT/runner)
    assert body==git('show',B_HEAD+':'+runner)==git('show',head+':'+runner)
    return dict(schema=1,status='EXACT_THREE_PATH_B_TO_C_TRANSITION_VALIDATED',
        priorHead=B_HEAD,priorTree=B_TREE,head=head,tree=tree,changedPaths=sorted(changed),directChild=True,
        allOtherTrackedPathsModesAndBlobsIdentical=True,trackedFilesCompared=len(before),
        replayTestChange='ONLY_CANONICALIZE_SYNTHETIC_TEMPORARY_FIXTURE_PREFIX',
        unchangedRunnerSHA256=hashlib.sha256(body).hexdigest(),
        qualification='B_APP_VALIDATION_AND_AUTHENTIC_HISTORICAL_EXECUTION_REUSED_BY_EXACT_UNCHANGED_SOURCE;NOT_RERUN_AT_C',
        acceptanceGranted=False,release='NO_GO')


def current_controls_receipt(head,tree,reuse):
    path=HERE/'governance/current-controls-revision3.execution.json'
    receipt=json.loads(stable_read(path));assert receipt['status']=='PASS_CURRENT_CONTROLS29'
    assert receipt['head']==receipt['headAfter']==head and receipt['tree']==receipt['treeAfter']==tree
    assert receipt['cleanBefore'] is True and receipt['cleanAfter'] is True
    for name,key in (('check.py','checkerSHA256'),('replay29.test.py','replayTestSHA256'),('source_consumer29.test.py','consumerSHA256')):
        relative='scripts/release/full-app-j01/'+name;body=stable_read(ROOT/relative)
        assert body==git('show',head+':'+relative) and receipt[key]==hashlib.sha256(body).hexdigest()
    transition=receipt['scopeTransition']
    assert transition['priorHead']==B_HEAD and transition['priorTree']==B_TREE and len(transition['changedPaths'])==3 and set(transition['changedPaths'])==C_PATHS
    assert transition['unchangedRunnerSHA256']==reuse['unchangedRunnerSHA256'] and transition['allOtherTrackedModesAndBytesExact'] is True
    labels={'python312-replay29','python312-source29','python312-short-temp-replay29','python39-replay29','python39-source29'}
    commands=receipt['commands'];assert type(commands) is list and len(commands)==5 and {row['label'] for row in commands}==labels
    tools=json.loads(stable_read(HERE/'runtime/ACTIVE_TOOLCHAIN29.json'))
    for row in commands:
        assert row['sourceContext']==dict(head=head,tree=tree) and type(row['exit']) is int and row['exit']==0
        replay=row['label'].endswith('replay29');script='scripts/release/full-app-j01/'+('replay29.test.py' if replay else 'source_consumer29.test.py')
        command=row['command'];assert type(command) is list and len(command)==4 and type(command[0]) is str and command[0] and command[1:]==['-I','-B',script]
        if row['label'].startswith('python312'):assert command[0]==tools['python']
        assert type(row['environmentQualification']) is str and row['environmentQualification']
        bodies={}
        for stream in ('stdout','stderr'):
            witness=row[stream];assert type(witness['path']) is str and Path(witness['path']).name==witness['path']
            body=stable_read(path.parent/witness['path'])
            assert len(body)==witness['bytes'] and hashlib.sha256(body).hexdigest()==witness['sha256'];bodies[stream]=body
        values=[json.loads(line) for line in bodies['stdout'].splitlines() if line.strip()]
        result=row['result'];assert values and values[-1]==result and result['status']=='PASS'
        assert result['positiveControls']==(5 if replay else 17) and result['refusals']==(74 if replay else 127)
        if not replay:assert result['inheritedFunctions']==218
        assert result['acceptanceGranted'] is False and result['release']=='NO_GO'
    return path.relative_to(HERE).as_posix()


def git(*args):
    return subprocess.check_output(['git','--no-replace-objects',*args],cwd=ROOT)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--validation',type=Path,required=True)
    parser.add_argument('--replay',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert not args.output.exists()
    head=git('rev-parse','HEAD').decode().strip()
    tree=git('rev-parse','HEAD^{tree}').decode().strip()
    assert not git('status','--porcelain=v1','--untracked-files=all')
    reuse=reuse_b_evidence(head,tree)
    main_receipt=current_main_receipt(head,tree)
    controls_receipt=current_controls_receipt(head,tree,reuse)
    validation=json.loads(stable_read(args.validation))
    assert validation['sourceHead']==B_HEAD and validation['sourceTree']==B_TREE
    records=validation['records'];assert len(records)==14
    labels=set()
    for row in records:
        label=row['label'];assert label not in labels;labels.add(label)
        assert row['exit']==(1 if label=='strict-native-readiness29' else 0), label
        assert row['timeout'] is False
        for key in ('sourceBefore','sourceAfter'):
            assert row[key]==dict(head=B_HEAD,tree=B_TREE,status='')
        for key in ('stdout','stderr'):
            witness=row[key];assert Path(witness['path']).name==witness['path']
            path=args.validation.parent/witness['path'];body=stable_read(path)
            assert len(body)==witness['bytes'] and hashlib.sha256(body).hexdigest()==witness['sha256']
    assert labels==EXPECTED_LABELS
    assert validation['forcedTasks']['mobileTests']==6478 and validation['forcedTasks']['operatorTests']==24
    assert validation['forcedTasks']['mobileFiles']==499 and validation['forcedTasks']['operatorFiles']==7
    assert validation['forcedTasks']['tasks']==8 and validation['forcedTasks']['cacheHits']==0
    assert validation['finalPostcheck']['exit']==0 and validation['finalPostcheck']['canonicalIdentityMatches'] is True
    assert validation['completeCanonicalToolIdentityComparedToFreshInstall'] is True
    assert validation['core05ActualTAP']=={
        'core05-original29':['# tests 36','# pass 36','# fail 0','# skipped 0'],
        'core05-focused29':['# tests 69','# pass 69','# fail 0','# skipped 0']}
    assert validation['nativeReadiness']['exit']==1
    native=next(row for row in records if row['label']=='strict-native-readiness29')
    native_text=text_body(stable_read(args.validation.parent/native['stderr']['path']))
    assert len(re.findall(r'^WARN ',native_text,re.M))==5 and 'Phase 5 strict mode failed on 5 warnings.' in native_text
    assert validation['localDatabase']=='LOCAL_DB_NOT_RUN_EXPLICIT_LOCAL_DOCKER_DAEMON_UNAVAILABLE'
    assert validation['officialRuntime35AfterFinalCommands']['files']==35
    assert validation['officialRuntime35AfterFinalCommands']['allBytesSHA256AndStableRegularIdentity'] is True
    for platform in ('ios','android'):
        value=validation['exports'][platform]
        assert value['NODE_ENV']=='development' and value['clearCache'] is True and value['unsigned'] is True
    historical=json.loads(stable_read(HERE/'history/SUMMARY29.json'))
    assert historical['status']=='PASS_NEW_CAMPAIGN29_ORIGINAL151_AND_ORIGINAL09_TO23'
    assert len(historical['runs'])==16
    for row in historical['runs']:
        assert row['exit']==0 and row['cleanAfter'] is True and row['before']==row['after']
        assert row['terminalResult']==row['expectedTerminalResult']
    replay_body=stable_read(args.replay);replay=json.loads(replay_body)
    assert replay['status']=='PASS' and replay['acceptanceGranted'] is False and replay['release']=='NO_GO'
    assert replay['context']['head']==B_HEAD and replay['context']['tree']==B_TREE
    assert [row['release'] for row in replay['records']]==[24,25,26,27,28]
    for row in replay['records']:
        assert row['checkoutBefore']==row['checkoutAfter']
        assert row['toolIdentityBefore']==row['toolIdentityAfter']==replay['tools']
        assert row['sourceResult']['exit']==0 and row['sourceResult']['acceptanceGranted'] is False
    # Execute only the authenticated runner's finite receipt guard, never its
    # main, tools, subprocesses or historical consumers during collection.
    runner_path='scripts/release/full-app-j01/replay29.py';runner=stable_read(ROOT/runner_path)
    assert runner==git('show',head+':'+runner_path)
    runner_ast=ast.parse(runner);namespace={'json':json,'re':re}
    wanted_functions={'require29','receipt29_guard'}
    wanted_constants={'PINNED29','LOCK29_SHA256','NATIVE29_PINS_SHA256'}
    subset=[node for node in runner_ast.body if isinstance(node,ast.FunctionDef) and node.name in wanted_functions or
        isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in wanted_constants]
    exec(compile(ast.Module(body=subset,type_ignores=[]),'<authenticated finite receipt guard>','exec'),namespace)
    namespace['receipt29_guard'](replay_body,replay['nonce'],replay['context'],replay['tools'])
    attestation=current_verifier_attestation(head,tree)
    selected=set();omitted=[];selected_witnesses={}
    for directory in ('github','review','reader','governance','history','validation','validation-b','packaging','ci-prefreeze','ci-prefreeze-b'):
        base=HERE/directory
        if not base.exists():continue
        # Never recurse through supplier clones, npm caches, runtime installs,
        # raw provider archives, or unknown child directories.
        candidates=list(base.glob('*'))
        if directory=='review':candidates+=list((base/'prior-brain').glob('*.json'))
        for path in candidates:
            info=path.lstat()
            if not stat.S_ISREG(info.st_mode) or path.suffix not in ('.json','.jsonl','.log','.py','.md','.txt'):continue
            assert info.st_nlink==1 and not getattr(info,'st_file_attributes',0)&1024
            relative=path.relative_to(HERE).as_posix()
            if any(part in ('node_modules','.git','npm-cache','exports','runtime','checkpoint') for part in path.relative_to(base).parts):continue
            if any(word in path.name.lower() for word in ('inprogress','incomplete-json')):continue
            if path.name in ('verify29.py','verify_return29.py'):continue
            selected.add(relative)
    for name in ('SOURCE_PREFLIGHT29.json','SOURCE_PREFLIGHT29.original-endhead-attribution.json',
                 'ROOT_SOURCE_REVIEW29.json','ROOT_SOURCE_REVIEW29_REVISION2.json','ROOT_SOURCE_REVIEW29_REVISION3.json','CLEAN_SUBSTANTIVE29.json',
                 'CLEAN_SUBSTANTIVE29_REVISION2.json','prepare_verifier29.py','freeze_worklists29.py',
                 'build_checkpoint29.py','collect_prefreeze_facts29.py'):
        if (HERE/name).is_file():selected.add(name)
    for name in ('ACTIVE_RUNTIME29.json','ACTIVE_TOOLCHAIN29.json'):
        pointer=HERE/'runtime'/name;selected.add(pointer.relative_to(HERE).as_posix())
        record=json.loads(stable_read(pointer))
        if 'receipt' in record:
            receipt=Path(record['receipt']);assert receipt.is_relative_to(HERE)
            if 'receiptSHA256' in record:
                assert hashlib.sha256(stable_read(receipt)).hexdigest()==record['receiptSHA256']
            selected.add(receipt.relative_to(HERE).as_posix())
    tools=json.loads(stable_read(HERE/'runtime/ACTIVE_TOOLCHAIN29.json'))
    receipt=Path(tools['receipt']);assert receipt.is_relative_to(HERE);selected.add(receipt.relative_to(HERE).as_posix())
    selected.add(args.validation.relative_to(HERE).as_posix());selected.add(args.replay.relative_to(HERE).as_posix())
    published_total=0
    for name in sorted(selected):
        body=stable_read(HERE/name);text_body(body)
        public,derivation=public_evidence(HERE/name,body)
        if derivation:omitted.append(dict(path=name,**derivation))
        if public is None:
            selected.remove(name);continue
        published_total+=len(public)
        selected_witnesses[name]=dict(bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
    assert args.validation.relative_to(HERE).as_posix() in selected and args.replay.relative_to(HERE).as_posix() in selected
    assert len(selected)<5000 and published_total<=64*1024*1024
    narrative=(
        'At exact clean B substantive source2f42fa45f1f6e7d776ede548da20edc10d3c6bb2 '
        '/tree015e185b35be44301e6d9a4be0c28d040150aec8, the forced uncached full run returned0: '
        '6,478 mobile tests/499 files and24 operator tests/7 files,8 successful tasks,0 cached. '
        'Unchanged Shelf Remove/Discard/F09 suites are identified subsets of that execution, not extra counts. '
        'Original CORE-05 is36/36; focused CORE-05 is69/69. Mandatory postinstall check, launch contracts, '
        'launch baseline check/smoke, native privacy and advisory/patch controls returned0. '
        'Both separate --clear unsigned development Expo exports returned0. '
        'Strict native readiness retained actual exit1/five warnings. Both unchanged original tool guards '
        'returned0 with the complete canonical1970-file npm identity matching the fresh install, after '
        'bounded metadata-only pre-observation. All35 official Python runtime members were reverified. '
        'Local Docker remained unavailable after bounded local-only probes; local DB is NOT_RUN.\n\n'
        'Original151 and historical09–23 completed16 actual unchanged original consumer invocations '
        'at their authenticated source heads/trees, all exit0 with raw tracked bytes equal before/after; '
        'their original bundle/synthetic qualifications and ten current-install public native fixtures '
        'remain explicit. New replay29 completed actual fresh full-clone/npm-ci/mandatory-hook original '
        'Release24–28 consumer/checker execution at each exact pin, including27@PR31 and28@PR32. '
        'Current reader/source/receipt controls and the39 artifact-verifier controls are separately recorded.\n\n'
        'B app validation and the B formal historical replay are explicitly reused at current C by the exact '
        'three-path direct-child Git transition: only new replay29.test.py, current check.py governance '
        'and TASK.md changed. The new test changes only canonicalization of its synthetic temporary '
        'fixture prefix. Every other tracked path/mode/blob, including the historical runner, old readers, '
        'original tests, application, lockfile, hooks and workflow, is identical to B. These B command '
        'executions are not claimed to have run at C. Current C replay/source controls separately returned0 '
        'with5/74 and17/127/218, including the official3.12 real8.3 temporary-path assay and Python3.9 compatibility. '
        'The complete current check.py main also returned0 at exact clean revision3 C source, with authenticated '
        'stdout/stderr and unchanged before/after HEAD/tree. Its parsed result remains valid=true, '
        'RELEASE29_FINITE_SCOPE_ONLY / SUBMITTED_REVIEW_REQUIRED / NO_GO, with all six admissions false.\n\n'
        'The earlier A6 formal replay failed with R29_REPLAY_CHILD_FAILURE; its suppressed child stage '
        'remains UNKNOWN. Separate unchanged original24 diagnostics observed NPM_TOOL_CHANGED during '
        'public-directory st_size0→4096 enumeration; a bounded metadata-only preparation followed by '
        'two consecutive original strict guards passed with the exact canonical profile. The new runner '
        'adds that preparation and static child-stage facts without changing or retrying the original guard. '
        'The B hosted Windows new replay-control step failed after the last pre-metadata case; that original '
        'failed result remains failed. A separate native8.3 temporary-directory alias reproduction showed '
        'that the new test supplied a noncanonical fixture path to the intentionally strict metadata helper. '
        'Canonicalizing only the fixture prefix preserves all5 positives and74 refusals. The exact suppressed '
        'hosted exception is not directly recovered by this controlled reproduction. '
        'A6 initial tool-precheck and summary-controller failures remain failed. The later B summary '
        'controller also failed a receipt-path lookup after all14 child commands; separate checked '
        'aggregations preserve the original logs/exits without rerunning or relabeling tests. '
        'These events are distinct from the original suppressed Windows reader exceptions.'
    )
    facts=dict(schema=1,status='PREFREEZE_ACTUAL_FACTS_READY',sourceHead=head,sourceTree=tree,
        allRequiredPrefreezeLocalCommandsComplete=True,validationNarrative=narrative,
        validationReceipt=args.validation.relative_to(HERE).as_posix(),
        formalReplayReceipt=args.replay.relative_to(HERE).as_posix(),
        currentMainReceipt=main_receipt,
        currentControlsReceipt=controls_receipt,
        validationEvidenceSourceHead=B_HEAD,validationEvidenceSourceTree=B_TREE,
        historicalEvidenceSourceHead=B_HEAD,historicalEvidenceSourceTree=B_TREE,
        reusedEvidenceQualification=reuse,
        evidenceFiles=sorted(selected),evidenceFileWitnesses=selected_witnesses,
        afterCollectionEvidenceFiles=list(AFTER_COLLECTION),verifierPinAttestation=attestation,
        omittedRawEvidence=dict(qualification='ORIGINAL_RAW_BODIES_RETAINED_EXTERNALLY_NOT_RELABELLED;PATH_ONLY_DERIVATIVES_KEEP_ORIGINAL_NAMES',files=omitted),
        release='NO_GO',acceptanceGranted=False)
    args.output.write_text(json.dumps(facts,sort_keys=True,indent=2)+'\n')
    print(json.dumps(dict(status=facts['status'],sourceHead=head,sourceTree=tree,evidenceFiles=len(selected))))


if __name__=='__main__':main()
