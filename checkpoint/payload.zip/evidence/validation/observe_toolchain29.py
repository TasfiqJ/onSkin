SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Read-only trace; original guard exceptions and outcomes are retained."""
import hashlib,json,pathlib,sys
ROOT=pathlib.Path(r'<LOCAL_HOME>\Documents\ChatGPT\MasterV2Code\c29-src')
sys.path.insert(0,str(ROOT/'scripts/security22'))
import toolchain
observations=[]
def trace(frame,event,arg):
    if frame.f_code.co_filename==toolchain.__file__ and frame.f_code.co_name=='walk' and event=='exception':
        kind,error,_=arg
        if error.args==('NPM_TOOL_CHANGED',) and 'before' in frame.f_locals:
            directory=frame.f_locals['directory'];before=frame.f_locals['before'];after=directory.lstat()
            fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_birthtime_ns')
            observations.append(dict(relativeDirectory=str(directory.relative_to(pathlib.Path(r'C:\Program Files\nodejs\node_modules\npm'))).replace('\\','/'),differences={f:[getattr(before,f,None),getattr(after,f,None)] for f in fields if getattr(before,f,None)!=getattr(after,f,None)},originalException=error.args[0]))
    return trace
source=pathlib.Path(toolchain.__file__).read_bytes();sys.settrace(trace)
try:
    value=toolchain.identity(ROOT);status='PASS_UNCHANGED_ORIGINAL_GUARD';exitcode=0
except BaseException as e:
    value=None;status='FAIL_UNCHANGED_ORIGINAL_GUARD';exitcode=1;failure=dict(type=type(e).__name__,code=e.args[0] if len(e.args)==1 and isinstance(e.args[0],str) else 'UNCLASSIFIED')
finally:sys.settrace(None)
assert pathlib.Path(toolchain.__file__).read_bytes()==source
print(json.dumps(dict(status=status,exit=exitcode,observations=observations,failure=failure if exitcode else None,identity=value,toolchainSHA256=hashlib.sha256(source).hexdigest(),guardChanged=False,waivers=False),sort_keys=True));raise SystemExit(exitcode)
