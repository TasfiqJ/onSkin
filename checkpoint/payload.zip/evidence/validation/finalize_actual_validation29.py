"""Aggregate actual completed executions; never replace or relabel failed calls."""
import datetime,hashlib,json,os,pathlib,re,stat,subprocess
OUT=pathlib.Path(__file__).parent;ROOT=OUT.parent.parent/'c29-src';H=lambda b:hashlib.sha256(b).hexdigest()
HEAD='a6f7e681f69380259876c3489f4d39be2b5244d0';TREE='abe7249fdb08106a16e96b0febd72f8d7192f3c0'
def need(v,c):
    if not v:raise ValueError(c)
records=json.loads((OUT/'CLEAN_SUBSTANTIVE_VALIDATION29.inprogress.json').read_text(encoding='utf8'))
expected=['clean-toolchain-before29','full-forced-quality29','clean-postinstall-check29','core05-original29','core05-focused29','launch-contracts29','launch-baseline-check29','launch-baseline-smoke29','native-privacy29','advisory-patch-controls29','strict-native-readiness29','unsigned-ios29','unsigned-android29','clean-toolchain-after29']
need([r['label'] for r in records]==expected,'VALIDATION_NOT_YET_COMPLETE')
for r in records:
    for side in ('sourceBefore','sourceAfter'):need(r[side]==dict(head=HEAD,tree=TREE,status=''),'SOURCE_IDENTITY_NOT_PRESERVED')
    for stream in ('stdout','stderr'):
        desc=r[stream];b=(OUT/desc['path']).read_bytes();need(len(b)==desc['bytes'] and H(b)==desc['sha256'],'ACTUAL_LOG_HASH_CHANGED')
    if r['label'] not in ('clean-toolchain-before29','clean-toolchain-after29','strict-native-readiness29'):need(r['exit']==0 and not r['timeout'],'REQUIRED_TECHNICAL_EXECUTION_FAILED')
need(records[0]['exit']==1,'INITIAL_FAILED_PRECHECK_MUST_BE_RETAINED')
native=next(r for r in records if r['label']=='strict-native-readiness29');need(native['exit']==1,'STRICT_NATIVE_GATE_MUST_STAY_FAILED')
quality=(OUT/'full-forced-quality29.stdout.log').read_text(encoding='utf8',errors='replace')+(OUT/'full-forced-quality29.stderr.log').read_text(encoding='utf8',errors='replace');quality=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',quality)
summaries=[line.strip() for line in quality.splitlines() if re.search(r'(Test Files|Tests\s+\d+ passed|Tasks:|Cached:)',line)]
need(any('6478 passed (6478)' in s for s in summaries) and any('499 passed (499)' in s for s in summaries) and any('24 passed (24)' in s for s in summaries) and any('7 passed (7)' in s for s in summaries) and any(re.search(r'Tasks:\s+8 successful, 8 total',s) for s in summaries) and any(re.search(r'Cached:\s+0 cached, 8 total',s) for s in summaries),'ACTUAL_QUALITY_COUNTS')
qualification=json.loads((OUT/'TOOLCHAIN_METADATA_QUALIFICATION29.json').read_text(encoding='utf8'));need(qualification['unchangedGuardCommand']['exit']==0 and qualification['identityMatchesSuccessfulFreshInstallGuard'] is True and qualification['waivers'] is False,'LATER_FULL_CANONICAL_TOOL_PROFILE_NOT_AUTHENTICATED')
prior=json.loads((OUT/'pinned-toolchain-before-install29.stdout.log').read_text(encoding='utf8'));during=json.loads((OUT/'original-toolchain-after-readonly-enumeration29.stdout.log').read_text(encoding='utf8'));need(prior==during,'CANONICAL_TOOL_IDENTITY_DIFFERENCE')
post=next(r for r in records if r['label']=='clean-toolchain-after29')
post_matches=False
if post['exit']==0:post_matches=json.loads((OUT/post['stdout']['path']).read_text(encoding='utf8'))==prior;need(post_matches,'FINAL_TOOL_PROFILE_CHANGED')
active=json.loads((OUT.parent/'runtime/ACTIVE_RUNTIME29.json').read_text(encoding='utf8'));receipt=pathlib.Path(active['receipt']).read_bytes();need(H(receipt)==active['receiptSHA256'],'RUNTIME_RECEIPT_IDENTITY');runtime=json.loads(receipt);directory=pathlib.Path(runtime['runtime']);need({p.name for p in directory.iterdir()}==set(runtime['files']) and len(runtime['files'])==35,'RUNTIME_FULL35_INVENTORY')
for name,row in runtime['files'].items():
    p=directory/name;a=p.lstat();b=p.read_bytes();c=p.read_bytes();d=p.lstat();need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and not getattr(a,'st_file_attributes',0)&1024 and b==c and len(b)==row['bytes'] and H(b)==row['sha256'] and (a.st_dev,a.st_ino,a.st_mode,a.st_nlink,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(d.st_dev,d.st_ino,d.st_mode,d.st_nlink,d.st_size,d.st_mtime_ns,d.st_ctime_ns),'RUNTIME_FULL35_MEMBER_CHANGED')
exports={}
for platform in ('ios','android'):
    folder=OUT/('unsigned-export-'+platform+'29');files={}
    for p in sorted(folder.rglob('*')):
        if p.is_file():
            b=p.read_bytes();files[p.relative_to(folder).as_posix()]=dict(bytes=len(b),sha256=H(b))
    need('metadata.json' in files and any(n.endswith('.hbc') for n in files),'UNSIGNED_EXPORT_BODY_MISSING')
    exports[platform]=dict(files=files,NODE_ENV='development',clearCache=True,unsigned=True,qualification='ACTUAL_CLEAR_CACHE_UNSIGNED_SOURCE_EXPORT_NOT_INSTALLED_NATIVE_DEVICE_OR_RELEASE_PROOF')
tap={label:[line for line in (OUT/(label+'.stdout.log')).read_text(encoding='utf8',errors='replace').splitlines() if re.match(r'# (tests|pass|fail|skipped) ',line)] for label in ('core05-original29','core05-focused29')}
subset_names=['confirmedDestructive28.test.ts','postDispatchCommit28.test.ts','privateKVCommitFence28.test.ts','detailActionSheet.campaign26.test.ts','manualDraftRecovery.campaign26.test.ts','manualCompare20.test.ts','manualCompare20Route.test.ts','progressEmptyLayout.c08b2.test.ts','progressSensitiveImageAuthority.c08a2.test.ts','progressDataAuthority.c08a1.test.ts','progressImageDemand.test.ts','progressRoutes.test.ts','compareAccessibility.test.ts','timeline.test.ts']
subsets={n:[line.strip() for line in quality.splitlines() if n in line] for n in subset_names}
for args,wanted in [(('rev-parse','HEAD'),HEAD),(('rev-parse','HEAD^{tree}'),TREE),(('status','--porcelain=v1','--untracked-files=all'), '')]:need(subprocess.check_output(['git',*args],cwd=ROOT).decode('utf8').strip()==wanted,'FINAL_SOURCE_IDENTITY_CHANGED')
value=dict(schema=1,status='ACTUAL_APP_CONTRACT_EXPORT_RESULTS_WITH_RETAINED_INITIAL_GUARD_FAILURE',sourceHead=HEAD,sourceTree=TREE,records=records,forcedTasks=dict(mobileTests=6478,mobileFiles=499,operatorTests=24,operatorFiles=7,tasks=8,cacheHits=0,actualSummaryRows=summaries,qualification='ONE_ACTUAL_EXPLICIT_FORCE_RUN;NO_FAILED_PRECHECK_RELABELING'),initialToolchainPrecheck=dict(exit=records[0]['exit'],state='FAIL_RETAINED_NPM_TOOL_CHANGED',isNotPassingBeforeSnapshot=True),toolchainQualification=qualification,completeCanonicalToolIdentityComparedToFreshInstall=True,finalPostcheck=dict(exit=post['exit'],canonicalIdentityMatches=post_matches),officialRuntime35AfterFinalCommands=dict(files=35,allBytesSHA256AndStableRegularIdentity=True,archiveSHA256=runtime['archive']['sha256'],receiptSHA256=H(receipt)),core05ActualTAP=tap,unchangedShelfF09SubsetsOfFullExecution=subsets,exports=exports,localDatabase=json.loads((OUT/'LOCAL_DOCKER_READINESS29.json').read_text(encoding='utf8'))['status'],nativeReadiness=dict(exit=1,state='FAIL_RETAINED_REQUIRED_NATIVE_WARNINGS'),aggregationQualification='External aggregation is necessary because the original controller summary attempted to parse the failed initial precheck empty output. All actual command records/logs and that controller failure remain unchanged; no app test was rerun.',qualification='ACTUAL_SUPPLIER_TECHNICAL_SOURCE_EXECUTION_NOT_BRAIN_SECURITY_DB_NATIVE_OR_RELEASE_ACCEPTANCE',observedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),acceptanceGranted=False,release='NO_GO')
(OUT/'CLEAN_SUBSTANTIVE_VALIDATION29_ACTUAL.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=value['status'],records=len(records),mobile=6478,operator=24,tasks=8,cacheHits=0,initialGuard=records[0]['exit'],finalGuard=post['exit'],native=1,exports={p:len(v['files']) for p,v in exports.items()})),flush=True)
