"""Read-only public npm metadata assay; no source/guard/file writes."""
import datetime,json,pathlib,os,stat
ROOT=pathlib.Path(r'C:\Program Files\nodejs\node_modules\npm');rows=[];counts={'directories':0,'files':0}
def walk(directory):
    a=directory.lstat();assert stat.S_ISDIR(a.st_mode) and not getattr(a,'st_file_attributes',0)&1024
    with os.scandir(directory) as entries:children=list(entries)
    b=directory.lstat();fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_birthtime_ns')
    difference={f:[getattr(a,f,None),getattr(b,f,None)] for f in fields if getattr(a,f,None)!=getattr(b,f,None)}
    if difference:rows.append({'directory':directory.relative_to(ROOT).as_posix(),'differences':difference})
    counts['directories']+=1
    for child in children:
        info=pathlib.Path(child.path).lstat();assert not getattr(info,'st_file_attributes',0)&1024 and not stat.S_ISLNK(info.st_mode)
        if stat.S_ISDIR(info.st_mode):walk(pathlib.Path(child.path))
        else:assert stat.S_ISREG(info.st_mode);counts['files']+=1
walk(ROOT)
result=dict(schema=1,status='READ_ONLY_PUBLIC_NPM_DIRECTORY_ENUMERATION_OBSERVED',counts=counts,metadataDifferences=rows,sourceEdits=False,toolEdits=False,guardEdits=False,waivers=False,qualification='Enumeration only; observed directory metadata is not an assertion of file content stability. Unchanged original guard must subsequently pass.',observedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(pathlib.Path(__file__).parent/'readonly-public-npm-enumeration29.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({'counts':counts,'changedDirectoryObservations':len(rows),'fields':sorted({f for r in rows for f in r['differences']})}))
