"""Observe an unchanged original guard; never alter require, output or return."""
import argparse,datetime,hashlib,json,os,pathlib,shutil,sys,time
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--node-prefix',required=True);p.add_argument('--output',required=True);a=p.parse_args()
root=pathlib.Path(a.root).resolve();prefix=pathlib.Path(a.node_prefix).resolve();npm=prefix/'node_modules/npm';output=pathlib.Path(a.output)
os.environ['PATH']=str(prefix)+os.pathsep+os.environ['PATH'];assert pathlib.Path(shutil.which('node')).resolve()==prefix/'node.exe'
sys.path.insert(0,str(root/'scripts/security22'));import toolchain
source=pathlib.Path(toolchain.__file__).read_bytes();assert hashlib.sha256(source).hexdigest()=='97f8c929054daaf09e67e90d2de67e49bf2ff25b33b99a8e4e5266683dc616ed'
events=[];observation_errors=0;numeric=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_birthtime_ns','st_file_attributes','st_reparse_tag')
def changes(x,y):return {n:[getattr(x,n,None),getattr(y,n,None)] for n in numeric if getattr(x,n,None)!=getattr(y,n,None)}
def trace(frame,event,arg):
    global observation_errors
    try:
        if frame.f_code.co_filename==toolchain.__file__ and event=='exception' and arg[1].args==('NPM_TOOL_CHANGED',):
            loc=frame.f_locals;row=dict(function=frame.f_code.co_name,line=frame.f_lineno,originalCode='NPM_TOOL_CHANGED')
            if frame.f_code.co_name=='walk' and 'directory' in loc and 'before' in loc:
                path=loc['directory'];row.update(publicRelativeDirectory=path.relative_to(npm).as_posix(),sameDomainPathChanges=changes(loc['before'],path.lstat()))
            elif frame.f_code.co_name=='_tool_read' and 'path' in loc and 'info' in loc:
                path=loc['path'];row.update(publicRelativeFile=path.relative_to(npm).as_posix(),sameDomainPathChanges=changes(loc['info'],path.lstat()))
                if 'opened' in loc:row['crossDomainObservedDifferences']=changes(loc['info'],loc['opened'])
                if 'source' in loc:
                    try:row['sameDomainHandleChanges']=changes(loc['opened'],os.fstat(loc['source'].fileno()))
                    except (OSError,ValueError):row['sameDomainHandleChanges']='HANDLE_ALREADY_CLOSED_AT_OBSERVATION'
            events.append(row)
    except BaseException:observation_errors+=1
    return trace
start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();sys.settrace(trace)
try:identity=toolchain.identity(root);exitcode=0;failure=None
except BaseException as error:identity=None;exitcode=1;failure=dict(type=type(error).__name__,code=error.args[0] if len(error.args)==1 and isinstance(error.args[0],str) and error.args[0].replace('_','').isalnum() else 'UNCLASSIFIED')
finally:sys.settrace(None)
assert pathlib.Path(toolchain.__file__).read_bytes()==source
result=dict(schema=1,status='UNCHANGED_ORIGINAL_TOOL_GUARD_PASS' if exitcode==0 else 'UNCHANGED_ORIGINAL_TOOL_GUARD_FAILURE_RETAINED',exit=exitcode,failure=failure,observedEvents=events,observationErrors=observation_errors,identity=identity,originalToolchainSHA256=hashlib.sha256(source).hexdigest(),sourceEdits=False,guardEdits=False,requireWrapped=False,waivers=False,readOnly=True,startedUTC=started,completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsedMilliseconds=round((time.monotonic()-start)*1000),qualification='Only original execution and bounded public npm relative names/numeric metadata observations; no guarded condition changed')
with output.open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status=result['status'],exit=exitcode,failure=failure,events=events,observationErrors=observation_errors)),flush=True);raise SystemExit(exitcode)
