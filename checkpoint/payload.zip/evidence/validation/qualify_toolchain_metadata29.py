"""Retain original guard failure and record read-only directory observations."""
import datetime,hashlib,json,os,pathlib,stat,subprocess,sys,time
OUT=pathlib.Path(__file__).parent;ROOT=OUT.parent.parent/'c29-src';TOOLS=json.loads((OUT.parent/'runtime/ACTIVE_TOOLCHAIN29.json').read_text());NPM=pathlib.Path(TOOLS['prefix'])/'node_modules/npm'
sys.path.insert(0,str(ROOT/'scripts/security22'));import toolchain
rows=[]
def trace(frame,event,arg):
    if frame.f_code.co_filename==toolchain.__file__ and frame.f_code.co_name=='walk' and event=='exception' and arg[1].args==('NPM_TOOL_CHANGED',) and 'before' in frame.f_locals:
        directory=frame.f_locals['directory'];a=frame.f_locals['before'];b=directory.lstat();fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_birthtime_ns');rows.append(dict(relativeDirectory=directory.relative_to(NPM).as_posix(),differences={n:[getattr(a,n,None),getattr(b,n,None)] for n in fields if getattr(a,n,None)!=getattr(b,n,None)}))
    return trace
original=os.environ.get('PATH','');os.environ['PATH']=TOOLS['prefix']+os.pathsep+original;started=datetime.datetime.now(datetime.timezone.utc).isoformat();sys.settrace(trace)
try:diagnostic=toolchain.identity(ROOT);failure=None
except BaseException as e:diagnostic=None;failure=dict(type=type(e).__name__,code=e.args[0] if len(e.args)==1 and isinstance(e.args[0],str) else 'UNCLASSIFIED')
finally:sys.settrace(None)
observed=[];count=0
for directory,dirs,files in os.walk(NPM):
    p=pathlib.Path(directory);a=p.lstat();list(os.scandir(p));b=p.lstat();count+=1
    fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_birthtime_ns');delta={n:[getattr(a,n,None),getattr(b,n,None)] for n in fields if getattr(a,n,None)!=getattr(b,n,None)}
    if delta:observed.append(dict(directory=p.relative_to(NPM).as_posix(),differences=delta))
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','GITHUB_','PYTHON','TURBO_','NPM_')) and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')};env.update(PATH=TOOLS['prefix']+os.pathsep+original,CI='1',NO_COLOR='1',PYTHONDONTWRITEBYTECODE='1')
code="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))";command=[TOOLS['python'],'-I','-B','-c',code];begin=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
(OUT/'original-toolchain-after-readonly-enumeration29.stdout.log').write_bytes(p.stdout);(OUT/'original-toolchain-after-readonly-enumeration29.stderr.log').write_bytes(p.stderr)
after=json.loads(p.stdout) if p.returncode==0 else None;prior=json.loads((OUT/'pinned-toolchain-before-install29.stdout.log').read_text())
receipt=dict(schema=1,status='ORIGINAL_GUARD_PASS_AFTER_READ_ONLY_ENUMERATION' if p.returncode==0 else 'ORIGINAL_GUARD_FAILURE_RETAINED',startedUTC=started,completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),traceDiagnostic=dict(originalFailure=failure,observations=rows,guardReturnUnchanged=True),readOnlyEnumeration=dict(directories=count,observations=observed),unchangedGuardCommand=dict(argv=command,exit=p.returncode,elapsedMilliseconds=round((time.monotonic()-begin)*1000),stdoutSHA256=hashlib.sha256(p.stdout).hexdigest(),stderrSHA256=hashlib.sha256(p.stderr).hexdigest()),identityMatchesSuccessfulFreshInstallGuard=after==prior,toolBytesOrSourceChanges=False,waivers=False,qualification='The initial actual guard failure remains failure. A subsequent unchanged guard pass and complete pinned byte model do not erase it. Directory metadata observations are not proof of universal stability.',acceptanceGranted=False,release='NO_GO')
(OUT/'TOOLCHAIN_METADATA_QUALIFICATION29.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=receipt['status'],traceFailure=failure,traceObservedChanges=[r for r in rows if r['differences']],exit=p.returncode,identityMatchesFreshInstall=after==prior)),flush=True)
