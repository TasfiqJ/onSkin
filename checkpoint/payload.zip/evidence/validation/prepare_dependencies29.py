SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Campaign29 fresh normal install; external receipts, no tracked writes."""
import datetime,hashlib,json,os,pathlib,subprocess,time,uuid
ROOT=pathlib.Path(r'<LOCAL_HOME>\Documents\ChatGPT\MasterV2Code\c29-src')
OUT=pathlib.Path(__file__).parent
TOOLS=json.loads((OUT.parent/'runtime/ACTIVE_TOOLCHAIN29.json').read_text(encoding='utf8'))
PYTHON=TOOLS['python'];NODE=TOOLS['node'];NPM=TOOLS['npmCLI']
ENV=os.environ.copy();ENV['PATH']=TOOLS['prefix']+os.pathsep+ENV['PATH']
H=lambda b:hashlib.sha256(b).hexdigest()
def snapshot():
    def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT).decode('utf8').strip()
    return dict(head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),status=git('status','--porcelain=v1','--untracked-files=all'))
records=[]
def run(label,argv,timeout=900):
    before=snapshot();started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
    stdout=OUT/(label+'.stdout.log');stderr=OUT/(label+'.stderr.log')
    with stdout.open('xb') as o,stderr.open('xb') as e:
        p=subprocess.Popen(argv,cwd=ROOT,env=ENV,stdout=o,stderr=e,creationflags=subprocess.CREATE_NO_WINDOW)
        try:code=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30);code=p.wait(timeout=30)
            records.append(dict(label=label,timeout=True,exit=code));raise
    record=dict(label=label,argv=argv,cwd=str(ROOT),startedUTC=started,elapsedMilliseconds=round((time.monotonic()-begin)*1000),exit=code,sourceBefore=before,sourceAfter=snapshot(),stdout=dict(path=stdout.name,bytes=stdout.stat().st_size,sha256=H(stdout.read_bytes())),stderr=dict(path=stderr.name,bytes=stderr.stat().st_size,sha256=H(stderr.read_bytes())))
    records.append(record);(OUT/'DEPENDENCY_PREPARATION29.inprogress.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(label=label,exit=code,elapsedMilliseconds=record['elapsedMilliseconds'])),flush=True)
    if code:raise ValueError(label+'_FAILED')
    return record
identity_code="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
run('pinned-toolchain-before-install29',[PYTHON,'-I','-B','-c',identity_code],60)
cache=OUT/('fresh-npm-cache29-'+uuid.uuid4().hex[:10]);cache.mkdir(exist_ok=False)
config=OUT/'empty-project-userconfig';config.write_bytes(b'')
run('normal-fresh-npm-ci29',[NODE,NPM,'ci','--cache',str(cache),'--userconfig',str(config),'--no-audit','--no-fund'],900)
run('mandatory-postinstall-check29',[NODE,'scripts/postinstall.mjs','--check'],60)
run('toolchain-after-install29',[PYTHON,'-I','-B','-c',identity_code],60)
before=json.loads((OUT/'pinned-toolchain-before-install29.stdout.log').read_text(encoding='utf8'));after=json.loads((OUT/'toolchain-after-install29.stdout.log').read_text(encoding='utf8'))
assert before==after
assert before['tools']['node']['version']=='v22.21.0' and before['tools']['npm']['version']=='11.20.0' and before['tools']['npm']['installationModelSHA256']=='c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9'
receipt=dict(schema=1,status='FRESH_NORMAL_NPM_CI_MANDATORY_HOOKS_AND_UNCHANGED_TOOLS_PASS',records=records,freshExternalCache=str(cache),cacheWasEmpty=True,ignoreScriptsUsed=False,toolchainGuardChanged=False,toolIdentityBeforeAfterEqual=True,python=PYTHON,acceptanceGranted=False,release='NO_GO')
(OUT/'DEPENDENCY_PREPARATION29.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8');print(receipt['status'],flush=True)
