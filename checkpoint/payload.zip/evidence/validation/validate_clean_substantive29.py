SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""Execute once only after root supplies the clean substantive source identity."""
import argparse,datetime,hashlib,json,os,pathlib,re,stat,subprocess,time
parser=argparse.ArgumentParser();parser.add_argument('--expected-head',required=True);parser.add_argument('--expected-tree',required=True);args=parser.parse_args()
ROOT=pathlib.Path(r'<LOCAL_HOME>\Documents\ChatGPT\MasterV2Code\c29-src');OUT=pathlib.Path(__file__).parent
TOOLS=json.loads((OUT.parent/'runtime/ACTIVE_TOOLCHAIN29.json').read_text(encoding='utf8'));NODE=TOOLS['node'];NPM=TOOLS['npmCLI'];PYTHON=TOOLS['python']
BASE='bace116586d58ed955f0a024ca96ae9f4ad9286d';H=lambda b:hashlib.sha256(b).hexdigest()
ENV={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','GITHUB_','PYTHON','TURBO_','NPM_')) and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')}
ENV.update(PATH=TOOLS['prefix']+os.pathsep+ENV['PATH'],CI='1',NO_COLOR='1',TURBO_TELEMETRY_DISABLED='1',EXPO_NO_TELEMETRY='1',PYTHONDONTWRITEBYTECODE='1')
def need(value,code):
    if not value:raise ValueError(code)
def git(*a):
    p=subprocess.run(['git','--no-replace-objects','-c','core.hooksPath=',*a],cwd=ROOT,env=ENV,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW);need(p.returncode==0,'VALIDATION_GIT_COMMAND');return p.stdout
def state():
    value=dict(head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip(),status=git('status','--porcelain=v1','--untracked-files=all','-z').decode())
    need(value['head']==args.expected_head and value['tree']==args.expected_tree and not value['status'],'CLEAN_SUBSTANTIVE_IDENTITY_REQUIRED');return value
def runtime_members():
    active=json.loads((OUT.parent/'runtime/ACTIVE_RUNTIME29.json').read_text(encoding='utf8'));receipt_path=pathlib.Path(active['receipt']);raw=receipt_path.read_bytes();need(H(raw)==active['receiptSHA256'],'RUNTIME_RECEIPT_IDENTITY');receipt=json.loads(raw);directory=pathlib.Path(receipt['runtime'])
    need({p.name for p in directory.iterdir()}==set(receipt['files']) and len(receipt['files'])==35,'RUNTIME_35_INVENTORY')
    for name,expected in receipt['files'].items():
        p=directory/name;before=p.lstat();a=p.read_bytes();b=p.read_bytes();after=p.lstat()
        need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and not getattr(before,'st_file_attributes',0)&1024 and a==b and len(a)==expected['bytes'] and H(a)==expected['sha256'] and (before.st_dev,before.st_ino,before.st_mode,before.st_nlink,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_dev,after.st_ino,after.st_mode,after.st_nlink,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'RUNTIME_35_MEMBER_IDENTITY')
    return dict(files=35,allBytesSHA256AndStableIdentity=True,officialArchiveSHA256=receipt['archive']['sha256'],receiptSHA256=H(raw))
records=[]
def run(label,argv,cwd=ROOT,expected_exit=0,timeout=900,environment=None):
    before=state();start=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat();o=OUT/(label+'.stdout.log');e=OUT/(label+'.stderr.log');env=ENV.copy();env.update(environment or {})
    with o.open('xb') as out,e.open('xb') as err:
        child=subprocess.Popen(argv,cwd=cwd,env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        try:exitcode=child.wait(timeout=timeout);timedout=False
        except subprocess.TimeoutExpired:
            subprocess.run(['taskkill','/PID',str(child.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30);exitcode=child.wait(timeout=30);timedout=True
    after=state();row=dict(label=label,argv=argv,cwd=str(cwd),environmentOverrides=environment or {},startedUTC=started,elapsedMilliseconds=round((time.monotonic()-start)*1000),exit=exitcode,timeout=timedout,expectedExitForRetainedGate=expected_exit,sourceBefore=before,sourceAfter=after,stdout=dict(path=o.name,bytes=o.stat().st_size,sha256=H(o.read_bytes())),stderr=dict(path=e.name,bytes=e.stat().st_size,sha256=H(e.read_bytes())))
    records.append(row);(OUT/'CLEAN_SUBSTANTIVE_VALIDATION29.inprogress.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(label=label,exit=exitcode,elapsedMilliseconds=row['elapsedMilliseconds'],sourcePreserved=before==after)),flush=True)
    if exitcode!=expected_exit or timedout:print(json.dumps(dict(label=label,status='ACTUAL_FAILURE_RETAINED_REQUIRES_REVIEW')),flush=True)
    return row
state();need(not (OUT/'CLEAN_SUBSTANTIVE_VALIDATION29.json').exists(),'FINAL_VALIDATION_ALREADY_RECORDED');runtime_before=runtime_members()
protected=['apps/mobile','apps/catalog-operator-console','scripts/core05','.github/workflows/security.yml','supabase']
need(not git('diff','--raw',BASE,'HEAD','--',*protected),'PROTECTED_SOURCE_DELTA')
identity="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
run('clean-toolchain-before29',[PYTHON,'-I','-B','-c',identity],timeout=90)
full=run('full-forced-quality29',[NODE,'node_modules/turbo/bin/turbo','run','test','typecheck','lint','--force','--concurrency=1'],timeout=1200)
text=(OUT/'full-forced-quality29.stdout.log').read_text(encoding='utf8',errors='replace')+(OUT/'full-forced-quality29.stderr.log').read_text(encoding='utf8',errors='replace');plain=re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',text)
task_rows=[line.strip() for line in plain.splitlines() if re.search(r'(?:Tasks:|Cached:|Test Files|Tests\s+\d+ passed)',line)]
focused_names=['confirmedDestructive28.test.ts','postDispatchCommit28.test.ts','privateKVCommitFence28.test.ts','detailActionSheet.campaign26.test.ts','manualDraftRecovery.campaign26.test.ts','manualCompare20.test.ts','manualCompare20Route.test.ts','progressEmptyLayout.c08b2.test.ts','progressSensitiveImageAuthority.c08a2.test.ts','progressDataAuthority.c08a1.test.ts','progressImageDemand.test.ts','progressRoutes.test.ts','compareAccessibility.test.ts','timeline.test.ts']
included=[dict(name=name,actualLogRows=[line.strip() for line in plain.splitlines() if name in line]) for name in focused_names]
run('clean-postinstall-check29',[NODE,'scripts/postinstall.mjs','--check'],timeout=90)
run('core05-original29',[NODE,'--test','scripts/core05/adherence-source-contract.test.mjs'],timeout=120)
run('core05-focused29',[NODE,'--test','scripts/core05/adherence-source-contract28.test.mjs'],timeout=180)
run('launch-contracts29',[NODE,NPM,'run','launch:contract:verify'],timeout=900)
run('launch-baseline-check29',[NODE,'scripts/launch/validate-execution-baseline.mjs'],timeout=120)
run('launch-baseline-smoke29',[NODE,'scripts/launch/execution-baseline-smoke.mjs'],timeout=120)
run('native-privacy29',[NODE,'scripts/phase9/ios-privacy-source-audit.mjs','--check','--strict'],timeout=120)
run('advisory-patch-controls29',[NODE,'--test','scripts/security24/advisory-behavior.test.mjs','scripts/security24/patch-tooling.test.mjs'],timeout=180)
run('strict-native-readiness29',[NODE,'scripts/phase5/check-native-config.mjs','--strict'],expected_exit=1,timeout=120)
exports={}
for platform in ('ios','android'):
    destination=OUT/('unsigned-export-'+platform+'29');need(not destination.exists(),'EXPORT_FRESH_DIRECTORY_REQUIRED')
    row=run('unsigned-'+platform+'29',[NODE,'../../node_modules/expo/bin/cli','export','--platform',platform,'--clear','--output-dir',str(destination)],cwd=ROOT/'apps/mobile',timeout=900,environment=dict(NODE_ENV='development'))
    files={}
    if destination.exists():
        for p in sorted(destination.rglob('*')):
            if p.is_file():
                b=p.read_bytes();files[p.relative_to(destination).as_posix()]=dict(bytes=len(b),sha256=H(b))
    exports[platform]=dict(exit=row['exit'],files=files,qualification='ACTUAL_CLEAR_CACHE_UNSIGNED_DEVELOPMENT_SOURCE_EXPORT_NOT_INSTALLED_NATIVE_APPLE_OR_RELEASE_PROOF')
run('clean-toolchain-after29',[PYTHON,'-I','-B','-c',identity],timeout=90)
before=json.loads((OUT/'clean-toolchain-before29.stdout.log').read_text(encoding='utf8'));after=json.loads((OUT/'clean-toolchain-after29.stdout.log').read_text(encoding='utf8'));need(before==after,'TOOLCHAIN_IDENTITY_CHANGED')
tap={label:[line for line in (OUT/(label+'.stdout.log')).read_text(encoding='utf8',errors='replace').splitlines() if re.match(r'# (tests|pass|fail|skipped) ',line)] for label in ('core05-original29','core05-focused29')}
value=dict(schema=1,status='CLEAN_SUBSTANTIVE_TECHNICAL_EXECUTIONS_COMPLETE_REVIEW_REQUIRED',source=state(),records=records,forcedTasks=dict(actualCommandForced=True,cacheProvenance='Fresh normal npm installation/external empty cache; actual full Turbo run used --force; raw observed summaries below',actualSummaryRows=task_rows),unchangedProtectedSourcesFromPR32=protected,unchangedShelfF09IncludedInFullRun=dict(qualification='IDENTIFIED_SUBSETS_OF_ACTUAL_FULL_RUN_NOT_ADDITIONAL_EXECUTIONS',observedRows=included),core05=dict(expectedOriginalFromUnchangedSource=36,expectedFocusedIncludingOriginal36AndNew33=69,expectedUniqueTotal=69,actualTAPSummaries=tap,earlierDuplicatedTotal105NotClaimedUnique=True),exports=exports,localDatabase=json.loads((OUT/'LOCAL_DOCKER_READINESS29.json').read_text(encoding='utf8'))['status'],toolchainBeforeAfterIdentical=True,runtime35MembersBefore=runtime_before,runtime35MembersAfter=runtime_members(),qualification='ACTUAL_CAMPAIGN29_TECHNICAL_SOURCE_EXECUTION_NOT_BRAIN_OR_QUALIFIED_NATIVE_DB_SECURITY_OR_RELEASE_ACCEPTANCE',acceptanceGranted=False,release='NO_GO')
(OUT/'CLEAN_SUBSTANTIVE_VALIDATION29.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf8');print(json.dumps(dict(status=value['status'],actualExits={r['label']:r['exit'] for r in records},actualSummaryRows=task_rows)),flush=True)
