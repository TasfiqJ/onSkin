SANITIZED_LOCAL_HOME_PREFIX_DERIVATIVE; ORIGINAL_BYTES_HASHED_IN_DERIVATION_INDEX; OTHER_OBSERVED_VALUES_UNCHANGED
"""One read-only prefix enumeration, then two consecutive unchanged guards."""
import datetime,hashlib,json,os,pathlib,stat,subprocess,time
OUT=pathlib.Path(__file__).parent.parent/'governance';ROOT=pathlib.Path(r'<LOCAL_HOME>\AppData\Local\Temp\release29-historical-bs0lv_9v\release24')
TOOLS=json.loads((OUT.parent/'runtime/ACTIVE_TOOLCHAIN29.json').read_text());PREFIX=pathlib.Path(TOOLS['prefix']);NPM=PREFIX/'node_modules/npm';H=lambda b:hashlib.sha256(b).hexdigest()
rows=[];counts={'directories':0,'files':0}
def enumerate_only(directory):
    before=directory.lstat();assert stat.S_ISDIR(before.st_mode) and not getattr(before,'st_file_attributes',0)&1024
    with os.scandir(directory) as stream:entries=list(stream)
    after=directory.lstat();fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns','st_birthtime_ns');delta={n:[getattr(before,n,None),getattr(after,n,None)] for n in fields if getattr(before,n,None)!=getattr(after,n,None)}
    if delta:rows.append(dict(publicRelativeDirectory=directory.relative_to(NPM).as_posix(),numericDifferences=delta))
    counts['directories']+=1
    for entry in entries:
        p=pathlib.Path(entry.path);i=p.lstat();assert not stat.S_ISLNK(i.st_mode) and not getattr(i,'st_file_attributes',0)&1024
        if stat.S_ISDIR(i.st_mode):enumerate_only(p)
        else:assert stat.S_ISREG(i.st_mode) and i.st_nlink==1;counts['files']+=1
started=datetime.datetime.now(datetime.timezone.utc).isoformat();enumerate_only(NPM)
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_','GITHUB_','PYTHON','NPM_')) and k.upper() not in ('NODE_OPTIONS','NODE_PATH','NODE_AUTH_TOKEN')};env['PATH']=str(PREFIX)+os.pathsep+env['PATH'];env['GIT_TERMINAL_PROMPT']='0'
code="import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))";gold=json.loads((OUT.parent/'validation/pinned-toolchain-before-install29.stdout.log').read_text());records=[]
for attempt in (1,2):
    command=[TOOLS['python'],'-I','-B','-c',code];begin=time.monotonic();p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    for name,b in [('stdout',p.stdout),('stderr',p.stderr)]:
        with (OUT/('original24-after-enumeration-attempt'+str(attempt)+'.'+name+'.log')).open('xb') as f:f.write(b)
    value=json.loads(p.stdout) if p.returncode==0 else None
    records.append(dict(attempt=attempt,argv=command,exit=p.returncode,elapsedMilliseconds=round((time.monotonic()-begin)*1000),stdoutSHA256=H(p.stdout),stderrSHA256=H(p.stderr),canonicalWholeIdentityMatchesFreshInstall=value==gold,canonicalAllToolsMatchFreshInstall=value is not None and value['tools']==gold['tools']))
assert H((ROOT/'scripts/security22/toolchain.py').read_bytes())=='97f8c929054daaf09e67e90d2de67e49bf2ff25b33b99a8e4e5266683dc616ed'
result=dict(schema=1,status='TWO_CONSECUTIVE_UNCHANGED_ORIGINAL24_GUARDS_PASS' if all(r['exit']==0 and r['canonicalAllToolsMatchFreshInstall'] for r in records) else 'ORIGINAL_GUARD_FAILURE_RETAINED',startedUTC=started,completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),singleReadOnlyEnumeration=dict(counts=counts,observedNumericDifferences=rows),records=records,originalGuardSHA256='97f8c929054daaf09e67e90d2de67e49bf2ff25b33b99a8e4e5266683dc616ed',guardChanges=False,sourceChanges=False,fileWritesInsidePrefix=False,waivers=False,qualification='Original failures stay FAIL; this assay observes a subsequent unchanged guard after metadata-only enumeration and never waives guarded comparisons',acceptanceGranted=False,release='NO_GO')
with (OUT/'ORIGINAL24_TWO_GUARD_ASSAY29.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status=result['status'],directories=counts['directories'],files=counts['files'],metadataChangeObservations=len(rows),records=records)),flush=True)
