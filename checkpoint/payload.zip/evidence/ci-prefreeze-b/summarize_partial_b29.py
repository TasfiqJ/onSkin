import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
PUBLIC = ROOT / 'linux-public-verified29b'
def read(name):
    return json.loads((PUBLIC / name).read_text())
def terminal(name):
    return [json.loads(s) for s in (PUBLIC / name).read_text().splitlines() if s.startswith('{') and 'positiveControls' in json.loads(s)]

artifact = read('PROVIDER_ARTIFACT_RECEIPT29.json')
history = read('security29-historical-receipt.json')
candidate = read('security22-public.json')
source = read('security29-current-source.json')
head = '2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
tree = '015e185b35be44301e6d9a4be0c28d040150aec8'
assert candidate['source']['head'] == head and candidate['source']['tree'] == tree
assert history['status'] == 'PASS' and len(history['records']) == 5
assert candidate['candidateReady'] is False and candidate['executionComplete'] is True
for record in history['records']:
    assert record['consumerResult']['exit'] == 0 and record['sourceResult']['exit'] == 0
    assert record['installation']['npmCiExit'] == 0 and record['installation']['postinstallCheckExit'] == 0
    assert record['installation']['mandatoryHooks'] and record['installation']['nativePinsCount'] == 10
    assert record['checkoutBefore'] == record['checkoutAfter']
    assert record['toolIdentityBefore'] == record['toolIdentityAfter']
result = {
    'schema':1, 'status':'PARTIAL_B_PREFREEZE_LINUX_AND_COMPLETED_JOB_EVIDENCE',
    'sourceHead':head, 'sourceTree':tree,
    'qualification':'PREFREEZE_B_ONLY_NOT_FINAL_TAIL_CI;WINDOWS_AND_CANONICAL_DB_NOT_YET_COMPLETE_AT_THIS_OBSERVATION',
    'candidateRun':41101933822, 'linuxJob':124220491245,
    'linuxConclusion':'failure', 'linuxActualPublicExit':1,
    'candidateReady':False, 'executionComplete':True,
    'unresolvedRequired':candidate['unresolvedRequired'],
    'providerArchive':{k:artifact[k]for k in ['status','providerArchiveBytes','providerArchiveSHA256','manifestDeclarations','nonAllowlistedBodiesExported']},
    'currentReader':terminal('security29-reader-controls.jsonl'),
    'replayControls':terminal('security29-replay-controls.jsonl'),
    'sourceControls':terminal('security29-source-controls.jsonl'),
    'historicalRecords':history['records'],
    'source29':source['source29'],
    'quality':{'completedSuccessJobs':[124220491240,124220491404,124220491420,124224101812,124224101895],
               'appTestCounts':{'mobileTests':6478,'mobileFiles':499,'operatorTests':24,'operatorFiles':7},
               'actualTypecheckLintTestCommands':'PLAIN_NPM_RUN', 'forceFlag':False,
               'cacheReceipts':['0/3 typecheck','0/3 lint','0/2 test'],
               'canonicalDBAtObservation':'IN_PROGRESS_NOT_CLAIMED_COMPLETE',
               'exports':'IOS_ANDROID_CLEAR_UNSIGNED_SOURCE_EXPORT_ONLY_NOT_DEVICE_OR_SIGNED_RELEASE'},
    'launch':{'run':41101934030,'job':124220491389,'conclusion':'success','appTests':'6478/499_MOBILE_24/7_OPERATOR','cache':'0/3_0/3_0/2'},
    'originalSecurity':{'run':41101934059,'conclusion':'failure','scope':'METADATA_ONLY_NO_LOG_FINDING_ANNOTATION_OR_ARTIFACT_ACCESSED'},
    'release':'NO_GO','acceptanceGranted':False,
}
destination=ROOT/'PARTIAL_B_COMPLETED_FACTS29.json'
destination.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'sha256':hashlib.sha256(destination.read_bytes()).hexdigest()}))
