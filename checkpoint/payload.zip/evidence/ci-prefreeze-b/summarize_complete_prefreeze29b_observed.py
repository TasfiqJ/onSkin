import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
LOCAL = ROOT.parents[1] / 'c29-local-ci-logs' / 'prefreeze'
HEAD = '2f42fa45f1f6e7d776ede548da20edc10d3c6bb2'
TREE = '015e185b35be44301e6d9a4be0c28d040150aec8'

def read(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))

def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]

result = {
    'schema': 1,
    'status': 'COMPLETE_PREFREEZE_B_OBSERVATION_WITH_WINDOWS_NEW_REPLAY_CONTROL_FAILURE',
    'sourceHead': HEAD,
    'sourceTree': TREE,
    'qualification': 'LIVE_COMPLETED_PREFREEZE_CI_ONLY_NOT_FINAL_TAIL_CI_OR_SECURITY_ACCEPTANCE',
    'release': 'NO_GO',
    'acceptanceGranted': False,
    'originalSecurity': {'scope': 'METADATA_ONLY_NO_LOG_FINDING_ANNOTATION_OR_ARTIFACT_ACCESSED'},
    'runs': [],
    'platforms': {},
    'localLogs': [],
}
for rid in [41101933822, 41101933967, 41101934030, 41101934059]:
    run = read(f'run-{rid}-complete.json')
    assert run['head_sha'] == HEAD and run['status'] == 'completed'
    result['runs'].append({k: run.get(k) for k in ['id', 'name', 'status', 'conclusion', 'head_sha', 'html_url', 'updated_at']})

for platform in ['linux', 'windows']:
    directory = ROOT / f'{platform}-public-verified29b'
    receipt = json.loads((directory / 'PROVIDER_ARTIFACT_RECEIPT29.json').read_text())
    public = json.loads((directory / 'security22-public.json').read_text())
    source = json.loads((directory / 'security29-current-source.json').read_text())
    history = json.loads((directory / 'security29-historical-receipt.json').read_text())
    assert receipt['status'] == 'AUTHENTIC_PROVIDER_BYTES_AND_PUBLIC_RECEIPTS_VERIFIED'
    assert not receipt['nonAllowlistedBodiesExported']
    assert public['source']['head'] == HEAD and public['source']['tree'] == TREE
    assert public['candidateReady'] is False and public['executionComplete'] is True
    assert source['source29']['checkoutHead'] == HEAD and source['source29']['checkoutTree'] == TREE
    assert history['status'] == 'PASS' and len(history['records']) == 5
    historical = []
    for r in history['records']:
        assert r['consumerResult']['status'] == 'PASS' and r['consumerResult']['exit'] == 0
        assert r['sourceResult']['valid'] and r['sourceResult']['exit'] == 0
        assert r['checkoutBefore'] == r['checkoutAfter'] and r['toolIdentityBefore'] == r['toolIdentityAfter']
        assert r['installation']['npmCiExit'] == 0 and r['installation']['postinstallCheckExit'] == 0
        assert r['installation']['mandatoryHooks'] and r['installation']['nativePinsCount'] == 10
        historical.append({
            'release': r['release'], 'head': r['head'], 'tree': r['tree'],
            'consumerSHA256': r['consumer']['sha256'], 'checkerSHA256': r['checker']['sha256'],
            'consumerResult': r['consumerResult'], 'sourceResult': r['sourceResult'],
            'installation': r['installation'], 'checkoutBeforeAfterEqual': True,
            'toolIdentityBeforeAfterEqual': True,
        })
    frozen = [{k: r.get(k) for k in ['releaseNumber', 'status', 'observedExit', 'observedPython', 'failedCase', 'exceptionType', 'lastCompletedCase', 'historicalSuppressedException', 'qualification', 'originalAssertionsUnchanged']} for r in rows(directory / 'security29-frozen-reader-diagnostics.jsonl')]
    controls = {}
    for filename in ['security27-hosted-reader.jsonl', 'security27-python312-reader.jsonl', 'security28-reader.jsonl', 'security29-reader-controls.jsonl', 'security29-replay-controls.jsonl', 'security29-source-controls.jsonl']:
        controls[filename] = [{k: r[k] for k in ['status', 'code', 'positiveControls', 'refusals', 'notRun', 'observedPython', 'platform', 'qualification', 'claimBoundaryObservations', 'inheritedFunctions'] if k in r} for r in rows(directory / filename) if 'positiveControls' in r or r.get('status') == 'FAIL']
    tap = (directory / 'security28-core05.tap').read_text()
    core = {key: int(re.search(r'^# ' + key + r' (\d+)$', tap, re.M).group(1)) for key in ['tests', 'pass', 'fail', 'skipped']}
    logid = 124220491245 if platform == 'linux' else 124220491072
    log = (LOCAL / f'job-{logid}.decoded-utf8.log').read_text()
    components = public['components']
    result['platforms'][platform] = {
        'providerArchiveBytes': receipt['providerArchiveBytes'], 'providerArchiveSHA256': receipt['providerArchiveSHA256'],
        'providerIntegrity': receipt['status'], 'manifestDeclarations': receipt['manifestDeclarations'],
        'allowlistedExports': len(receipt['exported']), 'nonAllowlistedBodiesExported': False,
        'frozenReaderBaselines': frozen, 'currentControls': controls, 'core05': core,
        'historicalRecords': historical, 'source29': source['source29'],
        'publicCandidate': {
            'candidateReady': False, 'executionComplete': True, 'actualExit': 1,
            'jobExit1Markers': log.count('Process completed with exit code 1.'),
            'publicActualExit': 1,
            'unresolvedRequired': public['unresolvedRequired'], 'release': public['release'],
            'nodeVersion': components['dependencies']['nodeVersion'], 'npmVersion': components['dependencies']['npmVersion'],
            'npmAdvisoryCounts': components['dependencies']['npm']['counts'],
            'osvAdvisoryPackages': len(components['dependencies']['osv']['findings']),
            'workingBytes': components['working_bytes'],
            'archiveCoverageState': components['archive_coverage']['state'],
            'binaryContentScan': components['archive_coverage']['binaryContentScan'],
            'originalSourceContract': {k: components['original_source_contract'].get(k) for k in ['classification', 'exit', 'reason', 'state']},
            'protectedSecretHistoryExecuted': components['protected_secret_history']['executed'],
            'protectedStaticAnalysisExecuted': components['protected_static_analysis']['executed'],
            'qualifiedCustodyExecuted': components['qualified_custody']['executed'],
        },
    }

for job in [124220491245,124220491072,124220491346,124220491404,124220491420,124220491240,124224101812,124224101895,124220491389]:
    file = LOCAL / f'job-{job}.decoded-utf8.log'
    body = file.read_bytes()
    result['localLogs'].append({'job':job,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'qualification':'COMPLETE_CONNECTOR_DECODED_UTF8_BODY_NOT_PROVIDER_LOG_ARCHIVE','rawBodyRetainedLocalOutsideReturn':True})

db = (LOCAL / 'job-124220491346.decoded-utf8.log').read_text()
for proof in ['reset 1 of 2 (migrations plus seed): PASS', 'reset 2 of 2 (repeatability): PASS', 'migration history: PASS (97, latest 20261010000081)', 'run structural pgTAP tests: PASS', 'lint migrated public schema: PASS', 'migration/schema drift: PASS (empty)', 'run CAT-08 two-connection revocation rehearsal: PASS', 'full local verification: PASS']:
    assert proof in db, 'MISSING_FRESH_B_DB_PROOF:' + proof
types = re.search(r'temporary types: PASS \((\d+) lines, sha256 ([0-9a-f]{64})\)', db)
assert types, 'MISSING_FRESH_B_TYPES_PROOF'
result['hostedCredentialFreeDB'] = {
    'job': 124220491346, 'conclusion': 'success',
    'actualCommand': 'node scripts/phase2/local-supabase-reset.mjs --verify',
    'bothResetsPassed': all(f'reset {i} of 2' in db and re.search(r'reset ' + str(i) + r' of 2[^\n]*: PASS', db) for i in [1,2]),
    'migrationHistory': '97; latest 20261010000081',
    'structuralPgTAP': 'PASS; individual successful SQL output intentionally not echoed by unchanged wrapper',
    'schemaLint': 'PASS', 'migrationSchemaDrift': 'PASS_EMPTY',
    'cat08TwoConnectionRevocation': 'PASS',
    'generatedPublicTypes': {'lines': int(types[1]), 'sha256': types[2]},
    'sourceContractTests': [63,171],
    'qualification':'DISPOSABLE_CREDENTIAL_FREE_HOSTED_LOCAL_STACK_NOT_PRODUCTION_DB_ADMISSION',
}
result['appAndLaunchQuality'] = {
    'mobile': {'tests':6478,'files':499}, 'operator': {'tests':24,'files':7},
    'qualityCommandModel':'NORMAL_NPM_CI_WITH_HOOKS_THEN_PLAIN_NPM_RUN_TYPECHECK_LINT_TEST',
    'qualityCacheReceipts': ['0/3 typecheck','0/3 lint','0/2 test'],
    'forceFlag':False,
    'pg15AndPg17Rehearsals':'SUCCESS_15_REHEARSAL_INVOCATIONS_EACH',
    'iosAndAndroidExports':'SUCCESS_CLEAR_UNSIGNED_EXPO_SOURCE_EXPORT_NODE_ENV_PRODUCTION',
    'deviceOrSignedRelease':'NOT_RUN',
}
result['newReplayControls'] = {
    'linux': {'exit': 0, 'positiveControls': 5, 'refusals': 74, 'status': 'PASS'},
    'windows': {'exit': 1, 'status': 'FAIL', 'code': 'R29_REPLAY_CONTROL_FAILED',
        'lastCompletedCase': 'synthetic-historical-mutated-ref-refused-before-scripts',
        'firstUnemittedPositiveCase': 'metadata-only-no-file-content-open',
        'originalHostedSuppressedException': 'UNKNOWN_NOT_EMITTED_BY_TOP_LEVEL_HANDLER',
        'qualification': 'ACTUAL_NEW_CONTROL_FAILURE_SEPARATE_FROM_LATER_AUTHENTIC_HISTORICAL_REPLAY_PASS_AND_PUBLIC_NO_GO_EXIT1'},
}
result['qualification'] += ';B_WINDOWS_NEW_REPLAY_CONTROLS_FAIL_NO_FREEZE_OR_FINAL_SUCCESS_CLAIM'
destination = ROOT / 'COMPLETE_PREFREEZE_B_FACTS29.json'
destination.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'file':str(destination),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'historicalRecordsPerPlatform':5,'platforms':list(result['platforms'])}))
