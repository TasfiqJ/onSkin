"""Seal the sole Campaign29 five-file checkpoint and root handoff after freeze."""
import argparse
import ast
import datetime
import hashlib
import io
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
from types import ModuleType
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent/'c29-src'
BASE = 'bace116586d58ed955f0a024ca96ae9f4ad9286d'
BASE_TREE = '6951590547b79a869464df987d16da6552907846'
AUTH = 'BRAIN-M1X-WINDOWS-READER-INTEGRITY29-CANDIDATE-01'
INPUT = '7a94feecb69b09d46acb6465972f1c7b809fbfa9e657aa50c1f7bc4523643579'
CHECKPOINT = 'docs/brain/checkpoints/M1-02/WINDOWS-READER-INTEGRITY-29/'
PLAN = 'docs/brain/task-specs/M1X-29/SCOPE_PLAN.md'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2)+'\n').encode()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


def zipped(files):
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, body in sorted(files.items()):
            assert name.isascii() and not name.startswith('/') and '\\' not in name and ':' not in name
            assert all(part not in ('','.','..') for part in name.split('/'))
            entry = zipfile.ZipInfo(name, (2026,10,30,0,0,0))
            entry.create_system = 3
            entry.external_attr = 0o100644 << 16
            entry.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(entry, body)
    return output.getvalue()


def witness(body):
    return {'bytes':len(body), 'sha256':sha(body)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--facts', type=Path, required=True)
    args = parser.parse_args()
    specification = importlib.util.spec_from_file_location('reviewed_prefreeze_helpers29', HERE/'collect_prefreeze_facts29.py')
    curated = importlib.util.module_from_spec(specification); specification.loader.exec_module(curated)
    read = curated.stable_read
    assert not (HERE/'CHECKPOINT_SEAL29.json').exists(), 'SECOND_TAIL_FORBIDDEN'
    freeze = json.loads(read(HERE/'WORKLIST_FREEZE29.json'))
    assert freeze['status'] == 'PASS_SOLE_TWO_WORKLIST_CHILD' and freeze['producerInvocationCount'] == 1
    assert git('rev-parse','HEAD').decode().strip() == freeze['worklistHead']
    assert git('rev-parse','HEAD^{tree}').decode().strip() == freeze['worklistTree']
    assert git('rev-parse',freeze['sourceHead']+'^{tree}').decode().strip() == freeze['sourceTree']
    assert git('rev-list','--parents','-n','1',freeze['worklistHead']).decode().split() == [freeze['worklistHead'],freeze['sourceHead']]
    assert not git('status','--porcelain=v1','--untracked-files=all')
    assert not (ROOT/CHECKPOINT).exists()
    facts_body = read(args.facts); facts = json.loads(facts_body)
    assert facts['schema']==1 and facts['status']=='PREFREEZE_ACTUAL_FACTS_READY'
    assert facts['acceptanceGranted'] is False and facts['release']=='NO_GO'
    assert facts['sourceHead'] == freeze['sourceHead'] and facts['sourceTree'] == freeze['sourceTree']
    assert facts['allRequiredPrefreezeLocalCommandsComplete'] is True
    source = dict(base=BASE, baseTree=BASE_TREE, runtimeHead=freeze['sourceHead'],
                  runtimeTree=freeze['sourceTree'], sourceHead=freeze['worklistHead'], sourceTree=freeze['worklistTree'])
    assert facts['afterCollectionEvidenceFiles']==list(curated.AFTER_COLLECTION)
    assert len(facts['evidenceFiles'])==len(set(facts['evidenceFiles']))<5000
    assert set(facts['evidenceFileWitnesses'])==set(facts['evidenceFiles'])
    intent=json.loads(read(HERE/'WORKLIST_PRODUCER29.started.json'))
    assert intent['producerInvocationCount']==1 and intent['sourceHead']==freeze['sourceHead'] and intent['sourceTree']==freeze['sourceTree']
    assert intent['producerSHA256']==freeze['producerSHA256'] and intent['argv']==freeze['argv']
    assert freeze['exit']==0 and set(freeze['actualChangedPaths'])==set(freeze['files'])=={
        'docs/phase-4/generated/source-worklist.json','docs/phase-4/generated/source-worklist.md'}
    for name,expected in freeze['files'].items():
        assert witness(read(ROOT/name))==expected
    producer_log=read(HERE/'worklist-producer29.log')
    assert witness(producer_log)==freeze['producerLog']
    evidence = {};derivations={item['path']:item for item in facts['omittedRawEvidence']['files']}
    assert len(derivations)==len(facts['omittedRawEvidence']['files'])
    for name,item in derivations.items():
        assert type(name) is str and not name.startswith('/') and '\\' not in name and ':' not in name
        assert all(part not in ('','.','..') for part in name.split('/'))
        raw=read(HERE/name);assert witness(raw)==item['original']
        public,current=curated.public_evidence(Path(name),raw)
        assert current=={key:value for key,value in item.items() if key!='path'}
    for name in [*facts['evidenceFiles'],*curated.AFTER_COLLECTION]:
        assert type(name) is str and not name.startswith('/') and '\\' not in name and ':' not in name
        assert all(p not in ('','.','..') for p in name.split('/'))
        path = HERE/name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info,'st_file_attributes',0)&1024
        body = read(path);curated.text_body(body)
        if name in facts['evidenceFileWitnesses']:
            assert witness(body)==facts['evidenceFileWitnesses'][name], 'COLLECTED_EVIDENCE_CHANGED'
        public,derivation=curated.public_evidence(path,body)
        assert public is not None, 'REQUIRED_EVIDENCE_UNSAFE_BODY'
        if name in curated.AFTER_COLLECTION and derivation:
            derivations[name]=dict(path=name,**derivation)
        elif derivation:
            assert derivations[name]==dict(path=name,**derivation)
        evidence['evidence/'+name] = public
    assert len(evidence) >= 15
    assert sum(len(body) for body in evidence.values())<=64*1024*1024
    evidence['source/SCOPE_PLAN.md'] = read(ROOT/PLAN)
    evidence['source/SOURCE_BINDING29.json'] = encoded(dict(source=source,qualification='PRE_TAIL_SOURCE_BINDING_NOT_ACCEPTANCE',
        finalHead='NOT_RUN_AT_SEAL',finalCI='NOT_RUN_AT_SEAL',finalClones='NOT_RUN_AT_SEAL',freshDownload='NOT_RUN_AT_SEAL'))
    evidence['evidence/PREFREEZE_FACTS29.json'] = facts_body
    evidence['evidence/OMITTED_RAW_EVIDENCE29.json'] = encoded(dict(
        qualification=facts['omittedRawEvidence']['qualification'],files=[derivations[name] for name in sorted(derivations)]))
    payload = zipped(evidence)
    verifier = read(HERE/'packaging/verify29.py')
    plan_sha = sha(read(ROOT/PLAN))
    literals = {}
    for node in ast.parse(verifier).body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            try: literals[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError,TypeError): pass
    expected_pins = dict(AUTHORITY=AUTH,INPUT=INPUT,BASE=BASE,BASE_TREE=BASE_TREE,CHECKPOINT=CHECKPOINT,
        PLAN=PLAN,PLAN_COMMIT='9b395cbee7594f7dc03934aed4e08c4e3ea43c23',PLAN_SHA256=plan_sha,
        CHECKER_SHA256=sha(read(ROOT/'scripts/release/full-app-j01/check.py')),
        CONSUMER_SHA256=sha(read(ROOT/'scripts/release/full-app-j01/source_consumer29.test.py')))
    assert all(literals.get(key)==value for key,value in expected_pins.items()), 'STALE_VERIFIER_BINDING_BEFORE_TAIL'
    build = json.loads(read(HERE/'packaging/VERIFIER_BUILD29.json'))
    assert build['checkpointVerifierSHA256']==sha(verifier), 'VERIFIER_BUILD_BYTES_CHANGED'
    attestation=facts['verifierPinAttestation']
    assert attestation['sourceHead']==freeze['sourceHead'] and attestation['sourceTree']==freeze['sourceTree']
    assert attestation['checkpointVerifierSHA256']==sha(verifier)
    assert attestation['sourcePins']=={key:expected_pins[key] for key in ('CHECKER_SHA256','CONSUMER_SHA256')}
    grant = set(json.loads(re.search(rb'```json\n(.*?)\n```',read(ROOT/PLAN),re.S).group(1)))
    assert literals['EXISTING']|literals['NEW']==grant and len(grant)==20
    assert read(ROOT/PLAN)==git('show',expected_pins['PLAN_COMMIT']+':'+PLAN)
    report = f'''# Campaign29 immutable pre-tail checkpoint

Authority: **{AUTH}**. SUBMITTED_REVIEW_REQUIRED / NO_GO.
Independent Brain retains ordinary source acceptance; qualified owners retain
all separate gates. This report seals pre-tail observations only. USD0. NO MERGES.

## Source custody and input authentication

Replacement WinCompat packet: 9,640,462 bytes, SHA256
`b285161758aa30cd126cd2e9d238cbb7a43494e247f110d35c93f04bfa2f8d96`.
External manifest `{INPUT}`; authenticated packet verifier
`aa1fc609458220e18982aeb259c3eadb2d32a68577a518e7b9453afc61b439d7`.
Independent raw archive/path/type/alias/expansion/CRC and all declared hashes
passed. The exact unmodified command returned exit0 / VERIFIED,15 files and
priorReturn/priorBrain HASH_VERIFIED. The former rejected packet was not reused.

Pinned PR32 `{BASE}` / tree`{BASE_TREE}` remains the draft repair parent.
Sole first-child plan `9b395cbee7594f7dc03934aed4e08c4e3ea43c23`, SHA256`{plan_sha}`,
contains the exact20-path grant and is immutable. Substantive source
`{source['runtimeHead']}` / tree`{source['runtimeTree']}` precedes the sole original
two-worklist child `{source['sourceHead']}` / tree`{source['sourceTree']}`.
The original producer ran exactly once, exit0. This report/checkpoint and root
handoff form the sole following evidence tail; no source edit follows freeze.
One open draft PR33 targets only the exact PR32 branch. Auto-merge and maintainer
modification are off. Prior PRs and main remain unchanged.

## Reader repair and honest diagnosis boundary

Only bytes27 and bytes28 change in the inherited reader implementation modules.
All helpers, other module bytes and both original test files remain exact PR32.
The first complete bounded observation is compared with an independent second
bounded full read of the same descriptor. Both stages retain same-domain pathname
and handle metadata, compatible Windows ctime/birthtime and suffix mode handling,
identity, regularity/link/reparse, bounds, complete-read and parent-chain checks.
Read-induced atime is excluded from mutation. New source29 governance appends to
the exact PR32 checker prefix and preserves all218 inherited function ASTs.
Only named reader implementation exceptions have positive/negative AST controls.

New hostile tests explicitly mutate consumed byte0 after32 original bytes with
all observed metadata aliased unchanged. Frozen readers accept the changed
backing state in this controlled scenario; current readers refuse. Visible
timestamps, truncation/growth/substitution, races, modes, missing parents, read
failures and exact restoration are exercised separately. The guarantee is
observed two-read source stability; coherent unobserved changes and mutations
after the last observation remain outside it. No universal TOCTOU or physical
native safety claim is made.

Original run41001481528/job123886648805 steps13 and14 remain genuine historical
FAIL. Their mains suppressed exception detail; exact historical exception is
UNKNOWN. Bounded local canonical and authenticated frozen diagnostic attempts
did not reproduce those failures. Fresh plan-only hosted Windows original tests
also passed. This does not relabel the old failures or prove their exact cause.
The separate conditional consumed-byte defect is demonstrated and repaired;
historical exception recovery remains OPEN_REQUIRED / NOT_REPRODUCED.

## Actual pre-freeze executions

{facts['validationNarrative']}

All exact commands, exits, runtime identities, cache provenance, source identities
and qualifications are in the authenticated payload evidence. Initial failed
prototype assertions, an interrupted stale source-check attempt and replaced
system-toolchain refusals remain distinct from final passing executions.
The newly authenticated task-owned Python3.12.10/Node22.21.0/npm11.20 toolchain
retains original guards and normal project npm-ci/postinstall hooks; system
global tools were not changed.

Original151 and historical09–23 keep their original fixture/synthetic boundaries.
Authentic Release24–28 executes at each original pin in fresh full remote clones;
Release27 is PR31 and Release28 is PR32. Successful mechanics are not source,
Security, database or native acceptance. Local Docker is NOT_RUN when unavailable;
hosted credential-free DB results are separately attributed and non-admitting.

## Required evidence after this seal

Final evidence-tail HEAD/tree, final live Windows/Linux reader/source steps,
Quality/iOS launch/original Security, two complete fresh final-head remote clones,
actual protected-source and artifact0/1/0, the minimal exact-PR32-required bundle,
one real return ZIP and actual fresh download/hash verification are
**NOT_RUN_AT_SEAL**. They must appear in the later external return, not be
fabricated inside this immutable checkpoint. Supplier clones are not independent
Brain execution. An artifact VERIFIED result means integrity only.

## Closed gates and disposition

Reader consumed-byte repair: FIXED_AND_PROVED only within observed source models
and actual tests listed above. Exact original suppressed exception:
OPEN_REQUIRED / NOT_REPRODUCED; no inferred diagnosis. Independent Brain review
remains required. G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED;
M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED;
J01 optical G1/G2/G3/G5 and longitudinal G4 NOT_ACCEPTED. Physical iPhone/
VoiceOver, provider/paid, professional/clinical/legal/licensing, Apple and public
release remain CLOSED. Future scope stays non-Korean F01–F17/F19–F20,C01–C12,
P01–P06, protected F09 and exactly qualified Korean J01. Automated F18 and
J02–J27 including J05 remain deferred. No original raw Security findings or
credentials opened/published. USD0; no merges, main promotion or public release.
'''.encode()
    readme = b'# Campaign29 source checkpoint\n\nExactly five files. SUBMITTED_REVIEW_REQUIRED / NO_GO.\nExternal manifest/verifier anchors authenticate this checkpoint. Artifact integrity is separate from source and release acceptance. Final CI, final-head clone/tamper proofs and download verification remain external to this pre-tail seal. Read REPORT.md and all limitations.\n'
    files = {'README.md':readme, 'REPORT.md':report, 'payload.zip':payload, 'verify29.py':verifier}
    manifest = dict(schema=1,authority=AUTH,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,
        release='NO_GO',inputManifestSHA256=INPUT,source=source,files={name:witness(body) for name,body in files.items()},
        payload=dict(schema=1,qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',files={name:witness(body) for name,body in evidence.items()}))
    files['manifest.json'] = encoded(manifest)
    # Refuse schema, aliases, framing, declared inventories and expansion errors
    # before the first tracked checkpoint file or handoff is written.
    inspector=ModuleType('authenticated_checkpoint_prewrite29')
    exec(compile(verifier,'<authenticated checkpoint verifier>','exec'),inspector.__dict__)
    assert inspector.MODE=='checkpoint'
    prewrite=inspector.checkpoint(inspector.Archive(zipped(files)),sha(files['manifest.json']))
    assert prewrite==manifest
    target = ROOT/CHECKPOINT
    target.mkdir(parents=True,exist_ok=False)
    for name,body in files.items():
        with (target/name).open('xb') as output: output.write(body)
    handoff = f'''CAMPAIGN29 — SUBMITTED_REVIEW_REQUIRED / PARTIAL_DIAGNOSIS / NO_GO
Authority: {AUTH}
Independent Brain retains source acceptance; all qualified gates remain CLOSED.
USD0. NO MERGES, MAIN PROMOTION, PUBLIC RELEASE OR PRIOR-PR MODIFICATION.

One draft PR33: https://github.com/TasfiqJ/onSkin/pull/33
Branch stage/m1-windows-reader-integrity29, only on stage/m1-destructive-commit-core05-28.
Auto-merge OFF; maintainer modification OFF. PR32/PR31 remain unmerged.
Pinned PR32 HEAD {BASE}; tree {BASE_TREE}.
External replacement context manifest {INPUT}.
Exact packet verifier exit0 / VERIFIED15; prior return/Brain anchors HASH_VERIFIED.
Context integrity is not source acceptance.

Immutable first plan 9b395cbee7594f7dc03934aed4e08c4e3ea43c23; SHA256 {plan_sha}.
Substantive source {source['runtimeHead']}; tree {source['runtimeTree']}.
Sole original two-worklist child {source['sourceHead']}; tree {source['sourceTree']}.
Original Phase4 producer ran exactly once. No source edits after freeze.
Exactly20 granted paths; only bytes27/bytes28 changed in old reader modules.
All218 inherited checker functions, original27/28 tests and application bytes preserved.
Current readers compare two bounded full observations and metadata/identity/parents.
Consumed-byte alias gap is demonstrated/refused; no universal TOCTOU/native claim.
Historical run41001481528 reader failures remain red; suppressed exception UNKNOWN.
Bounded frozen reproductions did not recover it: OPEN_REQUIRED / NOT_REPRODUCED.

Checkpoint {CHECKPOINT}
Manifest SHA256 {sha(files['manifest.json'])}
Verifier SHA256 {sha(verifier)}
Payload SHA256 {sha(payload)}
This handoff and exactly five checkpoint files are the sole evidence tail.
Final HEAD/tree, final CI, two complete independent supplier clones, actual source/artifact
0/1/0 and one real downloadable return/fresh-download proof are NOT_RUN_AT_SEAL and
must be recorded externally afterward. No second tail or producer is authorized.

G97 FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED;
M2 NOT_AUTHORIZED; J01 optical G1/G2/G3/G5 and G4 NOT_ACCEPTED. Physical iPhone/VoiceOver,
provider/paid/professional/clinical/legal/licensing/Apple/public release CLOSED.
Future first iPhone scope: F01–F17/F19–F20,C01–C12,P01–P06,protected F09,exactly qualified
Korean J01; automated F18 and J02–J27 including J05 deferred. Brain audits before further task.
'''.encode()
    (ROOT/'ONSKIN_BRAIN_HANDOFF.txt').write_bytes(handoff)
    tools = json.loads((HERE/'runtime/ACTIVE_TOOLCHAIN29.json').read_bytes())
    command = [tools['python'],'-I','-B',str(target/'verify29.py'),'--root',str(target),
               '--expected-manifest-sha256',sha(files['manifest.json']),'--expected-verifier-sha256',sha(verifier)]
    check = subprocess.run(command,cwd=ROOT,capture_output=True,timeout=300)
    (HERE/'checkpoint-artifact-preflight29.stdout.log').write_bytes(check.stdout)
    (HERE/'checkpoint-artifact-preflight29.stderr.log').write_bytes(check.stderr)
    state = dict(status='CHECKPOINT_BUILT_ARTIFACT_PREFLIGHT_PASS' if check.returncode==0 else 'BLOCKED_CHECKPOINT_PREFLIGHT_FAILED',
        source=source,checkpoint=CHECKPOINT,manifestSHA256=sha(files['manifest.json']),verifierSHA256=sha(verifier),
        payloadSHA256=sha(payload),payloadFiles=len(evidence),preflightExit=check.returncode,preflightArgv=command,
        createdUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),release='NO_GO',acceptanceGranted=False)
    (HERE/'CHECKPOINT_SEAL29.json').write_bytes(encoded(state))
    assert check.returncode == 0 and json.loads(check.stdout)['status']=='VERIFIED'
    expected = {CHECKPOINT+name for name in files}|{'ONSKIN_BRAIN_HANDOFF.txt'}
    changed = set(git('diff','--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
    assert changed == expected, changed
    git('add','--',*sorted(expected))
    assert set(git('diff','--cached','--name-only').decode().splitlines()) == expected
    git('commit','-m','docs(campaign29): seal reader integrity checkpoint and handoff')
    state.update(status='PASS_SOLE_SIX_FILE_EVIDENCE_TAIL',head=git('rev-parse','HEAD').decode().strip(),tree=git('rev-parse','HEAD^{tree}').decode().strip())
    assert git('rev-list','--parents','-n','1','HEAD').decode().split()==[state['head'],source['sourceHead']]
    assert not git('status','--porcelain=v1','--untracked-files=all')
    (HERE/'CHECKPOINT_SEAL29.json').write_bytes(encoded(state))
    print(json.dumps(state))


if __name__ == '__main__':
    main()
