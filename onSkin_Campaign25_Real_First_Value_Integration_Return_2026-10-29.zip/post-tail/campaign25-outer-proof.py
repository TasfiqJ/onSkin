from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse, datetime, hashlib, json, os, subprocess, time, zipfile

ROOT=Path(__file__).resolve().parent
VER='5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def facts(path):
    s=path.stat(); return dict(bytes=s.st_size,sha256=sha(path.read_bytes()),inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
def main():
    p=argparse.ArgumentParser(); p.add_argument('--archive',type=Path,required=True); p.add_argument('--hashes',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    a=p.parse_args(); archive=a.archive.resolve(); out=a.output.resolve(); out.mkdir(exist_ok=False)
    hashes=json.loads(a.hashes.read_text()); verifier=ROOT/'campaign25-review/verify_return25.py'
    saved=archive.read_bytes(); assert sha(saved)==hashes['outerZIPSHA256'] and len(saved)==hashes['outerZIPBytes']
    assert hashes['outerVerifierSHA256']==VER and sha(verifier.read_bytes())==VER
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist())==len(set(z.namelist()))
        manifest=z.read('manifest.json'); assert sha(manifest)==hashes['outerManifestSHA256']
        value=json.loads(manifest); assert set(z.namelist())==set(value['files'])|{'manifest.json'}
        assert z.read('verify_return25.py')==verifier.read_bytes()
        for name,witness in value['files'].items():
            data=z.read(name); assert witness==dict(bytes=len(data),sha256=sha(data))
    base=['python','-B',str(verifier),'--archive',str(archive),'--expected-manifest-sha256',hashes['outerManifestSHA256'],'--expected-verifier-sha256',VER]
    def run(label,cmd):
        start=time.time(); started=datetime.datetime.now(datetime.timezone.utc).isoformat()
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=ROOT,timeout=1800)
        (out/(label+'.stdout.log')).write_bytes(result.stdout); (out/(label+'.stderr.log')).write_bytes(result.stderr)
        item=dict(label=label,argv=cmd,startedUTC=started,seconds=round(time.time()-start,3),exit=result.returncode,stdoutSHA256=sha(result.stdout),stderrSHA256=sha(result.stderr))
        try: item['result']=json.loads(result.stdout)
        except ValueError: pass
        (out/(label+'.receipt.json')).write_text(json.dumps(item,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(dict(label=label,exit=result.returncode,seconds=item['seconds'])),flush=True)
        return item
    st=archive.stat(); before=facts(archive); current=run('current',base); assert current['exit']==0
    try:
        tampered=bytearray(saved); tampered[len(tampered)//2]^=1
        with archive.open('r+b') as f: f.write(tampered); f.flush(); os.fsync(f.fileno())
        bad=run('corrupted',base); assert bad['exit']==1
    finally:
        with archive.open('r+b') as f: f.write(saved); f.flush(); os.fsync(f.fileno())
        os.chmod(archive,st.st_mode); os.utime(archive,ns=(st.st_atime_ns,st.st_mtime_ns))
    after=facts(archive); assert before==after
    restored=run('restored',base); assert restored['exit']==0
    def git_proof(label):
        cmd=base+['--git-root',str(ROOT/label),'--expected-head',hashes['head'],'--expected-tree',hashes['tree']]
        result=run(label+'-bundle-history',cmd); assert result['exit']==0
        assert result['result']['sourceChecks']['state']=='NOT_RUN'
        return result
    with ThreadPoolExecutor(max_workers=2) as workers: git_results=list(workers.map(git_proof,('campaign25-final-a','campaign25-final-b')))
    receipt=dict(qualification='ACTUAL_OUTER_ARTIFACT_010_AND_EXACT_MINIMAL_DELTA_HISTORY_IN_TWO_COMPLETE_FINAL_CHECKOUTS',outerZIP=archive.name,outerZIPBytes=len(saved),outerZIPSHA256=sha(saved),outerManifestSHA256=hashes['outerManifestSHA256'],outerVerifierSHA256=VER,head=hashes['head'],tree=hashes['tree'],outerMembers=len(value['files'])+1,outerExpandedBytes=sum(v['bytes'] for v in value['files'].values())+len(manifest),sequence=[current['exit'],bad['exit'],restored['exit']],before=before,restored=after,records=[current,bad,restored],gitBundleHistoryResults=git_results,sourceChecks='NOT_RUN_IN_THIS_POSTPACKAGING_ASSAY;FULL_PAIRED_CHECKPOINT_EXECUTION_RECORDED_IN_TWO_FINAL_SOURCE_PROOFS',acceptanceGranted=False,release='NO_GO')
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(complete=True,sequence=receipt['sequence'],gitExits=[x['exit'] for x in git_results],outerMembers=receipt['outerMembers'],release='NO_GO')),flush=True)
if __name__=='__main__': main()
