from pathlib import Path
import datetime, hashlib, json, os, stat, subprocess, time

ROOT=Path(__file__).resolve().parent
repo=ROOT/'campaign25-final-a'; out=ROOT/'campaign25-evidence/final-a-proof'
stage=ROOT/'campaign25-checkpoint-stage-k71jglq0/checkpoint'
HEAD='52a3d01ebb36a6845d0ac21935ad35520732633f'; TREE='ef49a81ca814f3d82b8a868e0308b6dda09c9cca'
MAN='ada1ced48b5e00472e0207c036e9fbab3d7903b60c94784ece44186188c23d87'; VER='e12a0e3ae733b3c611ce9f6493502e1b454f41b4f3c14868e8a45a76af493a01'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def save(name,value): (out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def facts(path):
    s=path.stat(); return dict(bytes=s.st_size,sha256=sha(path.read_bytes()),inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns)
records=[]
def run(label,args,timeout=2400):
    start=time.time(); started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(args,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
    (out/(label+'.stdout.log')).write_bytes(result.stdout); (out/(label+'.stderr.log')).write_bytes(result.stderr)
    entry=dict(label=label,argv=args,cwd=str(repo),startedUTC=started,seconds=round(time.time()-start,3),exit=result.returncode,stdoutSHA256=sha(result.stdout),stderrSHA256=sha(result.stderr))
    records.append(entry); save('progress.json',records)
    print(json.dumps({'label':label,'exit':result.returncode,'seconds':entry['seconds']}),flush=True)
    return result
def snapshot(name):
    rows={}
    for record in git('ls-tree','-rz','--full-tree','HEAD').split(b'\0'):
        if not record: continue
        info,rawpath=record.split(b'\t',1); mode,kind,oid=info.decode().split(); path=rawpath.decode('utf-8')
        p=repo/path; st=p.lstat(); assert kind=='blob' and stat.S_ISREG(st.st_mode) and not getattr(st,'st_file_attributes',0)&1024
        data=p.read_bytes(); rows[path]=dict(mode=mode,blob=oid,bytes=len(data),sha256=sha(data))
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
    save(name,rows); return rows

out.mkdir(exist_ok=False)
assert sha((stage/'manifest.json').read_bytes())==MAN and sha((stage/'verify25.py').read_bytes())==VER
manifest=json.loads((stage/'manifest.json').read_bytes())
for name,expected in manifest['files'].items():
    data=(stage/name).read_bytes(); assert expected==dict(bytes=len(data),sha256=sha(data))
assert run('fetch-final',['git','fetch','origin','stage/m1-real-first-value25']).returncode==0
assert run('checkout-final',['git','checkout','--detach',HEAD]).returncode==0
assert git('rev-parse','HEAD').decode().strip()==HEAD and git('rev-parse','HEAD^{tree}').decode().strip()==TREE
assert git('rev-parse','--is-shallow-repository').strip()==b'false'
assert git('config','--local','core.autocrlf').strip()==b'false'
assert git('remote','get-url','origin').decode().strip()=='https://github.com/TasfiqJ/onSkin.git'
assert (repo/'.git').is_dir() and not (repo/'.git/objects/info/alternates').exists()
assert not git('status','--porcelain=v1','--untracked-files=all')
packFacts=[]
for p in (repo/'.git/objects/pack').iterdir():
    s=p.stat(); assert s.st_nlink==1; packFacts.append(dict(name=p.name,bytes=s.st_size,inode=s.st_ino,links=s.st_nlink))
before=snapshot('tracked-before.json')
cmd=['python','-B',str(stage/'verify25.py'),'--root',str(stage),'--expected-manifest-sha256',MAN,'--expected-verifier-sha256',VER,'--git-root',str(repo),'--expected-head',HEAD,'--expected-tree',TREE,'--execute-source-checks']
current=run('current',cmd); assert current.returncode==0, current.stdout.decode()
value=json.loads(current.stdout); assert value['status']=='VERIFIED' and value['sourceChecks']['phase4']=='PASS_UNCHANGED_PRODUCER_STRICT_CHECK'
target=repo/'04_repo_docs/README.md'; original=target.read_bytes(); st=target.stat(); targetBefore=facts(target)
try:
    changed=bytearray(original); changed[len(changed)//2]^=1
    with target.open('r+b') as f: f.write(changed); f.flush(); os.fsync(f.fileno())
    dirty=git('status','--porcelain=v1','--untracked-files=all').decode()
    save('mutation.json',dict(target='04_repo_docs/README.md',before=targetBefore,tampered=facts(target),gitStatus=dirty,statCacheHidden=not bool(dirty)))
    bad=run('tampered',cmd); assert bad.returncode==1 and json.loads(bad.stdout)['status']=='CONTEXT_INVALID'
    direct=run('tampered-direct-release25',['python','-B','scripts/release/full-app-j01/check.py']); assert direct.returncode==1
finally:
    with target.open('r+b') as f: f.write(original); f.flush(); os.fsync(f.fileno())
    os.chmod(target,st.st_mode); os.utime(target,ns=(st.st_atime_ns,st.st_mtime_ns))
assert facts(target)==targetBefore
restored=run('restored',cmd); assert restored.returncode==0, restored.stdout.decode()
after=snapshot('tracked-after.json'); assert before==after
assert not git('status','--porcelain=v1','--untracked-files=all')
assert git('rev-parse','HEAD').decode().strip()==HEAD
receipt=dict(qualification='INDEPENDENT_COMPLETE_REMOTE_FINAL_HEAD_CHECKOUT_SOURCE_ONLY_NOT_ACCEPTANCE',head=HEAD,tree=TREE,remote='https://github.com/TasfiqJ/onSkin.git',checkpointManifestSHA256=MAN,checkpointVerifierSHA256=VER,normalMandatoryNpmLifecycle='EXECUTED_DURING_SEPARATE_PREPARATION',noShallow=True,noAlternates=True,noSharedObjectStore=True,objectPackFiles=packFacts,trackedFiles=len(before),allRawWorkingBlobsEqualGit=True,fullBeforeAfterEqual=True,sourceSequence=[current.returncode,bad.returncode,restored.returncode],directTamperedRelease25Exit=direct.returncode,exactRestoration=targetBefore,records=records,sourceChecksCurrent=json.loads(current.stdout)['sourceChecks'],sourceChecksRestored=json.loads(restored.stdout)['sourceChecks'],cleanAfter=True,acceptanceGranted=False,release='NO_GO')
save('receipt.json',receipt)
print(json.dumps({'complete':True,'head':HEAD,'sequence':receipt['sourceSequence'],'trackedFiles':len(before),'release':'NO_GO'}),flush=True)
