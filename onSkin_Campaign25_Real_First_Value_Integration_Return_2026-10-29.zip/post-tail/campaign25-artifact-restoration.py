from pathlib import Path
import argparse, hashlib, json, os, subprocess, time, zipfile

def digest(data): return hashlib.sha256(data).hexdigest()
def facts(path):
    s=path.stat()
    return {'sha256':digest(path.read_bytes()),'bytes':s.st_size,'mode':s.st_mode,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',required=True); p.add_argument('--output',required=True)
    p.add_argument('--manifest',required=True); p.add_argument('--verifier',required=True)
    a=p.parse_args(); root=Path(a.root); out=Path(a.output); out.mkdir(exist_ok=False)
    manifest=(root/'manifest.json').read_bytes(); verifier=root/'verify25.py'
    assert digest(manifest)==a.manifest and digest(verifier.read_bytes())==a.verifier
    inventory=json.loads(manifest)
    assert set(x.name for x in root.iterdir())==set(inventory['files'])|{'manifest.json'}
    for name,expected in inventory['files'].items():
        raw=(root/name).read_bytes(); assert expected=={'bytes':len(raw),'sha256':digest(raw)}
    with zipfile.ZipFile(root/'payload.zip') as z:
        assert set(z.namelist())==set(inventory['payload']['files']) and len(z.namelist())==len(set(z.namelist()))
        for name,expected in inventory['payload']['files'].items():
            raw=z.read(name); assert expected=={'bytes':len(raw),'sha256':digest(raw)}
    cmd=['python','-B',str(verifier),'--root',str(root),'--expected-manifest-sha256',a.manifest,'--expected-verifier-sha256',a.verifier]
    records=[]
    def run(label):
        start=time.time(); result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
        log=out/(label+'.log'); log.write_bytes(result.stdout)
        records.append({'label':label,'exit':result.returncode,'seconds':round(time.time()-start,3),'argv':cmd,'log':log.name,'logSHA256':digest(result.stdout)})
        return result.returncode
    target=root/'payload.zip'; saved=target.read_bytes(); st=target.stat(); before=facts(target)
    assert run('current')==0
    try:
        changed=bytearray(saved); changed[len(changed)//2]^=1
        with target.open('r+b') as f: f.write(changed); f.flush(); os.fsync(f.fileno())
        assert run('corrupted')==1
    finally:
        with target.open('r+b') as f: f.write(saved); f.flush(); os.fsync(f.fileno())
        os.chmod(target,st.st_mode); os.utime(target,ns=(st.st_atime_ns,st.st_mtime_ns))
    after=facts(target); assert before==after
    assert run('restored')==0
    receipt={'qualification':'ACTUAL_CHECKPOINT_ARTIFACT_CURRENT_CORRUPTED_RESTORED_NOT_SOURCE_ACCEPTANCE','manifestSHA256':a.manifest,'verifierSHA256':a.verifier,'independentInventoryAuthentication':True,'sequence':[r['exit'] for r in records],'before':before,'restored':after,'records':records,'sourceChecks':'NOT_RUN','acceptanceGranted':False,'release':'NO_GO'}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt))

if __name__=='__main__': main()
