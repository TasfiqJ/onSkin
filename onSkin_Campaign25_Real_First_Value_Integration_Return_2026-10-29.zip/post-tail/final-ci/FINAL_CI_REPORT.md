# Campaign25 final CI evidence

All four workflows are terminal for [final head 52a3d01ebb36a6845d0ac21935ad35520732633f](https://github.com/TasfiqJ/onSkin/commit/52a3d01ebb36a6845d0ac21935ad35520732633f), tree `ef49a81ca814f3d82b8a868e0308b6dda09c9cca`. Collected 2026-10-29T06:11:19.659Z. This is post-tail source evidence: **SUBMITTED_REVIEW_REQUIRED, NO_GO, acceptanceGranted=false**.

| Workflow | Final result | Evidence |
| --- | --- | --- |
| Quality | SUCCESS | [Run 40824550393](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393) |
| iOS launch contract | SUCCESS | [Run 40824550434](https://github.com/TasfiqJ/onSkin/actions/runs/40824550434) |
| Security | FAILURE | [Run 40824550372](https://github.com/TasfiqJ/onSkin/actions/runs/40824550372), metadata only |
| Security candidate23 | FAILURE | [Run 40824550384](https://github.com/TasfiqJ/onSkin/actions/runs/40824550384), metadata only |

## Exact source and checkout

All seven public Quality/iOS job logs identify actual checkout [dfe9fb7024ea3778a96b5a48040e75f80526f438](https://github.com/TasfiqJ/onSkin/commit/dfe9fb7024ea3778a96b5a48040e75f80526f438), GitHub's temporary PR test commit with parents pinned PR28 `d0ccef65bcbe0c90483e6c0f691ed95f92228c6c` and final head `52a3d01ebb36a6845d0ac21935ad35520732633f`. Its tree exactly equals the final head's tree. These are distinct commit identities; no repository merge was performed. Security actual-checkout logs were not examined.

The final remote PR29 snapshot remains open/draft/unmerged, head exact, base PR28 exact, auto-merge OFF and maintainer modifications OFF. Original receipts are retained. `FINAL_HEAD_ANCHOR.workflowIDs` is a documented naming error containing run IDs; the final JSON uses `workflowRuns`.

## Source quality and exports

[Repository quality gates](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/job/123284459082) passed all steps. The actual Release25 checker reports TAIL, RAW_TRACKED_BLOBS_EXACT, all 23,501 tracked working blobs hashed locally, exact endpoint/tree, admissions false and NO_GO. The unchanged strict producer command `node scripts/phase4/build-source-worklist.mjs --strict --check` reports “Phase 4 source worklist is current.” Typecheck, lint, installed native/privacy source checks and the governed source contracts passed.

Quality and [iOS launch safe checks](https://github.com/TasfiqJ/onSkin/actions/runs/40824550434/job/123284459205) each executed the same mobile corpus: **6,317 tests/494 files**, plus **24 operator tests/7 files**. These are duplicate executions, not summed distinct coverage. Expected negative-path stderr exists; successful results do not imply zero console warnings. The original 151 negative fixture summary passed with current/tampered/restored 0/1/0, explicitly **bundle fixtures only**, alongside 23 bounded real-Git delta fixture refusals and 35 disposable-source fixture refusals. These do not replace the separate complete-checkout proofs.

[iOS export](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/job/123285916929) and [Android export](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/job/123285917056) both passed. Logs show `--clear`, empty-cache rebuilding and completed exports. These are unsigned JavaScript exports, not native iPhone/Apple proof. Content-free statistics artifacts are [iOS 12876272359](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/artifacts/12876272359) and [Android 12876720448](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/artifacts/12876720448); their sizes/digests are GitHub-reported metadata, not locally downloaded or rehashed archives.

## Actual canonical database execution

[Credential-free canonical verification](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/job/123284459427) passed, 2026-10-29T05:38:23Z to 2026-10-29T06:10:20Z. Actual runtime lines identify amd64 canonical identical-mirror image id/digest `sha256:af083ef64d0408c8f098ee6f5c364a59b26f36fbc0f3a334a62c5c1d57362e9b`; SQL/CLI history observations report server_version_num 150008 and exact final **97 migrations, latest 20261010000081**.

Actual phase markers prove isolated startup; 0067→0068 adherence, 0068→0069 bridge, 0069→0070 consent-draft, 0070→0071 recommendation and 0071→0072 commerce forward rehearsals; resets 1 of 2 and 2 of 2; focused CORE-05 structural regressions; structural pgTAP; public-schema lint; empty migration/schema drift; and CAT-08 two-connection revocation rehearsal. Full local verification completed PASS at 06:10:17Z. Generated public types and repository parity both passed: **7,381 lines**, SHA256 `2b475803f0ea143681de2912637e61b1cf26e271043a84a1692e7d1d6b87a795`, already-current. The successful contained producer emits no pgTAP assertion count; none is invented. Its 30 actual phase/parity PASS markers comprise 29 db05-local and one db08-types marker; these are not 30 tests. The failure-only diagnostic-types upload was SKIPPED, not executed.

Bootstrap TAP's prefixed `# [db05-local]` amd64/arm64 RootFS 48 diagnostics are synthetic controls and excluded from actual runtime claims. The actual runtime facts above come from unprefixed verifier lines. **DB06/DB08/R2B remain NOT_ACCEPTED.**

[PostgreSQL 15](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/job/123284459630) and [PostgreSQL 17](https://github.com/TasfiqJ/onSkin/actions/runs/40824550393/job/123284459577) each executed all 15 isolated rehearsal SQL scripts successfully. Each emits 16 PASS markers because 0075 also emits 0064; this is not 16 tests.

## Security and acceptance limits

Security's static/OSV, secret-scanning, code-gate and automated source-only-acceptance jobs failed. The live Supabase adversarial job was SKIPPED. Both candidate23 OS jobs failed; metadata names Campaign24 finite-source-governance and public-component steps. No Security logs, findings or artifacts were fetched/copied, and no finding diagnosis is inferred from step names. A failed or skipped result is not PASS.

G97 remains FAIL/NO_GO; DB06/DB08/R2B NOT_ACCEPTED; M1-03 BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 NOT_AUTHORIZED; J01 optical G1/G2/G3/G5 and G4 qualification NOT_ACCEPTED; native/VoiceOver/clinical/legal/licensing/provider/Apple/public release CLOSED. Collection made no source changes, PR edits, reruns or paid-service changes. USD0, NO MERGES, SUBMITTED_REVIEW_REQUIRED. Complete per-step results and sanitized public excerpts accompany the JSON; full raw logs are not included.

Automatic approval review rejected four already-dispatched public-log hashing calls because the generated code exceeded its 64,000-byte limit. Full raw/decoded log hashes remain NOT_RUN/AUTO_REVIEW_REJECTED; the canonical hash was not attempted after that rejection, and no alternate route, write or chunking was attempted.

