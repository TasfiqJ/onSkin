# Campaign25 post-tail CI collection

Exact authorized final source is commit `52a3d01ebb36a6845d0ac21935ad35520732633f`,
tree `ef49a81ca814f3d82b8a868e0308b6dda09c9cca`. This evidence is collected
after the evidence-only tail, outside the source tree, without further commits,
workflow reruns, PR edits, or release acceptance.

GitHub connector commit/run/job/step metadata is the primary evidence. Records
preserve exact trigger heads, run attempts, actual step conclusions, skipped
jobs, and collection times. Earlier heads are anticipation-only. Pending,
skipped, unavailable, and NOT_RUN are never counted as PASS.

For Quality and the iOS launch workflow, public job log excerpts may establish
the actual checkout and relevant check outcomes. Synthetic PR merge checkout
identity is distinct from the trigger head. A matching tree establishes content
equivalence; it does not equate two commit identities. Actual checkout is marked
unproved until supported by checkout logs.

Security and Security candidate workflows are metadata-only. No Security job
logs, findings, or artifacts are fetched or copied. Their checkout intent may
be described from unchanged workflow source, but is not substituted for actual
checkout log proof.

Canonical database and PostgreSQL rehearsal successes are source/CI evidence.
DB06/DB08/R2B remain NOT_ACCEPTED. G97 stays FAIL/NO_GO; M1-03 stays
BLOCKED_EXTERNAL_CUSTODY/NOT_ACCEPTED; M2 stays NOT_AUTHORIZED. J01 qualification,
native/VoiceOver/clinical/legal/licensing/provider/Apple/public release stay
CLOSED. USD0, NO MERGES, SUBMITTED_REVIEW_REQUIRED.
