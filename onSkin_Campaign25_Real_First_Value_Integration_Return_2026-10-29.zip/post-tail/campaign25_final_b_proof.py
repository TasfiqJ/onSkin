"""Independent final remote-checkout proof and reversible public-source control."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import subprocess
import sys
import time
import unicodedata
import zipfile

BASE=Path(__file__).resolve().parent
ROOT=BASE/'campaign25-final-b'
PACKET=BASE/'campaign25-checkpoint-stage-k71jglq0/checkpoint'
OUT=BASE/'campaign25-evidence/final-b-proof'
MANIFEST='ada1ced48b5e00472e0207c036e9fbab3d7903b60c94784ece44186188c23d87'
VERIFIER='e12a0e3ae733b3c611ce9f6493502e1b454f41b4f3c14868e8a45a76af493a01'
PAYLOAD='b5c550e6915598e514381817504b8db75446fa74e209b5f4deb49db139f3a6f6'
PIN_BASE='d0ccef65bcbe0c90483e6c0f691ed95f92228c6c'
RUNTIME='24b876fe068823c964c6796b0c8bf5a3bf4c090e'
FROZEN='165055f1c840821d89df1d7673468c0a19f20185'
MAX_FILE=128*1024*1024
MAX_TOTAL=512*1024*1024
def sha(raw):return hashlib.sha256(raw).hexdigest()
def regular(path):
    info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and not getattr(info,'st_file_attributes',0)&1024,str(path)
    assert info.st_size<=MAX_FILE,str(path)
    return info
def dump(name,value):
    path=OUT/name
    with path.open('x',encoding='utf8') as stream:json.dump(value,stream,indent=2);stream.write('\n')
    return sha(path.read_bytes())
def safe_paths(names):
    aliases={}
    for name in names:
        assert isinstance(name,str) and name and len(name)<=4096 and '\\' not in name and not name.startswith('/')
        parts=name.split('/');assert len(parts)<=64
        for count in range(1,len(parts)+1):
            component=parts[count-1];normalized=unicodedata.normalize('NFKC',component)
            assert component and normalized not in ('.','..') and not normalized.endswith(('.', ' '))
            assert not any(c in normalized for c in '/\\:<>"|?*') and not any(ord(c)<32 or 127<=ord(c)<160 for c in normalized)
            assert not re.fullmatch(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',normalized,re.I)
            parent='/'.join(parts[:count]);kind='file' if count==len(parts) else 'directory'
            alias=unicodedata.normalize('NFKC',parent).casefold()
            assert alias not in aliases or aliases[alias]==(parent,kind)
            aliases[alias]=(parent,kind)
def authenticate_packet():
    for directory in (PACKET,*PACKET.parents):
        info=directory.lstat();assert stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024
    raw=(PACKET/'manifest.json').read_bytes();regular(PACKET/'manifest.json');assert sha(raw)==MANIFEST
    def pairs(rows):
        value={}
        for key,item in rows:assert key not in value;value[key]=item
        return value
    def integer(text):assert len(text.lstrip('-'))<=20;return int(text)
    value=json.loads(raw.decode('utf8'),object_pairs_hook=pairs,parse_int=integer)
    assert set(value)=={'schema','authority','status','acceptanceGranted','release','inputManifestSHA256','source','files','payload'}
    assert type(value['schema']) is int and value['schema']==1 and value['acceptanceGranted'] is False and value['release']=='NO_GO'
    assert value['status']=='SUBMITTED_REVIEW_REQUIRED' and value['authority']=='BRAIN-M1X-REAL-FIRST-VALUE25-SOURCE-CANDIDATE-01'
    assert value['source']['base']==PIN_BASE and value['source']['runtimeHead']==RUNTIME and value['source']['sourceHead']==FROZEN
    assert set(value['files'])=={'README.md','REPORT.md','payload.zip','verify25.py'}
    assert {path.name for path in PACKET.iterdir()}==set(value['files'])|{'manifest.json'}
    outer={}
    for name,witness in value['files'].items():
        path=PACKET/name;info=regular(path);body=path.read_bytes()
        assert set(witness)=={'bytes','sha256'} and type(witness['bytes']) is int and info.st_size==len(body)==witness['bytes'] and sha(body)==witness['sha256']
        outer[name]={'bytes':len(body),'sha256':sha(body)}
    assert outer['verify25.py']['sha256']==VERIFIER and outer['payload.zip']['sha256']==PAYLOAD
    declared=value['payload']['files'];assert 0<len(declared)<20000;safe_paths(declared)
    payload=(PACKET/'payload.zip').read_bytes()
    end=payload.rfind(b'PK\x05\x06',max(0,len(payload)-65557));assert end>=0 and end+22==len(payload)
    disk,start,disk_count,count,size,offset,comment=struct.unpack_from('<HHHHIIH',payload,end+4)
    assert disk==start==0 and disk_count==count==len(declared) and count<20000 and comment==0 and offset+size==end
    total=0
    with zipfile.ZipFile(PACKET/'payload.zip') as archive:
        infos=archive.infolist();assert len(infos)==len(declared) and {item.filename for item in infos}==set(declared)
        for item in infos:
            assert not item.is_dir() and item.create_system==3 and stat.S_IFMT(item.external_attr>>16)==stat.S_IFREG
            assert not (item.external_attr>>16)&(stat.S_ISUID|stat.S_ISGID|stat.S_ISVTX) and not item.external_attr&1024
            assert item.flag_bits in (0,2048) and not item.extra and not item.comment and item.compress_type in (0,8)
            witness=declared[item.filename]
            assert set(witness)=={'bytes','sha256'} and type(witness['bytes']) is int and item.file_size==witness['bytes']<=MAX_FILE
            assert item.file_size<=max(1024*1024,item.compress_size*500)
            body=archive.read(item);assert len(body)==item.file_size and sha(body)==witness['sha256']
            total+=len(body);assert total<=MAX_TOTAL
    return {'manifestSHA256':MANIFEST,'verifierSHA256':VERIFIER,'outer':outer,'payloadFiles':len(declared),'payloadExpandedBytes':total,
      'qualification':'INDEPENDENT_EXTERNAL_ANCHOR_AND_COMPLETE_PAYLOAD_HASHES_BEFORE_PACKET_VERIFIER_EXECUTION'}
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--expected-head',required=True);parser.add_argument('--expected-tree',required=True);args=parser.parse_args()
    assert re.fullmatch('[0-9a-f]{40}',args.expected_head) and re.fullmatch('[0-9a-f]{40}',args.expected_tree)
    OUT.mkdir(parents=True,exist_ok=False)
    env={key:value for key,value in os.environ.items() if not key.upper().startswith(('GIT_','GITHUB_','PHASE4_','NPM_'))}
    env['CI']='1';env['PYTHONDONTWRITEBYTECODE']='1';steps=[]
    def run(name,argv,expected=0,timeout=900):
        print(json.dumps({'event':'START','name':name,'argv':argv}),flush=True)
        started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
        stdout=OUT/(name+'.stdout.log');stderr=OUT/(name+'.stderr.log')
        with stdout.open('xb') as out,stderr.open('xb') as err:
            try:
                result=subprocess.run(argv,cwd=ROOT,env=env,stdout=out,stderr=err,timeout=timeout)
                code=result.returncode;timedOut=False
            except subprocess.TimeoutExpired:
                code=None;timedOut=True
        row={'name':name,'argv':argv,'cwd':str(ROOT),'startedUTC':started,'exit':code,'expectedExit':expected,'timeout':timedOut,
          'durationSeconds':round(time.monotonic()-start,3),'stdoutSHA256':sha(stdout.read_bytes()),'stderrSHA256':sha(stderr.read_bytes())}
        try:row['json']=json.loads(stdout.read_bytes().decode('utf8'))
        except (ValueError,UnicodeError):pass
        dump(name+'.receipt.json',row);steps.append(row)
        print(json.dumps({'event':'FINISH',**row}),flush=True)
        assert code==expected,name
        return row
    def git(*argv):
        result=subprocess.run(['git','--no-replace-objects','--no-optional-locks',*argv],cwd=ROOT,env=env,capture_output=True,timeout=900)
        assert result.returncode==0,(argv,result.stderr.decode('utf8','replace'))
        return result.stdout
    def identity():
        assert git('rev-parse','HEAD').decode().strip()==args.expected_head
        assert git('rev-parse','HEAD^{tree}').decode().strip()==args.expected_tree
        assert not git('status','--porcelain=v1','--untracked-files=all','-z')
    def inventory(name):
        identity();tree={}
        for record in git('ls-tree','-r','-z','HEAD').split(b'\0'):
            if not record:continue
            meta,path=record.split(b'\t',1);mode,kind,oid=meta.decode().split();path=path.decode('utf8')
            assert kind=='blob' and mode in ('100644','100755') and path not in tree
            tree[path]=(mode,oid)
        safe_paths(tree);indexed={}
        for record in git('ls-files','--stage','-z').split(b'\0'):
            if not record:continue
            meta,path=record.split(b'\t',1);mode,oid,stage=meta.decode().split();assert stage=='0'
            indexed[path.decode('utf8')]=(mode,oid)
        assert tree==indexed and all(record.startswith(b'H ') for record in git('ls-files','-v','-z').split(b'\0') if record)
        rows={}
        for path,(mode,oid) in tree.items():
            target=ROOT/path;info=regular(target);raw=target.read_bytes()
            assert len(raw)==info.st_size and hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()==oid,path
            rows[path]={'mode':mode,'blob':oid,'bytes':len(raw),'sha256':sha(raw)}
        identity();digest=dump(name,rows)
        print(json.dumps({'event':'INVENTORY','name':name,'files':len(rows),'sha256':digest}),flush=True)
        return rows,digest
    packet=authenticate_packet();dump('independent-packet-authentication.json',packet)
    print(json.dumps({'event':'AUTHENTICATED',**packet}),flush=True)
    assert not git('status','--porcelain=v1','--untracked-files=all','-z')
    run('fetch-final-tail',['git','--no-replace-objects','fetch','--no-tags','origin','stage/m1-real-first-value25'])
    assert git('rev-parse','FETCH_HEAD').decode().strip()==args.expected_head
    run('checkout-exact-final-tail',['git','--no-replace-objects','checkout','--detach',args.expected_head])
    identity();assert git('config','--local','--get','core.autocrlf').strip()==b'false'
    assert git('rev-parse','--is-shallow-repository').strip()==b'false'
    assert not (ROOT/'.git/commondir').exists() and not (ROOT/'.git/objects/info/alternates').exists() and not (ROOT/'.git/objects/info/http-alternates').exists()
    for directory,dirs,files in os.walk(ROOT/'.git/objects',followlinks=False):
        for name in [*dirs,*files]:
            info=(Path(directory)/name).lstat();assert not stat.S_ISLNK(info.st_mode) and not getattr(info,'st_file_attributes',0)&1024
            if name in files:assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
    run('full-object-fsck',['git','--no-replace-objects','fsck','--full','--no-dangling'])
    missing=git('rev-list','--objects','--all','--missing=print');assert not any(line.startswith(b'?') for line in missing.splitlines())
    dump('object-store.json',{'nonShallow':True,'standaloneHTTPSClone':True,'noAlternatesOrSharedObjects':True,'allRefsReachableObjectsPresent':True,
      'objectListingSHA256':sha(missing),'localAutocrlf':False,'head':args.expected_head,'tree':args.expected_tree})
    before,beforeSHA=inventory('raw-tracked-before.json')
    history=[];witnesses={}
    for line in git('rev-list','--reverse','--parents',PIN_BASE+'..'+args.expected_head).decode().splitlines():
        commit,parent=line.split();raw=git('diff-tree','--no-commit-id','--raw','--no-abbrev','--no-renames','-r','-z',parent,commit);pieces=raw.split(b'\0');changes=[]
        for position in range(0,len(pieces)-1,2):
            oldmode,newmode,oldblob,newblob,status=pieces[position].decode().split();path=pieces[position+1].decode()
            for oid in (oldblob,newblob):
                if oid=='0'*40 or oid in witnesses:continue
                body=git('cat-file','blob',oid);witnesses[oid]={'bytes':len(body),'sha256':sha(body)}
            changes.append({'path':path,'oldMode':oldmode.lstrip(':'),'newMode':newmode,'oldBlob':oldblob,'newBlob':newblob,'status':status})
        history.append({'commit':commit,'parent':parent,'tree':git('rev-parse',commit+'^{tree}').decode().strip(),'changes':changes})
    dump('all-changed-history-modes-blobs.json',{'base':PIN_BASE,'head':args.expected_head,'tree':args.expected_tree,'commits':history,'blobWitnesses':witnesses})
    command=[sys.executable,'-B',str(PACKET/'verify25.py'),'--root',str(PACKET),'--expected-manifest-sha256',MANIFEST,
      '--expected-verifier-sha256',VERIFIER,'--git-root',str(ROOT),'--expected-head',args.expected_head,'--expected-tree',args.expected_tree,'--execute-source-checks']
    run('full-current',command)
    producer='scripts/phase4/build-source-worklist.mjs'
    producerRaw=git('show',PIN_BASE+':'+producer);assert (ROOT/producer).read_bytes()==producerRaw
    run('phase4-current',[shutil.which('node'),producer,'--strict','--check'])
    target=ROOT/'04_repo_docs/README.md';originalStat=regular(target);original=target.read_bytes()
    offset=next(position for position,value in enumerate(original) if 65<=value<=90 or 97<=value<=122)
    modified=bytearray(original);modified[offset]^=32
    def metadata():
        info=target.stat();return {key:getattr(info,key) for key in ('st_dev','st_ino','st_mode','st_nlink','st_size','st_atime_ns','st_mtime_ns')}
    originalMeta={key:getattr(originalStat,key) for key in ('st_dev','st_ino','st_mode','st_nlink','st_size','st_atime_ns','st_mtime_ns')}
    try:
        with target.open('r+b') as stream:stream.write(modified);stream.flush();os.fsync(stream.fileno())
        os.utime(target,ns=(originalStat.st_atime_ns,originalStat.st_mtime_ns))
        status=git('status','--porcelain=v1','--untracked-files=all','-z')
        dump('tamper-control.json',{'path':'04_repo_docs/README.md','originalSHA256':sha(original),'tamperedSHA256':sha(modified),
          'sameLength':len(original)==len(modified),'sameInode':target.stat().st_ino==originalStat.st_ino,
          'sameMtime':target.stat().st_mtime_ns==originalStat.st_mtime_ns,'gitStatusClean':not status,'gitStatus':status.decode().replace('\0','\n'),
          'qualification':'STAT_CACHE_HIDDEN_ACTUAL' if not status else 'GIT_STATUS_DETECTED_ACTUAL;NO_STAT_CACHE_HIDING_CLAIM'})
        run('full-tampered',command,1)
        run('direct-checker-tampered',[sys.executable,'-B','scripts/release/full-app-j01/check.py'],1)
    finally:
        with target.open('r+b') as stream:stream.write(original);stream.flush();os.fsync(stream.fileno())
        os.chmod(target,stat.S_IMODE(originalStat.st_mode))
        assert target.read_bytes()==original
        os.utime(target,ns=(originalStat.st_atime_ns,originalStat.st_mtime_ns))
        restored=metadata();assert restored==originalMeta,(restored,originalMeta)
        dump('exact-restoration.json',{'path':'04_repo_docs/README.md','original':originalMeta,'restored':restored,'identical':True,'sha256':sha(original)})
    run('full-restored',command)
    run('phase4-restored',[shutil.which('node'),producer,'--strict','--check'])
    after,afterSHA=inventory('raw-tracked-after.json');assert before==after
    identity();assert (ROOT/producer).read_bytes()==producerRaw
    summary={'qualification':'INDEPENDENT_FINAL_HEAD_SOURCE_ONLY;SUBMITTED_REVIEW_REQUIRED;NO_ACCEPTANCE_GRANTED','head':args.expected_head,'tree':args.expected_tree,
      'remote':'https://github.com/TasfiqJ/onSkin.git','packet':packet,'sameFullCommandExits':[0,1,0],'directTamperedCheckerExit':1,
      'rawTrackedFiles':len(before),'rawTrackedBeforeSHA256':beforeSHA,'rawTrackedAfterSHA256':afterSHA,'rawTrackedInventoriesIdentical':True,
      'trackedIndexAndWorkingSourceClean':True,'phase4ProducerSHA256':sha(producerRaw),'originalProducerStrictExits':[0,0],
      'release':'NO_GO','acceptanceGranted':False,'steps':steps,'allCachesExcludedFromEvidence':True}
    digest=dump('final-b-summary.json',summary);print(json.dumps({'event':'COMPLETE','summarySHA256':digest,'head':args.expected_head,'tree':args.expected_tree,'sameFullCommandExits':[0,1,0],'rawTrackedFiles':len(before)}),flush=True)

if __name__=='__main__':main()
