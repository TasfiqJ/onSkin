"""External-only Campaign25 packaging; no source writes, uploads or acceptance."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import zipfile

HERE = Path(__file__).resolve().parent
VERIFIER_SHA256 = '5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a'
CHECKPOINT_VERIFIER_SHA256 = 'e12a0e3ae733b3c611ce9f6493502e1b454f41b4f3c14868e8a45a76af493a01'
FINAL_HEAD = '52a3d01ebb36a6845d0ac21935ad35520732633f'
FINAL_TREE = 'ef49a81ca814f3d82b8a868e0308b6dda09c9cca'

def encoded(value): return (json.dumps(value, sort_keys=True, indent=2)+'\n').encode('utf-8')
def sha(raw): return hashlib.sha256(raw).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--git-root', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--checkpoint-manifest-sha256', required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--extras', type=Path, help='Explicit sanitized post-tail evidence directory; every regular file is inventoried.')
    parser.add_argument('--output', type=Path, required=True, help='NEW nonexistent external directory; its sibling .zip and annex files must also be absent.')
    args = parser.parse_args()
    own_verifier = HERE/'verify_return25.py'; outer_raw = own_verifier.read_bytes()
    if sha(outer_raw) != VERIFIER_SHA256: raise ValueError('PACKAGER_VERIFIER_IDENTITY')
    spec = importlib.util.spec_from_file_location('owned_return25', own_verifier)
    v = importlib.util.module_from_spec(spec); spec.loader.exec_module(v)
    root = Path(os.path.abspath(args.git_root)); checkpoint_root = Path(os.path.abspath(args.checkpoint))
    output = Path(os.path.abspath(args.output)); zip_path = output.parent/(output.name+'.zip')
    annex_path = output.parent/(output.name+'.hashes.json')
    report_path = output.parent/(output.name+'.FINAL_REPORT.complete.md')
    for parent in (output.parent,*output.parent.parents): v.node(parent,True)
    v.need(not any(os.path.lexists(path) for path in (output,zip_path,annex_path,report_path)), 'PACKAGER_OUTPUT_EXISTS')
    v.need(not (output == root or root in output.parents) and not (output == checkpoint_root or checkpoint_root in output.parents), 'PACKAGER_EXTERNAL_OUTPUT_REQUIRED')
    head = v.git(root,'rev-parse','HEAD').decode().strip(); tree = v.git(root,'rev-parse','HEAD^{tree}').decode().strip()
    v.need(head == FINAL_HEAD and tree == FINAL_TREE, 'PACKAGER_FINAL_SOURCE_IDENTITY')
    checkpoint = v.checkpoint(v.Directory(checkpoint_root),args.checkpoint_manifest_sha256)
    checkpoint_files = {name:v.read_regular(checkpoint_root/name) for name in sorted(v.CHECKPOINT_FILES)}
    v.need(sha(checkpoint_files['verify25.py']) == CHECKPOINT_VERIFIER_SHA256 and
           checkpoint_files['verify25.py'] == outer_raw.replace(b"MODE = 'return'",b"MODE = 'checkpoint'",1), 'PACKAGER_CHECKPOINT_VERIFIER_IDENTITY')
    report = v.read_regular(args.report)
    v.need(report and len(report) <= 16*1024*1024, 'PACKAGER_REPORT_BOUND')
    source = dict(checkpoint['source'],candidateHead=head,candidateTree=tree)
    # Exact per-commit/cumulative before/after modes, blob IDs, bytes and hashes.
    history = v.git_history(root,source)
    files = {'FINAL_REPORT.md':report,'verify_return25.py':outer_raw,'path-history.json':encoded(history)}
    files.update({'checkpoint/'+name:raw for name,raw in checkpoint_files.items()})
    files['REPRODUCE.md'] = ('''# Campaign25 reproduction

Authenticate the external manifest/verifier SHA256 values from the separate hash annex before executing downloaded code. All results remain NO_GO / SUBMITTED_REVIEW_REQUIRED / acceptanceGranted=false.

Artifact integrity only (source checks are NOT_RUN here):

```
python -B verify_return25.py --root . --expected-manifest-sha256 OUTER_MANIFEST_SHA256_FROM_EXTERNAL_ANNEX --expected-verifier-sha256 '''+VERIFIER_SHA256+'''
```

For each independent complete clean remote checkout at final HEAD '''+head+''' / tree '''+tree+''':

```
python -B EXTERNAL/verify_return25.py --archive RETURN.zip --expected-manifest-sha256 OUTER_MANIFEST_SHA256_FROM_EXTERNAL_ANNEX --expected-verifier-sha256 '''+VERIFIER_SHA256+''' --git-root CLEAN_FINAL_CHECKOUT --expected-head '''+head+''' --expected-tree '''+tree+''' --execute-source-checks
```

Require exact final source ancestry/inventory, sole evidence tail, RAW_TRACKED_BLOBS_EXACT, the audited Release25 checker and unchanged strict Phase4. Artifact integrity alone does not execute or accept source. All independent proof/CI receipts remain separately qualified. The minimal bundle requires exact PR28 '''+v.BASE+'''. No merges, production access or spend.
''').encode('utf-8')
    if args.extras:
        extras = Path(os.path.abspath(args.extras)); v.node(extras,True); stack=[extras]; count=0
        while stack:
            parent=stack.pop()
            with os.scandir(parent) as entries:
                for entry in entries:
                    path=Path(entry.path); info=path.lstat(); count+=1; v.need(count <= v.MAX_FILES,'PACKAGER_EXTRA_BOUND')
                    name=path.relative_to(extras).as_posix(); v.safe_path(name)
                    if stat.S_ISDIR(info.st_mode): v.node(path,True); stack.append(path)
                    else: files['post-tail/'+name]=v.read_regular(path)
    v.paths(files)
    v.need(len(files)+2 < v.MAX_FILES and sum(map(len,files.values())) <= v.MAX_TOTAL,'PACKAGER_TOTAL_BOUND')
    output.mkdir()
    # Native Git writes only the explicitly task-owned external bundle file.
    bundle=output/'source.delta.bundle'
    v.git(root,'bundle','create',str(bundle),'HEAD','^'+v.BASE)
    files['source.delta.bundle']=v.read_regular(bundle)
    for name,raw in sorted(files.items()):
        if name == 'source.delta.bundle': continue
        path=output/name;path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream:stream.write(raw)
    value=dict(schema=1,authority=v.AUTHORITY,status='SUBMITTED_REVIEW_REQUIRED',acceptanceGranted=False,release='NO_GO',
        inputManifestSHA256=v.INPUT,source=source,qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
        checkpoint=dict(path='checkpoint',manifestSHA256=args.checkpoint_manifest_sha256),
        gitDelta=dict(path='source.delta.bundle',base=v.BASE,baseTree=v.BASE_TREE,head=head,tree=tree),
        gitHistory=dict(path='path-history.json'),files={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(files.items())})
    manifest_raw=encoded(value)
    with (output/'manifest.json').open('xb') as stream:stream.write(manifest_raw)
    manifest_sha=sha(manifest_raw)
    # Integrity checks execute the already authenticated owned verifier engine.
    artifact=v.return_packet(v.Directory(output),manifest_sha)
    with zipfile.ZipFile(zip_path,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name,raw in sorted(dict(files,**{'manifest.json':manifest_raw}).items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,29,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,raw)
    v.need(zip_path.stat().st_size < 100*1024*1024,'PACKAGER_PUBLIC_ZIP_BOUND')
    zip_raw=v.read_regular(zip_path)
    v.return_packet(v.Archive(zip_raw),manifest_sha)
    v.need(v.git(root,'rev-parse','HEAD').decode().strip() == head and
           v.git(root,'rev-parse','HEAD^{tree}').decode().strip() == tree,'PACKAGER_SOURCE_CHANGED')
    hashes=dict(outerZIP=zip_path.name,outerZIPBytes=len(zip_raw),outerZIPSHA256=sha(zip_raw),outerManifestSHA256=manifest_sha,
        outerVerifierSHA256=VERIFIER_SHA256,checkpointManifestSHA256=args.checkpoint_manifest_sha256,
        checkpointVerifierSHA256=CHECKPOINT_VERIFIER_SHA256,head=head,tree=tree,
        qualification='PACKAGING_INTEGRITY_ONLY_SOURCE_CHECKS_NOT_RUN_BY_BUILDER',acceptanceGranted=False,release='NO_GO')
    complete=report+b'\n\n## External final artifact hash annex\n\nThis annex was written after the ZIP and its internal report were frozen. It is outside the ZIP to avoid circular hashes. Packaging integrity does not substitute for the separately qualified final source, CI or native evidence.\n\n```json\n'+encoded(hashes)+b'```\n'
    with report_path.open('xb') as stream:stream.write(complete)
    hashes['completeFinalReport']=report_path.name;hashes['completeFinalReportSHA256']=sha(complete)
    with annex_path.open('xb') as stream:stream.write(encoded(hashes))
    print(json.dumps(dict(status='PACKAGED',**hashes,artifact=artifact),sort_keys=True))

if __name__ == '__main__':
    try: main()
    except Exception:
        print(json.dumps(dict(status='PACKAGING_INCOMPLETE',acceptanceGranted=False,release='NO_GO')))
        sys.exit(1)
