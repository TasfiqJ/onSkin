# Campaign25 reproduction

Authenticate the external manifest/verifier SHA256 values from the separate hash annex before executing downloaded code. All results remain NO_GO / SUBMITTED_REVIEW_REQUIRED / acceptanceGranted=false.

Artifact integrity only (source checks are NOT_RUN here):

```
python -B verify_return25.py --root . --expected-manifest-sha256 OUTER_MANIFEST_SHA256_FROM_EXTERNAL_ANNEX --expected-verifier-sha256 5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a
```

For each independent complete clean remote checkout at final HEAD 52a3d01ebb36a6845d0ac21935ad35520732633f / tree ef49a81ca814f3d82b8a868e0308b6dda09c9cca:

```
python -B EXTERNAL/verify_return25.py --archive RETURN.zip --expected-manifest-sha256 OUTER_MANIFEST_SHA256_FROM_EXTERNAL_ANNEX --expected-verifier-sha256 5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a --git-root CLEAN_FINAL_CHECKOUT --expected-head 52a3d01ebb36a6845d0ac21935ad35520732633f --expected-tree ef49a81ca814f3d82b8a868e0308b6dda09c9cca --execute-source-checks
```

Require exact final source ancestry/inventory, sole evidence tail, RAW_TRACKED_BLOBS_EXACT, the audited Release25 checker and unchanged strict Phase4. Artifact integrity alone does not execute or accept source. All independent proof/CI receipts remain separately qualified. The minimal bundle requires exact PR28 d0ccef65bcbe0c90483e6c0f691ed95f92228c6c. No merges, production access or spend.
