"""Prepare new Campaign23 artifact directories; never commit, seal or publish."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import zipfile

import verify_return23 as v


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def witness(raw):
    return dict(bytes=len(raw), sha256=v.sha(raw))


def fresh(path):
    path = Path(os.path.abspath(path))
    for parent in path.parents:
        v.node(parent, True)
    path.mkdir()
    return path


def outside_checkout(output, root):
    destination = Path(os.path.abspath(output)).resolve()
    checkout = Path(os.path.abspath(root)).resolve()
    v.need(checkout not in (destination, *destination.parents), 'BUILDER_OUTPUT_INSIDE_CHECKOUT')


def write(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)


def archive(files, outer=False):
    if outer:
        v.need('manifest.json' in files and len(files['manifest.json']) <= 16*1024*1024,
            'BUILDER_OUTER_MANIFEST')
    v.inventory({name: witness(raw) for name, raw in files.items() if not outer or name != 'manifest.json'})
    v.need(sum(map(len, files.values())) <= v.MAX_TOTAL, 'BUILDER_TOTAL_BOUND')
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for name, raw in sorted(files.items()):
            item = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            item.create_system = 3
            item.external_attr = (stat.S_IFREG | 0o644) << 16
            item.compress_type = zipfile.ZIP_DEFLATED
            target.writestr(item, raw)
    result = stream.getvalue()
    parsed = v.Archive(result)
    parsed.exact(files)
    v.need(all(parsed.read(name) == raw for name, raw in files.items()), 'BUILDER_ARCHIVE_ROUNDTRIP')
    return result


def inputs(path):
    value = v.loads(v.read_regular(Path(path))) if path else {}
    v.need(type(value) is dict, 'BUILDER_INPUT_MAP')
    v.need(len(value) < v.MAX_FILES, 'BUILDER_INPUT_COUNT_BOUND')
    v.paths(value)
    result, total = {}, 0
    for name, source in value.items():
        v.need(type(source) is str and Path(source).is_absolute(), 'BUILDER_INPUT_MAP')
        # Explicit sanitized files only; never recurse into historical/private stores.
        tokens = ('private-review', 'raw-findings', 'gitleaks-results', 'trufflehog-results',
                  'secret-scan-proof', '3bc6b787')
        v.need(not any(token in source.casefold() for token in tokens) and
            not any(re.search(r'(^|[-_])private([_-]|$)', part.casefold()) for part in Path(source).parts),
            'BUILDER_PROTECTED_INPUT')
        data = v.read_regular(Path(source), min(v.MAX_FILE, v.MAX_TOTAL - total))
        total += len(data)
        v.need(total <= v.MAX_TOTAL, 'BUILDER_TOTAL_BOUND')
        result[name] = data
    return result


def source(root, runtime, frozen):
    v.need(v.HEX40.fullmatch(runtime) and v.HEX40.fullmatch(frozen), 'BUILDER_SOURCE_IDENTITY')
    return dict(base=v.BASE, baseTree=v.BASE_TREE, runtimeHead=runtime,
        runtimeTree=v.git(root, 'rev-parse', runtime+'^{tree}').decode().strip(), sourceHead=frozen,
        sourceTree=v.git(root, 'rev-parse', frozen+'^{tree}').decode().strip())


def envelope(binding, files):
    return dict(schema=1, authority=v.AUTHORITY, status='SUBMITTED_REVIEW_REQUIRED',
        acceptanceGranted=False, release='NO_GO', inputManifestSHA256=v.INPUT,
        source=binding, files={name: witness(raw) for name, raw in files.items()})


def checkpoint(args):
    outside_checkout(args.output, args.git_root)
    binding = source(args.git_root, args.runtime_head, args.source_head)
    v.need(v.git(args.git_root, 'rev-parse', 'HEAD').decode().strip() == args.source_head, 'BUILDER_FREEZE_HEAD')
    checked = v.verify_git(args.git_root, binding)
    v.need(checked['evidenceTail'] is False, 'BUILDER_ALREADY_SEALED')
    payload = inputs(args.evidence_map)
    v.need(bool(payload), 'BUILDER_EMPTY_PAYLOAD')
    files = {'README.md': v.read_regular(Path(args.readme)),
        'FINAL_REPORT.md': v.read_regular(Path(args.report)), 'payload.zip': archive(payload),
        'verify23.py': v.read_regular(Path(__file__).with_name('verify23.py'))}
    manifest = envelope(binding, files)
    manifest['payload'] = dict(schema=1, qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',
        files={name: witness(raw) for name, raw in payload.items()})
    destination = fresh(args.output)
    for name, raw in files.items():
        write(destination/name, raw)
    raw = encoded(manifest); write(destination/'manifest.json', raw)
    v.checkpoint(v.Directory(destination), v.sha(raw))
    anchors = dict(manifestSHA256=v.sha(raw), verifierSHA256=v.sha(files['verify23.py']),
        payloadSHA256=v.sha(files['payload.zip']), qualification='ARTIFACT_INTEGRITY_ONLY_NOT_ACCEPTANCE')
    write(Path(str(destination)+'.anchors.json'), encoded(anchors))
    return dict(state='PREPARED_NOT_COMMITTED_NOT_SEALED', **anchors)


def return_packet(args):
    outside_checkout(args.output, args.git_root)
    cp = v.Directory(args.checkpoint_dir)
    cp_raw = cp.read('manifest.json'); inner = v.checkpoint(cp, v.sha(cp_raw))
    binding = dict(inner['source'])
    binding.update(candidateHead=v.git(args.git_root, 'rev-parse', 'HEAD').decode().strip(),
        candidateTree=v.git(args.git_root, 'rev-parse', 'HEAD^{tree}').decode().strip())
    checked = v.verify_git(args.git_root, binding, cp)
    v.need(checked['evidenceTail'], 'BUILDER_FINAL_TAIL_REQUIRED')
    files = inputs(args.extra_map)
    fixed = {'FINAL_REPORT.md', 'verify_return23.py', 'source.delta.bundle', 'source-paths.json'}
    v.need(not set(files) & fixed and not any(name.startswith('checkpoint/') for name in files), 'BUILDER_RESERVED_PATH')
    files.update({'checkpoint/'+name: cp.read(name) for name in v.CHECKPOINT_FILES})
    files['FINAL_REPORT.md'] = v.read_regular(Path(args.report))
    files['verify_return23.py'] = v.read_regular(Path(__file__).with_name('verify_return23.py'))
    previous = v.BASE; commits = []
    for commit in v.git(args.git_root, 'rev-list', '--reverse', v.BASE+'..'+binding['candidateHead']).decode().splitlines():
        delta = v.diff(args.git_root, previous, commit)
        commits.append(dict(head=commit, parent=previous,
            tree=v.git(args.git_root, 'rev-parse', commit+'^{tree}').decode().strip(),
            paths=[dict(path=name, oldMode=row[0][1:], mode=row[1], oldBlob=row[2], blob=row[3], status=row[4])
                for name, row in sorted(delta.items())]))
        previous = commit
    files['source-paths.json'] = encoded(dict(schema=1, base=v.BASE, baseTree=v.BASE_TREE, commits=commits))
    destination = fresh(args.output)
    bundle = destination/'source.delta.bundle'
    # HEAD is verified before and after; the anchored manifest and bundle header
    # must still name the exact frozen object, so a concurrent ref change refuses.
    v.git(args.git_root, 'bundle', 'create', str(bundle), 'HEAD', '^'+v.BASE)
    v.need(v.git(args.git_root, 'rev-parse', 'HEAD').decode().strip() == binding['candidateHead'],
        'BUILDER_FINAL_HEAD_CHANGED')
    files['source.delta.bundle'] = v.read_regular(bundle)
    for name, raw in files.items():
        path = destination.joinpath(*name.split('/'))
        path.parent.mkdir(parents=True, exist_ok=True)
        if name != 'source.delta.bundle': write(path, raw)
    manifest = envelope(binding, files)
    manifest.update(qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
        checkpoint=dict(path='checkpoint', manifestSHA256=v.sha(cp_raw)),
        gitDelta=dict(path='source.delta.bundle', base=v.BASE, baseTree=v.BASE_TREE,
            head=binding['candidateHead'], tree=binding['candidateTree']))
    raw = encoded(manifest); write(destination/'manifest.json', raw)
    v.return_packet(v.Directory(destination), v.sha(raw), args.git_root)
    outer = archive({**files, 'manifest.json': raw}, outer=True)
    v.return_packet(v.Archive(outer), v.sha(raw))
    write(Path(str(destination)+'.zip'), outer)
    anchors = dict(manifestSHA256=v.sha(raw), verifierSHA256=v.sha(files['verify_return23.py']),
        zipSHA256=v.sha(outer), checkpointManifestSHA256=v.sha(cp_raw),
        head=binding['candidateHead'], tree=binding['candidateTree'],
        qualification='ARTIFACT_INTEGRITY_ONLY_NOT_ACCEPTANCE')
    write(Path(str(destination)+'.anchors.json'), encoded(anchors))
    return dict(state='PREPARED_NOT_PUBLISHED', filesIncludingManifest=len(files)+1, **anchors)


def main():
    class Parser(argparse.ArgumentParser):
        def error(self, _): raise v.Refusal('BUILDER_ARGUMENT_SCHEMA')
    parser = Parser(description=__doc__); commands = parser.add_subparsers(dest='command', required=True)
    cp = commands.add_parser('checkpoint'); ret = commands.add_parser('return')
    for child in (cp, ret):
        child.add_argument('--git-root', required=True); child.add_argument('--report', required=True)
        child.add_argument('--output', required=True)
    cp.add_argument('--runtime-head', required=True); cp.add_argument('--source-head', required=True)
    cp.add_argument('--readme', required=True); cp.add_argument('--evidence-map', required=True)
    ret.add_argument('--checkpoint-dir', required=True); ret.add_argument('--extra-map')
    try:
        args = parser.parse_args(); value = checkpoint(args) if args.command == 'checkpoint' else return_packet(args)
        print(json.dumps(value, sort_keys=True)); return 0
    except BaseException:
        print(json.dumps(dict(state='INCOMPLETE', error='PACKAGING_REFUSED', acceptanceGranted=False, release='NO_GO')))
        return 1


if __name__ == '__main__': sys.exit(main())
