"""Exact-checkout source proof; public fixed results, outside tracked source."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main():
    if sys.flags.optimize:
        print(json.dumps(dict(state='INCOMPLETE',reason='OPTIMIZED_PROOF_EXECUTION_FORBIDDEN',acceptanceGranted=False,release='NO_GO')))
        return 2
    parser = argparse.ArgumentParser()
    for name in ('root', 'output', 'head', 'tree'): parser.add_argument('--'+name, required=True)
    parser.add_argument('--controls', action='store_true')
    parser.add_argument('--checkpoint-manifest')
    parser.add_argument('--checkpoint-verifier')
    args = parser.parse_args(); root = Path(args.root).absolute()
    sys.path.insert(0, str(root/'scripts/security22'))
    from collect import execute
    from redact import diagnostic
    result = dict(schema=1, qualification='ACTUAL_INDEPENDENT_CHECKOUT_CURRENT_SOURCE_PROOF',
        acceptanceGranted=False, release='NO_GO', sourceAcceptance='SUBMITTED_REVIEW_REQUIRED',
        head=args.head, tree=args.tree, results=[], startedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
    candidate = root/'docs/brain/contracts/M1X-23/candidate.json'; original = None
    environment = {k:v for k,v in os.environ.items() if k.upper() != 'PYTHONOPTIMIZE' and not k.upper().startswith(('GIT_', 'NPM_', 'PHASE4_', 'GITHUB_'))}
    os.environ.clear(); os.environ.update(environment)
    def git(*argv):
        code, out, err = execute(['git', '-c', 'core.longpaths=true', *argv], root, seconds=120)
        if code or err: raise ValueError('GIT_REFUSED')
        return out
    def check(label):
        start = time.monotonic()
        checkpoint = root/'docs/brain/checkpoints/M1-03/SECURITY-INTEGRATION-23'
        if args.checkpoint_manifest:
            verifier = checkpoint/'verify23.py'
            assert args.checkpoint_verifier and hashlib.sha256(verifier.read_bytes()).hexdigest() == args.checkpoint_verifier
            command = [sys.executable,'-I','-B',str(verifier),'--root',str(checkpoint),
                '--expected-manifest-sha256',args.checkpoint_manifest,
                '--expected-verifier-sha256',args.checkpoint_verifier,
                '--git-root',str(root),'--expected-head',args.head,'--expected-tree',args.tree,'--execute-source-checks']
        else: command = [sys.executable, '-B', 'scripts/release/full-app-j01/check.py']
        code, out, err = execute(command, root, seconds=1200 if args.checkpoint_manifest else 900)
        value = json.loads(out)
        item = dict(label=label, exit=code, seconds=round(time.monotonic()-start,3),
            stdoutSHA256=hashlib.sha256(out).hexdigest(), stderrSHA256=hashlib.sha256(err).hexdigest())
        if code == 0:
            if args.checkpoint_manifest:
                assert value['status']=='VERIFIED' and value['release']=='NO_GO' and value['acceptanceGranted'] is False
                assert value['git']['head']==args.head and value['git']['tree']==args.tree and value['git']['evidenceTail'] is True
                assert value['sourceChecks']['release23']=='PASS_FINITE_SOURCE_GOVERNANCE_ONLY'
                assert value['sourceChecks']['phase4']=='PASS_UNCHANGED_PRODUCER_STRICT_CHECK'
                item.update(valid=True, checkpointManifestSHA256=args.checkpoint_manifest,
                    git=value['git'], sourceChecks=value['sourceChecks'], payloadFiles=value['payloadFiles'])
            else:
                assert value['valid'] is True and value['release'] == 'NO_GO' and value['source_acceptance'] == 'SUBMITTED_REVIEW_REQUIRED'
                assert value['current_source_governance'] == 'RELEASE23_FINITE_SCOPE_ONLY'
                item.update(valid=True, currentSourceGovernance=value['current_source_governance'])
        else:
            assert (value.get('status')=='CONTEXT_INVALID' if args.checkpoint_manifest else value['valid'] is False) and value['release'] == 'NO_GO'
            item.update(valid=False, reason=value['error'] if value.get('error') in ('R23_FROZEN_CHECKOUT_DIRTY','R23_NO_ADMISSION','GIT_CHECKOUT_DIRTY','GIT_WORKING_BLOB_MISMATCH') else 'FIXED_REFUSAL')
        result['results'].append(item); print(json.dumps(item), flush=True)
        return code
    try:
        assert git('rev-parse','HEAD').decode().strip() == args.head
        assert git('rev-parse','HEAD^{tree}').decode().strip() == args.tree
        assert not git('status','--porcelain=v1','--untracked-files=all')
        assert check('current') == 0
        if args.controls:
            original = candidate.read_bytes()
            candidate.write_bytes(original+b'\n')
            assert check('harmless-task-owned-working-byte-mutation') == 1
            candidate.write_bytes(original)
            git('update-index','--refresh')
            assert check('exactly-restored') == 0
            specification = importlib.util.spec_from_file_location('campaign23_check',root/'scripts/release/full-app-j01/check.py')
            checker = importlib.util.module_from_spec(specification); specification.loader.exec_module(checker)
            value = json.loads(original); value['admissions']['G97'] = True
            candidate.write_text(json.dumps(value, sort_keys=True)+'\n',encoding='utf8')
            try:
                checker.candidate23_guard(checker.regular23(candidate))
            except ValueError as error:
                assert error.args == ('R23_NO_ADMISSION',)
                result['semanticControl'] = dict(state='PASS',reason='R23_NO_ADMISSION',
                    qualification='ACTUAL_TASK_OWNED_ADMISSION_MUTATION_THROUGH_SEMANTIC_GUARD')
            else: raise ValueError('SEMANTIC_CONTROL_FAILED')
            candidate.write_bytes(original); git('update-index','--refresh')
            result.update(sourceControlExits=[item['exit'] for item in result['results']],
                restoredExactly=candidate.read_bytes() == original, protectedTaskPath='docs/brain/contracts/M1X-23/candidate.json')
        assert not git('status','--porcelain=v1','--untracked-files=all')
        assert git('rev-parse','HEAD').decode().strip() == args.head
        result.update(state='PASS', cleanBeforeAndAfter=True)
    except BaseException as error:
        result.update(state='INCOMPLETE', reason=diagnostic(error))
    finally:
        if original is not None and candidate.read_bytes() != original:
            candidate.write_bytes(original)
            try: git('update-index','--refresh')
            except BaseException: result['restorationIndexRefresh']='INCOMPLETE'
        with Path(args.output).open('x',encoding='utf8') as stream:
            json.dump(result,stream,indent=2); stream.write('\n')
    print(json.dumps({k:result[k] for k in ('state','head','tree','acceptanceGranted','release')}))
    return 0 if result['state']=='PASS' else 1


if __name__ == '__main__': sys.exit(main())
