"""Finite synthetic archive/parser/bootstrap controls; no final-checkout claim."""
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import struct
import subprocess
import sys
import tempfile
import warnings
import zipfile
import zlib

import package23 as p
import verify_return23 as v


def sample():
    source = dict(base=v.BASE, baseTree=v.BASE_TREE, runtimeHead='a'*40,
        runtimeTree='b'*40, sourceHead='c'*40, sourceTree='d'*40)
    payload = {'receipts/synthetic.json': p.encoded(dict(state='SYNTHETIC_ONLY', acceptanceGranted=False))}
    files = {'README.md': b'Synthetic parser control; not a delivery.\n',
        'FINAL_REPORT.md': b'Synthetic control; full checkout checks NOT_RUN.\n',
        'payload.zip': p.archive(payload), 'verify23.py': v.read_regular(Path(__file__).with_name('verify23.py'))}
    cp = p.envelope(source, files)
    cp['payload'] = dict(schema=1, qualification='SANITIZED_TECHNICAL_EVIDENCE_NOT_ACCEPTANCE',
        files={name: p.witness(raw) for name, raw in payload.items()})
    cp_raw = p.encoded(cp)
    files['manifest.json'] = cp_raw
    return files, cp, cp_raw


def bad_archive(names, mode=stat.S_IFREG | 0o644):
    out = io.BytesIO()
    with warnings.catch_warnings(record=True), zipfile.ZipFile(out, 'w') as target:
        for name in names:
            item = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            item.create_system = 3; item.external_attr = mode << 16
            target.writestr(item, b'synthetic-payload')
    return out.getvalue()


def main():
    results = []
    def check(name, action, refuses=False):
        try:
            action()
            state = 'FAIL' if refuses else 'PASS'
        except v.Refusal:
            state = 'PASS' if refuses else 'FAIL'
        except BaseException:
            state = 'INCOMPLETE'
        results.append(dict(name=name, state=state))

    files, cp, cp_raw = sample()
    check('checkpoint_positive', lambda: v.checkpoint(v.Archive(p.archive(files, outer=True)), v.sha(cp_raw)))
    for name, paths in [('traversal', ['../escape']), ('absolute', ['/escape']), ('drive', ['C:/escape']),
        ('duplicate', ['a', 'a']), ('case_parent_alias', ['A/x', 'a/y']),
        ('unicode_parent_alias', ['unicode-\u00e9/a', 'unicode-e\u0301/b']), ('file_directory_collision', ['a', 'a/b'])]:
        check(name, lambda paths=paths: v.Archive(bad_archive(paths)), True)
    check('symlink', lambda: v.Archive(bad_archive(['link'], stat.S_IFLNK | 0o777)), True)
    # Windows ZipInfo normalizes a supplied backslash before writing. Mutate
    # both equal-length filename fields to exercise the actual unsafe bytes.
    check('backslash', lambda: v.Archive(bad_archive(['a/b']).replace(b'a/b', b'a\\b')), True)
    normal = bad_archive(['a'])
    def modified(kind):
        raw = bytearray(normal); central = raw.index(b'PK\x01\x02'); end = raw.index(b'PK\x05\x06')
        if kind == 'unsupported_compression':
            struct.pack_into('<H', raw, 8, 99); struct.pack_into('<H', raw, central+10, 99)
        elif kind == 'local_identity': struct.pack_into('<I', raw, 14, 1)
        elif kind == 'claimed_expansion':
            struct.pack_into('<I', raw, 22, v.MAX_FILE+1); struct.pack_into('<I', raw, central+24, v.MAX_FILE+1)
        elif kind == 'member_count': struct.pack_into('<HH', raw, end+8, v.MAX_FILES+1, v.MAX_FILES+1)
        elif kind == 'crc': raw[31] ^= 1
        return v.Archive(bytes(raw)).read('a')
    for kind in ('unsupported_compression', 'local_identity', 'claimed_expansion', 'member_count', 'crc'):
        check(kind, lambda kind=kind: modified(kind), True)
    check('trailing_bytes', lambda: v.Archive(normal+b'\0'), True)
    check('path_depth', lambda: v.safe_path('/'.join(['a']*65)), True)
    check('duplicate_json_key', lambda: v.loads(b'{"a":1,"a":2}'), True)
    check('boolean_inventory_count', lambda: v.inventory({'a':dict(bytes=True, sha256='0'*64)}), True)
    check('self_hash_inventory', lambda: v.inventory({'manifest.json':p.witness(b'')}), True)
    for name, mutate in [('false_admission', lambda m:m.update(acceptanceGranted=True)),
        ('false_status', lambda m:m.update(status='ACCEPTED')), ('wrong_base', lambda m:m['source'].update(base='e'*40)),
        ('payload_omission', lambda m:m['payload']['files'].clear())]:
        altered = copy.deepcopy(cp); mutate(altered); raw = p.encoded(altered)
        packet = dict(files); packet['manifest.json'] = raw
        check(name, lambda packet=packet, raw=raw: v.checkpoint(v.Archive(p.archive(packet, outer=True)), v.sha(raw)), True)

    temporary = Path(tempfile.mkdtemp(prefix='package23-controls-'))
    try:
        cp_dir = temporary/'checkpoint'; cp_dir.mkdir()
        for name, raw in files.items(): p.write(cp_dir/name, raw)
        control = []
        def probe():
            try: v.checkpoint(v.Directory(cp_dir), v.sha(cp_raw)); control.append(0)
            except v.Refusal: control.append(1)
        probe(); original = files['payload.zip']
        (cp_dir/'payload.zip').write_bytes(original[:-1]+bytes([original[-1]^1])); probe()
        (cp_dir/'payload.zip').write_bytes(original); probe()
        check('actual_artifact_corruption_restoration_0_1_0', lambda: v.need(control == [0,1,0], 'CONTROL_FAILED'))

        # A real verifier executes only after the trusted bootstrap authenticates
        # this intentionally synthetic packet. No Git or source check is claimed.
        body = b'PACK'+struct.pack('>II', 2, 1)+bytes([0x39])+zlib.compress(b'synthetic')
        body += hashlib.sha1(body).digest()
        bundle = ('# v2 git bundle\n-'+v.BASE+' required pinned PR26\n'+'e'*40+' HEAD\n\n').encode()+body
        outer_files = {'checkpoint/'+name: raw for name, raw in files.items()}
        outer_files.update({'FINAL_REPORT.md': b'Synthetic bootstrap control only.\n', 'source.delta.bundle':bundle,
            'verify_return23.py':v.read_regular(Path(__file__).with_name('verify_return23.py'))})
        binding = dict(cp['source'], candidateHead='e'*40, candidateTree='f'*40)
        manifest = p.envelope(binding, outer_files)
        manifest.update(qualification='SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
            checkpoint=dict(path='checkpoint', manifestSHA256=v.sha(cp_raw)),
            gitDelta=dict(path='source.delta.bundle', base=v.BASE, baseTree=v.BASE_TREE, head='e'*40, tree='f'*40))
        outer_raw = p.encoded(manifest); outer_files['manifest.json'] = outer_raw
        raw = p.archive(outer_files, outer=True); outer_path = temporary/'synthetic-return.zip'; p.write(outer_path, raw)
        bootstrap = Path(__file__).with_name('bootstrap23.py')
        command = [sys.executable, '-I', '-B', str(bootstrap), '--archive', str(outer_path),
            '--expected-zip-sha256', v.sha(raw), '--expected-manifest-sha256', v.sha(outer_raw),
            '--expected-verifier-sha256', v.sha(outer_files['verify_return23.py']),
            '--expected-bootstrap-sha256', v.sha(v.read_regular(bootstrap))]
        child = subprocess.run(command, capture_output=True, timeout=60)
        def result():
            v.need(child.returncode == 0 and len(child.stdout) <= 1024*1024, 'CONTROL_FAILED')
            value = v.loads(child.stdout)
            v.need(value.get('status') == 'VERIFIED' and value.get('sourceChecks') == {'state':'NOT_RUN'} and
                value.get('acceptanceGranted') is False and b'Traceback' not in child.stderr, 'CONTROL_FAILED')
        check('externally_anchored_bootstrap_actual_execution', result)
        for label, index in [('wrong_zip_anchor',command.index('--expected-zip-sha256')+1),
                ('wrong_manifest_anchor',command.index('--expected-manifest-sha256')+1),
                ('wrong_verifier_anchor',command.index('--expected-verifier-sha256')+1)]:
            altered = list(command); altered[index] = '0'*64
            child = subprocess.run(altered, capture_output=True, timeout=60)
            check(label, lambda child=child: v.need(child.returncode == 1 and
                v.loads(child.stdout).get('status') == 'CONTEXT_INVALID', 'CONTROL_FAILED'))
    finally:
        # One verified task-created directory; never traverse or delete a checkout.
        v.need(temporary.parent == Path(tempfile.gettempdir()).resolve() and
            temporary.name.startswith('package23-controls-'), 'CONTROL_CLEANUP_SCOPE')
        import shutil
        shutil.rmtree(temporary)
    value = dict(schema=1, qualification='FINITE_SYNTHETIC_ARTIFACT_CONTROLS_ONLY', tests=len(results),
        passed=sum(r['state']=='PASS' for r in results), cases=results,
        inputs={name:v.sha(v.read_regular(Path(__file__).with_name(name))) for name in
            ('verify23.py', 'verify_return23.py', 'bootstrap23.py', 'package23.py', 'test_package23.py')},
        fullFinalCheckoutVerification='NOT_RUN_FINAL_HEAD_NOT_SEALED', acceptanceGranted=False, release='NO_GO')
    value['state'] = 'PASS' if value['passed'] == value['tests'] else 'INCOMPLETE'
    receipt = Path(__file__).with_name('package-tools-test-receipt.json'); counter = 0
    while receipt.exists():
        counter += 1
        receipt = Path(__file__).with_name('package-tools-test-receipt-'+str(counter)+'.json')
    p.write(receipt, p.encoded(value))
    print(json.dumps(value, sort_keys=True)); return 0 if value['state']=='PASS' else 1


if __name__ == '__main__': sys.exit(main())
