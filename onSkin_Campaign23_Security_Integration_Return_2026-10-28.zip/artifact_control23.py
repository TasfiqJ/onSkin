"""Run an externally anchored return-verifier 0/1/0 on a disposable ZIP copy."""
import argparse
import json
import os
from pathlib import Path
import struct
import sys
import tempfile

import verify_return23 as v


CONTROL_CODES = frozenset(('CONTROL_ANCHOR', 'CONTROL_COPY_IDENTITY', 'CONTROL_CHILD_RESULT',
    'CONTROL_EXPECTED_REFUSAL', 'CONTROL_MUTATION_TARGET', 'CONTROL_ORIGINAL_CHANGED',
    'CONTROL_OUTPUT_EXISTS', 'CONTROL_RECEIPT_SCOPE', 'CONTROL_RESTORATION',
    'CONTROL_TEMP_SCOPE', 'CONTROL_INCOMPLETE'))


def changed_crc(raw, member):
    """Change only the selected member's matching local/central CRC declarations."""
    parsed = v.Archive(raw)
    v.need(member in parsed.members, 'CONTROL_MUTATION_TARGET')
    item = parsed.members[member]
    result = bytearray(raw)
    struct.pack_into('<I', result, item.header_offset + 14, item.CRC ^ 1)
    end = len(raw) - 22  # Archive() already refused comments and trailing bytes.
    cursor = struct.unpack_from('<I', raw, end + 16)[0]
    changed = 0
    for _ in range(struct.unpack_from('<H', raw, end+10)[0]):
        v.need(raw[cursor:cursor+4] == b'PK\x01\x02', 'CONTROL_MUTATION_TARGET')
        flags = struct.unpack_from('<H', raw, cursor+8)[0]
        names, extra, comment = struct.unpack_from('<HHH', raw, cursor+28)
        name = raw[cursor+46:cursor+46+names].decode('utf-8' if flags & 2048 else 'cp437')
        if name == member:
            struct.pack_into('<I', result, cursor+16, item.CRC ^ 1)
            changed += 1
        cursor += 46 + names + extra + comment
    v.need(changed == 1 and len(result) == len(raw), 'CONTROL_MUTATION_TARGET')
    return bytes(result)


def control(archive, zip_anchor, manifest_anchor, verifier_anchor):
    for anchor in (zip_anchor, manifest_anchor, verifier_anchor):
        v.need(type(anchor) is str and v.HEX64.fullmatch(anchor), 'CONTROL_ANCHOR')
    original = v.read_regular(archive)
    v.need(v.sha(original) == zip_anchor, 'CONTROL_ANCHOR')
    packet = v.Archive(original)
    # Check the complete bounded inventory and nested data before executing code.
    v.return_packet(packet, manifest_anchor, None)
    manifest = v.loads(packet.read('manifest.json'))
    verifier = packet.read('verify_return23.py')
    v.need(v.sha(verifier) == verifier_anchor, 'CONTROL_ANCHOR')
    target = manifest['checkpoint']['path'] + '/payload.zip'
    mutated = changed_crc(original, target)
    parent = Path(tempfile.gettempdir()).resolve()
    for ancestor in (parent, *parent.parents): v.node(ancestor, True)
    temporary = Path(tempfile.mkdtemp(prefix='artifact23-control-', dir=parent))
    program, copied = temporary/'verify_return23.py', temporary/'return.zip'
    result = dict(schema=1, state='INCOMPLETE',
        qualification='ACTUAL_ARTIFACT_COPY_CONTROL_ONLY_NOT_SOURCE_CHECKOUT_PROOF',
        archiveSHA256=zip_anchor, manifestSHA256=manifest_anchor,
        verifierSHA256=verifier_anchor, driverSHA256=v.sha(v.read_regular(Path(__file__))),
        exits=[], refusalCodes=[], sourceChecks='NOT_RUN', fullGitVerification='NOT_RUN',
        originalUnchanged=False, copyRestoredExact=False, cleanupComplete=False,
        acceptanceGranted=False, release='NO_GO')
    try:
        with program.open('xb') as stream: stream.write(verifier)
        with copied.open('xb') as stream: stream.write(original)
        environment = {k:value for k,value in os.environ.items()
            if not k.upper().startswith(('GIT_', 'NPM_', 'PHASE4_', 'GITHUB_', 'PYTHON'))}
        command = [sys.executable, '-I', '-B', str(program), '--archive', str(copied),
            '--expected-manifest-sha256', manifest_anchor,
            '--expected-verifier-sha256', verifier_anchor]
        for position, content in enumerate((original, mutated, original)):
            if position:
                v.node(copied)
                with copied.open('wb') as stream: stream.write(content)
            v.need(v.read_regular(copied) == content, 'CONTROL_COPY_IDENTITY')
            code, output, errors = v.bounded(command, temporary, environment, 1024*1024, 300)
            value = v.loads(output)
            v.need(type(value) is dict and not errors and value.get('release') == 'NO_GO' and
                value.get('acceptanceGranted') is False, 'CONTROL_CHILD_RESULT')
            result['exits'].append(code)
            if position == 1:
                v.need(code == 1 and value.get('status') == 'CONTEXT_INVALID' and
                    value.get('error') == 'ZIP_READ_INVALID', 'CONTROL_EXPECTED_REFUSAL')
                result['refusalCodes'].append('ZIP_READ_INVALID')
            else:
                v.need(code == 0 and value.get('status') == 'VERIFIED' and
                    value.get('sourceChecks') == {'state':'NOT_RUN'}, 'CONTROL_CHILD_RESULT')
        result['copyRestoredExact'] = v.read_regular(copied) == original
        result['originalUnchanged'] = v.sha(v.read_regular(archive)) == zip_anchor
        v.need(result['exits'] == [0,1,0] and result['copyRestoredExact'], 'CONTROL_RESTORATION')
        v.need(result['originalUnchanged'], 'CONTROL_ORIGINAL_CHANGED')
    finally:
        # Exact two task-created regular files; no recursive cleanup or source writes.
        v.need(temporary.parent == parent and temporary.name.startswith('artifact23-control-'),
            'CONTROL_TEMP_SCOPE')
        v.node(temporary, True)
        for path in (copied, program):
            if path.exists(): v.node(path); path.unlink()
        temporary.rmdir()
        result['cleanupComplete'] = True
    result['state'] = 'PASS'
    return result


def main():
    class Parser(argparse.ArgumentParser):
        def error(self, _): raise v.Refusal('ARGUMENT_SCHEMA')
    parser = Parser(description=__doc__)
    parser.add_argument('--archive', required=True)
    parser.add_argument('--expected-zip-sha256', required=True)
    parser.add_argument('--expected-manifest-sha256', required=True)
    parser.add_argument('--expected-verifier-sha256', required=True)
    parser.add_argument('--receipt', required=True)
    receipt = None
    receipt_scope_valid = False
    try:
        args = parser.parse_args()
        archive = Path(os.path.abspath(args.archive))
        receipt = Path(os.path.abspath(args.receipt))
        v.need(receipt != archive and receipt.parent != archive and not receipt.exists(), 'CONTROL_RECEIPT_SCOPE')
        for ancestor in receipt.parents: v.node(ancestor, True)
        receipt_scope_valid = True
        result = control(archive, args.expected_zip_sha256,
            args.expected_manifest_sha256, args.expected_verifier_sha256)
        with receipt.open('xb') as stream:
            stream.write((json.dumps(result, sort_keys=True, indent=2)+'\n').encode())
        print(json.dumps(result, sort_keys=True)); return 0
    except BaseException as error:
        code = error.args[0] if isinstance(error, v.Refusal) and len(error.args) == 1 and \
            type(error.args[0]) is str and error.args[0] in CONTROL_CODES | v.PUBLIC_CODES else 'CONTROL_INCOMPLETE'
        result = dict(schema=1, state='INCOMPLETE', error=code,
            qualification='ACTUAL_ARTIFACT_COPY_CONTROL_ONLY_NOT_SOURCE_CHECKOUT_PROOF',
            acceptanceGranted=False, release='NO_GO')
        # Failed runs preserve only fixed diagnostics and never overwrite a receipt.
        if receipt_scope_valid and receipt is not None and not receipt.exists():
            try:
                with receipt.open('xb') as stream:
                    stream.write((json.dumps(result, sort_keys=True, indent=2)+'\n').encode())
            except OSError: pass
        print(json.dumps(result, sort_keys=True)); return 1


if __name__ == '__main__': sys.exit(main())
