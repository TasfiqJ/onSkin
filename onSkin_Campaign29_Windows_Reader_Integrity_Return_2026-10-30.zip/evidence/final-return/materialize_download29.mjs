import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Import into the local Windows node_repl. Supply only a fresh connector-issued
// HTTPS download URL privately; never print the call or save that URL to disk.
export async function materializeProviderBytes29({downloadUrl, archivePath, receiptPath, expectedBytes, expectedSHA256, providerIdentity, maxBytes = 134217728}) {
  const started = new Date().toISOString();
  let response, reader, chunks = [], actualBytes = 0;
  let stage = 'INPUT';
  try {
    const url = new URL(downloadUrl);
    if (url.protocol !== 'https:' || url.username || url.password) throw Error('URL_POLICY');
    if (!Number.isSafeInteger(expectedBytes) || expectedBytes < 22 || expectedBytes > maxBytes) throw Error('SIZE_POLICY');
    if (!/^[0-9a-f]{64}$/.test(expectedSHA256)) throw Error('DIGEST_POLICY');
    if (!path.isAbsolute(archivePath) || !path.isAbsolute(receiptPath)) throw Error('LOCAL_PATH_POLICY');
    if (!providerIdentity || Object.keys(providerIdentity).sort().join(',') !== 'canonicalURL,fileId,provider' ||
        providerIdentity.provider !== 'google-drive' || typeof providerIdentity.canonicalURL !== 'string') throw Error('PROVIDER_IDENTITY_POLICY');
    const identityMatch = /^https:\/\/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]+)\/(?:view|edit)(?:\?usp=(?:drivesdk|sharing|drive_link))?$/.exec(providerIdentity.canonicalURL);
    if (!identityMatch || providerIdentity.fileId !== identityMatch[1]) throw Error('PROVIDER_IDENTITY_POLICY');
    const safeProviderIdentity = Object.freeze({provider: 'google-drive', canonicalURL: providerIdentity.canonicalURL, fileId: providerIdentity.fileId});
    stage = 'HTTPS_FETCH';
    response = await fetch(url, {redirect: 'follow', signal: AbortSignal.timeout(55000)});
    if (response.status !== 200) throw Error('HTTP_' + response.status);
    if (new URL(response.url).protocol !== 'https:') throw Error('FINAL_URL_POLICY');
    const length = response.headers.get('content-length');
    if (length !== null && (!/^\d+$/.test(length) || Number(length) !== expectedBytes)) throw Error('DECLARED_SIZE_MISMATCH');
    stage = 'BOUNDED_STREAM';
    reader = response.body.getReader();
    for (;;) {
      const next = await reader.read();
      if (next.done) break;
      actualBytes += next.value.byteLength;
      if (actualBytes > expectedBytes) throw Error('ACTUAL_SIZE_BOUND');
      chunks.push(next.value);
    }
    stage = 'ACTUAL_BYTE_AUTHENTICATION';
    const body = Buffer.concat(chunks.map(value => Buffer.from(value)));
    const digest = crypto.createHash('sha256').update(body).digest('hex');
    if (actualBytes !== expectedBytes || digest !== expectedSHA256) throw Error('ACTUAL_DIGEST_OR_SIZE_MISMATCH');
    stage = 'NEW_LOCAL_FILE_WRITE';
    await fs.writeFile(archivePath, body, {flag: 'wx'});
    const reread = await fs.readFile(archivePath);
    if (reread.length !== expectedBytes || crypto.createHash('sha256').update(reread).digest('hex') !== expectedSHA256) throw Error('LOCAL_READBACK_MISMATCH');
    const receipt = {
      schema: 1, status: 'ACTUAL_NETWORK_BYTES_AND_NEW_LOCAL_READBACK_AUTHENTICATED',
      archivePath: path.resolve(archivePath),
      bridgeSHA256: crypto.createHash('sha256').update(await fs.readFile(fileURLToPath(import.meta.url))).digest('hex'),
      providerIdentity: safeProviderIdentity, started, completed: new Date().toISOString(), httpStatus: response.status,
      actualEOF: true, actualBytes, actualSHA256: digest, localReadbackMatches: true,
      finalHost: new URL(response.url).hostname, noSignedURLPersistedOrPrinted: true,
      qualification: 'NETWORK_AND_LOCAL_BYTE_IDENTITY_ONLY_RAW_ZIP_AND_MANIFEST_AUDIT_STILL_REQUIRED',
    };
    await fs.writeFile(receiptPath, JSON.stringify(receipt, null, 2) + '\n', {flag: 'wx'});
    return receipt;
  } catch (error) {
    // Never forward fetch exception URLs, response bodies, or signed queries.
    const diagnostic = /^(URL_POLICY|SIZE_POLICY|DIGEST_POLICY|LOCAL_PATH_POLICY|PROVIDER_IDENTITY_POLICY|HTTP_\d+|FINAL_URL_POLICY|DECLARED_SIZE_MISMATCH|ACTUAL_SIZE_BOUND|ACTUAL_DIGEST_OR_SIZE_MISMATCH|LOCAL_READBACK_MISMATCH)$/.test(error?.message ?? '') ? error.message : (error?.code === 'EEXIST' ? 'LOCAL_DESTINATION_EXISTS' : 'PROVIDER_MATERIALIZATION_FAILED');
    throw Error(JSON.stringify({status: 'FAIL', stage, diagnostic, actualBytes, qualification: 'NO_ZIP_ACCEPTANCE_GRANTED'}));
  } finally {
    try { await reader?.cancel(); } catch {}
    downloadUrl = null;
    chunks = [];
    response = null;
    reader = null;
  }
}
