"""Authenticate actual freshly downloaded bytes; source execution is separate."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import stat
import subprocess
import sys
from urllib.parse import parse_qsl, urlsplit

OUT = Path(__file__).resolve().parent
HERE = OUT.parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def full_postassembly_proof29(check, slot, state, python, logs_root=OUT):
    """Artifact-only download verification cannot stand in for either full run."""
    assert check['status'] == 'PASS_ACTUAL_RETURN_FULL_SOURCE_VERIFICATION'
    assert type(check['exit']) is int and check['exit'] == 0 and check['refusal'] is None
    assert check['slot'] == slot.lower() and check['supplierExecution'] is True and check['independentBrainExecution'] is False
    assert check['acceptanceGranted'] is False and check['release'] == 'NO_GO'
    for key in ('head', 'tree', 'zipBytes', 'zipSHA256', 'manifestSHA256', 'verifierSHA256'):
        assert check[key] == state[key]
    command = check['command']
    assert type(command) is list and all(type(item) is str for item in command)
    assert command.count('--git-root') == 1
    root_index = command.index('--git-root')
    assert root_index+1 < len(command) and Path(command[root_index+1]).is_absolute()
    assert command == [python, '-I', '-B', state['returnVerifierPath'], '--archive', state['output'],
        '--git-root', command[root_index+1], '--expected-manifest-sha256', state['manifestSHA256'],
        '--expected-verifier-sha256', state['verifierSHA256'], '--expected-head', state['head'],
        '--expected-tree', state['tree'], '--execute-source-checks']
    result = check['result']
    assert result['status'] == 'VERIFIED' and result['acceptanceGranted'] is False and result['release'] == 'NO_GO'
    assert result['git']['head'] == state['head'] and result['git']['tree'] == state['tree']
    assert result['git']['workingQualification'] == 'RAW_TRACKED_BLOBS_EXACT' and result['git']['evidenceTail'] is True
    assert result['sourceChecks']['release29'] == 'PASS_FINITE_SOURCE_GOVERNANCE_ONLY'
    assert result['sourceChecks']['consumer29'] == 'PASS_AUTHENTICATED_CURRENT_CONSUMER'
    assert result['sourceChecks']['phase4'] == 'PASS_UNCHANGED_PRODUCER_STRICT_CHECK'
    for stream, suffix, limit in (('stdout', 'stdout.json', 2*1024*1024), ('stderr', 'stderr.log', 1024*1024)):
        item = check['logs'][stream]
        assert item['path'] == 'postassembly-'+slot.lower()+'.'+suffix
        path = logs_root/item['path']
        assert path.stat().st_size <= limit
        body = path.read_bytes()
        assert len(body) == item['bytes'] and sha(body) == item['sha256']
        if stream == 'stdout': assert json.loads(body) == result
    identity = check['objectStoreIdentity']
    assert all(type(identity[key]) is int for key in ('device', 'inode'))
    return identity['device'], identity['inode']


def main():
    if sys.flags.optimize: raise SystemExit('FRESH_DOWNLOAD_ASSERTIONS_REQUIRED')
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--network-receipt', type=Path, required=True)
    parser.add_argument('--drive-url', required=True)
    args = parser.parse_args()
    target = OUT/'FINAL_FRESH_DOWNLOAD29.json'
    assert not target.exists()
    drive = urlsplit(args.drive_url)
    assert drive.scheme == 'https' and drive.netloc == 'drive.google.com' and not drive.fragment
    match = re.fullmatch(r'/file/d/([A-Za-z0-9_-]+)/(?:view|edit)', drive.path)
    assert match and (not drive.query or parse_qsl(drive.query) in
        ([('usp','drivesdk')], [('usp','sharing')], [('usp','drive_link')]))
    state = json.loads((OUT/'ONE_RETURN_ASSEMBLY29.json').read_bytes())
    assert state['status'] == 'ONE_ACTUAL_RETURN_ASSEMBLED'
    network = json.loads(args.network_receipt.read_bytes())
    assert network['status'] == 'ACTUAL_NETWORK_BYTES_AND_NEW_LOCAL_READBACK_AUTHENTICATED'
    assert network['httpStatus'] == 200 and network['actualEOF'] is True and network['localReadbackMatches'] is True
    assert network['actualBytes'] == state['zipBytes'] and network['actualSHA256'] == state['zipSHA256']
    assert network['noSignedURLPersistedOrPrinted'] is True
    archive = args.archive.absolute()
    assert Path(network['archivePath']).absolute() == archive
    assert network['bridgeSHA256'] == sha((OUT/'materialize_download29.mjs').read_bytes())
    provider = network['providerIdentity']
    assert provider['provider'] == 'google-drive' and provider['canonicalURL'] == args.drive_url
    assert provider['fileId'] == match.group(1)
    assert datetime.fromisoformat(network['started'].replace('Z', '+00:00')) >= datetime.fromisoformat(state['assembledUTC'])
    assert datetime.fromisoformat(network['completed'].replace('Z', '+00:00')) >= datetime.fromisoformat(network['started'].replace('Z', '+00:00'))
    assert archive != Path(state['output']).absolute() and archive.resolve() == archive
    info = archive.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0)&1024
    for parent in archive.parents:
        pi = parent.lstat()
        assert stat.S_ISDIR(pi.st_mode) and not getattr(pi, 'st_file_attributes', 0)&1024
    assert info.st_size == state['zipBytes'] and info.st_size <= 128*1024*1024
    raw = archive.read_bytes()
    assert len(raw) == state['zipBytes'] and sha(raw) == state['zipSHA256']
    verifier = Path(state['returnVerifierPath'])
    assert sha(verifier.read_bytes()) == state['verifierSHA256']
    tools = json.loads((HERE/'runtime/ACTIVE_TOOLCHAIN29.json').read_bytes())
    command = [tools['python'], '-I', '-B', str(verifier), '--archive', str(archive),
        '--expected-manifest-sha256', state['manifestSHA256'], '--expected-verifier-sha256', state['verifierSHA256']]
    child = subprocess.run(command, cwd=OUT, capture_output=True, timeout=300)
    assert len(child.stdout) <= 2*1024*1024 and len(child.stderr) <= 1024*1024
    stdout = OUT/'fresh-download-verifier.stdout.json'
    stderr = OUT/'fresh-download-verifier.stderr.log'
    with stdout.open('xb') as stream: stream.write(child.stdout)
    with stderr.open('xb') as stream: stream.write(child.stderr)
    value = json.loads(child.stdout)
    assert child.returncode == 0 and value['status'] == 'VERIFIED'
    assert value['sourceChecks'] == {'state':'NOT_RUN'} and value['acceptanceGranted'] is False and value['release'] == 'NO_GO'
    assert archive.stat().st_size == state['zipBytes'] and sha(archive.read_bytes()) == state['zipSHA256']
    postassembly = []; stores = []
    for slot in ('A', 'B'):
        path = OUT/('FINAL_RETURN_POSTASSEMBLY29_'+slot+'.json')
        check = json.loads(path.read_bytes())
        stores.append(full_postassembly_proof29(check, slot, state, tools['python']))
        postassembly.append(dict(path=path.name, bytes=path.stat().st_size, sha256=sha(path.read_bytes()), status=check['status']))
    assert stores[0] != stores[1]
    receipt = dict(schema=1, status='PASS_ACTUAL_FRESH_CONNECTED_ACCOUNT_DOWNLOAD_AND_ARTIFACT_AUDIT',
        completedUTC=datetime.now(timezone.utc).isoformat(), driveURL=args.drive_url,
        zipBytes=state['zipBytes'], zipSHA256=state['zipSHA256'],
        manifestSHA256=state['manifestSHA256'], verifierSHA256=state['verifierSHA256'],
        checkpointManifestSHA256=state['checkpointManifestSHA256'], checkpointVerifierSHA256=state['checkpointVerifierSHA256'],
        finalHead=state['head'], finalTree=state['tree'], actualFreshDownload=network,
        downloadVerifier=dict(command=command, exit=child.returncode, result=value,
            stdout=dict(path=stdout.name, bytes=len(child.stdout), sha256=sha(child.stdout)),
            stderr=dict(path=stderr.name, bytes=len(child.stderr), sha256=sha(child.stderr))),
        separateCompletedFullSourceChecks=postassembly,
        anonymousAccess='NOT_CLAIMED', supplierExecution=True, independentBrainExecution=False,
        qualification='ACTUAL_NETWORK_AND_ARCHIVE_INTEGRITY_ONLY;FULL_SOURCE_EXECUTION_SEPARATELY_ATTRIBUTED',
        acceptanceGranted=False, release='NO_GO')
    with target.open('xb') as stream: stream.write((json.dumps(receipt, sort_keys=True, indent=2)+'\n').encode())
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
