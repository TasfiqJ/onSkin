"""Verify the one actual return against one completed independent supplier clone."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

OUT = Path(__file__).resolve().parent
HERE = OUT.parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bound_clone_inputs29(raw, state, evidence_root=HERE):
    """Select the raw live-clone proofs only through the anchored actual ZIP."""
    assert len(raw) == state['zipBytes'] and sha(raw) == state['zipSHA256']
    def witness(body):
        return dict(bytes=len(body), sha256=sha(body))
    with zipfile.ZipFile(io.BytesIO(raw)) as packet:
        def member(name, expected=None):
            matches = [item for item in packet.infolist() if item.filename == name]
            assert len(matches) == 1 and not matches[0].is_dir() and matches[0].file_size <= 16*1024*1024
            body = packet.read(matches[0])
            assert len(body) <= 16*1024*1024 and (expected is None or witness(body) == expected)
            return body
        manifest_raw = member('manifest.json')
        assert sha(manifest_raw) == state['manifestSHA256']
        declared = json.loads(manifest_raw)['files']
        facts = json.loads(member('evidence/FINAL_RETURN_FACTS29.json', declared['evidence/FINAL_RETURN_FACTS29.json']))
        assert facts['head'] == state['head'] and facts['tree'] == state['tree']
        index_name = 'evidence/RETURN_EVIDENCE_DERIVATION_INDEX29.json'
        index = json.loads(member(index_name, declared[index_name]))
        derivations = {item['path']: item for item in index['files']}
        assert len(derivations) == len(index['files'])
        names = facts['cloneReceipts']
        assert type(names) is list and len(names) == 2 and len(set(names)) == 2
        receipts = []
        for name in names:
            assert type(name) is str and name.isascii() and not name.startswith('/') and '\\' not in name and ':' not in name
            assert all(part not in ('', '.', '..') for part in name.split('/'))
            published_name = 'evidence/'+name
            published = member(published_name, declared[published_name])
            derivation = derivations.get(published_name)
            expected = declared[published_name]
            if derivation is not None:
                assert derivation['published'] == witness(published)
                expected = derivation['original']
            path = evidence_root.joinpath(*name.split('/'))
            assert path.stat().st_size <= 16*1024*1024
            original = path.read_bytes()
            assert witness(original) == expected
            receipts.append(json.loads(original))
    return facts, receipts


def main():
    if sys.flags.optimize: raise SystemExit('POSTASSEMBLY_ASSERTIONS_REQUIRED')
    parser = argparse.ArgumentParser()
    parser.add_argument('--slot', choices=('a', 'b'), required=True)
    args = parser.parse_args()
    target = OUT/('FINAL_RETURN_POSTASSEMBLY29_'+args.slot.upper()+'.json')
    assert not target.exists(), 'POSTASSEMBLY_RECEIPT_ALREADY_EXISTS'
    state = json.loads((OUT/'ONE_RETURN_ASSEMBLY29.json').read_bytes())
    assert state['status'] == 'ONE_ACTUAL_RETURN_ASSEMBLED'
    archive = Path(state['output'])
    raw = archive.read_bytes()
    assert len(raw) == state['zipBytes'] and sha(raw) == state['zipSHA256']
    verifier = Path(state['returnVerifierPath'])
    assert sha(verifier.read_bytes()) == state['verifierSHA256']
    facts, receipts = bound_clone_inputs29(raw, state)
    assert len(receipts) == 2 and {row['slot'] for row in receipts} == {'a', 'b'}
    assert len({(row['objectStoreIdentity']['device'], row['objectStoreIdentity']['inode']) for row in receipts}) == 2
    receipt = next(row for row in receipts if row['slot'] == args.slot)
    assert receipt['status'] == 'PASS_COMPLETE_FRESH_REMOTE_CLONE_AND_ACTUAL_0_1_0_CONTROLS'
    assert receipt['expectedHead'] == state['head'] and receipt['expectedTree'] == state['tree']
    live = Path(receipt['checkout'])
    assert live.resolve() == live
    objects = (live/'.git/objects').lstat()
    assert (objects.st_dev, objects.st_ino) == (receipt['objectStoreIdentity']['device'], receipt['objectStoreIdentity']['inode'])
    tools = json.loads((HERE/'runtime/ACTIVE_TOOLCHAIN29.json').read_bytes())
    environment = {key: value for key, value in os.environ.items()
        if not key.upper().startswith(('GIT_', 'GITHUB_', 'NPM_', 'PYTHON', 'PHASE4_'))
        and key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
    environment['PATH'] = tools['prefix']+os.pathsep+str(Path(tools['python']).parent)+os.pathsep+environment.get('PATH', '')
    command = [tools['python'], '-I', '-B', str(verifier), '--archive', str(archive),
        '--git-root', receipt['checkout'], '--expected-manifest-sha256', state['manifestSHA256'],
        '--expected-verifier-sha256', state['verifierSHA256'], '--expected-head', state['head'],
        '--expected-tree', state['tree'], '--execute-source-checks']
    stdout = OUT/('postassembly-'+args.slot+'.stdout.json')
    stderr = OUT/('postassembly-'+args.slot+'.stderr.log')
    start = time.monotonic()
    record = dict(schema=1, status='RUNNING', slot=args.slot, command=command,
        startedUTC=datetime.now(timezone.utc).isoformat(), head=state['head'], tree=state['tree'],
        zipBytes=len(raw), zipSHA256=sha(raw), manifestSHA256=state['manifestSHA256'],
        verifierSHA256=state['verifierSHA256'], supplierExecution=True, independentBrainExecution=False,
        objectStoreIdentity=dict(device=objects.st_dev, inode=objects.st_ino),
        acceptanceGranted=False, release='NO_GO')
    (OUT/('postassembly-'+args.slot+'.inprogress.json')).write_text(json.dumps(record, indent=2)+'\n')
    refusal = None
    with stdout.open('xb') as output, stderr.open('xb') as errors:
        child = subprocess.Popen(command, cwd=OUT, env=environment, stdout=output, stderr=errors,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        while child.poll() is None:
            if time.monotonic()-start > 3600 or stdout.stat().st_size > 2*1024*1024 or stderr.stat().st_size > 1024*1024:
                refusal = 'TIME_OR_OUTPUT_BOUND'
                subprocess.run(['taskkill.exe', '/PID', str(child.pid), '/T', '/F'], capture_output=True, timeout=30)
                child.wait(timeout=30)
                break
            time.sleep(0.25)
    record.update(exit=child.returncode, refusal=refusal, elapsedMilliseconds=round((time.monotonic()-start)*1000),
        finishedUTC=datetime.now(timezone.utc).isoformat(),
        logs={label:dict(path=path.name, bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
              for label, path in (('stdout', stdout), ('stderr', stderr))})
    try:
        value = json.loads(stdout.read_bytes())
        record['result'] = value
        passed = child.returncode == 0 and refusal is None and value['status'] == 'VERIFIED'
        passed = passed and value['acceptanceGranted'] is False and value['release'] == 'NO_GO'
        passed = passed and value['git']['head'] == state['head'] and value['git']['tree'] == state['tree']
        passed = passed and value['git']['workingQualification'] == 'RAW_TRACKED_BLOBS_EXACT'
        passed = passed and value['sourceChecks']['release29'] == 'PASS_FINITE_SOURCE_GOVERNANCE_ONLY'
        passed = passed and value['sourceChecks']['consumer29'] == 'PASS_AUTHENTICATED_CURRENT_CONSUMER'
        passed = passed and value['sourceChecks']['phase4'] == 'PASS_UNCHANGED_PRODUCER_STRICT_CHECK'
        passed = passed and archive.stat().st_size == state['zipBytes'] and sha(archive.read_bytes()) == state['zipSHA256']
    except (ValueError, KeyError, TypeError):
        passed = False
    record['status'] = 'PASS_ACTUAL_RETURN_FULL_SOURCE_VERIFICATION' if passed else 'BLOCKED_POSTASSEMBLY_VERIFICATION'
    target.write_text(json.dumps(record, sort_keys=True, indent=2)+'\n')
    print(json.dumps(record, sort_keys=True))
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
