"""Supplier final-clone proof. Run only after root supplies FINAL_TAIL_READY pins.

Creates one complete fresh REMOTE clone per invocation. Nothing is deleted.
Protected-source bytes stay in memory and are never put in logs or receipts.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
import uuid


OUT = Path(__file__).resolve().parent
WORKSPACE = OUT.parent.parent
ACTIVE = OUT.parent/'runtime/ACTIVE_TOOLCHAIN29.json'
CHECKPOINT = 'docs/brain/checkpoints/M1-02/WINDOWS-READER-INTEGRITY-29/'
BRANCH = 'stage/m1-windows-reader-integrity29'
BASE = 'bace116586d58ed955f0a024ca96ae9f4ad9286d'
BASE_TREE = '6951590547b79a869464df987d16da6552907846'
PROTECTED = 'apps/mobile/src/lib/consent/healthDataWriteAdmission.ts'
FILES = {'README.md', 'REPORT.md', 'manifest.json', 'payload.zip', 'verify29.py'}
PYTHON_SHA = '4d6f5f81a4bca11191c4c7c6b43632694d0a4ce74e068619d8fdc161d469859a'
NODE_SHA = '47cd67453da180a39cdf5daedb89862667b8e627e60c116607874633450cd30d'


def metadata_loader29(raw, expected_sha):
    """Compile only the already authenticated public metadata helper ASTs."""
    need(sha(raw) == expected_sha, 'METADATA_HELPER_SOURCE_IDENTITY')
    nodes = [node for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef) and
             node.name in ('require29', 'metadata29')]
    need(len(nodes) == 2 and {node.name for node in nodes} == {'require29', 'metadata29'} and
         all(not node.decorator_list for node in nodes), 'METADATA_HELPER_AST_SCOPE')
    namespace = dict(os=os, Path=Path, stat=stat)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), '<authenticated-metadata-only-helper>', 'exec'), namespace)
    return namespace['metadata29']


class Refused(ValueError):
    pass


def need(value, code):
    if not value: raise Refused(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def file_identity(info, mtime=True):
    value = (info.st_dev, info.st_ino, info.st_mode, info.st_nlink, info.st_size,
             getattr(info, 'st_file_attributes', None), getattr(info, 'st_reparse_tag', None))
    return (*value, info.st_mtime_ns) if mtime else value


class ByteRestoration:
    """Task-local actual byte mutation, with exact in-memory restoration."""
    def __init__(self, path, boundary):
        self.path = Path(os.path.abspath(path))
        boundary = boundary.resolve()
        need(self.path.resolve() == self.path and self.path.is_relative_to(boundary), 'RESTORATION_TARGET_SCOPE')
        self.before = self.path.lstat()
        need(stat.S_ISREG(self.before.st_mode) and self.before.st_nlink == 1 and
             not getattr(self.before, 'st_file_attributes', 0)&1024, 'RESTORATION_TARGET_REGULAR')
        self.raw = self.path.read_bytes()
        need(self.raw and file_identity(self.path.lstat()) == file_identity(self.before), 'RESTORATION_INITIAL_STABILITY')

    def mutate(self):
        with self.path.open('r+b') as stream:
            need(stream.write(bytes([self.raw[0]^1])) == 1, 'TAMPER_WRITE_INCOMPLETE')
        need(self.path.read_bytes() != self.raw and
             file_identity(self.path.lstat(), False) == file_identity(self.before, False), 'TAMPER_NOT_APPLIED')

    def restore(self):
        # Neither mutation nor restoration replaces the file or creates a backup.
        with self.path.open('r+b') as stream:
            stream.seek(0)
            need(stream.write(self.raw) == len(self.raw), 'RESTORATION_WRITE_INCOMPLETE')
            stream.truncate(len(self.raw))
        need(self.path.read_bytes() == self.raw, 'RESTORATION_BYTES')
        os.utime(self.path, ns=(self.before.st_atime_ns, self.before.st_mtime_ns))
        need(file_identity(self.path.lstat()) == file_identity(self.before), 'RESTORATION_IDENTITY_OR_METADATA')
        return dict(bytesExact=True, identityExact=True, modeExact=True, linkCountExact=True,
                    sizeExact=True, mtimeExact=True, ctimeRestorationClaimed=False,
                    protectedBytesOrNewContentHashPublished=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--slot', choices=('a', 'b'), required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--tree', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--verifier-sha256', required=True)
    parser.add_argument('--final-tail-ready', action='store_true', required=True,
                        help='Root authorization after the sole final tail has been sealed and pushed')
    args = parser.parse_args()
    need(args.final_tail_ready and re.fullmatch('[0-9a-f]{40}', args.head) and
         re.fullmatch('[0-9a-f]{40}', args.tree) and args.head != BASE and args.tree != BASE_TREE and
         re.fullmatch('[0-9a-f]{64}', args.manifest_sha256) and
         re.fullmatch('[0-9a-f]{64}', args.verifier_sha256), 'FINAL_TAIL_ARGUMENTS')
    active_raw = ACTIVE.read_bytes(); active = json.loads(active_raw)
    need(set(active) == {'prefix', 'node', 'npmCLI', 'python', 'receipt'}, 'TOOLCHAIN_POINTER_SCHEMA')
    python, node, npm = (Path(active[name]) for name in ('python', 'node', 'npmCLI'))
    need(all(path.is_absolute() and path.resolve() == path for path in (python, node, npm)) and
         Path(sys.executable).resolve() == python and sha(python.read_bytes()) == PYTHON_SHA and
         sha(node.read_bytes()) == NODE_SHA, 'AUTHENTICATED_RUNTIME_REQUIRED')
    environment = {key: value for key, value in os.environ.items()
                   if not key.upper().startswith(('GITHUB_', 'GIT_', 'NPM_', 'PYTHON')) and
                   key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
    environment['PATH'] = str(Path(active['prefix']))+os.pathsep+str(python.parent)+os.pathsep+environment.get('PATH', '')
    environment.update(PYTHONDONTWRITEBYTECODE='1', GIT_TERMINAL_PROMPT='0', NO_COLOR='1')
    os.environ.clear(); os.environ.update(environment)
    git_cli = shutil.which('git'); need(git_cli is not None, 'GIT_UNAVAILABLE')
    token = uuid.uuid4().hex[:8]
    clone = WORKSPACE/('c29-f'+args.slot+'-'+token)
    evidence = OUT/('clone-'+args.slot+'-'+token)
    need(not clone.exists() and not evidence.exists() and clone.parent.resolve() == WORKSPACE.resolve(), 'FRESH_PATH_REQUIRED')
    evidence.mkdir(parents=True)
    receipt_path = evidence/'FINAL_CLONE_RECEIPT29.json'
    receipt = dict(schema=1, status='RUNNING', slot=args.slot, startedUTC=utc(),
        checkout=str(clone), evidenceDirectory=str(evidence), expectedHead=args.head, expectedTree=args.tree,
        expectedManifestSHA256=args.manifest_sha256, expectedVerifierSHA256=args.verifier_sha256,
        driverSHA256=sha(Path(__file__).read_bytes()), activeToolchainPointerSHA256=sha(active_raw),
        qualification='SUPPLIER_COMPLETE_REMOTE_CLONE_EXECUTION_NOT_INDEPENDENT_BRAIN_ACCEPTANCE',
        acceptanceGranted=False, release='NO_GO', commands=[], sequence=[])
    helper = None
    stage = 'SETUP'

    def save():
        temporary = receipt_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(receipt, sort_keys=True, indent=2)+'\n', encoding='utf-8')
        temporary.replace(receipt_path)

    def run(label, command, cwd, expected=0, seconds=600, limit=16*1024*1024, retain=True):
        nonlocal stage
        stage = label; save()
        print(json.dumps(dict(slot=args.slot, stage=label, state='STARTED')), flush=True)
        started = time.monotonic(); begin = utc()
        if helper is None:
            # Only trusted native Git is used before the final verifier is
            # copied and externally hash-authenticated. No hooks are enabled.
            child = subprocess.run(command, cwd=cwd, env=environment, capture_output=True,
                                   timeout=seconds, creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            code, stdout, stderr = child.returncode, child.stdout, child.stderr
            need(len(stdout)+len(stderr) <= limit, 'BOOTSTRAP_OUTPUT_BOUND')
        else:
            # The authenticated verifier provides bounded streams and a gated
            # Windows job object, including cleanup of descendant processes.
            code, stdout, stderr = helper._execute(command, cwd, seconds, limit, supplied_env=environment)
        row = dict(label=label, argv=[str(part) for part in command], startedUTC=begin,
                   elapsedMilliseconds=round((time.monotonic()-started)*1000), exit=code, expectedExit=expected)
        for name, raw in (('stdout', stdout), ('stderr', stderr)):
            value = dict(bytes=len(raw), sha256=sha(raw), retained=retain)
            if retain:
                log = evidence/(label+'.'+name+'.log'); log.write_bytes(raw); value['path'] = log.name
            row[name] = value
        receipt['commands'].append(row); save()
        print(json.dumps(dict(slot=args.slot, stage=label, state='COMPLETED', exit=code)), flush=True)
        need(code == expected, 'UNEXPECTED_COMMAND_EXIT')
        return stdout

    git_prefix = [git_cli, '--no-replace-objects', '-c', 'core.hooksPath=', '-c', 'core.autocrlf=false',
                  '-c', 'core.longpaths=true', '-c', 'core.fsmonitor=false']
    def git(label, *arguments):
        # Per-file catalog bodies stay in memory, never in public logs/receipts.
        return run(label, git_prefix+list(arguments), clone, retain=False)

    try:
        run('clone', git_prefix+['clone', '--no-checkout', '--no-hardlinks',
            '-c', 'core.autocrlf=false', '-c', 'core.longpaths=true',
            'https://github.com/TasfiqJ/onSkin.git', str(clone)], WORKSPACE)
        need(git('remote-task-branch', 'rev-parse', 'refs/remotes/origin/'+BRANCH).decode().strip() == args.head,
             'FINAL_BRANCH_MOVED')
        run('checkout', git_prefix+['checkout', '--detach', args.head], clone)
        need(git('head', 'rev-parse', 'HEAD').decode().strip() == args.head and
             git('tree', 'rev-parse', 'HEAD^{tree}').decode().strip() == args.tree and
             not git('clean-before', 'status', '--porcelain=v1', '--untracked-files=all', '-z'), 'CLONE_IDENTITY')
        run('fsck', git_prefix+['fsck', '--full', '--strict', '--no-reflogs', '--no-dangling'], clone)
        checkpoint = clone/CHECKPOINT
        need({path.name for path in checkpoint.iterdir()} == FILES, 'FINAL_CHECKPOINT_INVENTORY')
        copied = evidence/'checkpoint-copy'; copied.mkdir()
        for name in sorted(FILES):
            original_path = checkpoint/name; info = original_path.lstat()
            need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0)&1024,
                 'CHECKPOINT_COPY_REGULAR')
            body = original_path.read_bytes()
            with (copied/name).open('xb') as stream: stream.write(body)
            os.utime(copied/name, ns=(info.st_atime_ns, info.st_mtime_ns))
        need(sha((copied/'manifest.json').read_bytes()) == args.manifest_sha256 and
             sha((copied/'verify29.py').read_bytes()) == args.verifier_sha256, 'EXTERNAL_CHECKPOINT_ANCHORS')
        spec = importlib.util.spec_from_file_location('authenticated_final_verifier29', copied/'verify29.py')
        helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
        need(helper.BASE == BASE and helper.BASE_TREE == BASE_TREE and helper.MODE == 'checkpoint', 'VERIFIER_SOURCE_BINDING')
        stage = 'preinstall-artifact-and-git'; save()
        package = helper.Directory(copied)
        manifest = helper.checkpoint(package, args.manifest_sha256)
        preinstall = helper.verify_git(clone, manifest['source'], package)
        package.seal()
        need(preinstall['head'] == args.head and preinstall['tree'] == args.tree and preinstall['evidenceTail'] is True,
             'PREINSTALL_SOURCE_IDENTITY')
        receipt['preinstallArtifactAndGit'] = preinstall
        objects = (clone/'.git/objects').lstat()
        receipt['objectStoreIdentity'] = dict(device=objects.st_dev, inode=objects.st_ino,
                                             standalone=True, remoteClone=True, alternates=False, shallow=False)
        # Execute no repository helper until the complete raw Git proof above.
        # Then bind this exact replay bytes/hash/Git blob to the sealed checker.
        checker_raw = helper.read_regular(clone/'scripts/release/full-app-j01/check.py')
        need(sha(checker_raw) == helper.CHECKER_SHA256, 'SEALED_CHECKER_IDENTITY')
        replay_pins = [node for node in ast.parse(checker_raw).body if isinstance(node, ast.Assign) and
                       len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and
                       node.targets[0].id == 'RELEASE29_REPLAY_SHA256']
        need(len(replay_pins) == 1, 'SEALED_REPLAY_PIN')
        replay_sha = ast.literal_eval(replay_pins[0].value)
        need(type(replay_sha) is str and re.fullmatch('[0-9a-f]{64}', replay_sha), 'SEALED_REPLAY_PIN')
        replay_name = 'scripts/release/full-app-j01/replay29.py'
        replay_raw = helper.read_regular(clone/replay_name)
        replay_blob = helper.git(clone, 'rev-parse', 'HEAD:'+replay_name).decode().strip()
        need(hashlib.sha1(('blob '+str(len(replay_raw))+'\0').encode()+replay_raw).hexdigest() == replay_blob,
             'METADATA_HELPER_GIT_BLOB')
        metadata = metadata_loader29(replay_raw, replay_sha)
        receipt['metadataHelperSource'] = dict(path=replay_name, sha256=replay_sha, gitBlob=replay_blob,
            qualification='EXACT_SEALED_CURRENT_SOURCE_HELPER;METADATA_OBSERVATION_IS_NOT_AUTHENTICATION')
        receipt['metadataPreobservations'] = []
        save()
        loader_code = "import sys,json;from pathlib import Path;sys.path.insert(0,str(Path.cwd()/'scripts/security22'));from toolchain import identity;print(json.dumps(identity(Path.cwd()),sort_keys=True))"
        def original_identity(label):
            try:
                observation = metadata(node)
            except ValueError as error:
                codes = {'R29_NPM_METADATA_PATH', 'R29_NPM_METADATA_BOUND', 'R29_NPM_METADATA_CHANGED', 'R29_NPM_METADATA_NODE'}
                if len(error.args) == 1 and error.args[0] in codes: raise Refused(error.args[0]) from None
                raise
            need(type(observation) is dict and set(observation) == {'platform', 'directories', 'files', 'sizeChanges'} and
                 observation['platform'] in ('nt', 'posix') and all(type(observation[key]) is int and 0 <= observation[key] <= 50000
                 for key in ('directories', 'files', 'sizeChanges')), 'METADATA_OBSERVATION_SCHEMA')
            row = dict(beforeCommand=label, observation=observation,
                qualification='METADATA_ONLY_NOT_NPM_AUTHENTICATION;UNCHANGED_ORIGINAL_GUARD_FOLLOWS')
            receipt['metadataPreobservations'].append(row); save()
            print(json.dumps(dict(slot=args.slot, kind='METADATA_PREOBSERVATION', **row)), flush=True)
            # One original strict guard call, with no waiver or refusal retry.
            return json.loads(run(label, [str(python), '-I', '-B', '-c', loader_code], clone, seconds=180))
        before_tools = original_identity('toolchain-before')
        need(before_tools['tools']['npm']['version'] == '11.20.0' and
             before_tools['tools']['npm']['installationModelSHA256'] == 'c1d3e494bb27b0ae253a41f06bd2621786f0d215dff2679e9005b25f6c3ca0b9',
             'ORIGINAL_TOOLCHAIN_GUARD')
        need(not (clone/'node_modules').exists(), 'FRESH_INSTALL_REQUIRED')
        need(not any(path.exists() for area in ('apps', 'packages') for path in (clone/area).glob('*/node_modules')), 'FRESH_INSTALL_REQUIRED')
        cache = evidence/'npm-cache'; cache.mkdir()
        empty_config = evidence/'empty-global.npmrc'
        with empty_config.open('xb') as stream: stream.write(b'')
        # Explicit normal CLI configuration survives the verifier's intentional
        # removal of inherited NPM_* variables. Mandatory hooks remain enabled.
        install = [str(node), str(npm), 'ci', '--ignore-scripts=false', '--cache', str(cache),
            '--userconfig', os.devnull, '--globalconfig', str(empty_config),
            '--registry', 'https://registry.npmjs.org', '--no-audit', '--no-fund']
        run('normal-npm-ci', install, clone, seconds=1200)
        hooks = json.loads(run('mandatory-hooks', [str(node), 'scripts/postinstall.mjs', '--check'], clone, seconds=180))
        need(hooks.get('check') is True, 'MANDATORY_HOOKS_FAILED')
        after_install = original_identity('toolchain-after-install')
        need(before_tools == after_install and not git('clean-after-install', 'status', '--porcelain=v1', '--untracked-files=all', '-z'),
             'INSTALL_CHANGED_SOURCE_OR_TOOLS')
        receipt['installation'] = dict(normalNpmCiExit=0, mandatoryHooksCheckExit=0, hooksEnabled=True,
            cacheMode='FRESH_EMPTY_EXTERNAL_NPM_CACHE', originalToolchainUnchanged=True,
            installedNativeOrSignedBuild='NOT_RUN')
        full = [str(python), '-I', '-B', str(copied/'verify29.py'), '--root', str(copied), '--git-root', str(clone),
            '--expected-manifest-sha256', args.manifest_sha256, '--expected-verifier-sha256', args.verifier_sha256,
            '--expected-head', args.head, '--expected-tree', args.tree, '--execute-source-checks']
        receipt['fullVerifierCommand'] = full; save()
        def full_check(label, expected, expected_error=None):
            raw = run(label, full, clone, expected=expected, seconds=3600)
            value = json.loads(raw)
            need(value.get('acceptanceGranted') is False and value.get('release') == 'NO_GO', 'FALSE_ADMISSION')
            if expected == 0:
                need(value.get('status') == 'VERIFIED' and value['git']['head'] == args.head and
                     value['git']['tree'] == args.tree and value['git']['evidenceTail'] is True and
                     value['git']['workingQualification'] == 'RAW_TRACKED_BLOBS_EXACT' and
                     value['sourceChecks']['release29'] == 'PASS_FINITE_SOURCE_GOVERNANCE_ONLY' and
                     value['sourceChecks']['consumer29'] == 'PASS_AUTHENTICATED_CURRENT_CONSUMER' and
                     value['sourceChecks']['phase4'] == 'PASS_UNCHANGED_PRODUCER_STRICT_CHECK', 'FULL_RESULT_SEMANTICS')
            else:
                need(value.get('status') == 'CONTEXT_INVALID' and value.get('error') == expected_error,
                     'WRONG_TAMPER_REFUSAL')
            receipt['sequence'].append(dict(label=label, exit=expected, result=value)); save()
        full_check('baseline-full', 0)
        protected = ByteRestoration(clone/PROTECTED, clone)
        receipt['protectedSourceTarget'] = PROTECTED
        try:
            protected.mutate()
            full_check('protected-source-tampered', 1, 'GIT_CHECKOUT_DIRTY')
        finally:
            receipt['protectedSourceRestoration'] = protected.restore(); save()
        full_check('protected-source-restored', 0)
        artifact = ByteRestoration(copied/'payload.zip', copied)
        try:
            artifact.mutate()
            full_check('artifact-tampered', 1, 'ARTIFACT_HASH_MISMATCH')
        finally:
            receipt['artifactRestoration'] = artifact.restore(); save()
        full_check('artifact-restored', 0)
        final_tools = original_identity('toolchain-after')
        need(final_tools == before_tools and ACTIVE.read_bytes() == active_raw and
             not git('clean-final', 'status', '--porcelain=v1', '--untracked-files=all', '-z') and
             git('head-final', 'rev-parse', 'HEAD').decode().strip() == args.head and
             git('tree-final', 'rev-parse', 'HEAD^{tree}').decode().strip() == args.tree and
             [row['exit'] for row in receipt['sequence']] == [0, 1, 0, 1, 0], 'FINAL_CLOSURE')
        full_rows = [row for row in receipt['commands'] if row['label'] in {x['label'] for x in receipt['sequence']}]
        need(len(full_rows) == 5 and all(row['argv'] == full for row in full_rows), 'SAME_COMMAND_REQUIRED')
        receipt.update(status='PASS_COMPLETE_FRESH_REMOTE_CLONE_AND_ACTUAL_0_1_0_CONTROLS', completedUTC=utc(),
            fullVerifierInvocations=5, actualExitSequence=[0, 1, 0, 1, 0], sourceAndToolsUnchanged=True,
            originalSecurityFindingsOrCredentialsOpened=False, protectedSourceBytesPublished=False,
            independentBrainExecution=False)
        save()
        print(json.dumps(dict(status=receipt['status'], slot=args.slot, receipt=str(receipt_path),
                              head=args.head, tree=args.tree, acceptanceGranted=False, release='NO_GO')), flush=True)
        return 0
    except BaseException as error:
        code = error.args[0] if isinstance(error, Refused) and len(error.args) == 1 else 'CLONE_PROOF_INCOMPLETE'
        if helper is not None and isinstance(error, helper.Refusal) and len(error.args) == 1 and error.args[0] in helper.PUBLIC_CODES:
            code = error.args[0]
        receipt.update(status='FAILED_INCOMPLETE', failedStage=stage, error=code,
                       exceptionType=type(error).__name__, completedUTC=utc())
        save()
        print(json.dumps(dict(status='FAILED_INCOMPLETE', slot=args.slot, stage=stage, error=code,
                              receipt=str(receipt_path), acceptanceGranted=False, release='NO_GO')), flush=True)
        return 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Refused as error:
        print(json.dumps(dict(status='REFUSED_BEFORE_CLONE', code=error.args[0], acceptanceGranted=False, release='NO_GO')))
        raise SystemExit(1) from None
