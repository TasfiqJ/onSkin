# Reproduce the Campaign26 review return

SUBMITTED_REVIEW_REQUIRED / NO_GO. All acceptance/admission gates remain closed.

Use the externally published ZIP, outer manifest and outer verifier SHA256 anchors. Authenticate actual downloaded bytes first. The actual final ZIP hash, this ZIP's corruption/restoration receipt and later public download proof are external annexes; they cannot be embedded in their own sealed bytes.

Pinned base: 52a3d01ebb36a6845d0ac21935ad35520732633f
Base tree: ef49a81ca814f3d82b8a868e0308b6dda09c9cca
Final candidate: 8c02a02afd7f2e9775dcc512c800d4f71f733234
Final tree: ff0f76d11fa7775e27732f54ce7fdfbd51c8c676
Checkpoint manifest SHA256: 6834657ba95846baa1178aba387a226ebc04c07b56e8194be4e30c38c0f20e3f

Run the portable outer verifier without source arguments for artifact integrity only:

```text
python -I -B verify_return26.py --archive ABSOLUTE_RETURN_ZIP --expected-manifest-sha256 EXTERNALLY_PUBLISHED_OUTER_MANIFEST_SHA256 --expected-verifier-sha256 EXTERNALLY_PUBLISHED_OUTER_VERIFIER_SHA256
```

For an independent source replay, create a new complete ordinary clone from the authentic repository with separate objects, no shallow/partial clone, alternates, shared worktree or borrowed dependency cache. Authenticate the pinned PR29 base/tree, fetch the included bundle's HEAD and check out exactly the final candidate above. Using the source task's authenticated toolchain/native-source pins, run the normal install with all mandatory lifecycle hooks and its actual postinstall check:

```text
npm ci --ignore-scripts=false --cache ABSOLUTE_NEW_EMPTY_NPM_CACHE --no-audit --no-fund
node scripts/postinstall.mjs --check
```

Then run:

```text
python -I -B verify_return26.py --archive ABSOLUTE_RETURN_ZIP --expected-manifest-sha256 EXTERNALLY_PUBLISHED_OUTER_MANIFEST_SHA256 --expected-verifier-sha256 EXTERNALLY_PUBLISHED_OUTER_VERIFIER_SHA256 --git-root ABSOLUTE_COMPLETE_FINAL_CLONE --expected-head 8c02a02afd7f2e9775dcc512c800d4f71f733234 --expected-tree ff0f76d11fa7775e27732f54ce7fdfbd51c8c676 --execute-source-checks
```

The full verifier checks actual raw tracked blobs/index/modes, full object hashes, exact finite history, original unchanged Phase4 producer/strict worklists, current Release26 source checker, checkpoint copy, exact minimal bundle object set and authenticated path-history. Artifact-only VERIFIED does not replace those checks. A temporary PACK parser may use documented baseline alternates; it is not an independent checkout and never writes the delivered source object's store.

The immutable checkpoint REPORT is the pre-tail snapshot. FINAL_REPORT and explicitly cataloged later-evidence carry the later observations, preserving actual failures, skips and qualifications. Inspect those receipts and the separate actual ZIP 0/1/0/public-download annex before making any review decision. No signed native/device, provider, database, Security, professional or public release acceptance follows from this archive.
