"""Independent Campaign26 final clone/checkpoint proof; never source or release acceptance."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import struct
import subprocess
import sys
import time
import unicodedata
import uuid
import zlib

BASE = '52a3d01ebb36a6845d0ac21935ad35520732633f'
CP = 'docs/brain/checkpoints/M1-02/FIRST-VALUE-RECOVERY-26'
FILES = {'README.md', 'REPORT.md', 'manifest.json', 'payload.zip', 'verify26.py'}
PROTECTED = 'apps/mobile/src/lib/storage/privateKV.ts'
REPO = 'https://github.com/TasfiqJ/onSkin.git'
WORKSPACE = Path(r'C:\Users\jasim\Documents\ChatGPT\MasterV2Code')
OUT = Path(__file__).resolve().parent

class ProofFailure(ValueError):
    pass

def need(ok, code):
    if not ok:
        raise ProofFailure(code)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def pairs(values):
    result = {}
    for key, value in values:
        need(key not in result, 'DUPLICATE_JSON_KEY')
        result[key] = value
    return result

def loads(raw):
    return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
        parse_constant=lambda _: need(False, 'NONFINITE_JSON'))

def regular(path, bound=128*1024*1024, allow_tool_hardlinks=False):
    info = path.lstat()
    need(stat.S_ISREG(info.st_mode) and (info.st_nlink == 1 or allow_tool_hardlinks and info.st_nlink > 1) and not path.is_symlink() and
        not getattr(info, 'st_file_attributes', 0) & 1024 and info.st_size <= bound, 'REGULAR_FILE_REQUIRED')
    raw = path.read_bytes()
    need(len(raw) == info.st_size, 'FILE_CHANGED')
    return raw

def restore(path, raw, info):
    with path.open('r+b') as stream:
        stream.seek(0); stream.write(raw); stream.truncate(); stream.flush(); os.fsync(stream.fileno())
    os.utime(path, ns=(info.st_atime_ns, info.st_mtime_ns))
    need(path.read_bytes() == raw, 'RESTORATION_BYTES')
    os.utime(path, ns=(info.st_atime_ns, info.st_mtime_ns))

def payload_preflight(raw, declarations):
    need(len(raw) <= 128*1024*1024, 'PAYLOAD_COMPRESSED_BOUND')
    eocd = raw.rfind(b'PK\x05\x06')
    need(eocd >= 0, 'ZIP_END_RECORD')
    _, disk, cd_disk, disk_count, count, cd_size, cd_offset, comment = struct.unpack_from('<4s4H2LH', raw, eocd)
    need(disk == cd_disk == 0 and disk_count == count == len(declarations) <= 20000 and
        comment == 0 and eocd+22 == len(raw) and cd_offset+cd_size == eocd, 'ZIP_EXACT_STRUCTURE')
    aliases, parents, names = {}, set(), set()
    position, local_end, total = cd_offset, 0, 0
    inventory = []
    for _ in range(count):
        fields = struct.unpack_from('<4s6H3L5H2L', raw, position)
        signature, made, needed, flags, method, mtime, mdate, crc, compressed, size, nl, el, cl, disk, _, external, offset = fields
        need(signature == b'PK\x01\x02' and made >> 8 == 3 and needed <= 20 and flags in (0, 2048) and
            method in (0, 8) and disk == 0 and el == cl == 0 and external >> 16 == 0o100644 and
            external & 0xffff == 0 and offset == local_end and size <= 128*1024*1024 and
            compressed >= 0 and size/max(1, compressed) <= 500, 'ZIP_MEMBER_STRUCTURE')
        encoded = raw[position+46:position+46+nl]
        name = encoded.decode('utf-8' if flags & 2048 else 'cp437')
        need(name and not name.startswith('/') and '\\' not in name and not any(ord(c) < 32 for c in name) and
            not any(c in name for c in ':<>"|?*'), 'ZIP_PATH')
        parts = name.split('/')
        normalized_parts = [unicodedata.normalize('NFKC', p) for p in parts]
        need(all(p and p not in ('.', '..') and not p.endswith(('.', ' ')) and
            not any(c in p for c in ':<>\"|?*/\\') and not any(ord(c) < 32 or 127 <= ord(c) < 160 for c in p) and
            not re.fullmatch(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?', p, re.I) for p in normalized_parts), 'ZIP_PATH')
        for length in range(1, len(parts)+1):
            candidate = '/'.join(parts[:length]); key = unicodedata.normalize('NFKC', candidate).casefold()
            kind = 'file' if length == len(parts) else 'directory'
            need(key not in aliases or aliases[key] == (candidate, kind), 'ZIP_ALIAS')
            aliases[key] = (candidate, kind)
            if kind == 'directory': parents.add(candidate)
        need(name not in names and name in declarations, 'ZIP_INVENTORY')
        names.add(name)
        local = struct.unpack_from('<4s5H3L2H', raw, offset)
        need(local == (b'PK\x03\x04', needed, flags, method, mtime, mdate, crc, compressed, size, nl, 0) and
            raw[offset+30:offset+30+nl] == encoded, 'ZIP_LOCAL_CENTRAL_MISMATCH')
        start = offset+30+nl; body = raw[start:start+compressed]
        if method == 8:
            decompressor = zlib.decompressobj(-15)
            body = decompressor.decompress(body, size+1)
            need(len(body) <= size and decompressor.eof and not decompressor.unconsumed_tail and
                not decompressor.unused_data, 'ZIP_EXPANSION_OR_TRAILING_BYTES')
            need(not decompressor.flush(), 'ZIP_UNCONSUMED_OUTPUT')
        spec = declarations[name]
        need(type(spec) is dict and type(spec.get('bytes')) is int and spec['bytes'] == size == len(body) and
            spec.get('sha256') == digest(body) and zlib.crc32(body) & 0xffffffff == crc, 'ZIP_DECLARED_BYTES')
        total += size; need(total <= 512*1024*1024, 'ZIP_TOTAL_BOUND')
        inventory.append(dict(path=name, bytes=size, sha256=digest(body), mode='100644'))
        local_end = start+compressed; position += 46+nl
    need(local_end == cd_offset and position == eocd and names == set(declarations) and not names & parents, 'ZIP_EXACT_INVENTORY')
    return dict(members=count, uncompressedBytes=total, inventory=inventory)

def authenticate_checkpoint(source, output, manifest_anchor, verifier_anchor):
    original = source/CP
    need({p.name for p in original.iterdir()} == FILES, 'CHECKPOINT_FIVE_FILES')
    manifest_raw = regular(original/'manifest.json', 16*1024*1024)
    need(digest(manifest_raw) == manifest_anchor, 'EXTERNAL_CHECKPOINT_MANIFEST_ANCHOR')
    manifest = loads(manifest_raw)
    need(manifest.get('acceptanceGranted') is False and manifest.get('release') == 'NO_GO' and
        set(manifest['files']) == FILES-{'manifest.json'}, 'CHECKPOINT_DECLARATIONS')
    bodies = {'manifest.json': manifest_raw}
    for name, spec in manifest['files'].items():
        body = regular(original/name)
        need(type(spec.get('bytes')) is int and len(body) == spec['bytes'] and digest(body) == spec['sha256'], 'CHECKPOINT_FILE_AUTHENTICATION')
        bodies[name] = body
    need(digest(bodies['verify26.py']) == verifier_anchor, 'EXTERNAL_CHECKPOINT_VERIFIER_ANCHOR')
    nested = payload_preflight(bodies['payload.zip'], manifest['payload']['files'])
    output.mkdir(exist_ok=False)
    for name, body in bodies.items():
        with (output/name).open('xb') as stream: stream.write(body)
        need(regular(output/name) == body, 'CHECKPOINT_COPY_CHANGED')
    return dict(filesIncludingManifest=5, manifestSHA256=manifest_anchor, verifierSHA256=verifier_anchor,
        payloadMembers=nested['members'], payloadUncompressedBytes=nested['uncompressedBytes'])

class Runner:
    def __init__(self, folder, environment):
        self.folder, self.environment, self.records = folder, environment, []
    def call(self, name, argv, cwd, seconds=1800):
        started = time.time(); timed_out = False
        try:
            result = subprocess.run([str(a) for a in argv], cwd=cwd, env=self.environment,
                capture_output=True, timeout=seconds,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            code, stdout, stderr = result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired as error:
            code, stdout, stderr, timed_out = None, error.stdout or b'', error.stderr or b'', True
        (self.folder/(name+'.stdout.log')).write_bytes(stdout)
        (self.folder/(name+'.stderr.log')).write_bytes(stderr)
        receipt = dict(name=name, argv=list(map(str, argv)), cwd=str(cwd), exit=code, timeout=timed_out,
            elapsedSeconds=time.time()-started, stdoutBytes=len(stdout), stderrBytes=len(stderr),
            stdoutSHA256=digest(stdout), stderrSHA256=digest(stderr))
        try: receipt['result'] = loads(stdout.strip())
        except (ValueError, UnicodeError): receipt['result'] = None
        (self.folder/(name+'.receipt.json')).write_text(json.dumps(receipt, indent=2)+'\n')
        self.records.append(receipt)
        print(json.dumps(dict(phase=name, exit=code, elapsedSeconds=receipt['elapsedSeconds'])), flush=True)
        return receipt, stdout
    def git(self, source, *args):
        result = subprocess.run(['git', '--no-replace-objects', '-c', 'core.hooksPath=', *args],
            cwd=source, env=self.environment, capture_output=True, timeout=180,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
        need(result.returncode == 0, 'GIT_COMMAND_REFUSED')
        return result.stdout

def raw_snapshot(runner, source):
    metadata = runner.git(source, 'ls-tree', '-r', '-z', 'HEAD'); entries = {}
    for row in metadata.split(b'\0'):
        if not row: continue
        header, name = row.split(b'\t', 1); mode, kind, oid = header.decode('ascii').split(); name = name.decode('utf-8')
        need(kind == 'blob' and mode in ('100644', '100755') and name not in entries, 'RAW_TREE_MODE')
        entries[name] = (mode, oid)
    stage_raw = runner.git(source, 'ls-files', '--stage', '-z'); stage = {}
    for row in stage_raw.split(b'\0'):
        if not row: continue
        header, name = row.split(b'\t', 1); mode, oid, level = header.decode('ascii').split()
        need(level == '0', 'INDEX_STAGE'); stage[name.decode('utf-8')] = (mode, oid)
    need(stage == entries and all(row.startswith(b'H ') for row in runner.git(source, 'ls-files', '-v', '-z').split(b'\0') if row), 'INDEX_FLAGS_OR_CONTENT')
    mismatches = []
    for name, (mode, oid) in entries.items():
        raw = regular(source.joinpath(*name.split('/')))
        observed = hashlib.sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()
        if observed != oid: mismatches.append(name)
    return dict(trackedBlobs=len(entries), rawTrackedBytesMatch=not mismatches,
        mismatchCount=len(mismatches), requestedProtectedPathIsOnlyMismatch=mismatches == [PROTECTED],
        indexSemanticSHA256=digest(stage_raw), treeMetadataSHA256=digest(metadata))

def full_result(record, head, tree):
    need(record['exit'] == 0 and type(record['result']) is dict, 'FULL_VERIFIER_EXECUTION')
    result = record['result']; git = result.get('git', {}); checks = result.get('sourceChecks', {})
    need(result.get('status') == 'VERIFIED' and result.get('acceptanceGranted') is False and result.get('release') == 'NO_GO' and
        result.get('filesIncludingManifest') == 5 and git.get('head') == head and git.get('tree') == tree and
        git.get('evidenceTail') is True and git.get('workingQualification') == 'RAW_TRACKED_BLOBS_EXACT' and
        checks.get('release26') == 'PASS_FINITE_SOURCE_GOVERNANCE_ONLY' and
        checks.get('phase4') == 'PASS_UNCHANGED_PRODUCER_STRICT_CHECK' and
        checks.get('executionContext') == 'INDEPENDENT_EXACT_HEAD_CHECKOUT_NO_CI_EVENT_CLAIM', 'FULL_VERIFIER_SEMANTICS')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True)
    parser.add_argument('--tree', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--verifier-sha256', required=True)
    parser.add_argument('--checkout', type=Path)
    parser.add_argument('--tools-prefix', type=Path)
    parser.add_argument('--other-checkout', type=Path)
    args = parser.parse_args()
    for value, length in [(args.head, 40), (args.tree, 40), (args.manifest_sha256, 64), (args.verifier_sha256, 64)]:
        need(re.fullmatch('[0-9a-f]{'+str(length)+'}', value), 'EXPLICIT_FINAL_ANCHOR_REQUIRED')
    source = (args.checkout or WORKSPACE/('c26-final-b-'+uuid.uuid4().hex[:8])).absolute()
    need(source.parent.resolve() == WORKSPACE.resolve() and re.fullmatch(r'c26-final-b(?:-[a-z0-9]+)?', source.name) and
        not source.exists(), 'FRESH_SHORT_TASK_CHECKOUT_REQUIRED')
    folder = OUT/('proof-'+uuid.uuid4().hex); folder.mkdir(exist_ok=False)
    environment = {k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_', 'GITHUB_', 'NPM_', 'PYTHON', 'PHASE4_')) and
        k.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
    if args.tools_prefix:
        prefix = args.tools_prefix.resolve(strict=True)
        node = prefix/('node.exe' if os.name == 'nt' else 'bin/node')
        npm = prefix/('node_modules/npm/bin/npm-cli.js' if os.name == 'nt' else 'lib/node_modules/npm/bin/npm-cli.js')
        environment['PATH'] = str(node.parent)+os.pathsep+environment.get('PATH', '')
    else:
        node = Path(shutil.which('node')).resolve(strict=True)
        npm = node.parent/'node_modules/npm/bin/npm-cli.js' if os.name == 'nt' else node.parent.parent/'lib/node_modules/npm/bin/npm-cli.js'
    for name in ['npm-user-empty.npmrc', 'npm-global-empty.npmrc']:
        with (folder/name).open('xb'): pass
    environment.update(GIT_TERMINAL_PROMPT='0', PYTHONDONTWRITEBYTECODE='1', NO_COLOR='1',
        npm_config_userconfig=str(folder/'npm-user-empty.npmrc'), npm_config_globalconfig=str(folder/'npm-global-empty.npmrc'),
        npm_config_registry='https://registry.npmjs.org')
    runner = Runner(folder, environment)
    summary = dict(status='IN_PROGRESS', checkout=str(source), head=args.head, tree=args.tree,
        checkpointManifestSHA256=args.manifest_sha256, checkpointVerifierSHA256=args.verifier_sha256,
        acceptanceGranted=False, sourceAcceptance='SUBMITTED_REVIEW_REQUIRED', release='NO_GO',
        outerZipProof='NOT_RUN_SEPARATE_POSTPACKAGE_PROOF_REQUIRED')
    try:
        record, _ = runner.call('clone-full-remote', ['git', '-c', 'core.hooksPath=', 'clone', '--no-checkout', '--no-hardlinks', REPO, source], WORKSPACE, 600)
        need(record['exit'] == 0 and (source/'.git').is_dir(), 'FULL_REMOTE_CLONE')
        for key, value in [('core.autocrlf', 'false'), ('core.longpaths', 'true'), ('core.hooksPath', '')]: runner.git(source, 'config', '--local', key, value)
        runner.git(source, 'fetch', '--no-tags', 'origin', args.head)
        runner.git(source, 'checkout', '--detach', args.head)
        need(runner.git(source, 'rev-parse', 'HEAD').decode().strip() == args.head and
            runner.git(source, 'rev-parse', 'HEAD^{tree}').decode().strip() == args.tree and
            runner.git(source, 'rev-parse', '--is-shallow-repository').strip() == b'false' and
            not (source/'.git/objects/info/alternates').exists() and not (source/'.git/info/grafts').exists() and
            not runner.git(source, 'for-each-ref', '--format=%(refname)', 'refs/replace'), 'FINAL_FULL_SOURCE_IDENTITY')
        need(not runner.git(source, 'status', '--porcelain=v1', '--untracked-files=all'), 'INITIAL_CHECKOUT_DIRTY')
        baseline_raw = raw_snapshot(runner, source); need(baseline_raw['rawTrackedBytesMatch'], 'INITIAL_RAW_SOURCE_BYTES')
        summary['baselineRaw'] = baseline_raw
        checkpoint = folder/'checkpoint'
        summary['checkpointAuthentication'] = authenticate_checkpoint(source, checkpoint, args.manifest_sha256, args.verifier_sha256)
        verifier = checkpoint/'verify26.py'
        tool_info = {}
        for name, executable in [('python', Path(sys.executable)), ('git', Path(shutil.which('git'))), ('node', node), ('npmCli', npm)]:
            body = regular(executable.resolve(strict=True), 256*1024*1024, allow_tool_hardlinks=True)
            tool_info[name] = dict(path=str(executable.resolve()), bytes=len(body), sha256=digest(body))
        summary['observedTools'] = tool_info
        record, raw = runner.call('npm-version', [node, npm, '--version'], source, 60)
        need(record['exit'] == 0 and raw.strip() == b'11.20.0', 'PINNED_NPM_VERSION')
        cache = folder/'fresh-npm-cache'; cache.mkdir(exist_ok=False)
        record, _ = runner.call('normal-npm-ci', [node, npm, 'ci', '--ignore-scripts=false', '--cache', cache, '--no-audit', '--no-fund'], source, 1200)
        need(record['exit'] == 0, 'NORMAL_MANDATORY_INSTALL')
        record, _ = runner.call('mandatory-postinstall-check', [node, 'scripts/postinstall.mjs', '--check'], source, 180)
        need(record['exit'] == 0 and record.get('result', {}).get('check') is True, 'MANDATORY_POSTINSTALL_CHECK')
        phase4 = 'scripts/phase4/build-source-worklist.mjs'
        need(regular(source/phase4) == runner.git(source, 'show', BASE+':'+phase4), 'UNCHANGED_PHASE4_PRODUCER')
        common = [sys.executable, '-I', '-B', verifier, '--root', checkpoint,
            '--expected-manifest-sha256', args.manifest_sha256, '--expected-verifier-sha256', args.verifier_sha256]
        full = common+['--git-root', source, '--expected-head', args.head, '--expected-tree', args.tree, '--execute-source-checks']
        record, _ = runner.call('full-current', full, source, 2400); full_result(record, args.head, args.tree)
        record, _ = runner.call('phase4-current', [node, phase4, '--strict', '--check'], source, 180); need(record['exit'] == 0, 'PHASE4_CURRENT')
        protected, config, index = source/PROTECTED, source/'.git/config', source/'.git/index'
        snapshots = [(p, regular(p), p.stat()) for p in (protected, config, index)]
        original, original_info = snapshots[0][1:]
        need(len(original) > 32, 'PROTECTED_SOURCE_BOUND')
        position = original.find(b' '); need(position >= 0, 'SAME_LENGTH_MUTATION_POSITION')
        mutated = original[:position]+b'\t'+original[position+1:]
        need(len(mutated) == len(original) and mutated != original, 'SAME_LENGTH_MUTATION')
        probe = dict(sameByteLength=True, originalBytes=len(original), assumeUnchangedUsed=False, skipWorktreeUsed=False)
        (folder/'protected-recovery-metadata.json').write_text(json.dumps(dict(path=PROTECTED, head=args.head,
            originalAtimeNs=original_info.st_atime_ns, originalMtimeNs=original_info.st_mtime_ns), indent=2)+'\n')
        try:
            runner.git(source, 'config', '--local', 'core.trustctime', 'false')
            restore(protected, mutated, original_info)
            probe['normalStatusEmptyWhileCorrupted'] = not runner.git(source, 'status', '--porcelain=v1', '--untracked-files=all')
            probe['rawDuringMutation'] = raw_snapshot(runner, source)
            need(probe['rawDuringMutation']['requestedProtectedPathIsOnlyMismatch'], 'ACTUAL_PROTECTED_MUTATION_REQUIRED')
            record, _ = runner.call('full-protected-tampered', full, source, 600)
            need(record['exit'] == 1, 'PROTECTED_MUTATION_NOT_REFUSED')
            probe['firstRefusalCode'] = (record.get('result') or {}).get('error', 'UNPARSED_REFUSAL')
            probe['rawHashGuardReached'] = probe['firstRefusalCode'] == 'GIT_WORKING_BLOB_MISMATCH'
            direct, _ = runner.call('direct-source-protected-tampered', [sys.executable, '-I', '-B', 'scripts/release/full-app-j01/check.py'], source, 600)
            need(direct['exit'] == 1, 'DIRECT_SOURCE_MUTATION_NOT_REFUSED')
            probe['directSourceFirstRefusal'] = (direct.get('result') or {}).get('error', 'UNPARSED_REFUSAL')
        finally:
            for path, body, info in snapshots: restore(path, body, info)
        probe['restoration'] = dict(protectedBytesRestored=regular(protected) == original,
            protectedMtimeRestored=protected.stat().st_mtime_ns == original_info.st_mtime_ns,
            configBytesRestored=regular(config) == snapshots[1][1],
            indexBytesRestoredAtRestoration=regular(index) == snapshots[2][1])
        need(all(probe['restoration'].values()), 'PROTECTED_CONFIG_INDEX_RESTORATION')
        # Reads may update access time; restore the deliberately controlled times
        # again before the independent restored verifier reads the source.
        for path, _, info in snapshots: os.utime(path, ns=(info.st_atime_ns, info.st_mtime_ns))
        probe['restoration']['atimeMtimeExactAtRestoration'] = all(
            (path.stat().st_atime_ns, path.stat().st_mtime_ns) == (info.st_atime_ns, info.st_mtime_ns)
            for path, _, info in snapshots)
        need(probe['restoration']['atimeMtimeExactAtRestoration'], 'RESTORED_CONTROLLED_TIMESTAMPS')
        summary['protectedMutation'] = probe
        summary['protectedRawRestored'] = raw_snapshot(runner, source)
        need(summary['protectedRawRestored']['rawTrackedBytesMatch'] and
            summary['protectedRawRestored']['indexSemanticSHA256'] == baseline_raw['indexSemanticSHA256'], 'PROTECTED_RESTORATION_RAW_INDEX')
        need(not runner.git(source, 'status', '--porcelain=v1', '--untracked-files=all'), 'PROTECTED_RESTORATION_DIRTY')
        record, _ = runner.call('full-protected-restored', full, source, 2400); full_result(record, args.head, args.tree)
        record, _ = runner.call('phase4-restored', [node, phase4, '--strict', '--check'], source, 180); need(record['exit'] == 0, 'PHASE4_RESTORED')
        record, _ = runner.call('artifact-current', common, folder, 300)
        need(record['exit'] == 0 and (record.get('result') or {}).get('status') == 'VERIFIED', 'ARTIFACT_CURRENT')
        payload = checkpoint/'payload.zip'; payload_info = payload.stat(); payload_original = regular(payload)
        offset = len(payload_original)//2; need(len(payload_original) > 100, 'SEALED_PAYLOAD_BOUND')
        bad = payload_original[:offset]+bytes([payload_original[offset]^1])+payload_original[offset+1:]
        artifact = dict(actualSealedCheckpointCopy=True, sourceCheckpointUntouched=True, sameByteLength=True)
        try:
            restore(payload, bad, payload_info)
            record, _ = runner.call('artifact-corrupted', common, folder, 300)
            need(record['exit'] == 1, 'ARTIFACT_CORRUPTION_NOT_REFUSED')
            artifact['firstRefusalCode'] = (record.get('result') or {}).get('error', 'UNPARSED_REFUSAL')
            artifact['qualification'] = 'ACTUAL_SEALED_PAYLOAD_BYTE_CORRUPTION_REFUSED_AT_FIRST_REPORTED_GUARD_NO_LATER_GUARD_CLAIM'
        finally: restore(payload, payload_original, payload_info)
        record, _ = runner.call('artifact-restored', common, folder, 300)
        need(record['exit'] == 0 and (record.get('result') or {}).get('status') == 'VERIFIED', 'ARTIFACT_RESTORATION')
        artifact['restoredExactBytes'] = regular(payload) == payload_original
        summary['artifactMutation'] = artifact
        final_raw = raw_snapshot(runner, source); summary['finalRaw'] = final_raw
        need(final_raw['rawTrackedBytesMatch'] and final_raw['indexSemanticSHA256'] == baseline_raw['indexSemanticSHA256'] and
            not runner.git(source, 'status', '--porcelain=v1', '--untracked-files=all') and
            runner.git(source, 'rev-parse', 'HEAD').decode().strip() == args.head, 'FINAL_RESTORED_SOURCE_IDENTITY')
        summary['objectStore'] = dict(path=str(source/'.git/objects'), device=(source/'.git/objects').stat().st_dev,
            inode=(source/'.git/objects').stat().st_ino, shallow=False, alternates=False)
        if args.other_checkout:
            other = args.other_checkout.resolve(strict=True)/'.git/objects'
            need(other.is_dir() and not os.path.samefile(source/'.git/objects', other), 'INDEPENDENT_OBJECT_STORE_REQUIRED')
            summary['separateFromOtherFinalCheckout'] = True
        summary['protectedSequence'] = [0, 1, 0]; summary['artifactSequence'] = [0, 1, 0]
        summary['cleanFinal'] = True
        summary['status'] = 'PASS_INDEPENDENT_FINAL_SOURCE_CHECKPOINT_REFUSAL_RESTORATION_NOT_ACCEPTANCE' if probe['rawHashGuardReached'] else 'PROOF_INCOMPLETE_RAW_GUARD_NOT_REACHED_FIRST'
    except BaseException as error:
        summary['status'] = 'PROOF_FAILED_NOT_ACCEPTANCE'
        summary['failure'] = error.args[0] if type(error) is ProofFailure and len(error.args) == 1 else type(error).__name__
    finally:
        summary['records'] = [dict(name=r['name'], exit=r['exit'], receipt=r['name']+'.receipt.json') for r in runner.records]
        (folder/'FINAL_CLONE_B_PROOF.json').write_text(json.dumps(summary, indent=2)+'\n')
        print(json.dumps(dict(status=summary['status'], proof=str(folder/'FINAL_CLONE_B_PROOF.json'),
            acceptanceGranted=False, release='NO_GO')), flush=True)
    return 0 if summary['status'].startswith('PASS_') else 1

if __name__ == '__main__':
    sys.exit(main())
