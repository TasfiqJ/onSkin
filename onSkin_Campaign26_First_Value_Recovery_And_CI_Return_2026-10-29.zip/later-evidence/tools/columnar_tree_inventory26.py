"""Represent the exact content-free inventory compactly without losing fields."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
raw = args.input.read_bytes()
if len(raw) > 8 * 1024 * 1024:
    raise ValueError('INPUT_BOUND')
value = json.loads(raw)
columns = ['path', 'mode', 'blob', 'bytes']
if not all(set(row) == set(columns) for row in value['files']):
    raise ValueError('EXACT_COLUMNS_REQUIRED')
result = {key: item for key, item in value.items() if key != 'files'}
result.update(representation='COLUMNAR_FILES_METADATA_SAME_INFORMATION', columns=columns,
              rows=[[row[key] for key in columns] for row in value['files']],
              sourceInventorySHA256=hashlib.sha256(raw).hexdigest())
restored = {key: item for key, item in result.items()
            if key not in {'representation', 'columns', 'rows', 'sourceInventorySHA256'}}
restored['files'] = [dict(zip(columns, row)) for row in result['rows']]
if restored != value:
    raise ValueError('ROUNDTRIP_MISMATCH')
encoded = (json.dumps(result, separators=(',', ':'), ensure_ascii=True) + '\n').encode()
if len(encoded) > 4 * 1024 * 1024:
    raise ValueError('BOUNDED_CATALOG_FILE_LIMIT')
with args.output.open('xb') as stream:
    stream.write(encoded)
print(json.dumps({'qualification': 'CONTENT_FREE_COLUMNAR_EXACT_ROUNDTRIP_NOT_ACCEPTANCE',
                  'bytes': len(encoded), 'sha256': hashlib.sha256(encoded).hexdigest(),
                  'sourceInventorySHA256': result['sourceInventorySHA256'],
                  'head': result['head'], 'tree': result['tree'], 'trackedBlobs': result['trackedBlobs'],
                  'acceptanceGranted': False, 'release': 'NO_GO'}))
