"""Copy only explicitly selected public post-tail evidence into a NEW directory.

Pending requirements must be empty. No source/checkpoint files, Git state,
outer archive or publication are changed. Selected scripts are data only.
"""
import argparse
import hashlib
import os
from pathlib import Path
import re
import stat

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
BUILD_RETURN_SHA256 = '5d43ea5cd92837623cd7c21cab624fe5d22562b6d4d7b637182915ddaeabdbdc'
OUTER_SHA256 = '2b24bf81d7d3dac652cc3cdee3ebed74f5ef9fcf3830ff1240c1da50cab17fc1'
FINAL_HEAD = '8c02a02afd7f2e9775dcc512c800d4f71f733234'
FINAL_TREE = 'ff0f76d11fa7775e27732f54ce7fdfbd51c8c676'
PACKAGING_INPUTS = {
    'FINAL_SOURCE_ANCHORS26.json', 'ROOT_TAIL_COPY_FIRST_REFUSAL.json', 'SUBSTANTIVE_FREEZE26.json',
    'checkpoint-stage-actual26.seal-receipt.json', 'PUBLICATION_PREPARATION.json',
    'final-tree-inventory26.columnar.json', 'build_return26.py', 'tree_inventory26.py',
    'columnar_tree_inventory26.py', 'prepare_posttail_evidence26.py', 'RETURN_BUILDER_REVIEW.json',
    'FINAL_PR_POLICY26.json',
}
DRIVER_INPUTS = {
    'prove_final_clone_a26.py', 'prove_final_clone_b26.py',
    'prove_final_clone_a26.initial.py', 'prove_final_clone_a26_first_attempt.py', 'prove_final_clone_b26.initial.py',
    'TOOL_FINGERPRINT_HARDLINK_DIAGNOSIS.json', 'DRIVER_A_READONLY_TOOL_CORRECTION.json',
    'DRIVER_A_PREPARATION.json', 'DRIVER_PREPARATION.json',
    'TWO_FINAL_CLONES26.json',
}


def load_guard():
    path = HERE / 'build_return26.py'
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > 1024 * 1024:
        raise ValueError('ROOT_REVIEWED_GUARD_MODE')
    raw = path.read_bytes()
    after = path.lstat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) !=
        (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) or
        hashlib.sha256(raw).hexdigest() != BUILD_RETURN_SHA256):
        raise ValueError('ROOT_REVIEWED_GUARD_IDENTITY')
    guard = {'__name__': 'posttail26_root_reviewed_guard', '__file__': str(path)}
    exec(compile(raw, str(path), 'exec'), guard)
    return guard, raw


def public_source(relative):
    if type(relative) is not str or not relative.isascii():
        return False
    parts = relative.split('/')
    if len(parts) == 2 and parts[0] == 'packaging26':
        return parts[1] in PACKAGING_INPUTS
    if len(parts) == 2 and parts[0] == 'final-proof26':
        return parts[1] in DRIVER_INPUTS
    if len(parts) == 2 and parts[0] == 'external-ci26':
        return parts[1] in {'PROCEDURE.md', 'windows-separate-grant-proposal.md', 'FINAL_REPORT.md'} or bool(re.fullmatch(r'[A-Za-z0-9_.-]+\.json', parts[1]))
    return (len(parts) == 3 and parts[0] == 'final-proof26' and
            bool(re.fullmatch(r'proof-[a-f0-9]{32}', parts[1])) and
            bool(re.fullmatch(r'[A-Za-z0-9_.-]+\.(?:json|log)', parts[2])))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--catalog', required=True, type=Path)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    guard = None
    try:
        guard, guard_raw = load_guard()
        need, read, loads = guard['need'], guard['read'], guard['strict_json']
        output = guard['outside'](args.output, new=True)
        catalog_path = guard['outside'](args.catalog, new=True)
        receipt_path = guard['outside'](args.receipt or catalog_path.with_name(catalog_path.name + '.snapshot.json'), new=True)
        need(len({output, catalog_path, receipt_path}) == 3 and
             output not in catalog_path.parents and output not in receipt_path.parents, 'OUTPUT_PATH_COLLISION')
        guard['outside'](args.selection)
        raw = read(args.selection)
        selection = loads(raw)
        need(type(selection) is dict and set(selection) == {'schema', 'qualification', 'candidateHead', 'candidateTree',
             'pendingRequirements', 'files'} and type(selection['schema']) is int and selection['schema'] == 1 and
             selection['qualification'] == 'SANITIZED_PUBLIC_POST_TAIL_SELECTION_REVIEW_REQUIRED' and
             selection['candidateHead'] == FINAL_HEAD and selection['candidateTree'] == FINAL_TREE and
             type(selection['pendingRequirements']) is list and not selection['pendingRequirements'] and
             type(selection['files']) is dict and 0 < len(selection['files']) <= 512, 'PENDING_OR_INVALID_SELECTION')
        helper_args = argparse.Namespace(verifier=HERE / 'verify_return26.py', derivation=HERE / 'DERIVATION.json',
            controls=HERE / 'CONTROLS.json', expected_verifier_sha256=OUTER_SHA256)
        _, helper, _, _, _ = guard['authenticate'](helper_args)
        helper['paths'](selection['files'])
        helper['paths'](selection['files'].values())
        need(len(set(selection['files'].values())) == len(selection['files']), 'DUPLICATE_SELECTED_SOURCE')
        payload, inputs, total, categories = {}, [], 0, set()
        for target, relative in sorted(selection['files'].items()):
            parts = helper['safe_path'](target)
            suffixes = {'.json', '.log', '.txt', '.md', '.png'}
            if parts[0] == 'tools':
                suffixes |= {'.py', '.mjs', '.ts'}
            need(target.isascii() and len(parts) == 2 and parts[0] in guard['EVIDENCE_CATEGORIES'] and
                 Path(parts[1]).suffix.lower() in suffixes and public_source(relative), 'SELECTED_PATH_REFUSED')
            helper['safe_path'](relative)
            path = RUN.joinpath(*relative.split('/'))
            guard['outside'](path)
            data = read(path)
            total += len(data)
            need(total <= guard['MAX_EVIDENCE'], 'EVIDENCE_TOTAL_BOUND')
            payload[target] = data
            inputs.append({'sourcePath': relative, 'targetPath': target, **guard['witness'](data)})
            categories.add(parts[0])
        required_tools = {'tools/prove_final_clone_a26.py', 'tools/prove_final_clone_b26.py', 'tools/build_return26.py'}
        need({'ci', 'clones', 'source-controls'} <= categories and required_tools <= set(payload), 'REQUIRED_PROOF_SELECTION_MISSING')
        need(guard['sha'](payload['tools/build_return26.py']) == BUILD_RETURN_SHA256, 'EXACT_RETURN_BUILDER_DATA_IDENTITY')
        anchors = loads(read(HERE / 'FINAL_SOURCE_ANCHORS26.json'))
        need(anchors.get('candidateHead') == FINAL_HEAD and anchors.get('candidateTree') == FINAL_TREE and
             anchors.get('acceptanceGranted') is False and anchors.get('release') == 'NO_GO', 'FINAL_ANCHOR_MISMATCH')
        map_name = 'policy/posttail-source-map.json'
        need(map_name not in payload and len(payload) < 512, 'RESERVED_SOURCE_MAP_OR_COUNT')
        payload[map_name] = guard['encode']({'schema': 1,
            'qualification': 'EXPLICIT_PUBLIC_SOURCE_TO_ARCHIVE_PATH_MAP_NOT_ACCEPTANCE',
            'candidateHead': FINAL_HEAD, 'candidateTree': FINAL_TREE, 'files': inputs,
            'acceptanceGranted': False, 'release': 'NO_GO'})
        total += len(payload[map_name])
        need(total <= guard['MAX_EVIDENCE'], 'EVIDENCE_TOTAL_BOUND')
        helper['paths'](payload)
        output.mkdir(mode=0o755)
        for directory in sorted(helper['paths'](payload), key=lambda name: (name.count('/'), name)):
            (output / directory).mkdir(mode=0o755)
        for target, data in sorted(payload.items()):
            guard['write_new'](output / target, data)
        helper['Directory'](output).exact(payload)
        catalog = {'schema': 1, 'qualification': 'SANITIZED_POST_TAIL_PROOFS_NOT_ACCEPTANCE',
            'candidateHead': FINAL_HEAD, 'candidateTree': FINAL_TREE, 'acceptanceGranted': False, 'release': 'NO_GO',
            'files': {name: guard['witness'](data) for name, data in sorted(payload.items())}}
        for item in inputs:
            need(guard['witness'](read(RUN.joinpath(*item['sourcePath'].split('/')))) ==
                 {key: item[key] for key in ('bytes', 'sha256')}, 'SELECTED_SOURCE_CHANGED')
        need(read(args.selection) == raw and read(HERE / 'build_return26.py', 1024 * 1024) == guard_raw,
             'SELECTION_OR_GUARD_CHANGED')
        guard['write_new'](catalog_path, guard['encode'](catalog))
        receipt = {'status': 'EXPLICIT_PUBLIC_POST_TAIL_EVIDENCE_STAGED_ROOT_REVIEW_REQUIRED',
            'qualification': 'FILE_INTEGRITY_AND_EXPLICIT_SELECTION_ONLY_NOT_PROOF_SEMANTICS_OR_ACCEPTANCE',
            'candidateHead': FINAL_HEAD, 'candidateTree': FINAL_TREE, 'selectionSHA256': guard['sha'](raw),
            'catalogSHA256': guard['sha'](guard['encode'](catalog)), 'files': inputs, 'count': len(inputs),
            'stagedFilesIncludingGeneratedSourceMap': len(payload), 'totalBytes': total,
            'generatedSourceMap': {'path': map_name, **guard['witness'](payload[map_name])},
            'sourceWrites': False, 'outerArchiveBuildAndPublication': 'NOT_RUN_ROOT_ONLY',
            'acceptanceGranted': False, 'release': 'NO_GO'}
        guard['write_new'](receipt_path, guard['encode'](receipt))
        print(guard['encode'](receipt).decode(), end='')
        return 0
    except BaseException as error:
        import json
        code = guard['error_code'](error) if guard else 'ROOT_REVIEWED_GUARD_INCOMPLETE'
        print(json.dumps({'status': 'POST_TAIL_EVIDENCE_REFUSED', 'error': code,
                          'sourceWrites': False, 'acceptanceGranted': False, 'release': 'NO_GO'}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
