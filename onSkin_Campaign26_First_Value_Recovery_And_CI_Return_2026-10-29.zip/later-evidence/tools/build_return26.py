"""Build a new outside-source Campaign26 return from actual final anchors.

Root executes this only after the sole evidence tail and its independent proofs.
The production CLI has no synthetic, skip-verification or publication option.
It never commits, pushes, changes source files or writes source Git objects.
"""
import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
BASE = '52a3d01ebb36a6845d0ac21935ad35520732633f'
BASE_TREE = 'ef49a81ca814f3d82b8a868e0308b6dda09c9cca'
PLAN_COMMIT = 'd970311fd0741414f9a96a15afc653f7e1cc39df'
PLAN_SHA = '6c0f5f6d4f66612551e79216e49b698fe487b9d3cefc0c3f0cf1bb30b9fbd7e7'
INPUT_SHA = '9d87a26cb84ed81c5f0deb950a919ae0899c1f8805ebea7e386eace05a7db112'
AUTHORITY = 'BRAIN-M1X-FIRST-VALUE-RECOVERY26-REPAIR-01'
SUPPLIER = '5a936900831f1cee8f413800969b34ca3253f90b585412388cf0bded333b522a'
CHECKER = 'scripts/release/full-app-j01/check.py'
CHECKPOINT_FILES = {'README.md', 'REPORT.md', 'manifest.json', 'payload.zip', 'verify26.py'}
HEX40 = re.compile(r'[0-9a-f]{40}')
HEX64 = re.compile(r'[0-9a-f]{64}')
MAX_FILE = 4 * 1024 * 1024
MAX_EVIDENCE = 24 * 1024 * 1024
MAX_ARCHIVE = 96 * 1024 * 1024
EVIDENCE_CATEGORIES = {'ci', 'clones', 'source-controls', 'artifact-controls', 'policy', 'environment', 'reports', 'tools'}


class Refusal(ValueError):
    pass


def need(ok, code):
    if not ok:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + '\n').encode('utf-8')


def witness(raw):
    return {'bytes': len(raw), 'sha256': sha(raw)}


def error_code(error):
    return (error.args[0] if len(error.args) == 1 and type(error.args[0]) is str and
            re.fullmatch(r'[A-Z][A-Z0-9_]{1,100}', error.args[0]) else 'RETURN_BUILD_INCOMPLETE')


def read(path, limit=MAX_FILE):
    """Bootstrap stable bounded regular-file read before template execution."""
    path = Path(os.path.abspath(path))
    for parent in path.parents:
        item = parent.lstat()
        need(stat.S_ISDIR(item.st_mode) and not stat.S_ISLNK(item.st_mode) and
             not getattr(item, 'st_file_attributes', 0) & 1024, 'INPUT_PARENT_LINK_OR_MODE')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and not stat.S_ISLNK(before.st_mode) and before.st_nlink == 1 and
         not getattr(before, 'st_file_attributes', 0) & 1024 and
         not before.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX) and before.st_size <= limit,
         'INPUT_FILE_MODE_OR_BOUND')
    signature = lambda item: (item.st_dev, item.st_ino, item.st_mode, item.st_nlink, item.st_size,
                              item.st_mtime_ns, item.st_ctime_ns, getattr(item, 'st_file_attributes', 0))
    descriptor = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    try:
        need(signature(os.fstat(descriptor)) == signature(before), 'INPUT_CHANGED')
        pieces, total = [], 0
        while True:
            chunk = os.read(descriptor, min(65536, limit + 1 - total))
            if not chunk:
                break
            total += len(chunk)
            need(total <= limit and total <= before.st_size, 'INPUT_CHANGED_OR_BOUND')
            pieces.append(chunk)
        need(total == before.st_size and signature(os.fstat(descriptor)) == signature(before) and
             signature(path.lstat()) == signature(before), 'INPUT_CHANGED')
        return b''.join(pieces)
    finally:
        os.close(descriptor)


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'DUPLICATE_JSON_KEY')
            result[key] = value
        return result
    def integer(value):
        need(len(value.lstrip('-')) <= 20, 'JSON_INTEGER_BOUND')
        return int(value)
    def rejected(_):
        raise Refusal('JSON_FLOAT_OR_NONFINITE')
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs, parse_int=integer,
                          parse_float=rejected, parse_constant=rejected)
    except (UnicodeError, json.JSONDecodeError, RecursionError):
        raise Refusal('JSON_INVALID') from None


def authenticate(args):
    raw = read(args.verifier, 1024 * 1024)
    need(HEX64.fullmatch(args.expected_verifier_sha256) and sha(raw) == args.expected_verifier_sha256,
         'EXTERNAL_TEMPLATE_ANCHOR')
    derivation_raw, controls_raw = read(args.derivation), read(args.controls)
    derivation, controls = strict_json(derivation_raw), strict_json(controls_raw)
    need(derivation.get('supplierVerifierSHA256') == SUPPLIER and
         derivation.get('scopePlanSHA256') == PLAN_SHA and
         derivation.get('templates', {}).get('verify_return26.py') == witness(raw), 'TEMPLATE_DERIVATION')
    need(controls.get('status') == 'PASS' and controls.get('acceptanceGranted') is False and
         controls.get('release') == 'NO_GO' and type(controls.get('positive')) is int and controls['positive'] >= 8 and
         type(controls.get('refusals')) is int and controls['refusals'] >= 60 and
         controls.get('templateDerivation', {}).get('verify_return26.py') == witness(raw), 'TEMPLATE_CONTROLS')
    wanted = {'MODE': 'return', 'BASE': BASE, 'BASE_TREE': BASE_TREE, 'PLAN_COMMIT': PLAN_COMMIT,
              'PLAN_SHA256': PLAN_SHA, 'INPUT': INPUT_SHA, 'AUTHORITY': AUTHORITY,
              'CHECKER_SHA256': derivation.get('sourceCheckerSHA256')}
    actual = {}
    for item in ast.parse(raw).body:
        if isinstance(item, ast.Assign) and len(item.targets) == 1 and isinstance(item.targets[0], ast.Name):
            if item.targets[0].id in wanted:
                actual[item.targets[0].id] = ast.literal_eval(item.value)
    need(actual == wanted and HEX64.fullmatch(wanted['CHECKER_SHA256'] or ''), 'TEMPLATE_IDENTITY')
    helper = {'__name__': 'return26_authenticated_verifier', '__file__': str(args.verifier)}
    exec(compile(raw, str(args.verifier), 'exec'), helper)
    need(read(args.verifier, 1024 * 1024) == raw, 'TEMPLATE_CHANGED')
    return raw, helper, derivation, derivation_raw, controls_raw


def outside(path, new=False, directory=False):
    path = Path(os.path.abspath(path))
    need(not new or not os.path.lexists(path), 'OUTPUT_MUST_BE_NEW')
    need(path.parent.is_dir(), 'OUTPUT_PARENT_REQUIRED')
    for parent in (path.parent, *path.parent.parents):
        info = parent.lstat()
        need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
             not getattr(info, 'st_file_attributes', 0) & 1024 and parent.name != '.git' and
             not os.path.lexists(parent / '.git'), 'OUTSIDE_SOURCE_REQUIRED')
    if directory and not new:
        info = path.lstat()
        need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode) and
             not getattr(info, 'st_file_attributes', 0) & 1024 and not os.path.lexists(path / '.git'),
             'OUTSIDE_SOURCE_REQUIRED')
    return path


def write_new(path, raw):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0) |
                         getattr(os, 'O_BINARY', 0), 0o644)
    try:
        offset = 0
        while offset < len(raw):
            count = os.write(descriptor, raw[offset:])
            need(count > 0, 'OUTPUT_WRITE_FAILED')
            offset += count
    finally:
        os.close(descriptor)
    need(read(path, MAX_ARCHIVE) == raw, 'OUTPUT_WRITE_MISMATCH')


def replace_owned_byte(path, identity, position, old, new):
    before = path.lstat()
    need((before.st_dev, before.st_ino) == identity and stat.S_ISREG(before.st_mode) and
         before.st_nlink == 1 and not getattr(before, 'st_file_attributes', 0) & 1024,
         'CONTROL_COPY_IDENTITY')
    descriptor = os.open(path, os.O_RDWR | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_BINARY', 0))
    try:
        opened = os.fstat(descriptor)
        need((opened.st_dev, opened.st_ino) == identity and opened.st_nlink == 1, 'CONTROL_COPY_IDENTITY')
        os.lseek(descriptor, position, os.SEEK_SET)
        need(os.read(descriptor, 1) == old, 'CONTROL_COPY_BYTE')
        os.lseek(descriptor, position, os.SEEK_SET)
        need(os.write(descriptor, new) == 1, 'CONTROL_COPY_WRITE')
        need((path.lstat().st_dev, path.lstat().st_ino) == identity and
             os.fstat(descriptor).st_nlink == 1, 'CONTROL_COPY_IDENTITY')
    finally:
        os.close(descriptor)


def evidence(args, helper, source):
    root = outside(args.evidence_root, directory=True)
    catalog_path = outside(args.evidence_catalog)
    need(root not in catalog_path.parents, 'CATALOG_MUST_BE_OUTSIDE_EVIDENCE_ROOT')
    raw = read(catalog_path)
    value = strict_json(raw)
    need(type(value) is dict and set(value) == {'schema', 'qualification', 'candidateHead', 'candidateTree',
         'acceptanceGranted', 'release', 'files'} and type(value['schema']) is int and value['schema'] == 1 and
         value['qualification'] == 'SANITIZED_POST_TAIL_PROOFS_NOT_ACCEPTANCE' and
         value['candidateHead'] == source['candidateHead'] and value['candidateTree'] == source['candidateTree'] and
         value['acceptanceGranted'] is False and value['release'] == 'NO_GO' and
         type(value['files']) is dict and 0 < len(value['files']) <= 512, 'LATER_CATALOG_SCHEMA')
    helper['paths'](value['files'])
    helper['Directory'](root).exact(value['files'])
    output, inputs, total, categories = {}, [], 0, set()
    for name, expected in sorted(value['files'].items()):
        parts = helper['safe_path'](name)
        suffixes = {'.json', '.log', '.txt', '.md', '.png'}
        if parts[0] == 'tools':
            suffixes |= {'.py', '.mjs', '.ts'}
        need(name.isascii() and len(parts) == 2 and parts[0] in EVIDENCE_CATEGORIES and
             Path(parts[1]).suffix.lower() in suffixes and
             type(expected) is dict and set(expected) == {'bytes', 'sha256'} and
             type(expected['bytes']) is int and 0 <= expected['bytes'] <= MAX_FILE and
             type(expected['sha256']) is str and HEX64.fullmatch(expected['sha256']), 'LATER_EVIDENCE_REFUSED')
        data = read(root.joinpath(*parts))
        need(witness(data) == expected, 'LATER_EVIDENCE_HASH')
        total += len(data)
        need(total <= MAX_EVIDENCE, 'LATER_EVIDENCE_BOUND')
        output['later-evidence/' + name] = data
        inputs.append((root.joinpath(*parts), expected))
        categories.add(parts[0])
    need({'ci', 'clones', 'source-controls'} <= categories, 'LATER_PROOF_CATEGORIES_REQUIRED')
    output['later-evidence/CATALOG_AT_SEAL.json'] = raw
    return output, inputs, raw


def stored_zip(files, helper):
    helper['paths'](files)
    need(len(files) <= 1024 and sum(map(len, files.values())) <= MAX_ARCHIVE - 1024 * 1024, 'RETURN_TOTAL_BOUND')
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_STORED, allowZip64=False) as archive:
        for name, data in sorted(files.items()):
            need(type(data) is bytes and len(data) <= MAX_ARCHIVE, 'RETURN_FILE_BOUND')
            item = zipfile.ZipInfo(name, date_time=(2026, 10, 29, 0, 0, 0))
            item.create_system = 3
            item.external_attr = 0o100644 << 16
            item.compress_type = zipfile.ZIP_STORED
            item.extra = item.comment = b''
            archive.writestr(item, data)
    raw = stream.getvalue()
    need(len(raw) <= MAX_ARCHIVE, 'RETURN_TOTAL_BOUND')
    helper['Archive'](raw).exact(files)
    return raw


def reproduce(source, cp_anchor):
    return ('''# Reproduce the Campaign26 review return

SUBMITTED_REVIEW_REQUIRED / NO_GO. All acceptance/admission gates remain closed.

Use the externally published ZIP, outer manifest and outer verifier SHA256 anchors. Authenticate actual downloaded bytes first. The actual final ZIP hash, this ZIP's corruption/restoration receipt and later public download proof are external annexes; they cannot be embedded in their own sealed bytes.

Pinned base: ''' + BASE + '\nBase tree: ' + BASE_TREE + '\nFinal candidate: ' + source['candidateHead'] +
        '\nFinal tree: ' + source['candidateTree'] + '\nCheckpoint manifest SHA256: ' + cp_anchor + '''

Run the portable outer verifier without source arguments for artifact integrity only:

```text
python -I -B verify_return26.py --archive ABSOLUTE_RETURN_ZIP --expected-manifest-sha256 EXTERNALLY_PUBLISHED_OUTER_MANIFEST_SHA256 --expected-verifier-sha256 EXTERNALLY_PUBLISHED_OUTER_VERIFIER_SHA256
```

For an independent source replay, create a new complete ordinary clone from the authentic repository with separate objects, no shallow/partial clone, alternates, shared worktree or borrowed dependency cache. Authenticate the pinned PR29 base/tree, fetch the included bundle's HEAD and check out exactly the final candidate above. Using the source task's authenticated toolchain/native-source pins, run the normal install with all mandatory lifecycle hooks and its actual postinstall check:

```text
npm ci --ignore-scripts=false --cache ABSOLUTE_NEW_EMPTY_NPM_CACHE --no-audit --no-fund
node scripts/postinstall.mjs --check
```

Then run:

```text
python -I -B verify_return26.py --archive ABSOLUTE_RETURN_ZIP --expected-manifest-sha256 EXTERNALLY_PUBLISHED_OUTER_MANIFEST_SHA256 --expected-verifier-sha256 EXTERNALLY_PUBLISHED_OUTER_VERIFIER_SHA256 --git-root ABSOLUTE_COMPLETE_FINAL_CLONE --expected-head ''' +
        source['candidateHead'] + ' --expected-tree ' + source['candidateTree'] + ''' --execute-source-checks
```

The full verifier checks actual raw tracked blobs/index/modes, full object hashes, exact finite history, original unchanged Phase4 producer/strict worklists, current Release26 source checker, checkpoint copy, exact minimal bundle object set and authenticated path-history. Artifact-only VERIFIED does not replace those checks. A temporary PACK parser may use documented baseline alternates; it is not an independent checkout and never writes the delivered source object's store.

The immutable checkpoint REPORT is the pre-tail snapshot. FINAL_REPORT and explicitly cataloged later-evidence carry the later observations, preserving actual failures, skips and qualifications. Inspect those receipts and the separate actual ZIP 0/1/0/public-download annex before making any review decision. No signed native/device, provider, database, Security, professional or public release acceptance follows from this archive.
''').encode('utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('git-root', 'checkpoint', 'report', 'evidence-root', 'evidence-catalog', 'output', 'archive'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('candidate-head', 'candidate-tree', 'expected-checkpoint-manifest-sha256',
                 'expected-checkpoint-verifier-sha256', 'expected-verifier-sha256'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--verifier', type=Path, default=HERE / 'verify_return26.py')
    parser.add_argument('--derivation', type=Path, default=HERE / 'DERIVATION.json')
    parser.add_argument('--controls', type=Path, default=HERE / 'CONTROLS.json')
    parser.add_argument('--receipt', type=Path, help='NEW external receipt; defaults to ARCHIVE.receipt.json.')
    args = parser.parse_args()
    failure_detail = {}
    try:
        need(sys.flags.optimize == 0, 'OPTIMIZED_PYTHON_REFUSED')
        builder_raw = read(Path(__file__), 1024 * 1024)
        verifier, helper, derivation, derivation_raw, controls_raw = authenticate(args)
        output, archive = outside(args.output, new=True), outside(args.archive, new=True)
        receipt_path = outside(args.receipt or archive.with_name(archive.name + '.receipt.json'), new=True)
        control_copy = outside(archive.with_name(archive.name + '.corruption-control-copy'), new=True)
        need(len({output, archive, receipt_path, control_copy}) == 4 and
             all(output not in path.parents for path in (archive, receipt_path, control_copy)), 'OUTPUT_PATH_COLLISION')
        need(HEX40.fullmatch(args.candidate_head) and HEX40.fullmatch(args.candidate_tree) and
             HEX64.fullmatch(args.expected_checkpoint_manifest_sha256) and
             HEX64.fullmatch(args.expected_checkpoint_verifier_sha256), 'EXTERNAL_FINAL_ANCHORS')
        cp_path = Path(os.path.abspath(args.checkpoint))
        evidence_root = Path(os.path.abspath(args.evidence_root))
        temporary_root = outside(Path(tempfile.gettempdir()), directory=True)
        need(cp_path not in temporary_root.parents and evidence_root not in temporary_root.parents and
             temporary_root not in (cp_path, evidence_root), 'TEMPORARY_PARSER_INPUT_OVERLAP')
        need(all(cp_path not in path.parents and evidence_root not in path.parents and
                 path not in (cp_path, evidence_root) for path in (output, archive, receipt_path, control_copy)),
             'OUTPUT_INPUT_OVERLAP')
        cp = helper['Directory'](cp_path)
        cp.exact(CHECKPOINT_FILES)
        cp_value = helper['checkpoint'](cp, args.expected_checkpoint_manifest_sha256)
        cp_files = {name: read(cp_path / name, MAX_ARCHIVE) for name in CHECKPOINT_FILES}
        need(sha(cp_files['verify26.py']) == args.expected_checkpoint_verifier_sha256 and
             cp_files['verify26.py'] == verifier.replace(b"MODE = 'return'", b"MODE = 'checkpoint'", 1),
             'CHECKPOINT_VERIFIER_IDENTITY')
        source = {**cp_value['source'], 'candidateHead': args.candidate_head, 'candidateTree': args.candidate_tree}
        root = Path(os.path.abspath(args.git_root))
        need(helper['git'](root, 'rev-parse', 'HEAD').decode().strip() == args.candidate_head and
             helper['git'](root, 'rev-parse', 'HEAD^{tree}').decode().strip() == args.candidate_tree,
             'FINAL_SOURCE_IDENTITY')
        before = helper['verify_git'](root, source, cp)
        need(sha(read(root / CHECKER, 1024 * 1024)) == derivation['sourceCheckerSHA256'], 'CURRENT_CHECKER_TEMPLATE_PIN')
        history = helper['git_history'](root, source)
        later, later_inputs, catalog_raw = evidence(args, helper, source)
        outside(args.report)
        report = read(args.report, 512 * 1024)
        need(b'SUBMITTED_REVIEW_REQUIRED' in report and b'NO_GO' in report and
             args.candidate_head.encode() in report and args.candidate_tree.encode() in report,
             'FINAL_REPORT_IDENTITIES_OR_QUALIFICATION')
        output.mkdir(mode=0o755)
        bundle_path = output / 'source.delta.bundle'
        helper['git'](root, 'bundle', 'create', '--version=2', str(bundle_path), 'HEAD', '^' + BASE,
                      overrides=('pack.threads=1',))
        bundle = read(bundle_path, MAX_ARCHIVE)
        need(helper['git'](root, 'bundle', 'list-heads', str(bundle_path)).decode().splitlines() ==
             [args.candidate_head + ' HEAD'], 'BUNDLE_ADVERTISED_HEAD')
        helper['git'](root, 'bundle', 'verify', str(bundle_path))
        header, separator, body = bundle.partition(b'\n\n')
        need(separator and header.startswith(b'# v2 git bundle\n') and
             [line[1:41].decode('ascii') for line in header.splitlines()[1:] if line.startswith(b'-')] == [BASE],
             'BUNDLE_EXACT_PR29_PREREQUISITE')
        delta = helper['verify_delta_pack'](root, body, args.candidate_head)
        files = {'checkpoint/' + name: data for name, data in cp_files.items()}
        files.update(later)
        files.update({'FINAL_REPORT.md': report, 'REPRODUCE.md': reproduce(source, args.expected_checkpoint_manifest_sha256),
                      'verify_return26.py': verifier, 'source.delta.bundle': bundle, 'path-history.json': encode(history)})
        files['PACKAGING_PROVENANCE.json'] = encode({'qualification': 'ACTUAL_FINAL_GIT_AND_ARTIFACT_PACKAGING_NOT_ACCEPTANCE',
            'source': source, 'builderSHA256': sha(builder_raw), 'finalGitValidation': before,
            'bundleDelta': delta, 'laterEvidenceCatalogSHA256': sha(catalog_raw), 'sourceWrites': False,
            'phase4AndReleaseSourceExecution': 'NOT_RUN_BY_BUILDER_SEE_INDEPENDENT_CLONE_RECEIPTS',
            'actualFinalOuterZIPControlsAndDownloadProof': 'EXTERNAL_AFTER_THIS_SEAL_NO_CIRCULAR_HASH',
            'acceptanceGranted': False, 'release': 'NO_GO'})
        manifest = {'schema': 1, 'authority': AUTHORITY, 'status': 'SUBMITTED_REVIEW_REQUIRED',
            'acceptanceGranted': False, 'release': 'NO_GO', 'inputManifestSHA256': INPUT_SHA, 'source': source,
            'qualification': 'SANITIZED_REVIEW_RETURN_NOT_ACCEPTANCE',
            'checkpoint': {'path': 'checkpoint', 'manifestSHA256': args.expected_checkpoint_manifest_sha256},
            'gitDelta': {'path': 'source.delta.bundle', 'base': BASE, 'baseTree': BASE_TREE,
                         'head': args.candidate_head, 'tree': args.candidate_tree},
            'gitHistory': {'path': 'path-history.json'},
            'files': {name: witness(data) for name, data in sorted(files.items())}}
        files['manifest.json'] = encode(manifest)
        for directory in sorted(helper['paths'](files), key=lambda item: (item.count('/'), item)):
            (output / directory).mkdir(mode=0o755)
        for name, data in sorted(files.items()):
            if name != 'source.delta.bundle':
                write_new(output / name, data)
        helper['Directory'](output).exact(files)
        raw = stored_zip(files, helper)
        write_new(archive, raw)
        anchor = sha(files['manifest.json'])
        environment = {key: value for key, value in os.environ.items()
            if not key.upper().startswith(('GIT_', 'GITHUB_', 'PYTHON', 'NPM_')) and
            key.upper() not in ('NODE_OPTIONS', 'NODE_PATH', 'NODE_AUTH_TOKEN')}
        def verify(path, expected):
            command = [sys.executable, '-I', '-B', str(output / 'verify_return26.py'), '--archive', str(path),
                       '--expected-manifest-sha256', anchor, '--expected-verifier-sha256', sha(verifier)]
            code, stdout, stderr = helper['bounded'](command, output.parent, environment, 1024 * 1024, 120)
            result = strict_json(stdout)
            need(code == expected and not stderr and result.get('acceptanceGranted') is False and
                 result.get('release') == 'NO_GO', 'ACTUAL_ARTIFACT_CONTROL_FAILED')
            if expected == 0:
                need(result.get('status') == 'VERIFIED' and 'git' not in result and
                     result.get('sourceChecks') == {'state': 'NOT_RUN'}, 'ARTIFACT_ONLY_RESULT')
            else:
                need(result.get('status') == 'CONTEXT_INVALID' and type(result.get('error')) is str,
                     'CORRUPTION_NOT_REFUSED')
            return {'exit': code, 'result': result, 'stdoutSHA256': sha(stdout)}
        controls = [verify(archive, 0)]
        write_new(control_copy, raw)
        info = control_copy.lstat()
        control_identity = (info.st_dev, info.st_ino)
        with zipfile.ZipFile(io.BytesIO(raw)) as reader:
            item = reader.getinfo('FINAL_REPORT.md')
            position = item.header_offset + 30 + len(item.filename.encode('ascii')) + len(item.extra) + item.file_size // 2
        corrupt = bytearray(raw)
        corrupt[position] ^= 1
        original_error = None
        try:
            replace_owned_byte(control_copy, control_identity, position, raw[position:position + 1],
                               bytes(corrupt[position:position + 1]))
            need(read(control_copy, MAX_ARCHIVE) == bytes(corrupt) and read(archive, MAX_ARCHIVE) == raw,
                 'ACTUAL_CORRUPTION_COPY_MISMATCH')
            controls.append(verify(control_copy, 1))
        except BaseException as error:
            original_error = error
            failure_detail['firstArtifactControlFailure'] = error_code(error)
        finally:
            try:
                current = read(control_copy, MAX_ARCHIVE)
                if current != raw:
                    replace_owned_byte(control_copy, control_identity, position, current[position:position + 1],
                                       raw[position:position + 1])
                need(read(control_copy, MAX_ARCHIVE) == raw, 'EXACT_RESTORATION_FAILED')
                failure_detail['controlCopyRestoration'] = 'EXACT_ORIGINAL_BYTES_RESTORED'
            except BaseException as error:
                failure_detail['controlCopyRestoration'] = 'FAILED'
                failure_detail['controlCopyRestorationError'] = error_code(error)
                if original_error is None:
                    original_error = error
        if original_error is not None:
            raise original_error
        controls.append(verify(control_copy, 0))
        for path, expected in later_inputs:
            need(witness(read(path)) == expected, 'LATER_EVIDENCE_CHANGED_DURING_SEAL')
        need(read(args.evidence_catalog) == catalog_raw and read(args.report, 512 * 1024) == report and
             read(args.verifier, 1024 * 1024) == verifier and read(args.derivation) == derivation_raw and
             read(args.controls) == controls_raw and read(Path(__file__), 1024 * 1024) == builder_raw,
             'SEAL_INPUT_CHANGED')
        need(all(read(cp_path / name, MAX_ARCHIVE) == data for name, data in cp_files.items()) and
             helper['verify_git'](root, source, cp) == before and helper['git_history'](root, source) == history,
             'SOURCE_OR_CHECKPOINT_CHANGED_DURING_SEAL')
        cp.exact(CHECKPOINT_FILES)
        helper['Directory'](evidence_root).exact(strict_json(catalog_raw)['files'])
        need(all(read(output / name, MAX_ARCHIVE) == data for name, data in files.items()) and
             read(archive, MAX_ARCHIVE) == raw, 'SEALED_BYTES_CHANGED')
        helper['Directory'](output).exact(files)
        receipt = {'status': 'SEALED_RETURN_ARTIFACT_VERIFIED_ROOT_PUBLICATION_REVIEW_REQUIRED',
            'qualification': 'ACTUAL_FINAL_GIT_AND_ARTIFACT_CONTROLS_NOT_ACCEPTANCE', 'source': source,
            'stagingDirectory': str(output), 'archive': str(archive), 'archiveWitness': witness(raw),
            'manifestSHA256': anchor, 'verifierSHA256': sha(verifier),
            'checkpointManifestSHA256': args.expected_checkpoint_manifest_sha256,
            'checkpointVerifierSHA256': args.expected_checkpoint_verifier_sha256,
            'filesIncludingManifest': len(files), 'standaloneArtifactControls': controls,
            'actualArtifactExits': [row['exit'] for row in controls],
            'corruptionControl': {'qualification': 'ONE_ACTUAL_SEALED_ZIP_COPY_BYTE_NO_MANIFEST_OR_CRC_REGENERATION',
                'copy': str(control_copy), 'byteOffset': position, 'firstRefusal': controls[1]['result']['error'],
                'originalAndRestoredSHA256': sha(raw), 'corruptedSHA256': sha(bytes(corrupt))},
            'sourceWrites': False, 'publicationAndIndependentDownloadedByteProof': 'NOT_RUN_EXTERNAL_ANNEX_REQUIRED',
            'acceptanceGranted': False, 'release': 'NO_GO'}
        write_new(receipt_path, encode(receipt))
        print(json.dumps(receipt, sort_keys=True))
        return 0
    except BaseException as error:
        print(json.dumps({'status': 'RETURN_BUILD_REFUSED', 'error': error_code(error),
                          'failureDetail': failure_detail, 'sourceWrites': False,
                          'acceptanceGranted': False, 'release': 'NO_GO'}, sort_keys=True))
        return 1


if __name__ == '__main__':
    sys.exit(main())
