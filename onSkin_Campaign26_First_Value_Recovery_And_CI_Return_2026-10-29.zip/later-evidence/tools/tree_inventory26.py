"""Content-free complete Git tree metadata for the independently verified head."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def build(root, expected_head):
    def git(*args):
        return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root)
    head = git('rev-parse', 'HEAD').decode().strip()
    if head != expected_head:
        raise ValueError('EXACT_HEAD_REQUIRED')
    rows = []
    raw = git('ls-tree', '-r', '-l', '-z', '--full-tree', head)
    for record in raw.split(b'\0'):
        if not record:
            continue
        metadata, name = record.split(b'\t', 1)
        mode, kind, blob, size = metadata.decode('ascii').split()
        if kind != 'blob' or mode not in ('100644', '100755'):
            raise ValueError('REGULAR_TRACKED_SOURCE_REQUIRED')
        rows.append(dict(path=name.decode('utf-8'), mode=mode, blob=blob, bytes=int(size)))
    if git('rev-parse', 'HEAD').decode().strip() != head:
        raise ValueError('HEAD_CHANGED')
    return dict(schema=1, qualification='COMPLETE_PUBLIC_GIT_TREE_METADATA_NOT_ACCEPTANCE',
                head=head, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
                trackedBlobs=len(rows), totalTrackedBlobBytes=sum(row['bytes'] for row in rows),
                lsTreeSHA256=hashlib.sha256(raw).hexdigest(), files=rows,
                protectedWorkingContent='NOT_EXPORTED;INDEPENDENT_VERIFIERS_HASH_ALL_TRACKED_BYTES_LOCALLY',
                acceptanceGranted=False, release='NO_GO')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--git-root', required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    value = build(args.git_root, args.expected_head)
    with Path(args.output).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    print(json.dumps({key: value[key] for key in ('head', 'tree', 'trackedBlobs', 'totalTrackedBlobBytes', 'lsTreeSHA256', 'release')}))
